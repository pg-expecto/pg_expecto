#!/bin/sh
#get_iostat_info.sh

#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
		
    exit $ecode
fi
}


script=$(readlink -f $0)
current_path=`dirname $script`
timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")


performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

LOG_FILE=$current_path'/get_iostat_info.log'
ERR_FILE=$current_path'/get_iostat_info.err'
SOURCE_FILE=$current_path'/iostat.log'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - STARTED ' > $LOG_FILE

line_start=`grep -n "Device" $SOURCE_FILE | cut -d: -f1 | tail -1 `
echo "line_start="$line_start

let line_counter=1
while string= read -r line 
do 
	size=${#line}
	
    if [ "$size" == 0 ] && [ "$line_counter" -ge "$line_start" ];
    then
        break
    fi

	
	if [ "$line_counter" -le "$line_start" ];
	then 
		let line_counter=line_counter+1
		continue;
	fi 
	
	
	
    dev_string=`echo $line | sed -e "s/[[:space:]]\+/ /g" | sed 's/^[[:space:]]*//'`
    echo "DEVICE STRING = "$dev_string 	  
    psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -Aqtc "select os_stat_iostat_device( '$dev_string' )"  2>$ERR_FILE
    exit_code $? $LOG_FILE $ERR_FILE

let line_counter=line_counter+1
done < $SOURCE_FILE

#echo 'line_counter='$line_counter
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - FINISHED ' >> $LOG_FILE

exit 0 
