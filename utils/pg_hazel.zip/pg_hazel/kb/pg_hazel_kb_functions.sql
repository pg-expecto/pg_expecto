﻿-- pg_hazel_kb_functions.sql
-- version 81.2
-- mkdir /postgres/scripts/tester/kb
-- cd /postgres/scripts/tester/kb
-- psql -d performance_monitoring_db -U performance_monitoring_user -f pg_hazel_kb_functions.sql
-- psql -d performance_monitoring_db -U performance_monitoring_user -Atqc "select get_advice_for_wait_event('extend')" > /tmp/test1.html
-------------------------------------------------------------------------------------


--
CREATE OR REPLACE FUNCTION get_advice_for_wait_event( curr_wait_event text ) RETURNS text AS $$
DECLARE 
wait_event_knowledge_base_rec record ;
request_text text ;
BEGIN
SELECT * 
INTO wait_event_knowledge_base_rec
FROM wait_event_knowledge_base
WHERE wait_event = curr_wait_event ; 

IF wait_event_knowledge_base_rec.optimization_advice IS NULL 
THEN 
request_text='NEW';
return request_text;
END IF ;


return wait_event_knowledge_base_rec.optimization_advice ;
END
$$ LANGUAGE plpgsql ;
