#!/bin/sh
# pg_hazel_kb_install.sh 
# version 80.0
# mkdir /postgres/scripts/tester/kb
# cd /postgres/scripts/tester/kb
# rm pg_hazel_kb_install.sh
# vi pg_hazel_kb_install.sh
# chmod 755 pg_hazel_kb_install.sh



#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}


script=$(readlink -f $0)
current_path=`dirname $script`

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

LOG_FILE=$current_path'/pg_hazel_kb_install.log'
ERR_FILE=$current_path'/pg_hazel_kb_install.err'


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - STARTED' >> $LOG_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_fill' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_fill' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/kb/pg_hazel_kb_fill.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_functions' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/kb/pg_hazel_kb_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - FINISHED' >> $LOG_FILE

exit 0 