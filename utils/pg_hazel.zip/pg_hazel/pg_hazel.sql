﻿-- pg_hazel.sql
-- version 14.0

-- Корневая функция - сбор статистических данных 
CREATE OR REPLACE FUNCTION pg_hazel( ) RETURNS integer AS $$
DECLARE
  timepoint timestamptz ;
  is_paused_now integer ;
  
  curr_day_for_store integer ;
  pgh_stat_cluster_rec record ;
  benchmark_stats_rec record ;
  pg_hazel_result text ; 
  benchmark_result text ;
  
  cpi DOUBLE PRECISION;  
  current_test_queryid bigint ;
  current_benchmark_queryid bigint ;
  
  benchmark_median_time_short DOUBLE PRECISION ;
  benchmark_median_time_long DOUBLE PRECISION ;
  
  current_stat_db_rec record ; 
  current_stat_statement_rec record ; 
  
 current_dbid_userid_rec  record  ;

 start_timestamp timestamp with time zone ;
 finish_timestamp timestamp with time zone ;  
 
BEGIN
	--SELECT clock_timestamp() 
	--INTO start_timestamp ;


	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP )
	INTO timepoint;
	

	----------------------------------------
	-- СОБРАТЬ СТАТИСТИКУ ПО КЛАСТЕРУ	
	SELECT * 
	INTO pgh_stat_cluster_rec 
	FROM pgh_stat_cluster_analysis
	WHERE curr_timestamp = timepoint ;
	-- СОБРАТЬ СТАТИСТИКУ ПО КЛАСТЕРУ	
	----------------------------------------

	-----------------------------------------------------------------------------
	-- СФОРМИРОВАТЬ СНИМКИ ДЛЯ ЧЕРНОГО ЯЩИКА
		
	--Снимок activity
	TRUNCATE TABLE activity_snapshot;
	INSERT INTO activity_snapshot 
	( 
		datid             ,                     
		datname           ,                    
		pid                                ,
		usesysid                               ,
		usename                               ,
		application_name                      ,
		client_addr                           ,
		client_hostname                       ,
		client_port                        ,
		backend_start     ,
		xact_start        ,
		query_start       ,
		state_change      ,
		wait_event_type                       ,
		wait_event                            ,
		state                                 ,
		backend_xid                            ,
		backend_xmin                           ,
		query                                 ,
		backend_type                          ,
		blocking_pids	   
	)
	SELECT 
		datid             ,                     
		datname           ,                    
		pid                                ,
		usesysid                               ,
		usename                               ,
		application_name                      ,
		client_addr                           ,
		client_hostname                       ,
		client_port                        ,
		backend_start     ,
		xact_start        ,
		query_start       ,
		state_change      ,
		wait_event_type                       ,
		wait_event                            ,
		state                                 ,
		backend_xid                            ,
		backend_xmin                           ,
		query                                 ,
		backend_type                          ,
		pg_blocking_pids(pid)
	FROM 
		pg_stat_activity;
	--Снимок activity
	------------------------------------------

	------------------------------------------
	--Снимое locks
	TRUNCATE TABLE locks_snapshot;
	INSERT INTO locks_snapshot
	(
		w_pid ,
		w_mode, 
		b_pid ,
		b_mode , 
		w_locktype ,
		w_database ,
		w_relation ,
		w_page  ,
		w_tuple  ,
		w_virtualxid ,
		w_transactionid , 
		w_classid   , 
		w_objid    , 
		w_objsubid  ,
		w_virtualtransaction  ,   
		b_virtualtransaction ,   
		b_fastpath 
	) 
	WITH waiter AS
	(
		SELECT * FROM pg_locks WHERE not granted 
	) ,
	blocker AS
	(
		SELECT * FROM pg_locks WHERE granted 
	)
	SELECT DISTINCT
		w.pid ,
		w.mode, 
		b.pid ,
		b.mode, 
		w.locktype  ,
		w.database,
		w.relation,
		w.page ,
		w.tuple,
		w.virtualxid ,
		w.transactionid , 
		w.classid  , 
		w.objid , 
		w.objsubid,
		w.virtualtransaction,   
		b.virtualtransaction,   
		b.fastpath 
	FROM 
	waiter w JOIN blocker b ON 
			( w.database = b.database OR 
			w.relation = b.relation OR 
			w.page = b.page OR 
			w.tuple = b.tuple OR 
			w.virtualxid = b.virtualxid OR  
			w.transactionid = b.transactionid OR
			w.classid = b.classid OR
			w.objid = b.objid OR
			w.objsubid = b.objsubid ) ;
	
	--Снимок locks
	-- СФОРМИРОВАТЬ СНИМКИ ДЛЯ ЧЕРНОГО ЯЩИКА
	-----------------------------------------------------------------------------
	return 0 ; 
END
$$ LANGUAGE plpgsql;



