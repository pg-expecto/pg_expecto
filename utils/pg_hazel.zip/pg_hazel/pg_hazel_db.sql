-- pg_hazel_db.sql
-- version 1.0
DROP DATABASE IF EXISTS performance_monitoring_db WITH (FORCE) ; 
DROP ROLE IF EXISTS performance_monitoring_user;

--Роль-владелец статистических данных 
CREATE USER performance_monitoring_user PASSWORD '144513122024$Uimap!#1534567890';
GRANT pg_read_all_stats TO performance_monitoring_user;


--БД для хранения статистических данных 
CREATE DATABASE performance_monitoring_db WITH OWNER performance_monitoring_user ; 

