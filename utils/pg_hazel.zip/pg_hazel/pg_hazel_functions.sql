﻿-- pg_hazel_functions.sql
-- version 81.4
-------------------------------------------------------------------------------------
-- Базовые функции
-- default_configuration() Установить базовую конфигурацию
-- get_current_configuration() Получить текущую конфигурацию
-- set_day_for_store Установить глубину хранения
-- get_day_for_store Получить глубину хранения
-- set_24_7_flag() Установить флаг 24х7
-- unset_24_7_flag() Опустить флаг 24х7

-- cleaning() Удалить старые данные из статистических таблиц
-- get_dbname( current_index integer ) получить имя БД 
-- get_test_dbname_count( ) всего БД по которым проведен корреляционный анализ
-- get_test_dbname( current_index integer ) всего БД по которым проведен корреляционный анализ
-- get_correlation_queryid_count( ) счетчик queryid всего по которым проведен корреляционный анализ


-- is_need_new_pgpro_pwr_snapshot() Если нужно сделать новый снимок pgpro_pwr

-- log_sql_statistics_timestamp() зафиксировать время сбора статистики SQL 
-- get_sql_statistics_timestamp() получить время сбора статистики SQL  


-- stats_paused() Остановить сбор статистики 
-- stats_resume() Возобновить сбор статистики
-- has_stats_paused() Остановлен ли сбор статистики 
-- set_sql_statemets_stat_workers Установить количество воркеров для stat_statements 
-- get_sql_statemets_stat_workers Получить  количество воркеров для stat_statements из конфигурации
-- get_working_statemets_stat_workers() Получить количество работающих воркеров stat_statements
-- save_pgpro_pwr_samples( curr_timestamp text ) Добавить снимок pgpro_pwr





--------------------------------------------------------------------------------
-- Установить базовую конфигурацию
CREATE OR REPLACE FUNCTION default_configuration() RETURNS integer AS $$
DECLARE 
 configuration_rec record ;
BEGIN
	SELECT *
	INTO configuration_rec
	FROM  configuration ; 
	
	TRUNCATE TABLE configuration ; 
	
	INSERT INTO  configuration (curr_description  ) VALUES ( 'default_configuration'  ) ; 
	
	return 0 ;
END
$$ LANGUAGE plpgsql ;

-- Получить текущую конфигурацию
CREATE OR REPLACE FUNCTION get_current_configuration()  RETURNS TABLE
(
  current_description text , 
  current_version integer  ,
  current_timpoint timestamp with time zone ,
  current_is_24_7 boolean  ,
  current_day_for_store integer   
)
 AS $$
DECLARE 
 configuration_rec record ;
BEGIN
	RETURN QUERY 
	SELECT 
		curr_description , 
		curr_version   ,
		curr_timestamp ,
		is_24_7   ,
		day_for_store   		
	FROM  configuration 
	WHERE curr_version = (SELECT MAX(curr_version) FROM configuration ); 
END
$$ LANGUAGE plpgsql ;


--------------------------------------------------------------------------------
-- Установить глубину хранения
CREATE OR REPLACE FUNCTION set_day_for_store( new_counter integer ) RETURNS integer AS $$
DECLARE 
 configuration_rec record ;
BEGIN
	SELECT *
	INTO configuration_rec
	FROM  get_current_configuration() 	; 
	
	INSERT INTO  configuration 
	( 
		curr_description  , 				
		day_for_store  ,
		is_24_7   
	) 
	VALUES 
	( 
		'set_day_for_store = '||new_counter , 
		new_counter , 
		configuration_rec.current_is_24_7   
	) ; 
	
	return 0 ;
END
$$ LANGUAGE plpgsql ;

--------------------------------------------------------------------------------
-- Установить количество воркеров для stat_statements 
CREATE OR REPLACE FUNCTION set_sql_statemets_stat_workers( new_counter integer ) RETURNS integer AS $$
BEGIN
	UPDATE  configuration 
	SET sql_statemets_stat_workers = new_counter ;
	
	return 0 ;
END
$$ LANGUAGE plpgsql ;

--------------------------------------------------------------------------------
-- Получить  количество воркеров для stat_statements 
CREATE OR REPLACE FUNCTION get_sql_statemets_stat_workers() RETURNS integer AS $$
DECLARE 
 stat_workers integer  ;
BEGIN
	SELECT sql_statemets_stat_workers
	INTO stat_workers 
	FROM configuration ;
	
	
	return stat_workers ;
END
$$ LANGUAGE plpgsql ;

-- Получить глубину хранения
CREATE OR REPLACE FUNCTION get_day_for_store() RETURNS integer AS $$
DECLARE 
 configuration_rec record ;
BEGIN
	SELECT *
	INTO configuration_rec
	FROM  get_current_configuration() 	; 
	
RAISE NOTICE 'configuration_rec = % ', configuration_rec;	

	return configuration_rec.current_day_for_store ;
END
$$ LANGUAGE plpgsql ;


--------------------------------------------------------------------------------
-- Установить флаг 24х7
CREATE OR REPLACE FUNCTION set_24_7_flag() RETURNS integer AS $$
DECLARE 
 configuration_rec record ;
BEGIN
	SELECT *
	INTO configuration_rec
	FROM  get_current_configuration() 	; 
	
	INSERT INTO  configuration 
	( 
		curr_description  ,
		is_24_7 ,
		
		day_for_store  
	) 
	VALUES 
	( 
		'set 24_7_flag ', 
		TRUE , 
		
		configuration_rec.current_day_for_store 
	) ; 
	
	
	return 0 ;
END
$$ LANGUAGE plpgsql ;

--------------------------------------------------------------------------------
-- Опустить флаг 24х7
CREATE OR REPLACE FUNCTION unset_24_7_flag() RETURNS integer AS $$
DECLARE 
 configuration_rec record ;
BEGIN
	SELECT *
	INTO configuration_rec
	FROM  get_current_configuration() 	; 
	
	INSERT INTO  configuration 
	( 
		curr_description  ,
		is_24_7 ,
		
		day_for_store  
	) 
	VALUES 
	( 
		'unset 24_7_flag ', 
		FALSE , 
		
		configuration_rec.current_day_for_store 
	) ; 

	return 0 ;
END
$$ LANGUAGE plpgsql ;


-- Удалить старые данные из статистических таблиц
CREATE OR REPLACE FUNCTION cleaning() RETURNS integer AS $$
DECLARE 
 current_day_for_store integer ;
 current_day_for_store_performance_stats integer ;
 is_prepare_stat integer ; -- если prepare_stat_statement_analysis
 last_timepoint timestamp with time zone ;
BEGIN

    SELECT 	count(pid) 
	INTO 	is_prepare_stat
	FROM 	pg_stat_activity 
	WHERE 	query like '%prepare_stat_statement_analysis%'  AND pid != pg_backend_pid();
	
	RAISE NOTICE 'is_prepare_stat = % ',is_prepare_stat;
	
	IF is_prepare_stat != 0 
	THEN 
		RAISE NOTICE '! prepare_stat_statement_analysis is in progress ! ';
		return 0 ;
	END IF;
	
		
	SELECT get_day_for_store()
	INTO current_day_for_store ;
	
	SELECT day_for_store_performance_stats
	INTO current_day_for_store_performance_stats
	FROM 	configuration;
	

RAISE NOTICE 'current_day_for_store = % ', current_day_for_store;
	
	---------------------------------------------------------
	--УДАЛИТЬ СТАРУЮ СТАТИСТИКУ
	SELECT 
		MIN(curr_timestamp) 
	INTO 
		last_timepoint
	FROM 
		pgh_stat_cluster_analysis ;
    DELETE FROM pgh_stat_cluster WHERE curr_timestamp < last_timepoint;
	DELETE FROM pgh_stat_cluster_analysis WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));

	
	DELETE FROM stat_statement WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	DELETE FROM pgpro_pwr_samples WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	
	--78.0
	/*
	--Очистка перенесена в prepare_stats_for_period (deferred_strategy.sql)
	DELETE FROM stat_statement_analysis WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	DELETE FROM stat_statement_wait_events WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	DELETE FROM stat_statement_wait_events_analysis WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	*/
	--78.0
	

	
	DELETE FROM stat_timer_history WHERE curr_timestamp < CURRENT_TIMESTAMP - ( interval '1 hour'  );
	DELETE FROM stat_timer_statistics_short WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	DELETE FROM stat_timer_statistics_long WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	
	DELETE FROM sql_stats_history WHERE timepoint < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	--УДАЛИТЬ СТАРУЮ СТАТИСТИКУ
	
	--УДАЛИТЬ СТАРУЮ СТАТИСТИКУ ИНЦИДЕНТОВ ПРОИЗВОДИТЕЛЬНОСТИ
	DELETE FROM performance_incident WHERE start_timepoint < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));	
	--УДАЛИТЬ СТАРУЮ СТАТИСТИКУ ИНЦИДЕНТОВ ПРОИЗВОДИТЕЛЬНОСТИ
    --44.0
	---------------------------------------------------------
	
	
	
	---------------------------------------------------------
	-- УДАЛИТЬ СТАРУЮ СТАТИСТИКУ ОС
	DELETE FROM os_stat_vmstat WHERE curr_timestamp < CURRENT_TIMESTAMP - ( interval '1 hour'  );
	DELETE FROM os_stat_vmstat_analysis WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	
	DELETE FROM os_stat_iostat_cpu WHERE curr_timestamp < CURRENT_TIMESTAMP - ( interval '1 hour'  );
	DELETE FROM os_stat_iostat_cpu_analysis WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	
	DELETE FROM os_stat_iostat_device WHERE curr_timestamp < CURRENT_TIMESTAMP - ( interval '1 hour'  );
	DELETE FROM os_stat_iostat_device_analysis WHERE curr_timestamp < CURRENT_TIMESTAMP - (( interval '1 day' * current_day_for_store_performance_stats ) + ( interval '1 day' * current_day_for_store ));
	
	-- УДАЛИТЬ СТАРУЮ СТАТИСТИКУ ОС
	---------------------------------------------------------

	return 0 ;
END
$$ LANGUAGE plpgsql ;



CREATE OR REPLACE FUNCTION get_dbname( current_index integer ) RETURNS text AS $$
DECLARE
 pg_database_rec record ;
BEGIN
	SELECT datname , oid 
	INTO pg_database_rec
	FROM pg_database 
	ORDER BY datname 
	LIMIT 1 
	OFFSET current_index;

RAISE NOTICE '%' ,length( pg_database_rec.datname );
		
	IF length( pg_database_rec.datname ) IS NOT NULL 
	THEN 			
		return pg_database_rec.datname ;
	ELSE
		return 'NODB' ;
	END IF ;
END
$$ LANGUAGE plpgsql ;

-- get_test_dbname_count( ) всего БД по которым проведен корреляционный анализ
CREATE OR REPLACE FUNCTION get_test_dbname_count() RETURNS integer  AS $$
DECLARE
 counter  integer  ;
BEGIN
	SELECT count(*) 
	INTO counter
	FROM db_correlation_analysis ; 
	
	IF counter > 0 
	THEN 	
		return counter ; 
	ELSE 
		return -1 ;
	END IF;
END
$$ LANGUAGE plpgsql STABLE ;



-- get_test_dbname( current_index integer ) всего БД по которым проведен корреляционный анализ
CREATE OR REPLACE FUNCTION get_test_dbname( current_index integer ) RETURNS text  AS $$
DECLARE
 current_dbname text ;
BEGIN
	SELECT test_dbname
	INTO current_dbname
	FROM db_correlation_analysis 
	WHERE start_timepoint BETWEEN min_timestamp AND max_timestamp
	ORDER BY start_timepoint 
	LIMIT 1 
	OFFSET current_index;

RAISE NOTICE '%' ,length( current_dbname );
		
	IF length( current_dbname ) IS NOT NULL 
	THEN 			
		return current_dbname ;
	ELSE
		return 'NODB' ;
	END IF ;
END
$$ LANGUAGE plpgsql STABLE ;


-- get_correlation_queryid_count( ) счетчик queryid всего по которым проведен корреляционный анализ
CREATE OR REPLACE FUNCTION get_correlation_queryid_count() RETURNS integer  AS $$
DECLARE
 counter  integer  ;
BEGIN
	SELECT count(*) 
	INTO counter
	FROM correlation_queryid ; 
	
	IF counter > 0 
	THEN 	
		return counter ; 
	ELSE 
		return -1 ;
	END IF;
END
$$ LANGUAGE plpgsql STABLE ;

-- get_correlation_queryid( current_index integer ) queryid по которым проведен корреляционный анализ
CREATE OR REPLACE FUNCTION get_correlation_queryid( current_index integer ) RETURNS bigint  AS $$
DECLARE
 current_queryid bigint ;
BEGIN
	SELECT queryid
	INTO current_queryid
	FROM correlation_queryid 
	ORDER BY queryid 
	LIMIT 1 
	OFFSET current_index;

RAISE NOTICE '%' ,current_queryid;
		
	IF current_queryid IS NOT NULL 
	THEN 			
		return current_queryid ;
	ELSE
		return 0 ;
	END IF ;
END
$$ LANGUAGE plpgsql STABLE ;

-- is_need_new_pgpro_pwr_snapshot() Если нужно сделать новый снимок pgpro_pwr
CREATE OR REPLACE FUNCTION is_need_new_pgpro_pwr_snapshot() RETURNS integer AS $$
DECLARE
 current_minute numeric ;
 minute_mod numeric ; 
BEGIN
	SELECT EXTRACT( minute FROM  CURRENT_TIMESTAMP ) 
	INTO current_minute ;

	------------------------------------------
	-- СНИМКИ - КАЖДЫЕ 10 МИНУТ 
	SELECT MOD( current_minute , 10::numeric ) 
	INTO minute_mod ; 
	IF minute_mod = 0 
	THEN 
		return 1 ;
	-- СНИМКИ - КАЖДЫЕ 10 МИНУТ 
	ELSE
		return 0 ;
	END IF ;

END
$$ LANGUAGE plpgsql ;

-- log_sql_statistics_timestamp() зафиксировать время сбора статистики SQL 
CREATE OR REPLACE FUNCTION log_sql_statistics_timestamp() RETURNS integer AS $$
DECLARE 
  current_timepoint timestamp with time zone ; 
BEGIN
	SELECT date_trunc('minute' , CURRENT_TIMESTAMP )
	INTO current_timepoint ; 
	
	UPDATE configuration
	SET last_sql_statistics = current_timepoint ; 
	
	INSERT INTO sql_stats_history 
	(
		timepoint
	)
	VALUES 
	(
		current_timepoint
	);
	
 return 0 ;
END 
$$ LANGUAGE plpgsql ;

-- log_sql_statistics_timestamp() зафиксировать время сбора статистики SQL 
CREATE OR REPLACE FUNCTION log_sql_statistics_timestamp( current_timepoint timestamp with time zone  ) RETURNS integer AS $$
BEGIN
	UPDATE configuration
	SET last_sql_statistics = current_timepoint ; 
	
	INSERT INTO sql_stats_history 
	(
		timepoint
	)
	VALUES 
	(
		current_timepoint
	);
	
 return 0 ;
END 
$$ LANGUAGE plpgsql ;



-- get_sql_statistics_timestamp() получить время сбора статистики SQL  
CREATE OR REPLACE FUNCTION get_sql_statistics_timestamp() RETURNS text AS $$
DECLARE 
  current_timepoint timestamp with time zone ; 
BEGIN
	SELECT last_sql_statistics
	INTO current_timepoint 
	FROM configuration ; 
	
 return to_char( current_timepoint , 'YYYY-MM-DD HH24:MI') ;
END 
$$ LANGUAGE plpgsql ;


-- stats_paused() Остановить сбор статистики 
CREATE OR REPLACE FUNCTION stats_pause() RETURNS integer AS $$
BEGIN
 UPDATE configuration SET has_data_collection_been_stopped = TRUE ;
 return 0;
END 
$$ LANGUAGE plpgsql ;

-- stats_resume() Возобновить сбор статистики
CREATE OR REPLACE FUNCTION stats_resume() RETURNS integer AS $$
BEGIN
 UPDATE configuration SET has_data_collection_been_stopped = FALSE ;
 return 0;
END 
$$ LANGUAGE plpgsql ;

-- has_stats_paused() Остановлен ли сбор статистики 
CREATE OR REPLACE FUNCTION has_stats_paused() RETURNS BOOLEAN AS $$
DECLARE 
 stats_flag BOOLEAN;
BEGIN
 SELECT has_data_collection_been_stopped
 INTO stats_flag
 FROM configuration ; 
 
 return stats_flag;
END 
$$ LANGUAGE plpgsql ;

-- Получить количество работающих воркеров stat_statements
CREATE OR REPLACE FUNCTION 	get_working_statemets_stat_workers() RETURNS integer AS $$
DECLARE
 counter integer ;  
BEGIN

  SELECT 
	count(pid)
  INTO 
	counter
  FROM 
    pg_stat_activity 
  WHERE 
    query ='SELECT update_stat_statement_analysis_for_current_minute()';
  
  return counter ; 
END
$$ LANGUAGE plpgsql  ;

-- Добавить снимок pgpro_pwr
CREATE OR REPLACE FUNCTION 	save_pgpro_pwr_samples( curr_timestamp text  ) RETURNS integer AS $$
DECLARE
sample_timestamp timestamp with time zone;
BEGIN

	SELECT to_timestamp( curr_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO sample_timestamp ; 
	
	INSERT INTO pgpro_pwr_samples 
	(
		curr_timestamp 
	)
	VALUES 
	( 
		sample_timestamp 
	)
	ON CONFLICT ON CONSTRAINT pgpro_pwr_samples_pkey DO NOTHING ;
 
  return 0 ; 
END
$$ LANGUAGE plpgsql  ;






