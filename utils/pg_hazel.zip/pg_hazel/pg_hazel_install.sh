﻿#!/bin/sh
# pg_hazel_install.sh
# version 81.3


#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}


script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/pg_hazel_install.log'
ERR_FILE=$current_path'/pg_hazel_install.err'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M%S")

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE

#####################################
mkdir /tmp/bb
mkdir /tmp/performance_reports
mkdir /tmp/performance_reports_archive
mkdir /postgres/scripts/tester
mkdir /postgres/scripts/tester/stress_tester
mkdir /postgres/scripts/pgpro_pwr
 mkdir /postgres/scripts/tester/kb

cd /postgres/scripts/tester

#####################################

echo 'OK : START INSTALLATION '
echo 'OK : START INSTALLATION ' >> $LOG_FILE




cp -n /tmp/pg_hazel.zip /postgres/scripts/tester
exit_code $? $LOG_FILE $ERR_FILE

unzip -o  pg_hazel.zip
exit_code $? $LOG_FILE $ERR_FILE

rm -f /postgres/scripts/tester/pg_hazel.zip
exit_code $? $LOG_FILE $ERR_FILE
chmod 755 *.sh 

echo 'OK : scripts is ready'
echo 'OK : scripts is ready' >> $LOG_FILE

# Определить роль сервера СУБД
is_recovery=`psql -Aqtc 'SELECT pg_is_in_recovery()' 2>>$LOG_FILE`
if [ $? -ne 0 ]
then
  ##################################################################### 
  #ОШИБКА СУБД  
  echo 'ERROR : PostgreSQL ERROR : pg_is_in_recovery TERMINATED WITH ERROR '
  echo 'ERROR : PostgreSQL ERROR : pg_is_in_recovery TERMINATED WITH ERROR ' >> $LOG_FILE
  exit 1000
  #####################################################################
fi

if [ "$is_recovery" == 't' ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPLICATION NODE - FINISH  '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPLICATION NODE - FINISH  '>> $LOG_FILE
  exit 0 
  
fi 

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CREATE DATABASE AND USER '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CREATE DATABASE AND USER ' >> $LOG_FILE
psql -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel_db.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

##########################################################################################
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : СОЗДАТЬ БД pgpropwr'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : СОЗДАТЬ БД pgpropwr' >> $LOG_FILE

is_pgpropwr_db_exists=`psql -Aqtc "SELECT 1 FROM pg_database WHERE datname = 'pgpropwr'"` 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : is_pgpropwr_db_exists= '$is_pgpropwr_db_exists
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : is_pgpropwr_db_exists= '$is_pgpropwr_db_exists >> $LOG_FILE

if [ "$is_pgpropwr_db_exists" != "1" ]
then 
  psql -c 'CREATE DATABASE pgpropwr' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : CREATE DATABASE TERMINATED WITH ERROR '
    echo 'ERROR : CREATE DATABASE TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 100
  fi

  psql -d pgpropwr -c 'CREATE EXTENSION pg_wait_sampling' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : CREATE EXTENSION pg_wait_sampling TERMINATED WITH ERROR '
    echo 'ERROR : CREATE EXTENSION pg_wait_sampling TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 200
  fi

  psql -d pgpropwr -c 'CREATE EXTENSION pgpro_stats' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : CREATE EXTENSION pgpro_stats TERMINATED WITH ERROR '
    echo 'ERROR : CREATE EXTENSION pgpro_stats TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 300
  fi

  psql -d pgpropwr -c 'CREATE EXTENSION dblink' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : CREATE EXTENSION dblink TERMINATED WITH ERROR '
    echo 'ERROR : CREATE EXTENSION dblink TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 310
  fi
fi

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : БД pgpropwr - СОЗДАНА '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : БД pgpropwr - СОЗДАНА ' >> $LOG_FILE
##########################################################################################


##########################################################################################
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : СОЗДАТЬ РОЛЬ pgpropwr'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : СОЗДАТЬ РОЛЬ pgpropwr' >> $LOG_FILE

is_pgpropwr_role_exists=`psql -Aqtc "SELECT 1 from pg_roles WHERE rolname = 'pgpropwr'"` 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : is_pgpropwr_role_exists= '$is_pgpropwr_role_exists
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : is_pgpropwr_role_exists= '$is_pgpropwr_role_exists >> $LOG_FILE

if [ "$is_pgpropwr_role_exists" != "1" ]
then 
  psql -d pgpropwr -c 'CREATE USER pgpropwr' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : CREATE USER TERMINATED WITH ERROR '
    echo 'ERROR : CREATE USER TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 400
  fi

  psql -d pgpropwr -c 'create schema profile authorization pgpropwr' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : CREATE USER TERMINATED WITH ERROR '
    echo 'ERROR : CREATE USER TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 500
  fi

  psql -d pgpropwr -c 'grant usage on schema profile to pgpropwr' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : grant usage TERMINATED WITH ERROR '
    echo 'ERROR : grant usage TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 600
  fi

  psql -d pgpropwr -c 'grant pg_read_all_data to pgpropwr' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : grant pg_read_all_data TERMINATED WITH ERROR '
    echo 'ERROR : grant pg_read_all_data TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 700
  fi

  psql -d pgpropwr -c 'create extension pgpro_pwr schema profile' >> $LOG_FILE 2>&1
  if [ $? -ne 0 ]
  then
    echo 'ERROR : create extension pgpro_pwr TERMINATED WITH ERROR '
    echo 'ERROR : create extension pgpro_pwr TERMINATED WITH ERROR ' >> $LOG_FILE
    exit 800
  fi
fi
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : СОЗДАТЬ РОЛЬ pgpropwr'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : СОЗДАТЬ РОЛЬ pgpropwr' >> $LOG_FILE
##########################################################################################



echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_tables'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_tables' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel_tables.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_functions'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_performance_monitoring_tables'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_performance_monitoring_tables' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel_performance_monitoring_tables.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_performance_monitoring_functions'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel_performance_monitoring_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel_performance_monitoring_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE



echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SET DEFAULT CONFIGURATION'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SET DEFAULT CONFIGURATION' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -Aqtc 'select default_configuration()' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_hazel' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_stats CREATION '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_stats CREATION ' >> $LOG_FILE
psql -d $performance_monitoring_db -v ON_ERROR_STOP=on --echo-errors -c 'CREATE EXTENSION IF NOT EXISTS pgpro_stats' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_os_tables'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_os_tables' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_os_tables.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_os_functions'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_os_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_os_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_cluster_tables'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_cluster_tables' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_cluster_tables.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_cluster_functions'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_cluster_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_cluster_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_statement_tables'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_statement_tables' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_statement_tables.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_statement_functions'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_statement_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_statement_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_timer_tables'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_timer_tables' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_timer_tables.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_timer_functions'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_timer_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_timer_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_benchmark' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stat_benchmark' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stat_benchmark.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

################################################################################################
# ОТЧЕТЫ
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - stress_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - stress_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/stress_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - daily_incidents_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - daily_incidents_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/daily_incidents_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_stats' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_stats' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_stats.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_wait_event_stats' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_wait_event_stats' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_wait_event_stats.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - queryid_stat' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - queryid_stat' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/queryid_stat.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - cluster_performance' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - cluster_performance' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/cluster_performance.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_wait_event_queryid_stats' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_wait_event_queryid_stats' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_wait_event_queryid_stats.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_prepare_queryid_list' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_prepare_queryid_list' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_waitings_prepare_queryid_list.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_list_next_by_index' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_list_next_by_index' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_waitings_queryid_list_next_by_index.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_list_size' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_list_size' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_waitings_queryid_list_size.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_report_header' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_report_header' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_waitings_queryid_report_header.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_waitings_queryid.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - are_incident_wait_correlated' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - are_incident_wait_correlated' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/are_incident_wait_correlated.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_prepare_id_list' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_prepare_id_list' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/sql_list_for_report_prepare_id_list.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_header' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_header' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/sql_list_for_report_header.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_list_size' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_list_size' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/sql_list_for_report_list_size.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_next_by_index' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_report_next_by_index' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/sql_list_for_report_next_by_index.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - get_queryid_count_for_incidents' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - get_queryid_count_for_incidents' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/get_queryid_count_for_incidents.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_query_counts' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_query_counts' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incidents_query_counts.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - query_incident_counts' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - query_incident_counts' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/query_incident_counts.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_to_timepoint_wait_queryid_count' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_to_timepoint_wait_queryid_count' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_to_timepoint_wait_queryid_count.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_prepare_id_list' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_prepare_id_list' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incidents_to_timepoint_prepare_id_list.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_report_header' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_report_header' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incidents_to_timepoint_report_header.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_list_size' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_list_size' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incidents_to_timepoint_list_size.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_list_next_by_index' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_to_timepoint_list_next_by_index' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incidents_to_timepoint_list_next_by_index.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_to_timepoint_wait_event_queryid_counts' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_to_timepoint_wait_event_queryid_counts' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_to_timepoint_wait_event_queryid_counts.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incident_waitings_queryid_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incident_waitings_queryid_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - mix_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - mix_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/mix_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - mixwmt_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - mixwmt_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/mixwmt_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - mixwmt_wcpu_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - mixwmt_wcpu_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/mixwmt_wcpu_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/vmstat.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - iostat_cpu' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - iostat_cpu' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/iostat_cpu.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - iostat_device' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - iostat_device' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/iostat_device.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_cpu' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_cpu' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/vmstat_cpu.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_io' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_io' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/vmstat_io.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_ram' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_ram' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/vmstat_ram.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_iostat' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - vmstat_iostat' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/vmstat_iostat.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - correlation' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - correlation' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/correlation.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - alerts_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - alerts_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/alerts_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_report' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - incidents_report' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/incidents_report.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_period' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - sql_list_for_period' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/sql_list_for_period.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_period' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_period' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/wait_event_queryid_for_period.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_period_stats' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_period_stats' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/wait_event_queryid_for_period_stats.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - deferred_strategy' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - deferred_strategy' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/deferred_strategy.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_for_deepseek' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_for_deepseek' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/wait_event_for_deepseek.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_deepseek' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_deepseek' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/wait_event_queryid_for_deepseek.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_deepseek' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - wait_event_queryid_for_deepseek' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/wait_event_queryid_for_deepseek.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - get_hour_before' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - get_hour_before' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/get_hour_before.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - alerts_report_src' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT  - alerts_report_src' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/reports/functions/alerts_report_src.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


chmod 755 /postgres/scripts/tester/reports/*.sh
chmod 755 /postgres/scripts/tester/kb/*.sh
#chmod 755 /postgres/scripts/tester/reports/detailed/*.sh
#chmod 755 /postgres/scripts/tester/reports/incidents/*.sh

# ОТЧЕТЫ
################################################################################################

################################################################################################
# PGPRO_PWR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR' >> $LOG_FILE

chmod 755 /postgres/scripts/tester/pgpro_pwr/*.sh

# PGPRO_PWR
################################################################################################



################################################################################################
# PG_STAT_TESTER
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PG_STAT_TESTER INSTALLATION START' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PG_STAT_TESTER INSTALLATION START' >> $LOG_FILE

chmod 755 /postgres/scripts/tester/stress_tester/*.sh
/postgres/scripts/tester/stress_tester/pg_stat_tester_install.sh >>$LOG_FILE 2>$ERR_FILE
#exit_code $? $LOG_FILE $ERR_FILE

cat /postgres/scripts/tester/stress_tester/pg_stat_tester_install.log | grep -E "TIMESTAMP"
cat /postgres/scripts/tester/stress_tester/*.log | grep -E "ERROR"

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PG_STAT_TESTER INSTALLATION FINISH' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PG_STAT_TESTER INSTALLATION FINISH' >> $LOG_FILE
# PG_STAT_TESTER
################################################################################################


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SERVICE FUNCTIONS'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SERVICE FUNCTIONS' >> $LOG_FILE
psql -v ON_ERROR_STOP=on --echo-errors  -d pgpropwr -f /postgres/scripts/tester/pg_hazel_service.sql  >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : UPDATE VERSIONS'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : UPDATE VERSIONS' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_hazel_version.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_reports_version.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_stress_tester_version.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/pg_pro_pwr_version.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


psql -d pgpropwr -c "select pgpro_stats_statements_reset()" >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' OK : pgpro_stats_statements_reset  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' OK :  pgpro_stats_statements_reset  ' >> $LOG_FILE

psql -d pgpropwr -c "select pgpro_stats_totals_reset()" >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' OK : pgpro_stats_totals_reset  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' OK :  pgpro_stats_totals_reset  ' >> $LOG_FILE


psql -d pgpropwr -c "select pg_stat_reset()" >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' OK : pg_stat_reset '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' OK : pg_stat_reset  ' >> $LOG_FILE


#DISABLED
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CREATE FIRST PGPRO_PWR SAMPLE - STARTED '
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CREATE FIRST PGPRO_PWR SAMPLE - STARTED ' >> $LOG_FILE
##################################################
## NEW PGPRO_PWR SNAPSHOT
#ERR_FILE_pgpro_pwr=$current_path'/pgpro_pwr_snapshot.err'
#/postgres/scripts/tester/pgpro_pwr_snapshot.sh 2>$ERR_FILE_pgpro_pwr
#exit_code $? $LOG_FILE $ERR_FILE_pgpro_pwr	
## NEW PGPRO_PWR SNAPSHOT
##################################################
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CREATE FIRST PGPRO_PWR SAMPLE - FINISHED '
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CREATE FIRST PGPRO_PWR SAMPLE - FINISHED ' >> $LOG_FILE
#DISABLED

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - START '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - START ' >> $LOG_FILE

echo 'kill vmstat'

pkill -u postgres -x "vmstat"

echo 'start vmstat'
vmstat 60 -S M -t >/postgres/scripts/tester/vmstat.log 2>&1 &
echo 'vmstat started'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - IN PROCESS'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - IN PROCESS' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - START '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - START ' >> $LOG_FILE

echo 'kill iostat'

pkill -u postgres -x "iostat"

echo 'start iostat'
iostat 60 -d -x -m -t >/postgres/scripts/tester/iostat.log 2>&1 &
echo 'iostat started '

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - IN PROCESS'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - IN PROCESS' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - STARTED' >> $LOG_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_fill' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_fill' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/kb/pg_hazel_kb_fill.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_functions' 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE  - pg_hazel_kb_functions' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/kb/pg_hazel_kb_functions.sql >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : KNOWLEDGE BASE FILLING - FINISHED' >> $LOG_FILE



echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PG_HAZEL INSTALLED SUCCESSFULLY !'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PG_HAZEL INSTALLED SUCCESSFULLY !' >> $LOG_FILE





exit 0 