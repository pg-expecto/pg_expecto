-- pg_hazel_performance_monitoring_functions.sql
-- version 77.0
-- Сбор статистических данных о производительности объектов СУБД
-- statement_performance_stats() Собрать статистику по производительности отдельных SQL
-- benchmark_time_stats() Собрать статистику по медианному времени выполнения отдельных SQL
-- db_negative_correlation_pct() Процентное соотношение БД имеющих отрицательную скользащую корреляцию на точку времени
-- db_strong_negative_correlation_pct() Процентное соотношение БД имеющих среднюю и сильную отрицательную скользащую корреляцию на точку времени
-- sql_negative_correlation_pct() Процентное соотношение SQL имеющих отрицательную скользащую корреляцию на точку времени
-- sql_strong_negative_correlation_pct() Процентное соотношение SQL имеющих среднюю и сильную отрицательную скользащую корреляцию на точку времени

-- get_current_cpi() Получить текущие значения производительности 

-- open_performane_incident_p4() открыть инцидент производительности приоритет 4
-- open_performane_incident_p3() открыть инцидент производительности приоритет 3
-- close_performane_incidents() закрыть инциденты производительности 
-- performance_incidents_count - количество инцидентов производительности за период
-- get_performance_incidents -- получить id инцидента по индексу
-- performance_incidents_count_by_priority - количество инцидентов производительности за период по приоритету
-- get_performance_incidents_by_priority -- получить id инцидента по индексу приоритету 




--Текущий размер 
--Подготовить статистику 
CREATE OR REPLACE FUNCTION prepare_monitoring_queryid_table() RETURNS integer AS $$
DECLARE 
	queryid_for_monitoring_rec record ;
    queryid_count integer ;
BEGIN 
	TRUNCATE TABLE monitoring_queryid ; 
	TRUNCATE TABLE monitoring_queryid_stats ; 
	
	--------------------------------------------
	-- ТОЛЬКО ПОЛЬЗОВАТЕЛЬСКИЕ ЗАПРОСЫ К ПОЛЬЗОВАТЕЛЬСКИМ БД
	queryid_count = 0 ;
	FOR queryid_for_monitoring_rec IN 
	SELECT dbid  ,
			   userid , 
		       queryid
	FROM  pgpro_stats_statements		
	WHERE 
		dbid NOT IN 
		(
			SELECT oid 
			FROM pg_database 
			WHERE 
			datname IN 
				('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) 
		)
	GROUP BY dbid  ,
			   userid , 
		       queryid 
	LOOP
		queryid_count = queryid_count + 1;
		INSERT INTO monitoring_queryid 
		(
				id , 
				dbid , 
				userid , 
				queryid
		)
		VALUES 
		( 
			queryid_count , 
			queryid_for_monitoring_rec.dbid , 
			queryid_for_monitoring_rec.userid , 
			queryid_for_monitoring_rec.queryid
		);
	END LOOP ;

	INSERT INTO monitoring_queryid_stats
	(
		max_id
	)
	VALUES 
	(
		queryid_count
	) ;
	
 RETURN 0; 
END
$$ LANGUAGE plpgsql ;

--Подготовить статистику 
CREATE OR REPLACE FUNCTION get_next_queryid() RETURNS integer  AS $$
DECLARE 
	queryid_for_monitoring_rec record ; 
BEGIN 
	SELECT MIN( id ) AS id
	INTO queryid_for_monitoring_rec
	FROM monitoring_queryid ;

	IF queryid_for_monitoring_rec.id IS NULL 
	THEN
		queryid_for_monitoring_rec.id = 0 ;
	END IF ; 	
	
 RETURN queryid_for_monitoring_rec.id ;
END
$$ LANGUAGE plpgsql ;

--текущая статистика обработки SQL
CREATE OR REPLACE FUNCTION get_sql_perf_current_processing_status() RETURNS text  AS $$
DECLARE 
 result_text text ;
 monitoring_queryid_stats_rec record ; 
 timepoint timestamptz ; 
BEGIN 
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP ) 
	INTO 		timepoint ;
		
	SELECT * 
	INTO monitoring_queryid_stats_rec
	FROM monitoring_queryid_stats ;
	
	result_text = TO_CHAR(timepoint ,'YYYY-MM-DD HH24:MI' )||' | '||
	              'MAX ID = '||monitoring_queryid_stats_rec.max_id ||' | '||
				  'CURRENT ID = '||monitoring_queryid_stats_rec.current_id ||' | '||
				  'PCT = '||monitoring_queryid_stats_rec.pct_id ||' | '
				  ;	
 RETURN result_text ;
END
$$ LANGUAGE plpgsql ;
  

-- Собрать статистику по производительности отдельных SQL
CREATE OR REPLACE FUNCTION statement_performance_stats( curr_id integer ) RETURNS integer AS $$
DECLARE 
 queryid_count integer ;
 total_queryid_count integer ;
 i integer ;
 current_stat_statement_rec record ;
 timepoint timestamptz ; 

 result_str text ;
 
 queryid_for_monitoring_rec record ;
 monitoring_queryid_stats_rec record ; 
 
 curr_pct_id DOUBLE PRECISION ;
BEGIN
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP )
	INTO timepoint;

	SELECT * 
	INTO queryid_for_monitoring_rec
	FROM monitoring_queryid
	WHERE id = curr_id ; 	
		
	SELECT * 
	INTO current_stat_statement_rec 
	FROM current_stat_statement( queryid_for_monitoring_rec.dbid , queryid_for_monitoring_rec.userid , queryid_for_monitoring_rec.queryid , timepoint  );
	
	SELECT * 
	INTO monitoring_queryid_stats_rec
	FROM monitoring_queryid_stats;
	
	curr_pct_id = curr_id::DOUBLE PRECISION / monitoring_queryid_stats_rec.max_id::DOUBLE PRECISION * 100.0 ;
	UPDATE 	monitoring_queryid_stats
	SET current_id = curr_id , pct_id = curr_pct_id ; 
	
	
	DELETE FROM monitoring_queryid 
	WHERE id = queryid_for_monitoring_rec.id ; 

 RETURN 0 ; 

END
$$ LANGUAGE plpgsql ;

--Собрать статистику по медианному времени выполнения отдельных SQL
CREATE OR REPLACE FUNCTION benchmark_time_stats() RETURNS text AS $$
DECLARE 
 queryid_count integer ;
 timepoint timestamptz ; 

 result_str text ;
 
 benchmark_queries_rec record ;
 stat_timer_calc_statistics_res integer ;
 
 current_scenario integer ;
 
 curr_scenario_queryid bigint ; 
 scenario_sql text ;
 current_test_id integer;
BEGIN
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP )
	INTO timepoint;

	SELECT get_scenario()
	INTO current_scenario;
	
	result_str = 'INFO : SCENARIO = '||current_scenario||' BENCHMARKS  : ';

	
	-------------------------------------
	-- ЕСЛИ СПИСОК ПУСТОЙ 
	SELECT count(*) 
	INTO queryid_count
	FROM benchmark_queries ;
	
	IF current_scenario >= 1 AND current_scenario <= 4 
	THEN 
		IF queryid_count = 0 
		THEN
			----------------------------------------------
			-- QUERYID для заранее подготовленных запросов 
			--BENCHMARK - ТЕСТОВЫЙ СЦЕНАРИЙ НАГРУЗОЧНОГО ТЕСТИРОВАНИЯ
			-- СЧИТАТЬ ЕСЛИ ЗАПУЩЕН ТЕСТ
			INSERT INTO benchmark_queries
			(
				query ,  	
				dbid  ,
				userid , 
				queryid 		
			)
			SELECT 
				query ,
				dbid  ,
				userid , 
				queryid
			FROM  pgpro_stats_statements
			WHERE query like 'select custom_test%' AND dbid = ( SELECT oid from pg_database WHERE datname = 'test_pgbench_custom')
			GROUP BY 
				query ,
				dbid  ,
				userid , 
				queryid
				;
			--BENCHMARK - ТЕСТОВЫЙ СЦЕНАРИЙ НАГРУЗОЧНОГО ТЕСТИРОВАНИЯ			
			-- QUERYID для заранее подготовленных запросов 
			----------------------------------------------	
		END IF ;
	END IF ;
	
	-------------------------------------------------------------------
	-- MIX 
	IF current_scenario = 5
	THEN 
		IF queryid_count = 0 
		THEN
			----------------------------------------------
			-- QUERYID для заранее подготовленных запросов 
			--BENCHMARK - ТЕСТОВЫЙ СЦЕНАРИЙ НАГРУЗОЧНОГО ТЕСТИРОВАНИЯ
			-- СЧИТАТЬ ЕСЛИ ЗАПУЩЕН ТЕСТ
			INSERT INTO benchmark_queries
			(
				query ,  	
				dbid  ,
				userid , 
				queryid 		
			)
			SELECT 
				query ,
				dbid  ,
				userid , 
				queryid
			FROM  pgpro_stats_statements
			WHERE query like 'select mix_custom_test%' AND dbid = ( SELECT oid from pg_database WHERE datname = 'test_pgbench_custom')
			GROUP BY 
				query ,
				dbid  ,
				userid , 
				queryid
				;
				
			SELECT get_current_test_id()
			INTO current_test_id ;
			
			
			SELECT scenario_1_queryid
			INTO curr_scenario_queryid
			FROM test_statistics ;
			
			IF curr_scenario_queryid IS NULL 
			THEN 
				-------------------------------------------------------
				--SCENARIO_1_QUERYID
				SELECT 
					queryid
				INTO 
					curr_scenario_queryid
				FROM 
					pgpro_stats_statements
				WHERE 
					query like 'select mix_custom_test1%' ;
						
				UPDATE 	
					test_statistics
				SET
					scenario_1_queryid = curr_scenario_queryid
				WHERE 
					test_id = current_test_id;
				--SCENARIO_1_QUERYID
				-------------------------------------------------------
			END IF;
			
			SELECT scenario_2_queryid
			INTO curr_scenario_queryid
			FROM test_statistics ;
			
			IF curr_scenario_queryid IS NULL 
			THEN 
				-------------------------------------------------------
				--SCENARIO_2_QUERYID
				SELECT 
					queryid
				INTO 
					curr_scenario_queryid
				FROM 
					pgpro_stats_statements
				WHERE 
					query like 'select mix_custom_test2%' ;
						
				UPDATE 	
					test_statistics
				SET
					scenario_2_queryid = curr_scenario_queryid
				WHERE 
					test_id = current_test_id;
				--SCENARIO_2_QUERYID
				-------------------------------------------------------
			END IF;

			SELECT scenario_3_queryid
			INTO curr_scenario_queryid
			FROM test_statistics ;
			
			IF curr_scenario_queryid IS NULL 
			THEN 
				--SCENARIO_3_QUERYID
				SELECT 
					queryid
				INTO 
					curr_scenario_queryid
				FROM 
					pgpro_stats_statements
				WHERE 
					query like 'select mix_custom_test3%' ;
						
				UPDATE 	
					test_statistics
				SET
					scenario_3_queryid = curr_scenario_queryid
				WHERE 
					test_id = current_test_id;
				--SCENARIO_3_QUERYID
				-------------------------------------------------------
			END IF ;
			
			SELECT scenario_4_queryid
			INTO curr_scenario_queryid
			FROM test_statistics ;
			
			IF curr_scenario_queryid IS NULL 
			THEN 
				-------------------------------------------------------
				--SCENARIO_4_QUERYID
				SELECT 
					queryid
				INTO 
					curr_scenario_queryid
				FROM 
					pgpro_stats_statements
				WHERE 
					query like 'select mix_custom_test4%' ;
						
				UPDATE 	
					test_statistics
				SET
					scenario_4_queryid = curr_scenario_queryid
				WHERE 
					test_id = current_test_id;
				--SCENARIO_4_QUERYID
				-------------------------------------------------------
			END IF;
					
			--BENCHMARK - ТЕСТОВЫЙ СЦЕНАРИЙ НАГРУЗОЧНОГО ТЕСТИРОВАНИЯ			
			-- QUERYID для заранее подготовленных запросов 
			----------------------------------------------	
		END IF ;
	END IF ;
	-- MIX 
	-------------------------------------------------------------------

	-------------------------------------------------------------------
	-- MIX WITHOUT MEDIAN TIME 
	IF current_scenario = 6
	THEN 
		SELECT get_current_test_id()
		INTO current_test_id ;
			
			
		SELECT scenario_1_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_1_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test1%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_1_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_1_QUERYID
			-------------------------------------------------------
		END IF;
		
		SELECT scenario_2_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_2_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test2%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_2_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_2_QUERYID
			-------------------------------------------------------
		END IF;

		SELECT scenario_3_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			--SCENARIO_3_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test3%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_3_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_3_QUERYID
			-------------------------------------------------------
		END IF ;
		
		SELECT scenario_4_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_4_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test4%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_4_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_4_QUERYID
			-------------------------------------------------------
		END IF;
		
	END IF ;
	-- MIX WITHOUT MEDIAN TIME 
	-------------------------------------------------------------------
	
	-------------------------------------------------------------------
	-- MIX WITHOUT MEDIAN TIME  WITHOUT CPU LOAD
	IF current_scenario = 7
	THEN 
		SELECT get_current_test_id()
		INTO current_test_id ;
			
			
		SELECT scenario_1_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_1_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test1%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_1_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_1_QUERYID
			-------------------------------------------------------
		END IF;
		
		SELECT scenario_2_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_2_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test2%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_2_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_2_QUERYID
			-------------------------------------------------------
		END IF;

		SELECT scenario_3_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			--SCENARIO_3_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test3%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_3_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_3_QUERYID
			-------------------------------------------------------
		END IF ;
		
		SELECT scenario_4_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_4_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test4%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_4_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_4_QUERYID
			-------------------------------------------------------
		END IF;
		
	END IF ;
	-- MIX WITHOUT MEDIAN TIME  WITHOUT CPU LOAD
	-------------------------------------------------------------------
	
	
	-- ЕСЛИ СПИСОК ПУСТОЙ 
	-------------------------------------
	
	---------------------------------------------------------------------------------------
	SELECT count(*) 
	INTO queryid_count
	FROM benchmark_queries ;
	
	-- ЕСЛИ НТ НЕ ПРОВОДИТСЯ
	IF queryid_count = 0 
	THEN	
		result_str = result_str||queryid_count||' statements '; 
		RETURN result_str ; 	
	END IF;
	
	
	----------------------------------------------------------
	-- Удалить из списка SQL по которым уже нет статистики 
	FOR benchmark_queries_rec IN 
	 SELECT  dbid , userid , queryid FROM benchmark_queries    GROUP BY dbid  ,  userid , queryid 
	  EXCEPT 
	 SELECT  dbid , userid , queryid FROM pgpro_stats_statements 
	 GROUP BY dbid  ,  userid , queryid 
	LOOP
		DELETE FROM  benchmark_queries
		WHERE dbid = benchmark_queries_rec.dbid AND 
		      userid = benchmark_queries_rec.userid AND 
			  queryid = benchmark_queries_rec.queryid ;
	END LOOP ;
	-- Удалить из списка SQL по которым уже нет статистики 
	----------------------------------------------------------
	
	SELECT count(*) 
	INTO queryid_count
	FROM benchmark_queries ;
		
	IF queryid_count = 0 
	THEN	
		result_str = result_str||queryid_count||' statements '; 
		RETURN result_str ; 	
	END IF;
	-- ЕСЛИ НТ НЕ ПРОВОДИТСЯ
	---------------------------------------------------------------------------------------

	----------------------------------------------------------
	-- Собрать статистику медианного времени по SQL
	queryid_count = 0 ; 
	FOR benchmark_queries_rec IN 
	SELECT * 
	FROM benchmark_queries
	LOOP
		
		queryid_count = queryid_count  + 1 ; 
		SELECT stat_timer_calc_statistics( benchmark_queries_rec.queryid , timepoint )
		INTO stat_timer_calc_statistics_res ;		
	END LOOP ; 
	-- Собрать статистику по SQL
	----------------------------------------------------------

 result_str = result_str||queryid_count; 
 RETURN result_str ; 

END
$$ LANGUAGE plpgsql ;

-- db_negative_correlation_pct() Процентное соотношение БД имеющих отрицательную скользящую корреляцию на точку времени
CREATE OR REPLACE FUNCTION db_negative_correlation_pct( timepoint timestamptz  ) RETURNS DOUBLE PRECISION AS $$
DECLARE 
  result_pct DOUBLE PRECISION;
  max_timestamp timestamptz ;
  min_timestamp timestamptz ;
  pg_database_rec record ; 
  db_counter integer ; 
  negative_corr_counter integer ; 
  corr_speed DOUBLE PRECISION;
BEGIN

	SELECT date_trunc('minute' , timepoint )
	INTO max_timestamp ; 
	
	SELECT max_timestamp - interval '60 minute'
	INTO min_timestamp ; 
	
	
	SELECT count(*) 
	INTO db_counter
	FROM pg_database 
	WHERE datname NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) ;
	
	
	negative_corr_counter = 0 ;
	FOR pg_database_rec IN 
	SELECT oid , datname 
	FROM pg_database 
	WHERE datname NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) 
	ORDER BY datname 
	LOOP
		----------------------------------------------------------------------------------
		--WAITINGS SPEED CORR
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , SUM( operating_speed_long ) AS operating_speed_long  
			FROM stat_statement_analysis
			WHERE
				dbid = pg_database_rec.oid AND 
			curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND operating_speed_long  > 0 
			GROUP BY dbid , curr_timestamp    
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , SUM( waitings_long ) AS waitings_long 
			FROM stat_statement_analysis	
			WHERE
				dbid = pg_database_rec.oid AND 
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0 
			GROUP BY dbid ,curr_timestamp    
		) 
		SELECT COALESCE( corr( operating_speed_long  , waitings_long ) , 0 ) AS correlation_value 
		INTO corr_speed
		FROM
			operating_speed os JOIN waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		--WAITINGS SPEED CORR	
		----------------------------------------------------------------------------------
		
		IF corr_speed < 0 
		THEN 
			negative_corr_counter = negative_corr_counter + 1 ; 
		END IF ;		
			  
	END LOOP ; 
	
	result_pct = negative_corr_counter::DOUBLE PRECISION /  db_counter::DOUBLE PRECISION * 100.0 ; 

 RETURN result_pct ; 

END
$$ LANGUAGE plpgsql ;

-- db_strong_negative_correlation_pct() Процентное соотношение БД имеющих среднюю и сильную отрицательную скользащую корреляцию на точку времени
CREATE OR REPLACE FUNCTION db_strong_negative_correlation_pct( timepoint timestamptz  ) RETURNS DOUBLE PRECISION AS $$
DECLARE 
  result_pct DOUBLE PRECISION;
  max_timestamp timestamptz ;
  min_timestamp timestamptz ;
  pg_database_rec record ; 
  db_counter integer ; 
  negative_corr_counter integer ; 
  corr_speed DOUBLE PRECISION;
BEGIN

	SELECT date_trunc('minute' , timepoint )
	INTO max_timestamp ; 
	
	SELECT max_timestamp - interval '60 minute'
	INTO min_timestamp ; 
	
	
	SELECT count(*) 
	INTO db_counter
	FROM pg_database 
	WHERE datname NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) ;
	
	
	negative_corr_counter = 0 ;
	FOR pg_database_rec IN 
	SELECT oid , datname 
	FROM pg_database 
	WHERE datname NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) 
	ORDER BY datname 
	LOOP
		----------------------------------------------------------------------------------
		--WAITINGS SPEED CORR
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , SUM( operating_speed_long ) AS operating_speed_long  
			FROM stat_statement_analysis
			WHERE
				dbid = pg_database_rec.oid AND 
			curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND operating_speed_long  > 0 
			GROUP BY dbid , curr_timestamp    
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , SUM( waitings_long ) AS waitings_long 
			FROM stat_statement_analysis	
			WHERE
				dbid = pg_database_rec.oid AND 
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0 
			GROUP BY dbid ,curr_timestamp    
		) 
		SELECT COALESCE( corr( operating_speed_long  , waitings_long ) , 0 ) AS correlation_value 
		INTO corr_speed
		FROM
			operating_speed os JOIN waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		--WAITINGS SPEED CORR	
		----------------------------------------------------------------------------------
		
		IF corr_speed <= -0.5 
		THEN 
			negative_corr_counter = negative_corr_counter + 1 ; 
		END IF ;		
			  
	END LOOP ; 
	
	result_pct = negative_corr_counter::DOUBLE PRECISION /  db_counter::DOUBLE PRECISION * 100.0 ; 

 RETURN result_pct ; 

END
$$ LANGUAGE plpgsql ;

-- sql_negative_correlation_pct() Процентное соотношение БД имеющих отрицательную скользящую корреляцию на точку времени
CREATE OR REPLACE FUNCTION sql_negative_correlation_pct( timepoint timestamptz  ) RETURNS DOUBLE PRECISION AS $$
DECLARE 
  result_pct DOUBLE PRECISION;
  max_timestamp timestamptz ;
  min_timestamp timestamptz ;
  pg_sql_rec record ; 
  sql_counter integer ; 
  negative_corr_counter integer ; 
  corr_speed DOUBLE PRECISION;
  current_last_sql_statistics timestamptz ; 
BEGIN
	SELECT last_sql_statistics 
	INTO current_last_sql_statistics
	FROM configuration ;
	
	max_timestamp = current_last_sql_statistics ; 
	min_timestamp  = max_timestamp - interval '60 minute';
	
	WITH 
	queryid_count
	AS
	(
		SELECT queryid
		FROM  stat_statement_analysis	
		WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND operating_speed_long > 0 
			AND waitings_long > 0 
		GROUP BY queryid
	) 
	SELECT count(*) AS counter 
	INTO sql_counter
	FROM queryid_count ;	
	IF sql_counter IS NULL THEN sql_counter = 0 ; END IF ; 

	
	negative_corr_counter = 0 ;
	FOR pg_sql_rec IN 
	SELECT queryid
	FROM  stat_statement_analysis	
	WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		AND operating_speed_long > 0 
		AND waitings_long > 0 
	GROUP BY queryid 
	LOOP
		----------------------------------------------------------------------------------
		--WAITINGS SPEED CORR
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , SUM( operating_speed_long ) AS operating_speed_long  
			FROM stat_statement_analysis
			WHERE
				queryid = pg_sql_rec.queryid AND 
			    curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND operating_speed_long > 0 				
			GROUP BY queryid , curr_timestamp    
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , SUM( waitings_long ) AS waitings_long 
			FROM stat_statement_analysis	
			WHERE
				queryid = pg_sql_rec.queryid AND 
			    curr_timestamp BETWEEN min_timestamp AND max_timestamp 				
				AND operating_speed_long > 0 				
			GROUP BY queryid , curr_timestamp    
		) 
		SELECT COALESCE( corr( operating_speed_long  , waitings_long ) , 0 ) AS correlation_value 
		INTO corr_speed
		FROM
			operating_speed os JOIN waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		--WAITINGS SPEED CORR	
		----------------------------------------------------------------------------------
		
		IF corr_speed < 0 
		THEN 
			negative_corr_counter = negative_corr_counter + 1 ; 
		END IF ;		
			  
	END LOOP ; 
	
	IF sql_counter > 0 
	THEN 
		result_pct = negative_corr_counter::DOUBLE PRECISION /  sql_counter::DOUBLE PRECISION * 100.0 ; 
	ELSE 
		result_pct = 0 ;
	END IF ;

 RETURN result_pct ; 

END
$$ LANGUAGE plpgsql ;

-- sql_strong_negative_correlation_pct() Процентное соотношение БД имеющих среднюю и сильную отрицательную скользащую корреляцию на точку времени
CREATE OR REPLACE FUNCTION sql_strong_negative_correlation_pct( timepoint timestamptz  ) RETURNS DOUBLE PRECISION AS $$
DECLARE 
  result_pct DOUBLE PRECISION;
  max_timestamp timestamptz ;
  min_timestamp timestamptz ;
  pg_sql_rec record ; 
  sql_counter integer ; 
  negative_corr_counter integer ; 
  corr_speed DOUBLE PRECISION;
  current_last_sql_statistics timestamptz ; 
BEGIN
	SELECT last_sql_statistics 
	INTO current_last_sql_statistics
	FROM configuration ;
	
	max_timestamp = current_last_sql_statistics ; 
	min_timestamp  = max_timestamp - interval '60 minute';
	
	WITH 
	queryid_count
	AS
	(
		SELECT queryid
		FROM  stat_statement_analysis	
		WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND operating_speed_long > 0 			
		GROUP BY queryid
	) 
	SELECT count(*) AS counter 
	INTO sql_counter
	FROM queryid_count ;	
	IF sql_counter IS NULL THEN sql_counter = 0 ; END IF ; 

	
	negative_corr_counter = 0 ;
	FOR pg_sql_rec IN 
	SELECT queryid
	FROM  stat_statement_analysis	
	WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		AND operating_speed_long > 0 
		AND waitings_long > 0 
	GROUP BY queryid 
	LOOP
		----------------------------------------------------------------------------------
		--WAITINGS SPEED CORR
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , SUM( operating_speed_long ) AS operating_speed_long  
			FROM stat_statement_analysis
			WHERE
				queryid = pg_sql_rec.queryid AND 
			    curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND operating_speed_long > 0 
				AND waitings_long > 0 
			GROUP BY queryid , curr_timestamp    
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , SUM( waitings_long ) AS waitings_long 
			FROM stat_statement_analysis	
			WHERE
				queryid = pg_sql_rec.queryid AND 
			    curr_timestamp BETWEEN min_timestamp AND max_timestamp 				
				AND operating_speed_long > 0 				
			GROUP BY queryid , curr_timestamp    
		) 
		SELECT COALESCE( corr( operating_speed_long  , waitings_long ) , 0 ) AS correlation_value 
		INTO corr_speed
		FROM
			operating_speed os JOIN waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		--WAITINGS SPEED CORR	
		----------------------------------------------------------------------------------
		
		IF corr_speed <= -0.5 
		THEN 
			negative_corr_counter = negative_corr_counter + 1 ; 
		END IF ;		
			  
	END LOOP ; 
	
	IF sql_counter > 0 
	THEN 
		result_pct = negative_corr_counter::DOUBLE PRECISION /  sql_counter::DOUBLE PRECISION * 100.0 ; 
	ELSE 
		result_pct = 0 ;
	END IF ;

 RETURN result_pct ; 

END
$$ LANGUAGE plpgsql ;

--Получить текущие значения производительности 
CREATE OR REPLACE FUNCTION get_current_cpi() RETURNS text AS $$
DECLARE
 result_str text;
 timepoint timestamptz ;
 pgh_stat_cluster_analysis_rec record ;
current_dbid_userid_rec record ; 
 
active_speed_correlation DOUBLE PRECISION ;
speed_waitings_correlation DOUBLE PRECISION ;

sql_negative_corr_pct DOUBLE PRECISION ;
sql_strong_negative_corr_pct DOUBLE PRECISION ;

last_sql_statistics_timestamp text ; 
regr_slope_value DOUBLE PRECISION;

speed_degradation_indicator integer ;

speed_regr_slope_value DOUBLE PRECISION;
waitings_regr_slope_value DOUBLE PRECISION;

speed_regr_rec record;
waitings_regr_rec record;

BEGIN
	SELECT MAX(curr_timestamp)
	INTO timepoint 
	FROM pgh_stat_cluster_analysis ; 
	
	SELECT MAX(s.timepoint) 
	INTO last_sql_statistics_timestamp 
	FROM sql_stats_history s ;
	IF last_sql_statistics_timestamp IS NULL THEN last_sql_statistics_timestamp = ' '; END IF ;
	
	SELECT 	--COALESCE ( op_speed_short , 0 ) AS op_speed_short , 
			COALESCE ( op_speed_long , 0 ) AS op_speed_long , 			
			COALESCE ( waitings_long , 0 ) AS waitings_long	
	INTO 	pgh_stat_cluster_analysis_rec
	FROM 	pgh_stat_cluster_analysis 
	WHERE 	curr_timestamp = timepoint ; 
	
	
	-------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ - ОЖИДАНИЯ
	SELECT COALESCE( corr( op_speed_long ,  waitings_long ) , 0 ) AS correlation_value 
	INTO speed_waitings_correlation
	FROM
		 pgh_stat_cluster_analysis
	WHERE 
		curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint ; 
	--КОРРЕЛЯЦИЯ АКТИВНЫЕ СЕССИИ - СКОРОСТЬ 
	-------------------------------------------------------------------
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	pgh_stat_cluster_analysis
	WHERE 
		curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint 
	ORDER BY curr_timestamp	;
/*	
	----------------------------------------------------------------------------------------------------
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ
	SELECT COALESCE( regr_slope ( t.curr_timepoint::DOUBLE PRECISION ,  s.op_speed_long::DOUBLE PRECISION ) , 0 )
	INTO speed_regr_slope_value
	FROM
		pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
	WHERE 
		t.curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint ;
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - СКОРОСТЬ 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - ОЖИДАНИЯ 
	SELECT COALESCE( regr_slope ( t.curr_timepoint::DOUBLE PRECISION ,  s.waitings_long::DOUBLE PRECISION ) , 0 ) 
	INTO waitings_regr_slope_value
	FROM
		pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
	WHERE 
		t.curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint ;
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - ОЖИДАНИЯ
	----------------------------------------------------------------------------------------------------
*/
	----------------------------------------------------------------------------------------------------
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ
    -- 	линия регрессии  скорости  : Y = a + bX
	BEGIN
		WITH stats AS 
		(
		  SELECT 
			AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
			STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
			AVG(s.op_speed_long::DOUBLE PRECISION) as avg2, 
			STDDEV(s.op_speed_long::DOUBLE PRECISION) as std2
		  FROM
			pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
		  WHERE 
			t.curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint 
		),
		standardized_data AS 
		(
			SELECT 
				(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
				(s.op_speed_long::DOUBLE PRECISION - avg2) / std2 as y_z
			FROM
				pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
			WHERE 
				t.curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint  
		)	
		SELECT
			REGR_SLOPE(y_z, x_z) as slope, --b
			ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
			REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
		INTO 
			speed_regr_rec
		FROM standardized_data;
	EXCEPTION
	  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
	  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
	    SELECT 
			1.0 as slope, --b
			0.0  as slope_angle_degrees, --угол наклона
			0.0  as r_squared -- Коэффициент детерминации
		INTO 
		speed_regr_rec ;
	END;
	speed_regr_slope_value = speed_regr_rec.slope_angle_degrees ; 	
	-- 	линия регрессии  скорости  : Y = a + bX
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ
	-------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	-- ОЖИДАНИЯ
    -- 	линия регрессии  скорости  : Y = a + bX
	BEGIN 
		WITH stats AS 
		(
		  SELECT 
			AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
			STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
			AVG(s.waitings_long::DOUBLE PRECISION) as avg2, 
			STDDEV(s.waitings_long::DOUBLE PRECISION) as std2
		  FROM
			pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
		  WHERE 
			t.curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint  
		),
		standardized_data AS 
		(
			SELECT 
				(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
				(s.waitings_long::DOUBLE PRECISION - avg2) / std2 as y_z
			FROM
				pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
			WHERE 
				t.curr_timestamp BETWEEN timepoint - interval '1 hour' AND timepoint  
		)	
		SELECT
			REGR_SLOPE(y_z, x_z) as slope, --b
			ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
			REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
		INTO 
			waitings_regr_rec
		FROM standardized_data;
	EXCEPTION
	  --STDDEV(s.waitings_long::DOUBLE PRECISION) = 0  
	  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
	    SELECT 
			1.0 as slope, --b
			0.0  as slope_angle_degrees, --угол наклона
			0.0  as r_squared -- Коэффициент детерминации
		INTO 
		waitings_regr_rec ;
	END;
	waitings_regr_slope_value = waitings_regr_rec.slope_angle_degrees ; 	
	-- 	линия регрессии  скорости  : Y = a + bX
	-- ОЖИДАНИЯ
	-------------------------------------------------------------------
	
	--version 27.0
	-- ЕСЛИ 
	--  угол наклона линии скорости < 0 
	-- И 
	--  угол наклона линии ожиданий > 0 
	-- ТО деградация
/*
	От 0,7 до 1 или от -0,7 до -1 указывает на сильный корреляция.
	От 0,3 до 0,7 или от -0,3 до -0,7 отражает умеренный корреляция.
	От 0 до 0,3 или от -0,3 до 0 означает слабый корреляция.
https://mindthegraph.com/blog/ru/pearson-correlation/	
*/
	IF speed_regr_slope_value < 0 
	   AND 
	   waitings_regr_slope_value > 0 
	THEN 
		IF SIGN(speed_waitings_correlation) = 1 
		THEN 
			speed_degradation_indicator = 0 ;
			PERFORM close_performane_incidents();
		END IF;
		
		--Слабая и умеренная корреляция
		IF ABS(speed_waitings_correlation) < 0.7 AND SIGN(speed_waitings_correlation) = -1 
		THEN 
			speed_degradation_indicator = -50 ;
			PERFORM open_performane_incident_p4();
		END IF ;
		
		--Сильная корреляция
		IF ABS(speed_waitings_correlation) >= 0.7 AND SIGN(speed_waitings_correlation) = -1 
		THEN 
			speed_degradation_indicator = -100 ;
			PERFORM open_performane_incident_p3();
		END IF ;
	ELSE
		speed_degradation_indicator = 0 ;
		PERFORM close_performane_incidents();
	END IF ;
	--version 27.0
	-------------------------------------------------------------------
	
	
--------------------------------------------------------------------------------------------------------
--	ОБУЧЕНИЕ ЦЕПИ МАРКОВА - ПО УМОЛЧАНИЮ ОТКЛЮЧЕНО
/*
RAISE NOTICE 'ОБУЧЕНИЕ ЦЕПИ МАРКОВА - STARTED';
	PERFORM mchain_train_step();
RAISE NOTICE 'ОБУЧЕНИЕ ЦЕПИ МАРКОВА - FINISHED';	
*/
--	ОБУЧЕНИЕ ЦЕПИ МАРКОВА - ПО УМОЛЧАНИЮ ОТКЛЮЧЕНО
--------------------------------------------------------------------------------------------------------

	

	result_str = ROUND( speed_waitings_correlation::numeric , 4 )||'|'||      --1				 
	             pgh_stat_cluster_analysis_rec.op_speed_long     || ' | '|| --2
				 ROUND( pgh_stat_cluster_analysis_rec.waitings_long::numeric , 4 )  || ' | '|| --3
				 --ROUND( atand( speed_regr_slope_value )::numeric , 4 )  || ' | '|| --4
				 --ROUND( atand( waitings_regr_slope_value ) ::numeric , 4 )  || ' | '|| --5
				 ROUND( speed_regr_slope_value::numeric , 4 )  || ' | '|| --4
				 ROUND( waitings_regr_slope_value::numeric , 4 )  || ' | '|| --5
				 last_sql_statistics_timestamp ||'|'|| --6
				 speed_degradation_indicator  ||'|' --7
				 ;			
	return result_str;
END
$$ LANGUAGE plpgsql ;



-- close_performane_incidents() закрыть инциденты производительности 
CREATE OR REPLACE FUNCTION close_performane_incidents() RETURNS integer  AS $$
DECLARE 
  timepoint timestamp with time zone ; 
  performance_incident_rec record ; 
  configuration_rec record ; 
BEGIN
	SELECT 	performane_incident_p3_started , 
			performane_incident_p4_started
	INTO 	configuration_rec 
	FROM 	configuration  ;
	
	--ЕСЛИ НЕТ ОТКРЫТЫХ ИНЦИДЕНТОВ
	IF 	configuration_rec.performane_incident_p3_started IS NULL AND 
		configuration_rec.performane_incident_p4_started IS NULL 
	THEN 
		return 0;
	END IF;
	--ЕСЛИ НЕТ ОТКРЫТЫХ ИНЦИДЕНТОВ
	
	SELECT date_trunc( 'minute' , CURRENT_TIMESTAMP )
	INTO timepoint ;
	
	-------------------------------
	-- Обновить конфигурацию
	UPDATE configuration 
	SET performane_incident_p3_started = NULL  ,
		performane_incident_p4_started = NULL ;  
	-- Обновить конфигурацию
	-------------------------------
	
	
	-------------------------------
	-- Закрыть инциденты 
	UPDATE performance_incident
	SET finish_timepoint = timepoint 
	WHERE finish_timepoint IS NULL  ; 
	-- Закрыть инциденты 
	-------------------------------	
	
 return 0;
END 
$$ LANGUAGE plpgsql ;

-- open_performane_incident_p4() открыть инцидент производительности приоритет 4
CREATE OR REPLACE FUNCTION open_performane_incident_p4() RETURNS integer  AS $$
DECLARE 
  timepoint timestamp with time zone ; 
  current_performane_incident_p4_started timestamp with time zone ;  
BEGIN
	SELECT performane_incident_p4_started
	INTO current_performane_incident_p4_started
	FROM configuration ; 
	
	--если инцидент уже открыт
	IF current_performane_incident_p4_started IS NOT NULL 
	THEN 
		return 0 ;
	END IF ; 
	--если инцидент уже открыт
	
	SELECT date_trunc( 'minute' , CURRENT_TIMESTAMP )
	INTO timepoint ;
	
	UPDATE configuration
	SET performane_incident_p4_started = timepoint;
	
	INSERT INTO performance_incident
	(
		priority ,
		start_timepoint
	)
	VALUES 
	( 
		4 , 
		timepoint
	);	
	
 return 0;
END 
$$ LANGUAGE plpgsql ;

-- open_performane_incident_p3() открыть инцидент производительности приоритет 3
CREATE OR REPLACE FUNCTION open_performane_incident_p3() RETURNS integer  AS $$
DECLARE 
  timepoint timestamp with time zone ; 
  current_performane_incident_p3_started timestamp with time zone ;  
BEGIN
	SELECT performane_incident_p3_started
	INTO current_performane_incident_p3_started
	FROM configuration ; 
	
	--если инцидент уже открыт
	IF current_performane_incident_p3_started IS NOT NULL 
	THEN 
		return 0 ;
	END IF ; 
	--если инцидент уже открыт
	
	SELECT date_trunc( 'minute' , CURRENT_TIMESTAMP )
	INTO timepoint ;
	
	UPDATE configuration
	SET performane_incident_p3_started = timepoint;
	
	INSERT INTO performance_incident
	(
		priority ,
		start_timepoint
	)
	VALUES 
	( 
		3 , 
		timepoint
	);	
	
 return 0;
END 
$$ LANGUAGE plpgsql ;

-- performance_incidents_count - количество инцидентов производительности за период
CREATE OR REPLACE FUNCTION performance_incidents_count( start_timestamp text , finish_timestamp text) RETURNS integer  AS $$
DECLARE 
  min_timestamp timestamp with time zone ; 
  max_timestamp timestamp with time zone ;   
  counter integer ;
BEGIN
	SELECT to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO min_timestamp ; 
	
	SELECT to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO max_timestamp ; 
	
	SELECT count(*) 
	INTO counter
	FROM performance_incident
	WHERE start_timepoint BETWEEN min_timestamp AND max_timestamp ; 	
	
 return counter;
END 
$$ LANGUAGE plpgsql STABLE ;

--получить ID инцидента по индексу
CREATE OR REPLACE FUNCTION get_performance_incidents( current_index integer , start_timestamp text , finish_timestamp text ) RETURNS bigint  AS $$
DECLARE
 current_id bigint ;
  min_timestamp timestamp with time zone ; 
  max_timestamp timestamp with time zone ;  
BEGIN
	SELECT to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO min_timestamp ; 
	
	SELECT to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO max_timestamp ; 
	
	SELECT id
	INTO current_id
	FROM performance_incident 
	WHERE start_timepoint BETWEEN min_timestamp AND max_timestamp
	ORDER BY start_timepoint 
	LIMIT 1 
	OFFSET current_index;

	IF current_id IS NOT NULL 
	THEN 			
		return current_id ;
	ELSE
		return 0 ;
	END IF ;
END
$$ LANGUAGE plpgsql STABLE ;


CREATE OR REPLACE FUNCTION performance_incidents_count_by_priority( current_priority integer , start_timestamp text , finish_timestamp text) RETURNS integer  AS $$
DECLARE 
  min_timestamp timestamp with time zone ; 
  max_timestamp timestamp with time zone ;   
  counter integer ;
BEGIN
	SELECT to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO min_timestamp ; 
	
	SELECT to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO max_timestamp ; 
	
	SELECT count(*) 
	INTO counter
	FROM performance_incident
	WHERE start_timepoint BETWEEN min_timestamp AND max_timestamp 
	AND priority = current_priority; 	
	
 return counter;
END 
$$ LANGUAGE plpgsql STABLE ;

CREATE OR REPLACE FUNCTION get_performance_incidents_by_priority( current_priority integer , current_index integer , start_timestamp text , finish_timestamp text ) RETURNS bigint  AS $$
DECLARE
 current_id bigint ;
  min_timestamp timestamp with time zone ; 
  max_timestamp timestamp with time zone ;  
BEGIN
	SELECT to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO min_timestamp ; 
	
	SELECT to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI')
	INTO max_timestamp ; 
	
	SELECT id
	INTO current_id
	FROM performance_incident 
	WHERE start_timepoint BETWEEN min_timestamp AND max_timestamp
	AND priority = current_priority
	ORDER BY start_timepoint 
	LIMIT 1 
	OFFSET current_index;

	IF current_id IS NOT NULL 
	THEN 			
		return current_id ;
	ELSE
		return 0 ;
	END IF ;
END
$$ LANGUAGE plpgsql STABLE ;





		