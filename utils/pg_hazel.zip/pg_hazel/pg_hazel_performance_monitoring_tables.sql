-- pg_hazel_performance_monitoring_tables.sql
-- version 40.1
-- Сбор статистических данных о производительности объектов СУБД

DROP TABLE IF EXISTS performance_incident ;
CREATE UNLOGGED TABLE performance_incident 
(
	id bigserial PRIMARY KEY , 
	priority smallint , 
	
	start_timepoint timestamptz , 
	finish_timepoint timestamptz ,
	
	is_stats_calculated BOOLEAN DEFAULT FALSE ,
	
	curr_speed_long  DOUBLE PRECISION ,
	curr_waitings_long  DOUBLE PRECISION ,
	
	curr_speed_regr_slope_value DOUBLE PRECISION ,
	curr_waitings_regr_slope_value DOUBLE PRECISION ,
	
	curr_bufferpin_long  DOUBLE PRECISION ,
	curr_extension_long  DOUBLE PRECISION ,
	curr_io_long  DOUBLE PRECISION ,
	curr_ipc_long  DOUBLE PRECISION ,
	curr_lock_long  DOUBLE PRECISION ,
	curr_lwlock_long  DOUBLE PRECISION ,
	
	curr_speed_waitings_correlation DOUBLE PRECISION ,
  
	curr_corr_bufferpin  DOUBLE PRECISION ,
	curr_corr_extension  DOUBLE PRECISION ,
	curr_corr_io  DOUBLE PRECISION ,
	curr_corr_ipc  DOUBLE PRECISION ,
	curr_corr_lock  DOUBLE PRECISION ,
	curr_corr_lwlock  DOUBLE PRECISION
	

);
CREATE INDEX performance_incident_idx ON performance_incident ( priority );
CREATE INDEX performance_incident_start_timepoint_idx ON performance_incident ( start_timepoint );
CREATE INDEX performance_incident_finish_timepointidx ON performance_incident ( finish_timepoint );

--Список queryid для отчета incident_stats
DROP SEQUENCE IF EXISTS incident_stats_current_queryid_seq ; 
CREATE SEQUENCE incident_stats_current_queryid_seq AS smallint INCREMENT BY  1 MINVALUE 0 START WITH 0 ;

DROP TABLE IF EXISTS incident_stats_current_queryid ;
CREATE UNLOGGED TABLE incident_stats_current_queryid 
(
	id smallint DEFAULT nextval('incident_stats_current_queryid_seq') PRIMARY KEY ,
	queryid bigint
);

--Список инцидентов для отчета incidents_to_timepoint
DROP SEQUENCE IF EXISTS incidents_to_timepoint_current_id_seq ; 
CREATE SEQUENCE incidents_to_timepoint_current_id_seq AS smallint INCREMENT BY  1 MINVALUE 0 START WITH 0 ;

DROP TABLE IF EXISTS incidents_to_timepoint ;
CREATE UNLOGGED TABLE incidents_to_timepoint 
(
	id smallint DEFAULT nextval('incidents_to_timepoint_current_id_seq') PRIMARY KEY ,
	incident_id integer
);

--Связь многие-ко-многим инцидент-queryid
DROP TABLE IF EXISTS incidents_queryid ;
CREATE UNLOGGED TABLE incidents_queryid 
(
	incident_id bigint , 
	queryid bigint 
);
ALTER TABLE incidents_queryid ADD CONSTRAINT incidents_queryid_pk PRIMARY KEY ( incident_id , queryid ) ;
ALTER TABLE incidents_queryid ADD CONSTRAINT  incidents_queryid_fk FOREIGN KEY ( incident_id ) REFERENCES performance_incident ( id ) ON DELETE CASCADE ;


--список queryid для инцидентов для формирования списка SQL для отчета 
DROP SEQUENCE IF EXISTS sql_list_for_report_seq ; 
CREATE SEQUENCE sql_list_for_report_seq AS smallint INCREMENT BY  1 MINVALUE 0 START WITH 0 ;

DROP TABLE IF EXISTS sql_list_for_report ;
CREATE UNLOGGED TABLE sql_list_for_report
(
	id smallint DEFAULT nextval('sql_list_for_report_seq') PRIMARY KEY ,
	queryid bigint 
);


	

--стастика по ожиданиям по инцидентам
DROP TABLE IF EXISTS wait_event_type_queryid_stats ;
CREATE UNLOGGED TABLE wait_event_type_queryid_stats
(
	wait_event_type text ,
	queryid bigint , 
	pgpro_pwr_queryid_hex text ,
	calls numeric , 
	waitings numeric , 
	waitings_to_calls numeric , 
	wait_event_type_promile numeric
);

--стастика по ожиданиям по инцидентам для отчета incidents_to_timepoint
DROP TABLE IF EXISTS wait_event_type_queryid_stats_for_incidents_to_timepoint ;
CREATE UNLOGGED TABLE wait_event_type_queryid_stats_for_incidents_to_timepoint 
(
	wait_event_type text ,
	queryid bigint 
);

--количество queryid стастика по событиям ожидания  для отчета incidents_to_timepoint
DROP TABLE IF EXISTS incident_to_timepoint_wait_event_queryid ;
CREATE UNLOGGED TABLE incident_to_timepoint_wait_event_queryid 
(
	wait_event_type text ,
	wait_event text ,
	queryid bigint 
);


/*
--стастика по ожиданиям по инцидентам для ежедневного отчета 
DROP TABLE IF EXISTS daily_wait_event_type_queryid_stats ;
CREATE UNLOGGED TABLE daily_wait_event_type_queryid_stats
(
	start_timepoint timestamptz , 
	priority smallint , 	
	wait_event_type text ,
	queryid bigint , 
	pgpro_pwr_queryid_hex text ,
	calls bigint , 
	waitings bigint , 
	waitings_to_calls DOUBLE PRECISION , 
	wait_event_type_promile DOUBLE PRECISION	
);
CREATE INDEX daily_wait_event_type_queryid_stats_start_timepoint_idx ON daily_wait_event_type_queryid_stats ( start_timepoint );
CREATE INDEX daily_wait_event_type_queryid_stats_priority_idx ON daily_wait_event_type_queryid_stats ( priority );
CREATE INDEX daily_wait_event_type_queryid_stats_wait_event_type_idx ON daily_wait_event_type_queryid_stats ( wait_event_type );
CREATE INDEX daily_wait_event_type_queryid_stats_wait_event_queryid_idx ON daily_wait_event_type_queryid_stats ( queryid );
*/



DROP TABLE IF EXISTS monitoring_queryid ;
CREATE UNLOGGED TABLE monitoring_queryid 
(
	id integer PRIMARY KEY , 
	dbid oid , 
	userid oid , 
	queryid bigint 
);

DROP TABLE IF EXISTS monitoring_queryid_stats ;
CREATE UNLOGGED TABLE monitoring_queryid_stats 
(
	max_id integer ,
	current_id integer ,
	pct_id DOUBLE PRECISION 
);

DROP TABLE IF EXISTS queryid_for_monitoring ; 
CREATE UNLOGGED TABLE queryid_for_monitoring
(  
  dbid oid , 
  userid oid ,
  queryid bigint 
);

--Массив queryid для расчета медианного времени выполнения
DROP TABLE IF EXISTS benchmark_queries ; 
CREATE UNLOGGED TABLE benchmark_queries
(  
  query text , 
  dbid oid , 
  userid oid ,
  queryid bigint 
);

--Массив dbid для мониторинга производительности
DROP TABLE IF EXISTS dbid_for_monitoring ; 
CREATE UNLOGGED TABLE dbid_for_monitoring
(  
  datname name , 
  dbid oid 
);
