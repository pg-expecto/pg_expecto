----------------------------------------------------------------------------------------------------------------
-- сервисные функции 
-- pg_hazel_service.sql
-- psql -d pgpropwr -f pg_hazel_service.sql
-- version 8.0


CREATE OR REPLACE FUNCTION get_query_by_id( current_queryid bigint ) RETURNS text AS $$
DECLARE
 current_query text ;
 current_queryid_md5 text ;
BEGIN
	current_query = ' ';
	SELECT distinct queryid_md5 
	INTO current_queryid_md5
	FROM profile.sample_statements 
	WHERE queryid = current_queryid;
RAISE NOTICE 'current_queryid_md5 = % ' , current_queryid_md5;

	SELECT query 
	INTO   current_query
	FROM profile.stmt_list 
	WHERE queryid_md5 = current_queryid_md5;
 
  return current_query ; 
END
$$ LANGUAGE plpgsql ;


