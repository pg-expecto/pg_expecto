﻿-- pg_hazel_tables.sql
-- version 77.0
-------------------------------------------------------------------------------------
-- Таблицы и индексы
--Конфигурационные параметры
DROP TABLE IF EXISTS configuration ; 
CREATE UNLOGGED TABLE configuration
(  
  curr_description text , 
  curr_version SERIAL PRIMARY KEY ,
  curr_timestamp timestamp with time zone DEFAULT now()  ,
  is_24_7 boolean DEFAULT TRUE ,
  day_for_store integer DEFAULT 3 , 
  day_for_store_performance_stats integer DEFAULT 7 , 
  last_pgpro_pwr_snapshot timestamp with time zone,
  cluster_reset_flag BOOLEAN DEFAULT TRUE , 
  sql_reset_flag BOOLEAN DEFAULT TRUE ,
  performane_incident_p3_started timestamp with time zone ,
  performane_incident_p4_started timestamp with time zone ,
  has_data_collection_been_stopped boolean DEFAULT FALSE 
);



--Снимок представления pg_stat_activity
DROP TABLE IF EXISTS activity_snapshot;
CREATE UNLOGGED TABLE activity_snapshot
(
 datid            oid ,                     
 datname          name ,                    
 pid              integer                  ,
 usesysid         oid                      ,
 usename          name                     ,
 application_name text                     ,
 client_addr      inet                     ,
 client_hostname  text                     ,
 client_port      integer                  ,
 backend_start    timestamp with time zone ,
 xact_start       timestamp with time zone ,
 query_start      timestamp with time zone ,
 state_change     timestamp with time zone ,
 wait_event_type  text                     ,
 wait_event       text                     ,
 state            text                     ,
 backend_xid      xid                      ,
 backend_xmin     xid                      ,
 query            text                     ,
 backend_type     text                     ,
 blocking_pids	  integer[]
);

--Снимок представления pg_locks
DROP TABLE IF EXISTS locks_snapshot;
CREATE UNLOGGED TABLE locks_snapshot
(
  w_pid integer,
  w_mode text, 
  b_pid integer,
  b_mode text, 
  w_locktype text,
  w_database oid,
  w_relation oid,
  w_page integer ,
  w_tuple smallint ,
  w_virtualxid text,
  w_transactionid xid, 
  w_classid  oid , 
  w_objid  oid  , 
  w_objsubid smallint ,
  w_virtualtransaction text ,   
  b_virtualtransaction text,   
  b_fastpath boolean
);

--Результаты корреляционного анализа 
DROP TABLE IF EXISTS correlation_analysis;
CREATE UNLOGGED TABLE correlation_analysis
(
	wait_event_type text , 
	wait_event text ,
	queryid bigint[]
);

ALTER TABLE correlation_analysis ADD CONSTRAINT correlation_analysis_pk PRIMARY KEY (wait_event_type , wait_event);

--Результаты корреляционного анализа Баз Данных
DROP TABLE IF EXISTS db_correlation_analysis;
CREATE UNLOGGED TABLE db_correlation_analysis
(
	test_dbname name 
);

DROP TABLE IF EXISTS correlation_queryid ;
CREATE TABLE correlation_queryid 
(
	queryid bigint 
);
ALTER TABLE correlation_queryid ADD CONSTRAINT correlation_queryid_pk PRIMARY KEY (queryid);
	

-- Таблицы и индексы
-------------------------------------------------------------------------------------
