#!/bin/sh
# pg_hazel_version.sh 
performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'
echo 'PG_HAZEL VERSIONS'
psql -d $performance_monitoring_db -U $performance_monitoring_user -qtc 'SELECT * FROM jsonb_each (pg_hazel_version()) ORDER BY 2 DESC ' 

echo 'REPORTS VERSION'
psql -d $performance_monitoring_db -U $performance_monitoring_user -qtc 'SELECT * FROM jsonb_each (pg_report_version()) ORDER BY 2 DESC ' 


echo 'STRESS_TESTER VERSION'
psql -d $performance_monitoring_db -U $performance_monitoring_user -qtc 'SELECT * FROM jsonb_each (pg_stress_tester_version()) ORDER BY 2 DESC ' 

echo 'PGPRO_PWR VERSIONS'
psql -d $performance_monitoring_db -U $performance_monitoring_user -qtc 'SELECT * FROM jsonb_each (pg_pro_pwr_version()) ORDER BY 2 DESC ' 

