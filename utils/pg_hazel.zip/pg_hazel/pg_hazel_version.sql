﻿-- pg_hazel_version.sql
------------------------------------------------------------------------------------
--Версия 
CREATE OR REPLACE FUNCTION pg_hazel_version() RETURNS JSONB AS $$
BEGIN
RETURN 
jsonb_build_object('pg_hazel_version' , '081.4' ) ||
jsonb_build_object('pg_hazel_install.sh' , '081.3' ) ||
jsonb_build_object('pg_hazel_kb_fill.sql' , '081.3' ) ||
jsonb_build_object('pg_hazel_kb_functions.sql' , '081.2' ) ||
jsonb_build_object('pg_hazel_cluster.sh' , '078.1' ) || 
jsonb_build_object('deferred_strategy.sql' , '078.0' ) ||
jsonb_build_object('pg_hazel_functions.sql' , '077.7' ) ||
jsonb_build_object('stat_statement_tables.sql' , '077.6' ) ||
jsonb_build_object('stat_statement_functions.sql' , '077.6' ) ||
jsonb_build_object('stat_cluster_functions.sql' , '077.6' ) ||
jsonb_build_object('pg_hazel_sql.sh' , '077.6' ) ||
jsonb_build_object('pg_hazel_tables.sql' , '077.0' ) ||
jsonb_build_object('pg_hazel_performance_monitoring_functions.sql' , '077.0' ) ||
jsonb_build_object('pgpro_pwr_snapshot.sh' , '076.2' ) ||
jsonb_build_object('stat_os_tables.sql' , '075.0' ) ||
jsonb_build_object('stat_os_functions.sql' , '075.0' ) ||
jsonb_build_object('get_iostat_info.sh' , '061.0' ) ||
jsonb_build_object('stat_cluster_tables.sql' , '060.0' ) ||
jsonb_build_object('pg_hazel_db.sql' , '001.0.0' ) || 
jsonb_build_object('pg_hazel_performance_monitoring_tables.sql' , '040.1' ) ||
jsonb_build_object('pg_hazel_service.sql' , '008.0' ) ||
jsonb_build_object('pg_hazel.sql' , '014.0' ) ||
jsonb_build_object('smart_black_box_activity.sql' , '001.0' ) ||
jsonb_build_object('smart_black_box_locks.sql' , '001.0' ) ||
jsonb_build_object('stat_benchmark.sql' , '010.0') ||
jsonb_build_object('stat_timer_functions.sql' , '006.1.' ) ||
jsonb_build_object('stat_timer_tables.sql' , '001.0.0' ) 
;
END
$$ LANGUAGE plpgsql IMMUTABLE;
