﻿-- pg_pro_pwr_version.sql
------------------------------------------------------------------------------------
--Версия 
CREATE OR REPLACE FUNCTION pg_pro_pwr_version() RETURNS JSONB AS $$
BEGIN
RETURN 
jsonb_build_object('create_pgpro_pwr_baseline_by_desc.sh' , '007.0' ) ||
jsonb_build_object('create_pgpro_pwr_baseline_diff_report.sh' , '007.0' ) ||
jsonb_build_object('create_pgpro_pwr_baseline_report.sh' , '007.0' ) ||
jsonb_build_object('create_pgpro_pwr_baseline.sh' , '007.0' ) ||
jsonb_build_object('create_pgpro_pwr_diff_report.sh' , '007.0' ) ||
jsonb_build_object('create_pgpro_pwr_report.sh' , '007.0' ) ||
jsonb_build_object('last_hour.sh' , '007.0' ) ||
jsonb_build_object('show_pgpro_pwr_baseline.sh' , '007.0' ) ||
jsonb_build_object('show_samples.sh' , '007.0' );

END
$$ LANGUAGE plpgsql IMMUTABLE;
