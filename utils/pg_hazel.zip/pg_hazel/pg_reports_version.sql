﻿-- pg_reports_version.sql
------------------------------------------------------------------------------------
--Версия 
CREATE OR REPLACE FUNCTION pg_report_version() RETURNS JSONB AS $$
BEGIN
RETURN 
 jsonb_build_object('summary.sh' , '081.4' ) ||     
 jsonb_build_object('performance_report.sh' , '081.4' ) ||   
 jsonb_build_object('alerts_report.sh' , '081.3' ) ||
 jsonb_build_object('alerts_report_src.sh' , '081.3' ) ||
 jsonb_build_object('vmstat_iostat.sql' , '081.3' ) ||
 jsonb_build_object('vmstat_io.sql' , '081.3' ) || 
 jsonb_build_object('vmstat_cpu.sql' , '081.3' ) || 
 jsonb_build_object('vmstat_ram.sql' , '081.3' ) ||    
 jsonb_build_object('wait_event_for_deepseek.sql' , '081.3' ) ||  
 jsonb_build_object('stress_report.sh' , '081.2' ) || 
 jsonb_build_object('get_hour_before.sql' , '081.1' ) ||   
 jsonb_build_object('wait_event_queryid_for_deepseek' , '081.1' ) ||  
 jsonb_build_object('prepare_performance_report.sh' , '078.1' ) ||    
 jsonb_build_object('wait_event_queryid_for_period_stats.sql' , '078.1' ) ||  
 jsonb_build_object('correlation.sql' , '074.3' ) ||   
 jsonb_build_object('queryid_stat.sql' , '073.0' ) ||  
 jsonb_build_object('make_summary.sh' , '073.0' ) ||  
 jsonb_build_object('sql_list_for_period.sql' , '070.0' ) || 
 jsonb_build_object('wait_event_queryid_for_period.sql' , '070.1' ) ||  
 jsonb_build_object('incidents_report.sql' , '070.0' ) || 
 jsonb_build_object('clear_report_dir.sh' , '070.0' ) ||  
 jsonb_build_object('test_queires.sh' , '070.0' ) ||  
 jsonb_build_object('incidents_report.sh' , '070.0' ) ||  
 jsonb_build_object('cluster_performance.sh' , '044.0' ) ||   
 jsonb_build_object('cluster_performance.sql' , '066.0' ) ||  
 jsonb_build_object('mixwmt_wcpu_report.sql' , '065.0' ) ||  
 jsonb_build_object('mixwmt_report.sql' , '065.0' ) ||   
 jsonb_build_object('stress_report.sql' , '065.0' ) ||     
 jsonb_build_object('iostat_device.sql' , '061.0' ) ||
 jsonb_build_object('vmstat.sql' , '062.0' ) ||
 jsonb_build_object('iostat_cpu.sql' , '062.0' ) ||
 jsonb_build_object('iostat_cpu.sh' , '061.0' ) || 
 jsonb_build_object('iostat_device.sh' , '064.0' ) ||  
 jsonb_build_object('vmstat.sh' , '061.0' ) || 
 jsonb_build_object('queryid_stat.sh' , '060.0' ) || 
 jsonb_build_object('mix_report.sql' , '051.0' ) ||
 jsonb_build_object('are_cluster_wait_correlated.sql' , '044.0' ) ||   
 jsonb_build_object('incident_waitings_queryid_report.sql' , '040.1' ) ||  
 jsonb_build_object('incident_to_timepoint_wait_event_queryid_counts.sql' , '040.0' ) ||  
 jsonb_build_object('incident_to_timepoint_wait_queryid_count.sql' , '040.0' ) || 
 jsonb_build_object('incidents_query_counts.sql' , '037.2' ) || 
 jsonb_build_object('query_incident_counts.sql' , '037.2' ) || 
 jsonb_build_object('get_queryid_count_for_incidents.sql' , '036.1' ) ||
 jsonb_build_object('are_incident_wait_correlated.sql' , '036.1' ) ||
 jsonb_build_object('sql_list_for_report_prepare_id_list.sql' , '040.1' ) || 
 jsonb_build_object('sql_list_for_report_header.sql' , '036.1' ) ||
 jsonb_build_object('sql_list_for_report_list_size.sql' , '036.1' ) ||
 jsonb_build_object('sql_list_for_report_next_by_index.sql' , '036.1' ) ||
 jsonb_build_object('incidents_to_timepoint_prepare_id_list.sql' , '036.0' ) ||
 jsonb_build_object('incidents_to_timepoint_report_header.sql' , '040.1' ) ||
 jsonb_build_object('incidents_to_timepoint_list_size.sql' , '036.0' ) ||
 jsonb_build_object('incidents_to_timepoint_list_next_by_index.sql' , '036.0' ) ||
 jsonb_build_object('incident_wait_event_queryid_stats.sql' , '035.1' ) ||
 jsonb_build_object('incident_waitings_prepare_queryid_list.sql' , '040.0' ) ||
 jsonb_build_object('incident_waitings_queryid_list_next_by_index.sql' , '035.0' ) ||
 jsonb_build_object('incident_waitings_queryid_list_size.sql' , '035.0' ) ||
 jsonb_build_object('incident_waitings_queryid_report_header.sql' , '035.1' ) ||
 jsonb_build_object('incident_waitings_queryid.sql' , '040.1' ) ||
 jsonb_build_object('incident_wait_event_queryid_stats.sql' , '034.0' ) || 
 jsonb_build_object('weekly_incident_analysis.sh' , '033.0' ) ||   
 jsonb_build_object('incidents_to_timepoint.sh' , '040.1' ) ||  
 jsonb_build_object('incident_analysis.sh' , '038.0' ) || 
 jsonb_build_object('daily_incidents_report.sh' , '038.0' ) ||
 jsonb_build_object('daily_incidents_report.sql' , '038.0' ) ||  
 jsonb_build_object('incident_stats.sh' , '040.1' ) ||  
 jsonb_build_object('incident_stats.sql' , '037.0' )   
 ;
END
$$ LANGUAGE plpgsql IMMUTABLE;
