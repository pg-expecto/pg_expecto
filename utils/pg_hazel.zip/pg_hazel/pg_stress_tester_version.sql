﻿-- pg_stress_tester_version.sql
------------------------------------------------------------------------------------
--Версия 
CREATE OR REPLACE FUNCTION pg_stress_tester_version() RETURNS JSONB AS $$
BEGIN
RETURN 
jsonb_build_object('pg_stat_tester.sh' , '081.2' ) ||
jsonb_build_object('tables_functions.sql' , '067.0' ) ||
jsonb_build_object('pg_stat_tester_install.sh' , '059.0' ) ||
jsonb_build_object('pg_stat_tester.init_pgbench.sh' , '058.0' ) ||
jsonb_build_object('pg_stat_tester.create_db.sh' , '058.0' ) ||
jsonb_build_object('do_customized_test.sql' , '058.0' ) ||
jsonb_build_object('customized_test.sql' , '058.0' ) ||
jsonb_build_object('custom_test.sql' , '058.0' ) ||
jsonb_build_object('vacuum_analyze.sh' , '056.0' ) ||
jsonb_build_object('pg_stat_tester_stop.sh' , '053.0' ) ||
jsonb_build_object('stress.sh' , '053.0' ) ||
jsonb_build_object('custom_test.1.sql' , '053.0' ) ||
jsonb_build_object('custom_test.2.sql' , '053.0' ) ||
jsonb_build_object('custom_test.3.sql' , '053.0' ) ||
jsonb_build_object('custom_test.4.sql' , '053.0' ) ||
jsonb_build_object('mixwmt.custom_test.1.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.custom_test.2.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.custom_test.3.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.custom_test.4.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.do_custom_test.1.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.do_custom_test.2.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.do_custom_test.3.sql' , '052.0' ) ||
jsonb_build_object('mixwmt.do_custom_test.4.sql' , '052.0' ) ||
jsonb_build_object('do_custom_test.1.sql' , '051.0' ) ||
jsonb_build_object('do_custom_test.2.sql' , '051.0' ) ||
jsonb_build_object('do_custom_test.3.sql' , '051.0' ) ||
jsonb_build_object('do_custom_test.4.sql' , '051.0' ) ||
jsonb_build_object('mix.custom_test1.sql' , '051.0' ) ||
jsonb_build_object('mix.custom_test2.sql' , '051.0' ) ||
jsonb_build_object('mix.custom_test3.sql' , '051.0' ) ||
jsonb_build_object('mix.custom_test4.sql' , '051.0' ) || 
jsonb_build_object('stress_start.sh' , '050.0' ) ||
jsonb_build_object('finish_test.sh' , '005.0' ) ||
jsonb_build_object('get_conf_param.sh' , '005.0' ) ||
jsonb_build_object('pg_stats_tester_version.sh' , '005.0' ) ||
jsonb_build_object('stress_start_custom.sh' , '005.0' ) ||
jsonb_build_object('do_custom_test.sql' , '005.0' ) ||
jsonb_build_object('is_test_could_be_finished.sql' , '005.0' ) ||
jsonb_build_object('pg_stats_tester_version.sql' , '005.0' ) ||
jsonb_build_object('start_collect_data.sql' , '005.0' ) ||
jsonb_build_object('stop_collect_data.sql' , '005.0' ) ||
jsonb_build_object('user_test.101.sql' , '005.0' ) ||
jsonb_build_object('user_test.102.sql' , '005.0' ) ||
jsonb_build_object('user_test.sql' , '005.0' ) 
;

END
$$ LANGUAGE plpgsql IMMUTABLE;
