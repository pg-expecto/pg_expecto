#create_pgpro_pwr_baseline_by_desc.sh
#Зафиксировать baseline по описанию (номер задачи в Open Project)  
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/create_pgpro_pwr_baseline_by_desc.log'
ERR_FILE=$current_path'/create_pgpro_pwr_baseline_by_desc.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE
echo -n > $ERR_FILE

echo 'Start ID:'
read start_id

echo 'End ID:'
read end_id

echo 'Description:'
read task_desc

baseline_name="'$task_desc'"
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : baseline_name='"$baseline_name">> $LOG_FILE

psql -d pgpropwr -Atqc 'select profile.create_baseline('"$baseline_name"' , '"$start_id"','"$end_id"' )' >> $LOG_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
	echo 'ERROR : profile.create_baseline TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : profile.create_baseline TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
fi

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR BASELINE '$baseline_name' HAS BEEN CREATED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR BASELINE '$baseline_name' HAS BEEN CREATED' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 