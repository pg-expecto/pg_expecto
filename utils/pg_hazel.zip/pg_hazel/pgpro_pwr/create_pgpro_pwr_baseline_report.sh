#create_pgpro_pwr_baseline_report.sh
#Сформировать отчет pgpro_pwr для baseline
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/create_pgpro_pwr_baseline_report.log'
ERR_FILE=$current_path'/create_pgpro_pwr_baseline_report.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE
echo -n > $ERR_FILE

echo 'baseline:'
read baseline_name

REPORT_FILE=$current_path'/pgpro_pwr_baseline.'$baseline_name'.html'

baseline_name="'$baseline_name'"

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : baseline_name='"$baseline_name">> $LOG_FILE

psql -d pgpropwr -Atqc 'select profile.get_report('"$baseline_name"' )' -o $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
	echo 'ERROR : profile.get_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : profile.get_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE /tmp/

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to /tmp '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to /tmp '>> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 