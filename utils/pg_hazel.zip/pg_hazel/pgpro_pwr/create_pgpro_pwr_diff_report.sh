#create_pgpro_pwr_diff_report.sh
#Сформировать разностный отчет pgpro_pwr
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/create_pgpro_pwr_diff_report.log'
ERR_FILE=$current_path'/create_pgpro_pwr_diff_report.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE
echo -n > $ERR_FILE

echo 'Start1 ID:'
read start1_id

echo 'End1 ID:'
read end1_id

echo 'Start2 ID:'
read start2_id

echo 'End2 ID:'
read end2_id

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start1_id='"$start1_id">> $LOG_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : end1_id='"$end1_id">> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start2_id='"$start2_id">> $LOG_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : end2_id='"$end2_id">> $LOG_FILE


REPORT_FILE=$current_path'/pgpro_pwr_diff.'"$start1_id"'-'"$end1_id"'-'"$start2_id"'-'"$end2_id"'.html'
psql -d pgpropwr -Atqc 'select profile.get_diffreport('"$start1_id"','"$end1_id"','"$start2_id"','"$end2_id"' )' -o $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
	echo 'ERROR : profile.get_diffreport TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : profile.get_diffreport TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE /tmp/

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR DIFF REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to /tmp '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR DIFF REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to /tmp '>> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 