#create_pgpro_pwr_report.sh
#Сформировать отчет pgpro_pwr
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/create_pgpro_pwr_report.log'
ERR_FILE=$current_path'/create_pgpro_pwr_report.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE
echo -n > $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : $1='$1
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : $1='$1 >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : $2='$2
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : $2='$2 >> $LOG_FILE

start_id=$1
if [ "$start_id" == "" ]
then 
	echo 'Start ID:'
	read start_id
fi

end_id=$2
if [ "$end_id" == "" ]
then 
	echo 'End ID:'
	read end_id
fi

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_id='"$start_id"
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_id='"$start_id">> $LOG_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : end_id='"$end_id"
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : end_id='"$end_id">> $LOG_FILE

REPORT_FILE=$current_path'/pgpro_pwr.'"$start_id"'-'"$end_id"'.html'
psql -d pgpropwr -Atqc 'select profile.get_report('"$start_id"','"$end_id"' )' -o $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
	echo 'ERROR : profile.get_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : profile.get_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
fi

chmod 777 $REPORT_FILE

REPORT_DIR=$3
if [ "$REPORT_DIR" == "" ]
then 
	mv $REPORT_FILE /tmp/

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to /tmp '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to /tmp '>> $LOG_FILE
else    
	mv $REPORT_FILE $REPORT_DIR

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE 
 
	find $REPORT_DIR -type f -mtime +7 -delete >> $LOG_FILE 2>>$ERR_FILE	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : OLD PGPRO_PWR REPORT FILES IN  '$REPORT_DIR' HAS BEEB DELETED'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_PWR REPORT FILES IN  '$REPORT_DIR' HAS BEEB DELETED' >> $LOG_FILE 
 
fi
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 