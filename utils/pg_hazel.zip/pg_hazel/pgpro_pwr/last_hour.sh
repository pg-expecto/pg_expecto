#last_hour.sh
#Сформировать отчет за прошедший час
#0 * * * * /postgres/scripts/pgpro_pwr/last_hour.sh /tmp/reports/
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`
timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M%S")
LOG_FILE=$current_path'/last_hour.log'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE

psql -d pgpropwr -c 'SELECT sample , sample_time FROM profile.show_samples()' > $current_path'/samples.txt'
if [ $? -ne 0 ]
then
	echo 'ERROR : last_hour TERMINATED WITH ERROR '
	echo 'ERROR : last_hour TERMINATED WITH ERROR ' >> $LOG_FILE
	exit 100
fi

last_sample=`tail -3 /postgres/scripts/pgpro_pwr/samples.txt | head -1 | awk -F '|' '{print $1}' | tr -d " "`
echo "last_sample="$last_sample
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : last_sample='$last_sample >> $LOG_FILE
let "start_sample=$last_sample - 6"
echo "start_sample="$start_sample
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_sample='$start_sample >> $LOG_FILE

REPORT_DIR=$1
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT_DIR =  '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : REPORT_DIR =  '$REPORT_DIR >> $LOG_FILE

$current_path'/create_pgpro_pwr_report.sh' $start_sample $last_sample $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 