#show_pgpro_pwr_baseline.sh
#Показать список baseline
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/show_pgpro_pwr_baseline.log'
ERR_FILE=$current_path'/show_pgpro_pwr_baseline.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE
echo -n > $ERR_FILE


psql -d pgpropwr -Atqc 'select profile.show_baselines()' > $current_path'/baselines.txt'
if [ $? -ne 0 ]
then
	echo 'ERROR : profile.show_baselines TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : profile.show_baselines TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
fi

more $current_path'/baselines.txt'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 