#show_samples.sh
#Показать полный список снимков
# version 7.0

script=$(readlink -f $0)
current_path=`dirname $script`
timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M%S")
LOG_FILE=$current_path'/show_samples.log'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE

echo 'Дата снимка (YYYY-MM-DD):'
read sample_day

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : sample_day='$sample_day >> $LOG_FILE

psql -d pgpropwr -c 'SELECT sample , sample_time FROM profile.show_samples()' > $current_path'/samples.txt'
if [ $? -ne 0 ]
then
	echo 'ERROR : show_samples TERMINATED WITH ERROR '
	echo 'ERROR : show_samples TERMINATED WITH ERROR ' >> $LOG_FILE
	exit 100
fi

cat $current_path'/samples.txt' | grep $sample_day | more 

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE

exit 0 