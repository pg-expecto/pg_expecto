#!/bin/sh
# pgpro_pwr_snapshot.sh
# version 76.3
 
#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE

    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'


LOG_FILE=$current_path'/take_sample.log'
ERR_FILE=$current_path'/take_sample.psql.err'

PG_HAZEL_LOG_FILE=$current_path'/pg_hazel_cluster.log'
PG_HAZEL_ERR_FILE=$current_path'/pg_hazel_cluster.err'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : profile.take_sample STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : profile.take_sample STARTED' > $LOG_FILE

psql -d "dbname=pgpropwr application_name=take_sample" -c "SELECT * FROM profile.take_sample('local', true)" >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE	
take_sample_result=`cat $current_path'/take_sample.log' | head -4 | tail -1 | grep "OK" | wc -l`
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : INFO : profile.take_sample FINISHED WITH RESULT '$take_sample_result
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : INFO : profile.take_sample FINISHED WITH RESULT '$take_sample_result >> $LOG_FILE

if [[ $take_sample_result == "0" ]]
then 
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ALARM : profile.take_sample ERROR . Details in take_sample.log '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ALARM : profile.take_sample ERROR . Details in take_sample.log ' >> $LOG_FILE
  cat $LOG_FILE >> $PG_HAZEL_LOG_FILE
  cat $LOG_FILE >> $PG_HAZEL_ERR_FILE
 exit 1
fi 

cp -f $LOG_FILE /postgres/scripts/pgpro_pwr/
cp -f $ERR_FILE /postgres/scripts/pgpro_pwr/

sample_time=`psql -d pgpropwr -Aqtc "SELECT date_trunc('minute',sample_time) FROM profile.show_samples() ORDER BY 1 DESC LIMIT 1"`>> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_pwr_sample= '$sample_time
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_pwr_sample= '$sample_time >> $LOG_FILE  

############################
# Сохранить снимок pgpro_pwr
psql -d $performance_monitoring_db -U $performance_monitoring_user  -Aqtc "SELECT save_pgpro_pwr_samples('$sample_time')">> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : save_pgpro_pwr_samples '$sample_time
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : save_pgpro_pwr_samples '$sample_time >> $LOG_FILE  
# Обновить снимок stat_statement 
###########################

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : LOG FILES HAVE BEEN COPIED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : LOG FILES HAVE BEEN COPIED' >> $LOG_FILE


exit 0 