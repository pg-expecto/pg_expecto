#!/bin/sh
# clear_report_dir.sh
# mkdir /postgres/scripts/tester/reports

REPORT_DIR='/tmp/performance_reports/'

rm /tmp/performance_reports/*.txt
#rm /tmp/performance_reports/*.html

exit 0 


