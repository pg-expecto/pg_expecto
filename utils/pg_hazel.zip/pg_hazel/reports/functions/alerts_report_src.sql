----------------------------------------------------
-- alerts_report_src.sql
-- version 81.3


CREATE OR REPLACE FUNCTION alerts_report_src( cpu_count integer , start_timestamp text , finish_timestamp text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;

 si_count numeric ;
 so_count numeric ;
 r_count numeric ;
 wa_count numeric ;
 id_count numeric ;
 st_count numeric ;
 st_0_5_count integer ;
 st_5_count integer ;
 st_10_count integer ;
 
 
 
 os_stat_vmstat_analysis_rec record ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;

 counter integer ; 
 
 swap_count integer ;
 io_count integer ; 
 
 swap_count_pct DOUBLE PRECISION ;
 io_count_pct DOUBLE PRECISION ;
 cpu_count_pct DOUBLE PRECISION ;
 st_0_5_count_pct DOUBLE PRECISION ;
 st_5_count_pct DOUBLE PRECISION ;
 st_10_count_pct DOUBLE PRECISION ;
 
BEGIN
    IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;
	
    line_count = 1 ;
	
	
	result_str[line_count] = 'ALERTS REPORT VMSTAT SOURCE' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'alerts_report_src.sh' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'CPU' ; 
	line_count=line_count+1;
	result_str[line_count] = cpu_count ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+2; 
	
	
	result_str[line_count] = 	'timestamp '||'|'||
								'si' ||'|'||
								'so' ||'|'||
								'SWAP' ||'|'||
								'r' ||'|'||
								'wa' ||'|'||
								'IO' ||'|'||
								'r' ||'|'||
								'id' ||'|'||
								'CPU' ||'|'||
								'st' ||'|'||
								'RESOURCE' ||'|'
								;							
	line_count=line_count+1; 


	counter = 0 ;	
	swap_count = 0 ;	
	io_count = 0 ;	
	cpu_count = 0 ;	
	st_0_5_count = 0 ;
	st_5_count = 0 ;
	st_10_count = 0 ;
	
	SELECT count(cl.curr_timestamp) 
	INTO counter
	FROM os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp;
--RAISE NOTICE 'counter = %',counter; 		
 
	FOR os_stat_vmstat_analysis_rec IN
	SELECT 
		cl.curr_timestamp
	FROM 
		os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
    ORDER BY cl.curr_timestamp 
	LOOP
		result_str[line_count] = to_char( os_stat_vmstat_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'
								;

		--SWAP
		SELECT 
			s.vmstat_analysis_swap_si_source 
		INTO 
			si_count
		FROM 
			os_stat_vmstat_analysis s
		WHERE 			
			s.curr_timestamp = os_stat_vmstat_analysis_rec.curr_timestamp ;
	    
		SELECT 
			s.vmstat_analysis_swap_so_source
		INTO 
			so_count
		FROM 
			os_stat_vmstat_analysis s
		WHERE 
			s.curr_timestamp = os_stat_vmstat_analysis_rec.curr_timestamp ;
		
		IF si_count = 0 AND so_count = 0 
		THEN
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( si_count  , 2) , '000000000000D0000' ) , '.' , ',' ) 
									||'|' || 
									REPLACE ( TO_CHAR( ROUND( so_count  , 2) , '000000000000D0000' ) , '.' , ',' ) 
									||' | OK |' ;
		ELSE
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( si_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||'|' || 
									REPLACE ( TO_CHAR( ROUND( so_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | ALERT |' ;
			swap_count = swap_count + 1 ;
		END IF ;
		--SWAP	
		
		--IO
		SELECT 
			s.vmstat_analysis_procs_r_source 
		INTO 
			r_count
		FROM 
			os_stat_vmstat_analysis s
		WHERE 
			s.curr_timestamp = os_stat_vmstat_analysis_rec.curr_timestamp ;
			
		SELECT 
			s.vmstat_analysis_cpu_wa_source
		INTO 
			wa_count
		FROM 
			os_stat_vmstat_analysis s
		WHERE 
			s.curr_timestamp = os_stat_vmstat_analysis_rec.curr_timestamp ;
			
		IF r_count > cpu_count*4 AND wa_count > 10 
		THEN
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( r_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||'|' || 
									REPLACE ( TO_CHAR( ROUND( wa_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | ALERT |' ;
			io_count = io_count + 1  ;	 
		ELSE
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( r_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||'|' || 
									REPLACE ( TO_CHAR( ROUND( wa_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | OK |' ;
		END IF ;	
		--IO
		
		--CPU
		SELECT 
			s.vmstat_analysis_cpu_id_long
		INTO 
			id_count
		FROM 
			os_stat_vmstat_analysis s
		WHERE 
			s.curr_timestamp = os_stat_vmstat_analysis_rec.curr_timestamp ;
			
		IF r_count > r_count*4 AND id_count > 10 
		THEN
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( r_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||'|' || 
									REPLACE ( TO_CHAR( ROUND( id_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | ALERT |' ;
			cpu_count = cpu_count + 1  ;	
 
		ELSE
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( r_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||'|' || 
									REPLACE ( TO_CHAR( ROUND( id_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | OK |' ;
		END IF ;	
		--CPU
		
		--ST
		SELECT 
			s.vmstat_analysis_cpu_st_source 
		INTO 
			st_count
		FROM 
			os_stat_vmstat_analysis s
		WHERE 
			s.curr_timestamp = os_stat_vmstat_analysis_rec.curr_timestamp ;
					
		IF st_count <= 5 
		THEN
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( st_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | OK |' ;
			st_0_5_count = st_0_5_count + 1 ; 
		ELSIF st_count > 5 AND st_count <=10 
		THEN 
			result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( st_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | WARNING |' ;
			st_5_count = st_5_count + 1 ;
		ELSE 
					result_str[line_count] = result_str[line_count] || 
									REPLACE ( TO_CHAR( ROUND( st_count  , 2 ) , '000000000000D0000' ) , '.' , ',' ) 
									||' | ALARM |' ;		
			st_10_count = st_10_count + 1 ;
		END IF ;	
		
	  line_count=line_count+1; 	
	
	END LOOP ;
	

	
  return result_str ; 
END
$$ LANGUAGE plpgsql STABLE ;

