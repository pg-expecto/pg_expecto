----------------------------------------------------------------------------------------------------------------
-- are_cluster_wait_correlated.sql
-- version 44.0

CREATE OR REPLACE FUNCTION are_cluster_wait_correlated(  current_wait_event_type text , start_timestamp text , finish_timestamp text ) RETURNS smallint AS $$
DECLARE
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 corr_value DOUBLE PRECISION;
BEGIN
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) 
		INTO 	max_timestamp ; 
	
		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' )
		INTO 	min_timestamp ; 
		
		SELECT 	to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) 
		INTO 	max_timestamp ; 		
	END IF ;
	
	CASE 
		--BufferPin			
		WHEN current_wait_event_type = 'BufferPin' THEN
			WITH 
			waitings AS
			(
				SELECT 
					curr_timestamp , waitings_long  AS waitings_long  
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp
					AND waitings_long > 0
			) ,
			bufferpin_waitings AS
			(
				SELECT 
					curr_timestamp , bufferpin_long  AS bufferpin_long 
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND bufferpin_long > 0 
			) 
			SELECT COALESCE( corr( waitings_long , bufferpin_long ) , 0 ) AS correlation_value 
			INTO corr_value
			FROM
				waitings os JOIN bufferpin_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			
		--Extension	
		WHEN current_wait_event_type = 'Extension' THEN 
			WITH 
			waitings AS
			(
				SELECT 
					curr_timestamp , waitings_long  AS waitings_long  
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp
					AND waitings_long > 0
			) ,
			extension_waitings AS
			(
				SELECT 
					curr_timestamp , extension_long  AS extension_long 
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND extension_long > 0 
			) 
			SELECT COALESCE( corr( waitings_long , extension_long ) , 0 ) AS correlation_value 
			INTO corr_value
			FROM
				waitings os JOIN extension_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
				
		--IO 	
		WHEN current_wait_event_type = 'IO' THEN 
			WITH 
			waitings AS
			(
				SELECT 
					curr_timestamp , waitings_long  AS waitings_long  
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp
					AND waitings_long > 0
			) ,
			io_waitings AS
			(
				SELECT 
					curr_timestamp , io_long  AS io_long 
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND io_long > 0 
			) 
			SELECT COALESCE( corr( waitings_long , io_long ) , 0 ) AS correlation_value 
			INTO corr_value
			FROM
				waitings os JOIN io_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		--IPC
		WHEN current_wait_event_type = 'IPC' THEN
			WITH 
			waitings AS
			(
				SELECT 
					curr_timestamp , waitings_long  AS waitings_long  
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp
					AND waitings_long > 0
			) ,
			ipc_waitings AS
			(
				SELECT 
					curr_timestamp , ipc_long  AS ipc_long 
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND ipc_long > 0 
			) 
			SELECT COALESCE( corr( waitings_long , ipc_long ) , 0 ) AS correlation_value 
			INTO corr_value
			FROM
				waitings os JOIN ipc_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
			
		--Lock	
		WHEN current_wait_event_type = 'Lock' THEN 
			WITH 
			waitings AS
			(
				SELECT 
					curr_timestamp , waitings_long  AS waitings_long  
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp
					AND waitings_long > 0
			) ,
			lock_waitings AS
			(
				SELECT 
					curr_timestamp , lock_long  AS lock_long 
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND lock_long > 0 
			) 
			SELECT COALESCE( corr( waitings_long , lock_long ) , 0 ) AS correlation_value 
			INTO corr_value
			FROM
				waitings os JOIN lock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
			
		--LWLock
		WHEN current_wait_event_type = 'LWLock' THEN
			WITH 
			waitings AS
			(
				SELECT 
					curr_timestamp , waitings_long  AS waitings_long  
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND waitings_long > 0				
			) ,
			lwlock_waitings AS
			(
				SELECT 
					curr_timestamp , lwlock_long  AS lwlock_long 
				FROM pgh_stat_cluster_analysis
				WHERE				
					curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND lwlock_long > 0 
			) 
			SELECT COALESCE( corr( waitings_long , lwlock_long ) , 0 ) AS correlation_value 
			INTO corr_value
			FROM
				waitings os JOIN lwlock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END CASE ;
	
	IF corr_value > 0 
	THEN 
		return 1 ; 
	ELSE 
		return 0 ; 
	END IF ;
		
END
$$ LANGUAGE plpgsql  ;
