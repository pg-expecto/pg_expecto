----------------------------------------------------------------------------------------------------------------
-- are_incident_wait_correlated.sql
-- version 36.1

CREATE OR REPLACE FUNCTION are_incident_wait_correlated(  incident_id bigint  , current_wait_event_type text ) RETURNS smallint AS $$
DECLARE
performance_incident_rec record ;  
BEGIN
	SELECT *
	INTO performance_incident_rec
	FROM performance_incident
	WHERE id = incident_id ; 
	
	CASE 
		--BufferPin			
		WHEN current_wait_event_type = 'BufferPin' THEN
			IF performance_incident_rec.curr_corr_bufferpin > 0 
			THEN 
				return 1 ; 
			ELSE 
				return 0 ; 
			END IF ;
			
		--Extension	
		WHEN current_wait_event_type = 'Extension' THEN 
			IF performance_incident_rec.curr_corr_extension > 0 
			THEN 
				return 1 ; 
			ELSE 
				return 0 ; 
			END IF ;
		--IO 	
		WHEN current_wait_event_type = 'IO' THEN 
			IF performance_incident_rec.curr_corr_io > 0 
			THEN 
				return 1 ; 
			ELSE 
				return 0 ; 
			END IF ;
			
		--IPC
		WHEN current_wait_event_type = 'IPC' THEN 
			IF performance_incident_rec.curr_corr_ipc > 0 
			THEN 
				return 1 ; 
			ELSE 
				return 0 ; 
			END IF ;
			
		--Lock	
		WHEN current_wait_event_type = 'Lock' THEN 
			IF performance_incident_rec.curr_corr_lock > 0 
			THEN 
				return 1 ; 
			ELSE 
				return 0 ; 
			END IF ;
			
		--LWLock
		WHEN current_wait_event_type = 'LWLock' THEN
			IF performance_incident_rec.curr_corr_lwlock > 0 
			THEN 
				return 1 ; 
			ELSE 
				return 0 ; 
			END IF ;
			
	END CASE ;
END
$$ LANGUAGE plpgsql  ;
