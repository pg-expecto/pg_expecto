----------------------------------------------------------------------------------------------------------------
-- ПРОИЗВОДИТЕЛЬНОСТЬ И ОЖИДАНИЯ НА УРОВНЕ КЛАСТЕРА
-- cluster_performance.sql
-- version 66.0
-- 


CREATE OR REPLACE FUNCTION cluster_performance(  cluster_performance_start_timestamp text , cluster_performance_finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
  corr_bufferpin DOUBLE PRECISION ; 
  corr_extension DOUBLE PRECISION ; 
  corr_io DOUBLE PRECISION ; 
  corr_ipc DOUBLE PRECISION ; 
  corr_lock DOUBLE PRECISION ; 
  corr_lwlock DOUBLE PRECISION ; 
  corr_timeout DOUBLE PRECISION ; 
  	
  speed_regr_rec record ;
  waitings_regr_rec record ; 
  
  
  column_count integer ;
  stress_flag BOOLEAN; --TRUE - если отчет составляется по результатам НТ
  min_max_load_rec record ;
  current_test_id integer ;
  current_load_rec record ; 
BEGIN
	line_count = 1 ;
	
	SELECT get_current_test_id()
	INTO current_test_id; 
	
	
	IF cluster_performance_finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( cluster_performance_start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( cluster_performance_start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( cluster_performance_finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'CLUSTER PERFORMANCE' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'cluster_performance' ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 

	line_count=line_count+2; 
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	pgh_stat_cluster_analysis
	WHERE 
		curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;
	
	
	/*
	SELECT (MAX(test.finish_timestamp)= max_timestamp)
	INTO stress_flag
	FROM test_statistics_pass test
	WHERE test_id = current_test_id ; 
	*/
	
	SELECT ( min_timestamp , max_timestamp ) overlaps ( test.start_timestamp , test.finish_timestamp) 
	INTO stress_flag
	FROM test_statistics_pass test
	WHERE test_id = current_test_id ; 



--------------------------------------
-- Cтандартизация z-score
-- 	линия регрессии  скорости  : Y = a + bX
	BEGIN
		WITH stats AS 
		(
		  SELECT 
			AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
			STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
			AVG(s.op_speed_long::DOUBLE PRECISION) as avg2, 
			STDDEV(s.op_speed_long::DOUBLE PRECISION) as std2
		  FROM
			pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
		  WHERE 
			t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		),
		standardized_data AS 
		(
			SELECT 
				(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
				(s.op_speed_long::DOUBLE PRECISION - avg2) / std2 as y_z
			FROM
				pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
			WHERE 
				t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		)	
		SELECT
			REGR_SLOPE(y_z, x_z) as slope, --b
			ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
			REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
		INTO 
			speed_regr_rec
		FROM standardized_data;
	EXCEPTION
	  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
	  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
	    SELECT 
			1.0 as slope, --b
			0.0  as slope_angle_degrees, --угол наклона
			0.0  as r_squared -- Коэффициент детерминации
		INTO 
		speed_regr_rec ;
	END;
-- 	линия регрессии  скорости  : Y = a + bX

-- 	линия регрессии  ожиданий  : Y = a + bX
	BEGIN
		WITH stats AS 
		(
		  SELECT 
			AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
			STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
			AVG(s.waitings_long::DOUBLE PRECISION) as avg2, 
			STDDEV(s.waitings_long::DOUBLE PRECISION) as std2
		  FROM
			pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
		  WHERE 
			t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		),
		standardized_data AS 
		(
			SELECT 
				(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
				(s.waitings_long::DOUBLE PRECISION - avg2) / std2 as y_z
			FROM
				pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
			WHERE 
				t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		)	
		SELECT
			REGR_SLOPE(y_z, x_z) as slope, --b
			ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона		
			REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
		INTO 
			waitings_regr_rec
		FROM standardized_data;
	EXCEPTION
	  --STDDEV(s.waitings_long::DOUBLE PRECISION) = 0  
	  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
	    SELECT 
			1.0 as slope, --b
			0.0  as slope_angle_degrees, --угол наклона
			0.0  as r_squared -- Коэффициент детерминации
		INTO 
		waitings_regr_rec ;
	END;
-- 	линия регрессии  ожиданий  : Y = a + bX

-- Cтандартизация z-score
--------------------------------------
	

	
	line_count=line_count+1; 
	result_str[line_count] = 'ЛИНИЯ РЕГРЕССИИ: Y = a + bX ' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'ОПЕРАЦИОННАЯ СКОРОСТЬ' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'Коэффициент детерминации R^2 ' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_regr_rec.r_squared::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 	
	result_str[line_count] = 'угол наклона ' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_regr_rec.slope_angle_degrees::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	line_count=line_count+1; 
	
	
	result_str[line_count] = 'ОЖИДАНИЯ СУБД' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'Коэффициент детерминации R^2 ' ||'|'|| REPLACE ( TO_CHAR( ROUND( waitings_regr_rec.r_squared::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 	
	result_str[line_count] = 'угол наклона ' ||'|'|| REPLACE ( TO_CHAR( ROUND( waitings_regr_rec.slope_angle_degrees::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	line_count=line_count+1; 

	

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ		
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS operating_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 						
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS curr_waitings_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0 
		) 
		SELECT COALESCE( corr( operating_speed_long , curr_waitings_long ) , 0 ) AS correlation_value 
		INTO speed_waitings_correlation
		FROM
			operating_speed os JOIN waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		bufferpin_waitings AS
		(
			SELECT 
				curr_timestamp , bufferpin_long  AS bufferpin_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND bufferpin_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , bufferpin_long ) , 0 ) AS correlation_value 
		INTO corr_bufferpin
		FROM
			waitings os JOIN bufferpin_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		extension_waitings AS
		(
			SELECT 
				curr_timestamp , extension_long  AS extension_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND extension_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , extension_long ) , 0 ) AS correlation_value 
		INTO corr_extension
		FROM
			waitings os JOIN extension_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		io_waitings AS
		(
			SELECT 
				curr_timestamp , io_long  AS io_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND io_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , io_long ) , 0 ) AS correlation_value 
		INTO corr_io
		FROM
			waitings os JOIN io_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		ipc_waitings AS
		(
			SELECT 
				curr_timestamp , ipc_long  AS ipc_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND ipc_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , ipc_long ) , 0 ) AS correlation_value 
		INTO corr_ipc
		FROM
			waitings os JOIN ipc_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		lock_waitings AS
		(
			SELECT 
				curr_timestamp , lock_long  AS lock_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND lock_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , lock_long ) , 0 ) AS correlation_value 
		INTO corr_lock
		FROM
			waitings os JOIN lock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0				
		) ,
		lwlock_waitings AS
		(
			SELECT 
				curr_timestamp , lwlock_long  AS lwlock_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND lwlock_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , lwlock_long ) , 0 ) AS correlation_value 
		INTO corr_lwlock
		FROM
			waitings os JOIN lwlock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock 
	----------------------------------------------------------------------------------------------------
	
	-- version 60.0
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - timeout
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0				
		) ,
		timeout_waitings AS
		(
			SELECT 
				curr_timestamp , timeout_long  AS timeout_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND timeout_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , timeout_long ) , 0 ) AS correlation_value 
		INTO corr_timeout
		FROM
			waitings os JOIN timeout_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - timeout 
	----------------------------------------------------------------------------------------------------
	
	-- version 60.0
	
	result_str[line_count] = 'КОЭФФИЦИЕНТЫ КОРРЕЛЯЦИИ' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'SPEED - WAITINGS' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_waitings_correlation::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - BUFFERPIN' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_bufferpin::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - EXTENSION' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_extension::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - IO' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_io::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - IPC' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_ipc::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - LOCK' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_lock::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - LWLOCK' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_lwlock::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - TIMEOUT' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_timeout::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	
	
	SELECT 
		MIN( cl.op_speed_short) AS min_op_speed_short , MAX( cl.op_speed_short) AS max_op_speed_short , 
		MIN( cl.op_speed_long) AS min_op_speed_long , MAX( cl.op_speed_long) AS max_op_speed_long , 
		MIN( cl.waitings_long) AS min_waitings_long , MAX( cl.waitings_long) AS max_waitings_long , 
		MIN( cl.bufferpin_long) AS min_bufferpin_long , MAX( cl.bufferpin_long) AS max_bufferpin_long , 
		MIN( cl.extension_long) AS min_extension_long , MAX( cl.extension_long) AS max_extension_long , 
		MIN( cl.io_long) AS min_io_long , MAX( cl.io_long) AS max_io_long , 
		MIN( cl.ipc_long) AS min_ipc_long , MAX( cl.ipc_long) AS max_ipc_long , 
		MIN( cl.lock_long) AS min_lock_long , MAX( cl.lock_long) AS max_lock_long , 
		MIN( cl.lwlock_long) AS min_lwlock_long , MAX( cl.lwlock_long) AS max_lwlock_long ,
		MIN( cl.timeout_long) AS min_timeout_long , MAX( cl.timeout_long) AS max_timeout_long 
	INTO  	min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl 
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
		
	IF stress_flag 
	THEN 
		SELECT 
			MIN(load_connections) AS min_load , MAX(load_connections) AS max_load
		INTO 
			min_max_load_rec
		FROM 
			test_statistics_pass tp
		WHERE 
			tp.test_id = current_test_id AND
			tp.pass_counter >= 6 AND 
			tp.finish_timestamp <= max_timestamp ;	
			
		result_str[line_count] = 	' '||'|'||
									'№'||'|'||		
									'LOAD'||'|'||
									'SPEED '||'|'||
									'WAITINGS' ||'|'||
									'BUFFERPIN ' ||'|'||
									'EXTENSION ' ||'|'||
									'IO ' ||'|'||
									'IPC ' ||'|'||
									'LOCK ' ||'|'||
									'LWLOCK ' ||'|'||
									'TIMEOUT ' ||'|'
									;							
		line_count=line_count+1; 
		
		result_str[line_count] = 	'MIN'||'|'||
									1 ||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_load_rec.min_load::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_op_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_bufferpin_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_extension_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_io_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_ipc_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_lock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_lwlock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_timeout_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
									;							
		line_count=line_count+1; 	
			
	ELSE 
		result_str[line_count] = 	' '||'|'||
									'№'||'|'||		
									'SPEED '||'|'||
									'WAITINGS' ||'|'||
									'BUFFERPIN ' ||'|'||
									'EXTENSION ' ||'|'||
									'IO ' ||'|'||
									'IPC ' ||'|'||
									'LOCK ' ||'|'||
									'LWLOCK ' ||'|'||
									'TIMEOUT ' ||'|'
									;							
		line_count=line_count+1; 
		
		result_str[line_count] = 	'MIN'||'|'||
									1 ||'|'||
									--REPLACE ( TO_CHAR( ROUND( min_max_rec.min_op_speed_short::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_op_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_bufferpin_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_extension_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_io_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_ipc_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_lock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_lwlock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.min_timeout_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
									;							
		line_count=line_count+1; 	
	END IF ;


	
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis
	WHERE 	
		curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	
	IF stress_flag 
	THEN		
		result_str[line_count] = 	'MAX'||'|'||
									line_counter||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_load_rec.max_load::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_op_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_bufferpin_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_extension_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_io_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_ipc_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_lock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_lwlock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_timeout_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
									;							
		line_count=line_count+1; 	
			
	ELSE 
		
		result_str[line_count] = 	'MAX'||'|'||
									line_counter||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_op_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_bufferpin_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_extension_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_io_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_ipc_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_lock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_lwlock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( min_max_rec.max_timeout_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
									;								
		line_count=line_count+2; 
	END IF ;

	
	IF stress_flag 
	THEN
		result_str[line_count] = 	'timestamp'||'|'||  --1
									'№'||'|'||--2	
									'LOAD '||'|'||
									'SPEED '||'|'|| --3
									'WAITINGS' ||'|' --4
									;
	ELSE
		result_str[line_count] = 	'timestamp'||'|'||  --1
									'№'||'|'||--2	
									'SPEED '||'|'|| --3
									'WAITINGS' ||'|' --4
									;
	END IF;
									
								
	IF min_max_rec.max_bufferpin_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'BUFFERPIN ' ||'|' ;
	END IF ;
	
	IF min_max_rec.max_extension_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'EXTENSION ' ||'|' ;
	END IF ;
	
	IF min_max_rec.max_io_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'IO ' ||'|' ;
	END IF ;
	
	IF min_max_rec.max_ipc_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'IPC ' ||'|' ;
	END IF ;
	
	IF min_max_rec.max_lock_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'LOCK ' ||'|' ;
	END IF ;
	
	IF min_max_rec.max_lwlock_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'LWLOCK ' ||'|' ;
	END IF ;
	
	IF min_max_rec.max_timeout_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 'TIMEOUT ' ||'|' ;
	END IF ;
								
	line_count=line_count+1; 
	
	
	
	counter = 0 ; 
	FOR pgh_stat_cluster_analysis_rec IN
	SELECT 
	    ( SELECT 
				load_connections 
		  FROM 	test_statistics_pass test 
		  WHERE test_id = current_test_id AND  
				cl.curr_timestamp BETWEEN test.start_timestamp AND test.finish_timestamp  
		) AS load_connections , 
		cl.curr_timestamp , --1
		cl.op_speed_long AS op_speed_long ,  --2
		cl.waitings_long AS waitings_long  ,--3
		cl.bufferpin_long AS bufferpin_long , --4
		cl.extension_long AS extension_long , --5
		cl.io_long AS io_long , --8
		cl.ipc_long AS ipc_long , --7
		cl.lock_long AS lock_long , --9
		cl.lwlock_long AS lwlock_long, 	 --9
		cl.timeout_long AS timeout_long 	 --10
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
    ORDER BY cl.curr_timestamp 
	LOOP
		counter = counter + 1 ;

		----------------------------------------------------------------------------------------------------

	IF stress_flag 
	THEN

		result_str[line_count] = 	to_char( pgh_stat_cluster_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'|| --1
									counter ||'|'||
									ROUND( pgh_stat_cluster_analysis_rec.load_connections::numeric , 0 ) ||'|'
									;
			
	
		result_str[line_count] = 	result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.op_speed_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| --2
									REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.waitings_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'  --3
									;

	ELSE
		result_str[line_count] = 	to_char( pgh_stat_cluster_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'|| --1
									counter ||'|'||
									REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.op_speed_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| --2
									REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.waitings_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'  --3
									;
	END IF ;
								
								
	IF min_max_rec.max_bufferpin_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.bufferpin_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|';  --4 
	END IF ;
	
	IF min_max_rec.max_extension_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.extension_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|';  --5 
	END IF ;
	
	IF min_max_rec.max_io_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.io_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|';  --6 ;
	END IF ;
	
	IF min_max_rec.max_ipc_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.ipc_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'; --7;
	END IF ;
	
	IF min_max_rec.max_lock_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.lock_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|';  --8;
	END IF ;
	
	IF min_max_rec.max_lwlock_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.lwlock_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'; --9
	END IF ;
	
	IF min_max_rec.max_timeout_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] || 
								 REPLACE ( TO_CHAR( ROUND( pgh_stat_cluster_analysis_rec.timeout_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|';  --10
	END IF ;								
	  line_count=line_count+1; 			
	END LOOP;
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

/*	
	----------------------------------------------------------------------------------------------------
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - СКОРОСТЬ 
	--SELECT COALESCE( regr_slope ( t.curr_timepoint::DOUBLE PRECISION ,  s.op_speed_long::DOUBLE PRECISION ) , 0 )
	SELECT COALESCE( regr_slope ( s.op_speed_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION ) , 0 )
	INTO speed_regr_slope_value
	FROM
		pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
	WHERE 
		t.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - СКОРОСТЬ 
	----------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - ОЖИДАНИЯ 
	--SELECT COALESCE( regr_slope ( t.curr_timepoint::DOUBLE PRECISION ,  s.waitings_long::DOUBLE PRECISION ) , 0 ) 
	SELECT COALESCE( regr_slope ( s.waitings_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION ) , 0 ) 
	INTO waitings_regr_slope_value
	FROM
		pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
	WHERE 
		t.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - ОЖИДАНИЯ
	----------------------------------------------------------------------------------------------------
	
	result_str[line_count] = 'SPEED LINE' ||'|'|| REPLACE ( TO_CHAR( ROUND( atand( speed_regr_slope_value )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS LINE' ||'|'|| REPLACE ( TO_CHAR( ROUND( atand( waitings_regr_slope_value )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+2; 

	result_str[line_count] = 'REGRESSION LINE ANGLE(PCT)' ; 
	line_count=line_count+1; 
	
	IF speed_regr_slope_value >= 0 
	THEN 
		result_str[line_count] = 'THE SPEED IS INCREASING (PCT)' ; 
		line_count=line_count+1; 
		result_str[line_count] = 'PERCENTAGE OF GROWTH ' ||'|'|| REPLACE ( TO_CHAR( ROUND( (speed_regr_slope_value*100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
		line_count=line_count+1; 
	ELSE 
		result_str[line_count] = 'THE SPEED IS DECREASING' ; 
		line_count=line_count+1; 
		result_str[line_count] = 'PERCENTAGE OF DECREASE' ||'|'|| REPLACE ( TO_CHAR( ROUND( (speed_regr_slope_value*100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
		line_count=line_count+1; 	
	END IF ;
	
	
	result_str[line_count] = 'WAITINGS LINE PCT' ||'|'|| REPLACE ( TO_CHAR( ROUND( (waitings_regr_slope_value*100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+2; 
*/

--------------------------------------
-- Без стандартизации z-score
/*
	----------------------------------------------------------------------------------------------------
	-- 	линия регрессии  скорости  : Y = a + bX
	SELECT 
		regr_slope ( s.op_speed_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION ) as slope , --b
		ATAN(regr_slope ( s.op_speed_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION )) * 180 / PI() AS slope_angle_degrees, --угол наклона
		regr_intercept(s.op_speed_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION) AS intercept, --a
		regr_r2(s.op_speed_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION) AS r_squared
	INTO 
		speed_regr_rec
	FROM
		pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
	WHERE 
		t.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;	
	-- 	линия регрессии  скорости  : Y = a + bX
	----------------------------------------------------------------------------------------------------


    ----------------------------------------------------------------------------------------------------
	-- 	линия регрессии  ожиданий: Y = a + bX
	SELECT 
		regr_slope ( s.waitings_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION ) as slope , --b
		ATAN(regr_slope ( s.waitings_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION )) * 180 / PI() AS slope_angle_degrees, --угол наклона
		regr_intercept(s.waitings_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION) AS intercept , --a
		regr_r2(s.waitings_long::DOUBLE PRECISION , t.curr_timepoint::DOUBLE PRECISION) AS r_squared
	INTO 
		waitings_regr
	FROM
		pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
	WHERE 
		t.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;	
	-- 	линия регрессии ожиданий : Y = a + bX
	----------------------------------------------------------------------------------------------------
*/	
-- Без стандартизации z-score
--------------------------------------