----------------------------------------------------------------------------------------------------------------
-- correlation.sql
-- version 74.3
-- 
/*

*/

CREATE OR REPLACE FUNCTION waitings_os_corr( start_timestamp text , finish_timestamp text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
  min_max_pct_rec record ;
  
  corr_io_wa DOUBLE PRECISION ; -- Корреляция 
  corr_io_b DOUBLE PRECISION ; -- Корреляция 
  corr_io_si DOUBLE PRECISION ; -- Корреляция 
  corr_io_so DOUBLE PRECISION ; -- Корреляция 
  corr_io_bi DOUBLE PRECISION ; -- Корреляция 
  corr_io_bo DOUBLE PRECISION ; -- Корреляция 
  corr_lwlock_us DOUBLE PRECISION ; -- Корреляция 
  corr_lwlock_sy DOUBLE PRECISION ; -- Корреляция 
  
  bi_regr_rec record ;
  bo_regr_rec record ;
  
  timestamp_counter integer ;
  us_sy_pct DOUBLE PRECISION ; 
  us_regr_rec record ;
  sy_regr_rec record ;
  
  
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;

	SELECT 
		count(curr_timestamp)
	INTO timestamp_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		cl.curr_timestamp , 
		row_number() over (order by cl.curr_timestamp) AS x
	FROM
	os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)	
	WHERE 
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY cl.curr_timestamp	;		
	
	result_str[line_count] = 'WAIT_EVENT_TYPE - VMSTAT CORRELATION' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'correlation.sh' ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+2; 
	
	
	SELECT 
		MIN( cl_w.io_long) AS min_vmstat_io_long , MAX( cl_w.io_long) AS max_io_long , 
		MIN( cl_w.lwlock_long) AS min_lwlock_long , MAX( cl_w.lwlock_long) AS max_lwlock_long , 		
		MIN( cl.vmstat_analysis_cpu_wa_long) AS min_vmstat_analysis_cpu_wa_long , MAX( cl.vmstat_analysis_cpu_wa_long) AS max_vmstat_analysis_cpu_wa_long ,
		MIN( cl.vmstat_analysis_procs_b_long) AS min_vmstat_analysis_procs_b_long , MAX( cl.vmstat_analysis_procs_b_long) AS max_vmstat_analysis_procs_b_long , 
		MIN( cl.vmstat_analysis_swap_si_long) AS min_vmstat_analysis_swap_si_long , MAX( cl.vmstat_analysis_swap_si_long) AS max_vmstat_analysis_swap_si_long , 
		MIN( cl.vmstat_analysis_swap_so_long) AS min_vmstat_analysis_swap_so_long , MAX( cl.vmstat_analysis_swap_so_long) AS max_vmstat_analysis_swap_so_long , 
		MIN( cl.vmstat_analysis_io_bi_long) AS min_vmstat_analysis_io_bi_long , MAX( cl.vmstat_analysis_io_bi_long) AS max_vmstat_analysis_io_bi_long ,
		MIN( cl.vmstat_analysis_io_bo_long) AS min_vmstat_analysis_io_bo_long , MAX( cl.vmstat_analysis_io_bo_long) AS max_vmstat_analysis_io_bo_long ,
		MIN( cl.vmstat_analysis_cpu_us_long) AS min_vmstat_analysis_cpu_us_long , MAX( cl.vmstat_analysis_cpu_us_long) AS max_vmstat_analysis_cpu_us_long ,
		MIN( cl.vmstat_analysis_cpu_sy_long) AS min_vmstat_analysis_cpu_sy_long , MAX( cl.vmstat_analysis_cpu_sy_long) AS max_vmstat_analysis_cpu_sy_long		
	INTO  	min_max_rec
	FROM 
		os_stat_vmstat_analysis cl 
		JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp;
		
		
	---------------------------------------------------------------------------
	--1.Проблема в ОС (по vmstat): Высокий wa, b (медленный/перегруженный диск)	
	--IO - wa	 
		IF min_max_rec.min_vmstat_io_long != min_max_rec.max_io_long AND 
		   min_max_rec.min_vmstat_analysis_cpu_wa_long != min_max_rec.max_vmstat_analysis_cpu_wa_long
		THEN 
			WITH 
			io_values AS
			(
				SELECT 
					cl.curr_timestamp , io_long  AS io_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND io_long > 0 
			) ,
			cpu_wa_values AS
			(
				SELECT 
					cl.curr_timestamp , vmstat_analysis_cpu_wa_long  AS vmstat_analysis_cpu_wa_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND vmstat_analysis_cpu_wa_long > 0 					
			) 
			SELECT COALESCE( corr( v1.io_long , v2.vmstat_analysis_cpu_wa_long ) , 0 ) AS correlation_value 
			INTO corr_io_wa
			FROM
				io_values v1 JOIN cpu_wa_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
		ELSE
			corr_io_wa = 0 ;
		END IF;
		
		result_str[line_count] = 'Корреляция ожиданий IO и wa(I/O wait): IO-wa | ' ||
		REPLACE ( TO_CHAR( ROUND( corr_io_wa::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
		line_count=line_count+1;	

		IF corr_io_wa <= 0 
		THEN 
			result_str[line_count] = 'OK: Корреляция (IO-wa)  - отрицательная или отсутствует' ; 
			line_count=line_count+1;	
		ELSIF corr_io_wa > 0.7 
		THEN 
			result_str[line_count] = 'ALARM : Очень высокая корреляция (IO-wa)' ; 
			line_count=line_count+1;
			
			-----------------------------------------------------------------------------------------------------------
			result_str[line_count] = 'Процесс переходит в состояние непрерываемого сна (D), ожидая ответа от диска.' ; 
			line_count=line_count+1;
			result_str[line_count] = 'Даже простые операции чтения/записи (WAL, сброс буферов) начинают занимать неприемлемо много времени,';
			line_count=line_count+1;
			result_str[line_count] = 'так как диск не успевает обрабатывать запросы.';
			line_count=line_count+1;
			result_str[line_count] = 'Возможные причины и последствия ';
			line_count=line_count+1;
			result_str[line_count] = '1. Неоптимальные настройки I/O подсистемы (например, неверный sheduler, низкие лимиты IOPS/пропускной способности)';
			line_count=line_count+1;
			result_str[line_count] = 'Медленный диск или неправильная настройка контроллера/ФС приводят к тому, что даже обычные операции записи WAL ';
			line_count=line_count+1;
			result_str[line_count] = 'или сброса "грязных" страниц на диск начинают занимать много времени.';
			line_count=line_count+1;	
			result_str[line_count] = '2. Неверные настройки виртуальной памяти (например, vm.dirty_*)';
			line_count=line_count+1;	
			result_str[line_count] = 'Слишком большие значения vm.dirty_background_bytes и vm.dirty_bytes приводят к тому, что ОС копит много "грязных" данных в кеше,';
			line_count=line_count+1;
			result_str[line_count] = 'а затем сбрасывает их на диск одним большим взрывом. Это вызывает длительные ожидания записи ';
			line_count=line_count+1;
			result_str[line_count] = 'и может провоцировать длительные проверки контрольных точек (checkpoint).';
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------
			
		ELSIF corr_io_wa > 0.5 AND corr_io_wa <= 0.7
		THEN 
			result_str[line_count] = 'WARNING : Высокая корреляция (IO-wa)' ; 
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------
			result_str[line_count] = 'Процесс переходит в состояние непрерываемого сна (D), ожидая ответа от диска.' ; 
			line_count=line_count+1;
			result_str[line_count] = 'Даже простые операции чтения/записи (WAL, сброс буферов) начинают занимать неприемлемо много времени,';
			line_count=line_count+1;
			result_str[line_count] = 'так как диск не успевает обрабатывать запросы.';
			line_count=line_count+1;
			result_str[line_count] = 'Возможные причины и последствия ';
			line_count=line_count+1;
			result_str[line_count] = '1. Неоптимальные настройки I/O подсистемы (например, неверный sheduler, низкие лимиты IOPS/пропускной способности)';
			line_count=line_count+1;
			result_str[line_count] = 'Медленный диск или неправильная настройка контроллера/ФС приводят к тому, что даже обычные операции записи WAL ';
			line_count=line_count+1;
			result_str[line_count] = 'или сброса "грязных" страниц на диск начинают занимать много времени.';
			line_count=line_count+1;	
			result_str[line_count] = '2. Неверные настройки виртуальной памяти (например, vm.dirty_*)';
			line_count=line_count+1;	
			result_str[line_count] = 'Слишком большие значения vm.dirty_background_bytes и vm.dirty_bytes приводят к тому, что ОС копит много "грязных" данных в кеше,';
			line_count=line_count+1;
			result_str[line_count] = 'а затем сбрасывает их на диск одним большим взрывом. Это вызывает длительные ожидания записи ';
			line_count=line_count+1;
			result_str[line_count] = 'и может провоцировать длительные проверки контрольных точек (checkpoint).';
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------
						
		ELSE
			result_str[line_count] = 'INFO : Слабая или средняя корреляция (IO-wa)' ; 
			line_count=line_count+1;		
			-----------------------------------------------------------------------------------------------------------
			result_str[line_count] = 'Процесс переходит в состояние непрерываемого сна (D), ожидая ответа от диска.' ; 
			line_count=line_count+1;
			result_str[line_count] = 'Даже простые операции чтения/записи (WAL, сброс буферов) начинают занимать неприемлемо много времени,';
			line_count=line_count+1;
			result_str[line_count] = 'так как диск не успевает обрабатывать запросы.';
			line_count=line_count+1;
			result_str[line_count] = 'Возможные причины и последствия ';
			line_count=line_count+1;
			result_str[line_count] = '1. Неоптимальные настройки I/O подсистемы (например, неверный sheduler, низкие лимиты IOPS/пропускной способности)';
			line_count=line_count+1;
			result_str[line_count] = 'Медленный диск или неправильная настройка контроллера/ФС приводят к тому, что даже обычные операции записи WAL ';
			line_count=line_count+1;
			result_str[line_count] = 'или сброса "грязных" страниц на диск начинают занимать много времени.';
			line_count=line_count+1;	
			result_str[line_count] = '2. Неверные настройки виртуальной памяти (например, vm.dirty_*)';
			line_count=line_count+1;	
			result_str[line_count] = 'Слишком большие значения vm.dirty_background_bytes и vm.dirty_bytes приводят к тому, что ОС копит много "грязных" данных в кеше,';
			line_count=line_count+1;
			result_str[line_count] = 'а затем сбрасывает их на диск одним большим взрывом. Это вызывает длительные ожидания записи ';
			line_count=line_count+1;
			result_str[line_count] = 'и может провоцировать длительные проверки контрольных точек (checkpoint).';
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------		
								
		END IF;
		line_count=line_count+1;
		--IO - wa
		--------------------------------------------------------------------------------------------------------------------------
		--IO - b
		IF min_max_rec.min_vmstat_io_long != min_max_rec.max_io_long AND 
		   min_max_rec.min_vmstat_analysis_procs_b_long != min_max_rec.max_vmstat_analysis_procs_b_long
		THEN 
			WITH 
			io_values AS
			(
				SELECT 
					cl.curr_timestamp , io_long  AS io_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND io_long > 0 
			) ,
			procs_b_values AS
			(
				SELECT 
					cl.curr_timestamp , vmstat_analysis_procs_b_long  AS vmstat_analysis_procs_b_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND vmstat_analysis_procs_b_long > 0 					
			) 
			SELECT COALESCE( corr( v1.io_long , v2.vmstat_analysis_procs_b_long ) , 0 ) AS correlation_value 
			INTO corr_io_b
			FROM
				io_values v1 JOIN procs_b_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
		ELSE
			corr_io_b = 0 ;
		END IF;
		
		result_str[line_count] = 'Корреляция ожиданий IO и b(blocked) процессы, находящихся в состоянии непрерываемого сна: IO-b | ' ||
		REPLACE ( TO_CHAR( ROUND( corr_io_b::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
		line_count=line_count+1;	

		IF corr_io_b <= 0 
		THEN 
			result_str[line_count] = 'OK: Корреляция (IO-b)  - отрицательная или отсутствует' ; 
			line_count=line_count+1;	
		ELSIF corr_io_b > 0.7 
		THEN 
			result_str[line_count] = 'ALARM : Очень высокая корреляция (IO-b)' ; 
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------
			result_str[line_count] = 'Процесс переходит в состояние непрерываемого сна (D), ожидая ответа от диска.' ; 
			line_count=line_count+1;
			result_str[line_count] = 'Даже простые операции чтения/записи (WAL, сброс буферов) начинают занимать неприемлемо много времени,';
			line_count=line_count+1;
			result_str[line_count] = 'так как диск не успевает обрабатывать запросы.';
			line_count=line_count+1;
			result_str[line_count] = 'Возможные причины и последствия ';
			line_count=line_count+1;
			result_str[line_count] = '1. Неоптимальные настройки I/O подсистемы (например, неверный sheduler, низкие лимиты IOPS/пропускной способности)';
			line_count=line_count+1;
			result_str[line_count] = 'Медленный диск или неправильная настройка контроллера/ФС приводят к тому, что даже обычные операции записи WAL ';
			line_count=line_count+1;
			result_str[line_count] = 'или сброса "грязных" страниц на диск начинают занимать много времени.';
			line_count=line_count+1;	
			result_str[line_count] = '2. Неверные настройки виртуальной памяти (например, vm.dirty_*)';
			line_count=line_count+1;	
			result_str[line_count] = 'Слишком большие значения vm.dirty_background_bytes и vm.dirty_bytes приводят к тому, что ОС копит много "грязных" данных в кеше,';
			line_count=line_count+1;
			result_str[line_count] = 'а затем сбрасывает их на диск одним большим взрывом. Это вызывает длительные ожидания записи ';
			line_count=line_count+1;
			result_str[line_count] = 'и может провоцировать длительные проверки контрольных точек (checkpoint).';
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------		
								
		ELSIF corr_io_b > 0.5 AND corr_io_b <= 0.7
		THEN 
			result_str[line_count] = 'WARNING : Высокая корреляция (IO-b)' ; 
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------
			result_str[line_count] = 'Процесс переходит в состояние непрерываемого сна (D), ожидая ответа от диска.' ; 
			line_count=line_count+1;
			result_str[line_count] = 'Даже простые операции чтения/записи (WAL, сброс буферов) начинают занимать неприемлемо много времени,';
			line_count=line_count+1;
			result_str[line_count] = 'так как диск не успевает обрабатывать запросы.';
			line_count=line_count+1;
			result_str[line_count] = 'Возможные причины и последствия ';
			line_count=line_count+1;
			result_str[line_count] = '1. Неоптимальные настройки I/O подсистемы (например, неверный sheduler, низкие лимиты IOPS/пропускной способности)';
			line_count=line_count+1;
			result_str[line_count] = 'Медленный диск или неправильная настройка контроллера/ФС приводят к тому, что даже обычные операции записи WAL ';
			line_count=line_count+1;
			result_str[line_count] = 'или сброса "грязных" страниц на диск начинают занимать много времени.';
			line_count=line_count+1;	
			result_str[line_count] = '2. Неверные настройки виртуальной памяти (например, vm.dirty_*)';
			line_count=line_count+1;	
			result_str[line_count] = 'Слишком большие значения vm.dirty_background_bytes и vm.dirty_bytes приводят к тому, что ОС копит много "грязных" данных в кеше,';
			line_count=line_count+1;
			result_str[line_count] = 'а затем сбрасывает их на диск одним большим взрывом. Это вызывает длительные ожидания записи ';
			line_count=line_count+1;
			result_str[line_count] = 'и может провоцировать длительные проверки контрольных точек (checkpoint).';
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------
					
		ELSE
			result_str[line_count] = 'INFO : Слабая или средняя корреляция (IO-b)' ; 
			line_count=line_count+1;		
			-----------------------------------------------------------------------------------------------------------
			result_str[line_count] = 'Процесс переходит в состояние непрерываемого сна (D), ожидая ответа от диска.' ; 
			line_count=line_count+1;
			result_str[line_count] = 'Даже простые операции чтения/записи (WAL, сброс буферов) начинают занимать неприемлемо много времени,';
			line_count=line_count+1;
			result_str[line_count] = 'так как диск не успевает обрабатывать запросы.';
			line_count=line_count+1;
			result_str[line_count] = 'Возможные причины и последствия ';
			line_count=line_count+1;
			result_str[line_count] = '1. Неоптимальные настройки I/O подсистемы (например, неверный sheduler, низкие лимиты IOPS/пропускной способности)';
			line_count=line_count+1;
			result_str[line_count] = 'Медленный диск или неправильная настройка контроллера/ФС приводят к тому, что даже обычные операции записи WAL ';
			line_count=line_count+1;
			result_str[line_count] = 'или сброса "грязных" страниц на диск начинают занимать много времени.';
			line_count=line_count+1;	
			result_str[line_count] = '2. Неверные настройки виртуальной памяти (например, vm.dirty_*)';
			line_count=line_count+1;	
			result_str[line_count] = 'Слишком большие значения vm.dirty_background_bytes и vm.dirty_bytes приводят к тому, что ОС копит много "грязных" данных в кеше,';
			line_count=line_count+1;
			result_str[line_count] = 'а затем сбрасывает их на диск одним большим взрывом. Это вызывает длительные ожидания записи ';
			line_count=line_count+1;
			result_str[line_count] = 'и может провоцировать длительные проверки контрольных точек (checkpoint).';
			line_count=line_count+1;
			-----------------------------------------------------------------------------------------------------------	
						
		END IF;
		line_count=line_count+1;
		
		--IO - b
		--------------------------------------------------------------------------------------------------------------------------
	--1.Проблема в ОС (по vmstat): Высокий wa, b (медленный/перегруженный диск)	
    ---------------------------------------------------------------------------
	
	-----------------------------------------------------------------------------
	--Высокие значения bi(blocks in) 
	IF min_max_rec.min_vmstat_io_long != min_max_rec.max_io_long AND 
		   min_max_rec.min_vmstat_analysis_io_bi_long != min_max_rec.max_vmstat_analysis_io_bi_long
	THEN 
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bi
		-- 	линия регрессии  скорости  : Y = a + bX
			BEGIN
				WITH stats AS 
				(
				  SELECT 
					AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
					STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
					AVG(s.vmstat_analysis_io_bi_long::DOUBLE PRECISION) as avg2, 
					STDDEV(s.vmstat_analysis_io_bi_long::DOUBLE PRECISION) as std2
				  FROM
					os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
				  WHERE 
					t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				),
				standardized_data AS 
				(
					SELECT 
						(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
						(s.vmstat_analysis_io_bi_long::DOUBLE PRECISION - avg2) / std2 as y_z
					FROM
						os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
					WHERE 
						t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				)	
				SELECT
					REGR_SLOPE(y_z, x_z) as slope, --bi
					ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
					REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
				INTO 
					bi_regr_rec
				FROM standardized_data;
			EXCEPTION
			  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
			  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
				SELECT 
					1.0 as slope, --b
					0.0  as slope_angle_degrees, --угол наклона
					0.0  as r_squared -- Коэффициент детерминации
				INTO 
				bi_regr_rec ;
			END;
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bi
		-- 	линия регрессии  скорости  : Y = a + bX
			
			IF  bi_regr_rec.slope_angle_degrees <= 0 
			THEN 
				result_str[line_count] = 'Количество bi(блоки, считанные с устройств) - не растёт | ' ;
				line_count=line_count+1;	
			ELSE 
				WITH 
				io_values AS
				(
					SELECT 
						cl.curr_timestamp , io_long  AS io_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND io_long > 0 
				) ,
				io_bi_values AS
				(
					SELECT 
						cl.curr_timestamp , vmstat_analysis_io_bi_long  AS vmstat_analysis_io_bi_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND vmstat_analysis_io_bi_long > 0 					
				) 
				SELECT COALESCE( corr( v1.io_long , v2.vmstat_analysis_io_bi_long ) , 0 ) AS correlation_value 
				INTO corr_io_bi
				FROM
					io_values v1 JOIN io_bi_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;  
			END IF;
	ELSE
		corr_io_bi = 0 ;
	END IF;

	result_str[line_count] = 'Корреляция ожиданий IO и bi(blocks in):| ' ||
	REPLACE ( TO_CHAR( ROUND( corr_io_bi::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	

	IF corr_io_bi <= 0 
	THEN 
		result_str[line_count] = 'OK: Корреляция IO и bi(blocks in) - отрицательная или отсутствует' ; 
		line_count=line_count+1;				
	ELSIF corr_io_bi > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (IO и bi)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Активная работа с большими объемами данных  ' ;
		line_count=line_count+1;
		result_str[line_count] = '(например, полное сканирование таблиц, интенсивная запись). ' ;
		line_count=line_count+1;
		result_str[line_count] = 'Неэффективные запросы, вызывающие чрезмерный I/O.	 ' ;
		line_count=line_count+1;
		
	ELSIF corr_io_bi > 0.5 AND corr_io_bi <= 0.7
	THEN 	
		result_str[line_count] = 'WARNING : Высокая корреляция (IO и bi)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Активная работа с большими объемами данных  ' ;
		line_count=line_count+1;
		result_str[line_count] = '(например, полное сканирование таблиц, интенсивная запись). ' ;
		line_count=line_count+1;
		result_str[line_count] = 'Неэффективные запросы, вызывающие чрезмерный I/O.	 ' ;
		line_count=line_count+1;	
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (IO и bi)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Активная работа с большими объемами данных  ' ;
		line_count=line_count+1;
		result_str[line_count] = '(например, полное сканирование таблиц, интенсивная запись). ' ;
		line_count=line_count+1;
		result_str[line_count] = 'Неэффективные запросы, вызывающие чрезмерный I/O.	 ' ;
		line_count=line_count+1;
	END IF ; 
	line_count=line_count+1;	
	--Высокие значения bi(blocks in) 
	-------------------------------------------------------
	
	-----------------------------------------------------------------------------
	--Высокие значения bo(blocks out) 
	IF min_max_rec.min_vmstat_io_long != min_max_rec.max_io_long AND 
		   min_max_rec.min_vmstat_analysis_io_bo_long != min_max_rec.max_vmstat_analysis_io_bo_long
	THEN 
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bo
		-- 	линия регрессии  скорости  : Y = a + bX
			BEGIN
				WITH stats AS 
				(
				  SELECT 
					AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
					STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
					AVG(s.vmstat_analysis_io_bo_long::DOUBLE PRECISION) as avg2, 
					STDDEV(s.vmstat_analysis_io_bo_long::DOUBLE PRECISION) as std2
				  FROM
					os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
				  WHERE 
					t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				),
				standardized_data AS 
				(
					SELECT 
						(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
						(s.vmstat_analysis_io_bo_long::DOUBLE PRECISION - avg2) / std2 as y_z
					FROM
						os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
					WHERE 
						t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				)	
				SELECT
					REGR_SLOPE(y_z, x_z) as slope, --bo
					ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
					REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
				INTO 
					bo_regr_rec
				FROM standardized_data;
			EXCEPTION
			  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
			  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
				SELECT 
					1.0 as slope, --b
					0.0  as slope_angle_degrees, --угол наклона
					0.0  as r_squared -- Коэффициент детерминации
				INTO 
				bo_regr_rec ;
			END;
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bo
		-- 	линия регрессии  скорости  : Y = a + bX
			
			IF  bo_regr_rec.slope_angle_degrees <= 0 
			THEN 
				result_str[line_count] = 'Количество bo(записанные на устройства ) - не растёт | ' ;
				line_count=line_count+1;	
			ELSE 
				WITH 
				io_values AS
				(
					SELECT 
						cl.curr_timestamp , io_long  AS io_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND io_long > 0 
				) ,
				io_bo_values AS
				(
					SELECT 
						cl.curr_timestamp , vmstat_analysis_io_bo_long  AS vmstat_analysis_io_bo_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND vmstat_analysis_io_bo_long > 0 					
				) 
				SELECT COALESCE( corr( v1.io_long , v2.vmstat_analysis_io_bo_long ) , 0 ) AS correlation_value 
				INTO corr_io_bo
				FROM
					io_values v1 JOIN io_bo_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;  
			END IF;
	ELSE
		corr_io_bo = 0 ;
	END IF;

	result_str[line_count] = 'Корреляция ожиданий IO и bo(blocks out):| ' ||
	REPLACE ( TO_CHAR( ROUND( corr_io_bo::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	

	IF corr_io_bo <= 0 
	THEN 
		result_str[line_count] = 'OK: Корреляция IO и bo(blocks out) - отрицательная или отсутствует' ; 
		line_count=line_count+1;				
	ELSIF corr_io_bo > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (IO и bo)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Активная работа с большими объемами данных  ' ;
		line_count=line_count+1;
		result_str[line_count] = '(например, полное сканирование таблиц, интенсивная запись). ' ;
		line_count=line_count+1;
		result_str[line_count] = 'Неэффективные запросы, вызывающие чрезмерный I/O.	 ' ;
		line_count=line_count+1;
		
	ELSIF corr_io_bo > 0.5 AND corr_io_bo <= 0.7
	THEN 	
		result_str[line_count] = 'WARNING : Высокая корреляция (IO и bo)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Активная работа с большими объемами данных  ' ;
		line_count=line_count+1;
		result_str[line_count] = '(например, полное сканирование таблиц, интенсивная запись). ' ;
		line_count=line_count+1;
		result_str[line_count] = 'Неэффективные запросы, вызывающие чрезмерный I/O.	 ' ;
		line_count=line_count+1;	
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (IO и bo)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Активная работа с большими объемами данных  ' ;
		line_count=line_count+1;
		result_str[line_count] = '(например, полное сканирование таблиц, интенсивная запись). ' ;
		line_count=line_count+1;
		result_str[line_count] = 'Неэффективные запросы, вызывающие чрезмерный I/O.	 ' ;
		line_count=line_count+1;
	END IF ; 
	line_count=line_count+1;	
	--Высокие значения bo(blocks out) 
	-------------------------------------------------------
	
	---------------------------------------------------------------------------
	--Низкое значение id (idle time) при высоком us (user time) или sy (system time)
	--us + sy > 80%
	WITH 
	  cpu_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND (vmstat_analysis_cpu_us_long + vmstat_analysis_cpu_sy_long ) > 80
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / timestamp_counter::DOUBLE PRECISION)*100.0 
	INTO
		us_sy_pct
	FROM cpu_counter ;
	
	result_str[line_count] = 'us(user time) + sy(system time) (% свыше 80%) | '|| REPLACE ( TO_CHAR( ROUND( us_sy_pct::numeric , 2 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF us_sy_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - wa > 10%' ; 
		line_count=line_count+1;		
	ELSIF us_sy_pct > 25.0 AND us_sy_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - wa > 10%' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).';
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).';
		line_count=line_count+1;
		result_str[line_count] = 'Резкий рост sy может указывать на проблемы с системными вызовами (например, частое переключение контекста).';
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - wa > 10%' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).';
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).';
		line_count=line_count+1;
		result_str[line_count] = 'Резкий рост sy может указывать на проблемы с системными вызовами (например, частое переключение контекста).';
		line_count=line_count+1;
	END IF ;
	
	--------------------------------------------------------------------
	-- us — user time
	IF min_max_rec.min_lwlock_long != min_max_rec.max_lwlock_long AND 
	   min_max_rec.min_vmstat_analysis_cpu_us_long != min_max_rec.max_vmstat_analysis_cpu_us_long 
	THEN 
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bi
		-- 	линия регрессии  скорости  : Y = a + bX
			BEGIN
				WITH stats AS 
				(
				  SELECT 
					AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
					STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
					AVG(s.vmstat_analysis_cpu_us_long::DOUBLE PRECISION) as avg2, 
					STDDEV(s.vmstat_analysis_cpu_us_long::DOUBLE PRECISION) as std2
				  FROM
					os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
				  WHERE 
					t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				),
				standardized_data AS 
				(
					SELECT 
						(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
						(s.vmstat_analysis_cpu_us_long::DOUBLE PRECISION - avg2) / std2 as y_z
					FROM
						os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
					WHERE 
						t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				)	
				SELECT
					REGR_SLOPE(y_z, x_z) as slope, --bi
					ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
					REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
				INTO 
					us_regr_rec
				FROM standardized_data;
			EXCEPTION
			  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
			  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
				SELECT 
					1.0 as slope, --b
					0.0  as slope_angle_degrees, --угол наклона
					0.0  as r_squared -- Коэффициент детерминации
				INTO 
				us_regr_rec ;
			END;
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bi
		-- 	линия регрессии  скорости  : Y = a + bX
			
			IF  us_regr_rec.slope_angle_degrees <= 0 
			THEN 
				result_str[line_count] = 'us (user time)- не растёт | ' ;
				line_count=line_count+1;	
			ELSE 
				WITH 
				lwlock_values AS
				(
					SELECT 
						cl.curr_timestamp , lwlock_long  AS lwlock_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND lwlock_long > 0 
				) ,
				lwlock_us_values AS
				(
					SELECT 
						cl.curr_timestamp , vmstat_analysis_cpu_us_long  AS vmstat_analysis_cpu_us_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND vmstat_analysis_cpu_us_long > 0 					
				) 
				SELECT COALESCE( corr( v1.lwlock_long , v2.vmstat_analysis_cpu_us_long ) , 0 ) AS correlation_value 
				INTO corr_lwlock_us
				FROM
					lwlock_values v1 JOIN lwlock_us_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ; 			
			END IF;
			
	ELSE
		corr_lwlock_us = 0 ;
	END IF;

	result_str[line_count] = 'Корреляция LWLock и us(user time):| ' ||
	REPLACE ( TO_CHAR( ROUND( corr_lwlock_us::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	

	IF corr_lwlock_us <= 0 
	THEN 
		result_str[line_count] = 'OK: Корреляция LWLock и us(user time) - отрицательная или отсутствует' ; 
		line_count=line_count+1;				
	ELSIF corr_lwlock_us > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (LWLock-us)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).' ;
		line_count=line_count+1;		
	ELSIF corr_lwlock_us > 0.5 AND corr_lwlock_us <= 0.7
	THEN 	
		result_str[line_count] = 'WARNING : Высокая корреляция (LWLock-us)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).' ;
		line_count=line_count+1;	
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (LWLock-us)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).' ;
		line_count=line_count+1;
	END IF ; 
	line_count=line_count+1;	
	-- us — user time
	--------------------------------------------------------------------
	
	--------------------------------------------------------------------
	-- sy — system time
	IF min_max_rec.min_lwlock_long != min_max_rec.max_lwlock_long AND 
	   min_max_rec.min_vmstat_analysis_cpu_sy_long != min_max_rec.max_vmstat_analysis_cpu_sy_long 
	THEN 
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bi
		-- 	линия регрессии  скорости  : Y = a + bX
			BEGIN
				WITH stats AS 
				(
				  SELECT 
					AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
					STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
					AVG(s.vmstat_analysis_cpu_sy_long::DOUBLE PRECISION) as avg2, 
					STDDEV(s.vmstat_analysis_cpu_sy_long::DOUBLE PRECISION) as std2
				  FROM
					os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
				  WHERE 
					t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				),
				standardized_data AS 
				(
					SELECT 
						(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
						(s.vmstat_analysis_cpu_sy_long::DOUBLE PRECISION - avg2) / std2 as y_z
					FROM
						os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
					WHERE 
						t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				)	
				SELECT
					REGR_SLOPE(y_z, x_z) as slope, --bi
					ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
					REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
				INTO 
					sy_regr_rec
				FROM standardized_data;
			EXCEPTION
			  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
			  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
				SELECT 
					1.0 as slope, --b
					0.0  as slope_angle_degrees, --угол наклона
					0.0  as r_squared -- Коэффициент детерминации
				INTO 
				sy_regr_rec ;
			END;
		-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ bi
		-- 	линия регрессии  скорости  : Y = a + bX
			
			IF  sy_regr_rec.slope_angle_degrees <= 0 
			THEN 
				result_str[line_count] = 'sy (system time)- не растёт | ' ;
				line_count=line_count+1;	
			ELSE 
				WITH 
				lwlock_values AS
				(
					SELECT 
						cl.curr_timestamp , lwlock_long  AS lwlock_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND lwlock_long > 0 
				) ,
				lwlock_sy_values AS
				(
					SELECT 
						cl.curr_timestamp , vmstat_analysis_cpu_sy_long  AS vmstat_analysis_cpu_sy_long 
					FROM 
						os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
					WHERE				
						cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
						AND vmstat_analysis_cpu_sy_long > 0 					
				) 
				SELECT COALESCE( corr( v1.lwlock_long , v2.vmstat_analysis_cpu_sy_long ) , 0 ) AS correlation_value 
				INTO corr_lwlock_sy
				FROM
					lwlock_values v1 JOIN lwlock_sy_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ; 			
			END IF;
			
	ELSE
		corr_lwlock_sy = 0 ;
	END IF;

	result_str[line_count] = 'Корреляция LWLock и sy(system time):| ' ||
	REPLACE ( TO_CHAR( ROUND( corr_lwlock_sy::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	

	IF corr_lwlock_sy <= 0 
	THEN 
		result_str[line_count] = 'OK: Корреляция LWLock и sy(system time) - отрицательная или отсутствует' ; 
		line_count=line_count+1;				
	ELSIF corr_lwlock_sy > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (LWLock-sy)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).' ;
		line_count=line_count+1;	
		result_str[line_count] = 'Резкий рост sy может указывать на проблемы с системными вызовами (например, частое переключение контекста).';
		line_count=line_count+1;		
	ELSIF corr_lwlock_sy > 0.5 AND corr_lwlock_sy <= 0.7
	THEN 	
		result_str[line_count] = 'WARNING : Высокая корреляция (LWLock-sy)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).' ;
		line_count=line_count+1;	
		result_str[line_count] = 'Резкий рост sy может указывать на проблемы с системными вызовами (например, частое переключение контекста).';
		line_count=line_count+1;				
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (LWLock-sy)' ; 
		line_count=line_count+1;
		---------------------------------------------------------------------------------------------
		result_str[line_count] = 'Причины и последствия: ' ; 
		line_count=line_count+1;
		result_str[line_count] = 'Высокая нагрузка на CPU из-за сложных запросов (агрегации, JOINs).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Конкуренция за ресурсы CPU (например, из-за параллельных процессов).' ;
		line_count=line_count+1;
		result_str[line_count] = 'Резкий рост sy может указывать на проблемы с системными вызовами (например, частое переключение контекста).';
		line_count=line_count+1;				
	END IF ; 
	line_count=line_count+1;	
	-- sy — system time
	--------------------------------------------------------------------	
	--Низкое значение id (idle time) при высоком us (user time) или sy (system time)
	---------------------------------------------------------------------------
	
	
	---------------------------------------------------------------------------
	-- Высокие si, so (активный своппинг)	
	--IO - si 
		IF min_max_rec.min_vmstat_io_long != min_max_rec.max_io_long AND 
		   min_max_rec.min_vmstat_analysis_swap_si_long != min_max_rec.max_vmstat_analysis_swap_si_long
		THEN 
			WITH 
			io_values AS
			(
				SELECT 
					cl.curr_timestamp , io_long  AS io_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND io_long > 0 
			) ,
			swap_si_values AS
			(
				SELECT 
					cl.curr_timestamp , vmstat_analysis_swap_si_long  AS vmstat_analysis_swap_si_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND vmstat_analysis_swap_si_long > 0 					
			) 
			SELECT COALESCE( corr( v1.io_long , v2.vmstat_analysis_swap_si_long ) , 0 ) AS correlation_value 
			INTO corr_io_si
			FROM
				io_values v1 JOIN swap_si_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
		ELSE
			corr_io_si = 0 ;
		END IF;

		
		result_str[line_count] = 'Корреляция ожиданий IO и si (swap in): Объем данных, загружаемых с свопа в оперативную память: IO-si | ' ||
		REPLACE ( TO_CHAR( ROUND( corr_io_si::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
		line_count=line_count+1;	

		IF corr_io_si <= 0 
		THEN 
			result_str[line_count] = 'OK: Корреляция (IO-si)  - отрицательная или отсутствует' ; 
			line_count=line_count+1;				
		ELSIF corr_io_si > 0.7 
		THEN 
			result_str[line_count] = 'ALARM : Очень высокая корреляция (IO-si)' ; 
			line_count=line_count+1;
			---------------------------------------------------------------------------------------------
			result_str[line_count] = 'Причины и последствия: ' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'Системе не хватает оперативной памяти. Данные, которые должны быть в кеше, вытесняются на медленный диск (своп),' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает дополнительную дисковую нагрузку и увеличивает время чтения.' ; 
			line_count=line_count+1;				
			result_str[line_count] = 'Чтение страниц БД с диска, которые должны были быть в кеше, теперь требует еще и своппинга,' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает двойную нагрузку на I/O и катастрофически замедляет работу.' ; 
			line_count=line_count+1;	
			---------------------------------------------------------------------------------------------	
								
		ELSIF corr_io_si > 0.5 AND corr_io_si <= 0.7
		THEN 
			result_str[line_count] = 'WARNING : Высокая корреляция (IO-si)' ; 
			line_count=line_count+1;
			---------------------------------------------------------------------------------------------
			result_str[line_count] = 'Причины и последствия: ' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'Системе не хватает оперативной памяти. Данные, которые должны быть в кеше, вытесняются на медленный диск (своп),' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает дополнительную дисковую нагрузку и увеличивает время чтения.' ; 
			line_count=line_count+1;				
			result_str[line_count] = 'Чтение страниц БД с диска, которые должны были быть в кеше, теперь требует еще и своппинга,' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает двойную нагрузку на I/O и катастрофически замедляет работу.' ; 
			line_count=line_count+1;	
			---------------------------------------------------------------------------------------------						
		ELSE
			result_str[line_count] = 'INFO : Слабая или средняя корреляция (IO-si)' ; 
			line_count=line_count+1;	

			---------------------------------------------------------------------------------------------
			result_str[line_count] = 'Причины и последствия: ' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'Системе не хватает оперативной памяти. Данные, которые должны быть в кеше, вытесняются на медленный диск (своп),' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает дополнительную дисковую нагрузку и увеличивает время чтения.' ; 
			line_count=line_count+1;				
			result_str[line_count] = 'Чтение страниц БД с диска, которые должны были быть в кеше, теперь требует еще и своппинга,' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает двойную нагрузку на I/O и катастрофически замедляет работу.' ; 
			line_count=line_count+1;	
			---------------------------------------------------------------------------------------------							
		END IF;
		line_count=line_count+1;
		--------------------------------------------------------------------------------------------------------------------------
	--IO - si 
	------------------------------------------------------------------------------------------------------------------------------
	--IO - so 
		IF min_max_rec.min_vmstat_io_long != min_max_rec.max_io_long AND 
		   min_max_rec.min_vmstat_analysis_swap_so_long != min_max_rec.max_vmstat_analysis_swap_so_long
		THEN 
			WITH 
			io_values AS
			(
				SELECT 
					cl.curr_timestamp , io_long  AS io_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND io_long > 0 
			) ,
			swap_so_values AS
			(
				SELECT 
					cl.curr_timestamp , vmstat_analysis_swap_so_long  AS vmstat_analysis_swap_so_long 
				FROM 
					os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
				WHERE				
					cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
					AND vmstat_analysis_swap_so_long > 0 					
			) 
			SELECT COALESCE( corr( v1.io_long , v2.vmstat_analysis_swap_so_long ) , 0 ) AS correlation_value 
			INTO corr_io_so
			FROM
				io_values v1 JOIN swap_so_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
		ELSE
			corr_io_so = 0 ;
		END IF;
		
		result_str[line_count] = 'Корреляция ожиданий IO и si (swap in): Объем данных, загружаемых из оперативную память в своп: IO-so | ' ||
		REPLACE ( TO_CHAR( ROUND( corr_io_so::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
		line_count=line_count+1;	

		IF corr_io_so <= 0 
		THEN 
			result_str[line_count] = 'OK: Корреляция (IO-si)  - отрицательная или отсутствует' ; 
			line_count=line_count+1;				
		ELSIF corr_io_so > 0.7 
		THEN 
			result_str[line_count] = 'ALARM : Очень высокая корреляция (IO-si)' ; 
			line_count=line_count+1;
			---------------------------------------------------------------------------------------------
			result_str[line_count] = 'Причины и последствия: ' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'Системе не хватает оперативной памяти. Данные, которые должны быть в кеше, вытесняются на медленный диск (своп),' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает дополнительную дисковую нагрузку и увеличивает время чтения.' ; 
			line_count=line_count+1;				
			result_str[line_count] = 'Чтение страниц БД с диска, которые должны были быть в кеше, теперь требует еще и своппинга,' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает двойную нагрузку на I/O и катастрофически замедляет работу.' ; 
			line_count=line_count+1;	
			---------------------------------------------------------------------------------------------	
								
		ELSIF corr_io_so > 0.5 AND corr_io_so <= 0.7
		THEN 
			result_str[line_count] = 'WARNING : Высокая корреляция (IO-si)' ; 
			line_count=line_count+1;
			---------------------------------------------------------------------------------------------
			result_str[line_count] = 'Причины и последствия: ' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'Системе не хватает оперативной памяти. Данные, которые должны быть в кеше, вытесняются на медленный диск (своп),' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает дополнительную дисковую нагрузку и увеличивает время чтения.' ; 
			line_count=line_count+1;				
			result_str[line_count] = 'Чтение страниц БД с диска, которые должны были быть в кеше, теперь требует еще и своппинга,' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает двойную нагрузку на I/O и катастрофически замедляет работу.' ; 
			line_count=line_count+1;	
			---------------------------------------------------------------------------------------------						
		ELSE
			result_str[line_count] = 'INFO : Слабая или средняя корреляция (IO-si)' ; 
			line_count=line_count+1;	

			---------------------------------------------------------------------------------------------
			result_str[line_count] = 'Причины и последствия: ' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'Системе не хватает оперативной памяти. Данные, которые должны быть в кеше, вытесняются на медленный диск (своп),' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает дополнительную дисковую нагрузку и увеличивает время чтения.' ; 
			line_count=line_count+1;				
			result_str[line_count] = 'Чтение страниц БД с диска, которые должны были быть в кеше, теперь требует еще и своппинга,' ; 
			line_count=line_count+1;	
			result_str[line_count] = 'что создает двойную нагрузку на I/O и катастрофически замедляет работу.' ; 
			line_count=line_count+1;	
			---------------------------------------------------------------------------------------------							
		END IF;
		line_count=line_count+1;
		--------------------------------------------------------------------------------------------------------------------------
	--IO - so 
	-- 2. Высокие si, so (активный своппинг)	
	---------------------------------------------------------------------------

	
  return result_str ; 
END
$$ LANGUAGE plpgsql  ;