----------------------------------------------------------------------------------------------------------------
-- ЕЖЕДНЕВНЫЙ ОТЧЕТ ПО ИНЦИДЕНТАМ ПРОИЗВОДИТЕЛЬНОСТИ ЗА ЗАДАННЫЕ ПЕРИОД
-- daily_incidents_report.sql
-- version 38.0


CREATE OR REPLACE FUNCTION daily_incidents_report(  start_timestamp text , finish_timestamp text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 current_last_sql_statistics timestamp with time zone ; 
 
 counter integer ; 
 
 performance_incident_rec record ; 
  
  speed_waitings_correlation DOUBLE PRECISION;
  
  corr_bufferpin DOUBLE PRECISION ; 
  corr_extension DOUBLE PRECISION ; 
  corr_io DOUBLE PRECISION ; 
  corr_ipc DOUBLE PRECISION ; 
  corr_lock DOUBLE PRECISION ; 
  corr_lwlock DOUBLE PRECISION ; 
  	
  speed_regr_slope_value DOUBLE PRECISION;
  waitings_regr_slope_value DOUBLE PRECISION;  
  
  pgh_stat_cluster_analysis_rec record ; 
  incident_duration numeric ;
BEGIN	
	line_count = 1 ;
	counter = 0 ; 
	
	IF start_timestamp = 'YESTERDAY'
	THEN 
		SELECT 	date_trunc('day' ,  CURRENT_TIMESTAMP ) 
		INTO 	max_timestamp ; 
		
		SELECT 	date_trunc('day' ,  CURRENT_TIMESTAMP - interval '1 day') 
		INTO 	min_timestamp ; 	
    ELSIF start_timestamp = 'LAST_WEEK'		
	THEN 
		SELECT date_trunc('week' , current_timestamp - interval '1 day') 
		INTO min_timestamp ; 
		
        SELECT date_trunc('week' , current_timestamp - interval '1 day') + interval '1 week'
		INTO max_timestamp ; 
	ELSE
		result_str[line_count] = 'WRONG TIME PERIOD' ;
		return result_str ;  
	END IF;

	result_str[line_count] = 'daily_incidents_report' ; 
	line_count=line_count+1; 
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 

	result_str[line_count] =	'ID  |'|| --1
								'PRIORITY |'|| --2
								'START TIME |'|| --3
								'FINISH TIME |'|| --4
								'DURATION |'|| --5
								'SPEED LINE SLOPE |'|| --6
								'THE SPEED IS INCREASING (PCT) |'|| --7
								'WAITING LINE SLOPE |'|| --8
								'THE WAITINGS IS INCREASING (PCT) |'|| --9
								'SPEED-WAITINGS |'|| --10
								'BUFFERPIN |'|| --11
								'EXTENSION |'|| --12
								'IO |'|| --13
								'IPC |'|| --14
								'LOCK |'|| --15
								'LWLOCK |' --16
								;
	line_count=line_count+1; 	
	
	-------------------------------------------------------------------
	--ПО ИНЦИДЕНТАМ В ПЕРИОД ОТЧЕТА 
	FOR performance_incident_rec IN 
	SELECT 	*
	FROM 	performance_incident p 
	WHERE 	p.start_timepoint BETWEEN min_timestamp AND max_timestamp		
	ORDER BY start_timepoint 
	LOOP 
		counter = counter + 1 ; 
		
		----------------------------------------------
		--ЕСЛИ СТАТИСТИКА ИНЦИДЕНТА НЕ РАСЧИТАНА
		IF NOT performance_incident_rec.is_stats_calculated
		THEN 
				----------------------------------------------------------------------------------------------------
				--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ		
				WITH 
				operating_speed AS
				(
					SELECT 
						curr_timestamp , op_speed_long  AS operating_speed_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
				) ,
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS curr_waitings_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0 
				) 
				SELECT COALESCE( corr( operating_speed_long , curr_waitings_long ) , 0 ) AS correlation_value 
				INTO speed_waitings_correlation
				FROM
					operating_speed os JOIN waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin
				WITH 
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS waitings_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0
				) ,
				bufferpin_waitings AS
				(
					SELECT 
						curr_timestamp , bufferpin_long  AS bufferpin_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND bufferpin_long > 0 
				) 
				SELECT COALESCE( corr( waitings_long , bufferpin_long ) , 0 ) AS correlation_value 
				INTO corr_bufferpin
				FROM
					waitings os JOIN bufferpin_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension
				WITH 
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS waitings_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0
				) ,
				extension_waitings AS
				(
					SELECT 
						curr_timestamp , extension_long  AS extension_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND extension_long > 0 
				) 
				SELECT COALESCE( corr( waitings_long , extension_long ) , 0 ) AS correlation_value 
				INTO corr_extension
				FROM
					waitings os JOIN extension_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io
				WITH 
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS waitings_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0
				) ,
				io_waitings AS
				(
					SELECT 
						curr_timestamp , io_long  AS io_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND io_long > 0 
				) 
				SELECT COALESCE( corr( waitings_long , io_long ) , 0 ) AS correlation_value 
				INTO corr_io
				FROM
					waitings os JOIN io_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc
				WITH 
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS waitings_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0
				) ,
				ipc_waitings AS
				(
					SELECT 
						curr_timestamp , ipc_long  AS ipc_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND ipc_long > 0 
				) 
				SELECT COALESCE( corr( waitings_long , ipc_long ) , 0 ) AS correlation_value 
				INTO corr_ipc
				FROM
					waitings os JOIN ipc_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock
				WITH 
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS waitings_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0
				) ,
				lock_waitings AS
				(
					SELECT 
						curr_timestamp , lock_long  AS lock_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND lock_long > 0 
				) 
				SELECT COALESCE( corr( waitings_long , lock_long ) , 0 ) AS correlation_value 
				INTO corr_lock
				FROM
					waitings os JOIN lock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock
				WITH 
				waitings AS
				(
					SELECT 
						curr_timestamp , waitings_long  AS waitings_long  
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND waitings_long > 0				
				) ,
				lwlock_waitings AS
				(
					SELECT 
						curr_timestamp , lwlock_long  AS lwlock_long 
					FROM pgh_stat_cluster_analysis
					WHERE				
						curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
						AND lwlock_long > 0 
				) 
				SELECT COALESCE( corr( waitings_long , lwlock_long ) , 0 ) AS correlation_value 
				INTO corr_lwlock
				FROM
					waitings os JOIN lwlock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock 
			----------------------------------------------------------------------------------------------------
			DROP TABLE IF EXISTS tmp_timepoints;
			CREATE TEMPORARY TABLE tmp_timepoints
			(
				curr_timestamp timestamptz  ,   
				timepoint integer 
			);


			INSERT INTO tmp_timepoints
			(
				curr_timestamp ,	
				timepoint 
			)
			SELECT 
				curr_timestamp , 
				row_number() over (order by curr_timestamp) AS x
			FROM
			pgh_stat_cluster_analysis
			WHERE 
				curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint
			ORDER BY curr_timestamp	;
			
			----------------------------------------------------------------------------------------------------
			-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - СКОРОСТЬ 
			SELECT COALESCE( regr_slope ( t.timepoint::DOUBLE PRECISION ,  s.op_speed_long::DOUBLE PRECISION ) , 0 )
			INTO speed_regr_slope_value
			FROM
				pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
			WHERE 
				t.curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint;		
			-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - СКОРОСТЬ 
			----------------------------------------------------------------------------------------------------
			
			----------------------------------------------------------------------------------------------------
			-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - ОЖИДАНИЯ 
			SELECT COALESCE( regr_slope ( t.timepoint::DOUBLE PRECISION ,  s.waitings_long::DOUBLE PRECISION ) , 0 ) 
			INTO waitings_regr_slope_value
			FROM
				pgh_stat_cluster_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
			WHERE 
				t.curr_timestamp BETWEEN performance_incident_rec.start_timepoint - interval '1 hour' AND performance_incident_rec.start_timepoint;
			-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ - ОЖИДАНИЯ
			----------------------------------------------------------------------------------------------------
			
				IF performance_incident_rec.finish_timepoint IS NOT NULL 
				THEN 
					SELECT ( EXTRACT( EPOCH FROM performance_incident_rec.finish_timepoint )
										 - 
										 EXTRACT( EPOCH from performance_incident_rec.start_timepoint ) ) / 60.0 
					INTO incident_duration ;
					
					result_str[line_count] =performance_incident_rec.id ||'|'||  
											REPLACE ( TO_CHAR( ROUND( performance_incident_rec.priority::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
											to_char( performance_incident_rec.start_timepoint , 'YYYY-MM-DD HH24:MI' ) ||'|'||  
											to_char( performance_incident_rec.finish_timepoint , 'YYYY-MM-DD HH24:MI' ) ||'|'||  
											REPLACE ( TO_CHAR( ROUND( incident_duration::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||                           			
											REPLACE ( TO_CHAR( ROUND( atand( speed_regr_slope_value )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
											REPLACE ( TO_CHAR( ROUND( ( speed_regr_slope_value*100.0 )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
											REPLACE ( TO_CHAR( ROUND( atand( waitings_regr_slope_value )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
											REPLACE ( TO_CHAR( ROUND( ( waitings_regr_slope_value*100.0 )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
											REPLACE ( TO_CHAR( ROUND( speed_waitings_correlation::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
											REPLACE ( TO_CHAR( ROUND( corr_bufferpin::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
											REPLACE ( TO_CHAR( ROUND( corr_extension::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
											REPLACE ( TO_CHAR( ROUND( corr_io::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
											REPLACE ( TO_CHAR( ROUND( corr_ipc::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
											REPLACE ( TO_CHAR( ROUND( corr_lock::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
											REPLACE ( TO_CHAR( ROUND( corr_lwlock::numeric , 4 ) , '000000000000D0000') , '.' , ',' )  
											;	
					line_count=line_count+1; 	
				ELSE
					result_str[line_count] =performance_incident_rec.id ||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.priority::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									to_char( performance_incident_rec.start_timepoint , 'YYYY-MM-DD HH24:MI' ) ||'|'||  
									' ' ||'|'||  
									' ' ||'|'||
                           			REPLACE ( TO_CHAR( ROUND( atand( speed_regr_slope_value )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( ( speed_regr_slope_value*100.0 )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( atand( waitings_regr_slope_value )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( ( waitings_regr_slope_value*100.0 )::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( speed_waitings_correlation::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( corr_bufferpin::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( corr_extension::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
									REPLACE ( TO_CHAR( ROUND( corr_io::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
									REPLACE ( TO_CHAR( ROUND( corr_ipc::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
									REPLACE ( TO_CHAR( ROUND( corr_lock::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||  
									REPLACE ( TO_CHAR( ROUND( corr_lwlock::numeric , 4 ) , '000000000000D0000') , '.' , ',' )  
									;	
			line_count=line_count+1;	
				
				END IF ;		
			
			-----------------------------------------------
			-- СОХРАНИТЬ СТАТИСТИКУ ИНЦИДЕНТА
			UPDATE 	performance_incident
			SET		
				is_stats_calculated = TRUE ,

				
				curr_speed_regr_slope_value = atand( speed_regr_slope_value ) , 
				curr_waitings_regr_slope_value = atand( waitings_regr_slope_value ) ,
				
				curr_speed_waitings_correlation = speed_waitings_correlation,
			  
				curr_corr_bufferpin  = corr_bufferpin  , 
				curr_corr_extension  = corr_extension  , 
				curr_corr_io  = corr_io  , 
				curr_corr_ipc  = corr_ipc  , 
				curr_corr_lock  = corr_lock  , 
				curr_corr_lwlock  = corr_lwlock
			WHERE	id = performance_incident_rec.id ;
			-- СОХРАНИТЬ СТАТИСТИКУ ИНЦИДЕНТА
			-----------------------------------------------
		--ЕСЛИ СТАТИСТИКА ИНЦИДЕНТА НЕ РАСЧИТАНА
		----------------------------------------------
		--ЕСЛИ СТАТИСТИКА ИНЦИДЕНТА УЖЕ РАСЧИТАНА
		ELSE
			IF performance_incident_rec.finish_timepoint IS NOT NULL 
			THEN 
			  SELECT ( EXTRACT( EPOCH FROM performance_incident_rec.finish_timepoint )
										 - 
										 EXTRACT( EPOCH from performance_incident_rec.start_timepoint ) ) / 60.0
				INTO incident_duration ;
				
				result_str[line_count] =performance_incident_rec.id ||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.priority::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
										to_char( performance_incident_rec.start_timepoint , 'YYYY-MM-DD HH24:MI' ) ||'|'||  
										to_char( performance_incident_rec.finish_timepoint , 'YYYY-MM-DD HH24:MI' ) ||'|'|| 
										REPLACE ( TO_CHAR( ROUND( incident_duration::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_speed_regr_slope_value::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||   
										REPLACE ( TO_CHAR( ROUND( (tand( performance_incident_rec.curr_speed_regr_slope_value) * 100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_waitings_regr_slope_value::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( (tand(performance_incident_rec.curr_waitings_regr_slope_value) * 100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_speed_waitings_correlation::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_bufferpin::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_extension::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_io::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_ipc::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_lock::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
										REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_lwlock::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
										;	
				line_count=line_count+1;  
			ELSE
			  result_str[line_count] =performance_incident_rec.id ||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.priority::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									to_char( performance_incident_rec.start_timepoint , 'YYYY-MM-DD HH24:MI' ) ||'|'||  
									' ' ||'|'|| 
									' ' ||'|'||
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_speed_regr_slope_value::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||   
									REPLACE ( TO_CHAR( ROUND( (tand( performance_incident_rec.curr_speed_regr_slope_value) * 100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_waitings_regr_slope_value::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( (tand(performance_incident_rec.curr_waitings_regr_slope_value) * 100.0)::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_speed_waitings_correlation::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_bufferpin::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_extension::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_io::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_ipc::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_lock::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||  
									REPLACE ( TO_CHAR( ROUND( performance_incident_rec.curr_corr_lwlock::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
									;	
			line_count=line_count+1; 
			
			END IF;
		END IF; 
		--ЕСЛИ СТАТИСТИКА ИНЦИДЕНТА УЖЕ РАСЧИТАНА
		----------------------------------------------
	END LOOP ;
	--ПО ИНЦИДЕНТАМ В ПЕРИОД ОТЧЕТА 
	-------------------------------------------------------------------
	
	
/*	
	-----------------------------------------------
	-- УДАЛИТЬ ТЕКУЩИЕ ЗНАЧЕНИЯ НА ДЕНЬ , ЕСЛИ ЕСТЬ 
	DELETE FROM daily_wait_event_type_queryid_stats
	WHERE start_timepoint = min_timestamp ; 
	-- УДАЛИТЬ ТЕКУЩИЕ ЗНАЧЕНИЯ НА ДЕНЬ , ЕСЛИ ЕСТЬ 
*/	
  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
