-- deferred_strategy.sql
-- version 78.0
/*
prepare_stats_for_period() - подготовить сбор статистики за период
start_stats_for_period() - начать сбор статистики за период
get_next_timepoint_for_report - следующий период
*/

--------------------------------------------------------
-- ВНУТРЕННЯЯ ТАБЛИЦА ДЛЯ ХРАНЕНИЯ ДАННЫХ ПО ОТЧЕТУ
DROP TABLE IF EXISTS deferred_strategy;
CREATE UNLOGGED TABLE deferred_strategy 
(
  min_timestamp timestamptz ,
  max_timestamp timestamptz ,
  curr_timestamp timestamptz ,
  total_rows integer 
);

-- ВНУТРЕННЯЯ ТАБЛИЦА ДЛЯ ХРАНЕНИЯ ДАННЫХ ПО ОТЧЕТУ
--------------------------------------------------------
--подготовить сбор статистики за период
CREATE OR REPLACE FUNCTION 	prepare_stats_for_period( start_timestamp text  , finish_timestamp text) RETURNS integer 
AS $$
DECLARE
  pgpwr_pro_sample_count integer ; 
  min_time timestamptz ;  
  max_time timestamptz ;  
  curr_time timestamptz ;  
  total_rows integer ;
  first_pgpro_pwr_time timestamptz ;  
BEGIN

	SELECT 
		COUNT(curr_timestamp) 
	INTO	
		pgpwr_pro_sample_count
	FROM 
		pgpro_pwr_samples ; 

	
	IF pgpwr_pro_sample_count < 2
	THEN 
		return 1; --'INSUFFICIENT_DATA'
	END IF ;
	
	SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
	INTO 	min_time ; 		
	
	SELECT MAX(curr_timestamp)
	INTO first_pgpro_pwr_time
	FROM pgpro_pwr_samples
	WHERE curr_timestamp <= min_time ; 
	
	SELECT date_trunc('minute' ,  first_pgpro_pwr_time ) 
	INTO min_time ;
	
	SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
	INTO 	max_time ; 

	SELECT 
		count(id) 
	INTO 
		total_rows
	FROM 
		stat_statement 
	WHERE curr_timestamp 
		BETWEEN min_time AND max_time ; 	
	
	TRUNCATE TABLE deferred_strategy ; 
	TRUNCATE TABLE stat_statement_analysis;
	TRUNCATE TABLE stat_statement_wait_events;
	TRUNCATE TABLE stat_statement_wait_events_analysis;
	TRUNCATE TABLE sql_stats_history ;
	
	INSERT INTO deferred_strategy
	(
		min_timestamp ,
		max_timestamp ,		
		total_rows 
	)
	VALUES 
	(
		min_time ,
		max_time ,
		total_rows 
	);
	
return 0 ;
END
$$ LANGUAGE plpgsql;

--начать сбор статистики за период
CREATE OR REPLACE FUNCTION 	start_stats_for_period() RETURNS text 
AS $$
DECLARE
  deferred_strategy_rec record ;
  result_text text ;
BEGIN
	SELECT * 
	INTO deferred_strategy_rec
	FROM deferred_strategy ; 
	
	result_text = 'ROWS = '||deferred_strategy_rec.total_rows||', START = '|| deferred_strategy_rec.min_timestamp||' , FINISH ='||deferred_strategy_rec.max_timestamp ;
	
return result_text;
END
$$ LANGUAGE plpgsql;

--следующий период
CREATE OR REPLACE FUNCTION 	get_next_timepoint_for_report() RETURNS text 
AS $$
DECLARE
  deferred_strategy_rec record ;
  res integer ;
BEGIN
	SELECT * 
	INTO deferred_strategy_rec
	FROM deferred_strategy ; 

	--самый первый отрезок
	IF 	deferred_strategy_rec.curr_timestamp IS NULL 
	THEN 
		UPDATE deferred_strategy
		SET curr_timestamp = deferred_strategy_rec.min_timestamp ; 
		
		return to_char( deferred_strategy_rec.min_timestamp , 'YYYY-MM-DD HH24:MI') ;
	END IF ;
	--самый первый отрезок
	
	--последний отрезок
	IF 	deferred_strategy_rec.curr_timestamp = deferred_strategy_rec.max_timestamp
	THEN 
		return 'FINISH' ;
	END IF ;
	--последний отрезок
	
	--Следующий отрезок
	deferred_strategy_rec.curr_timestamp = deferred_strategy_rec.curr_timestamp + interval '1 minute';
	UPDATE deferred_strategy
	SET curr_timestamp = deferred_strategy_rec.curr_timestamp ; 
	
	SELECT prepare_stat_statement_analysis( to_char( deferred_strategy_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI ') , 
											to_char( deferred_strategy_rec.curr_timestamp + interval '1 minute' , 'YYYY-MM-DD HH24:MI ') )
	INTO res ;
	
	INSERT INTO sql_stats_history 
	(
		timepoint
	)
	VALUES 
	(
		deferred_strategy_rec.curr_timestamp
	);
		
	return to_char( deferred_strategy_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ;
	--Следующий отрезок
END
$$ LANGUAGE plpgsql;


