-- get_hour_before.sql
-- cd /postgres/scripts/tester/reports/functions
-- psql -d performance_monitoring_db -U performance_monitoring_user -f get_hour_before.sql
-- version 81.1
CREATE OR REPLACE FUNCTION get_hour_before( finish_timestamp text ) RETURNS text AS $$
DECLARE
 result_str text;
BEGIN
	SELECT 
		to_char(to_timestamp(finish_timestamp , 'YYYY-MM-DD HH24:MI') - interval '1 hour','YYYY-MM-DD HH24:MI')
	INTO 
		result_str ; 
		
	return result_str ; 
END
$$ LANGUAGE plpgsql  ;

	
	
	
