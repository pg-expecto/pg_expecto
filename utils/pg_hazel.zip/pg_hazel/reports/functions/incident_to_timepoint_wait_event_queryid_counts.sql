----------------------------------------------------------------------------------------------------------------
-- incident_to_timepoint_wait_event_queryid_counts.sql
-- version 40.0


CREATE OR REPLACE FUNCTION incident_to_timepoint_wait_event_queryid_counts() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 
 incident_to_timepoint_wait_event_queryid_rec record ; 
 wait_event_type_rec record ; 
  
BEGIN
	line_count = 1 ;
	
	result_str[line_count] =' WAIT_EVENT_TYPE  '||'|'|| 
						    ' WAIT_EVENT  '||'|'|| 
							' QUERYID COUNT '||'|'
							;	
	line_count=line_count+1;
		
	FOR incident_to_timepoint_wait_event_queryid_rec IN 
	SELECT 	
		wait_event_type , 
		wait_event , 
		count(*) AS queryid_count
	FROM 	
		incident_to_timepoint_wait_event_queryid
	GROUP BY 
		wait_event_type , 
		wait_event
	ORDER BY 
		3 DESC
	LOOP 
		result_str[line_count] =incident_to_timepoint_wait_event_queryid_rec.wait_event_type  ||'|'||
								incident_to_timepoint_wait_event_queryid_rec.wait_event  ||'|'||
								incident_to_timepoint_wait_event_queryid_rec.queryid_count  ||'|'
								;							
		line_count=line_count+1; 		
	END LOOP ; 	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

	
	
	
