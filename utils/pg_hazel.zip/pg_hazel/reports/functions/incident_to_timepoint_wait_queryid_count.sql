----------------------------------------------------------------------------------------------------------------
-- incident_to_timepoint_wait_queryid_count.sql
-- version 40.0

CREATE OR REPLACE FUNCTION incident_to_timepoint_wait_queryid_count() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 
 wait_event_type_queryid_stats_rec record ; 
 waitings_for_sql_rec record ; 
 
 wait_event_type_rec record ; 
  
BEGIN
	line_count = 1 ;
	
	result_str[line_count] =' WAIT_EVENT_TYPE  '||'|'||  
							' QUERYID COUNT '||'|'
							;	
	line_count=line_count+1;
		
	FOR wait_event_type_queryid_stats_rec IN 
	SELECT 	
		w.wait_event_type , 
		count(*) AS queryid_count
	FROM 	
		wait_event_type_queryid_stats_for_incidents_to_timepoint w
	GROUP BY 
		w.wait_event_type 
	ORDER BY 
		w.wait_event_type
	LOOP 
		result_str[line_count] =wait_event_type_queryid_stats_rec.wait_event_type  ||'|'||
								wait_event_type_queryid_stats_rec.queryid_count  ||'|'
								;							
		line_count=line_count+1; 		
	END LOOP ; 	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

