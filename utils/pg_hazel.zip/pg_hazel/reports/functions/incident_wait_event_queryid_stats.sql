----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО WAIT_EVENT - QUERYID ПО ИНЦИДЕНТУ
-- incident_wait_event_queryid_stats.sql
-- version 35.1

CREATE OR REPLACE FUNCTION incident_wait_event_queryid_stats() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 
 wait_event_type_queryid_stats_rec record ; 
 waitings_for_sql_rec record ; 
 
 wait_event_type_rec record ; 
  
BEGIN
	line_count = 1 ;

	result_str[line_count] = 'incident_wait_event_queryid_stats' ; 
	line_count=line_count+2; 
	
	
	result_str[line_count] =' WAIT_EVENT_TYPE  '||'|'||  
							' QUERYID COUNT '||'|'
							;	
	line_count=line_count+1;
		
	FOR wait_event_type_queryid_stats_rec IN 
	SELECT 	
		w.wait_event_type , 
		count(*) AS queryid_count
	FROM 	
		wait_event_type_queryid_stats w
	GROUP BY 
		w.wait_event_type 
	ORDER BY 
		w.wait_event_type
	LOOP 
		result_str[line_count] =wait_event_type_queryid_stats_rec.wait_event_type  ||'|'||
								wait_event_type_queryid_stats_rec.queryid_count  ||'|'
								;							
		line_count=line_count+1; 		
	END LOOP ; 	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
