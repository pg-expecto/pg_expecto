----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО WAIT_EVENT ПО ИНЦИДЕНТУ
-- incident_wait_event_stats.sql
-- version 29.0

CREATE OR REPLACE FUNCTION incident_wait_event_stats() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 
 wait_event_type_queryid_stats_rec record ; 
 waitings_for_sql_rec record ; 
  
BEGIN
	line_count = 1 ;

	result_str[line_count] = 'incident_wait_event_stats' ; 
	line_count=line_count+1; 
	
	
	
	result_str[line_count] = 'WAIT_EVENT_TYPE FOR SQL' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 	' QUERYID  '||'|'||  
								' PGPRO_PWR QUERYID '||'|'||  
								' WAIT_EVENT_TYPE COUNT '||'|'||  
								' WAIT_EVENT_TYPE LIST' ||'|'						
								;	
	line_count=line_count+1; 
	
	
	FOR waitings_for_sql_rec IN 	
	WITH 
	all_wait_event_type AS
	(
		SELECT 	
			w.queryid , 
			w.pgpro_pwr_queryid_hex , 
			w.wait_event_type 	
		FROM 	wait_event_type_queryid_stats w
		GROUP BY  
			w.queryid , 
			w.pgpro_pwr_queryid_hex ,
			w.wait_event_type
	),
	wait_event_count AS
	( 
		SELECT 
			aw.queryid , 
			aw.pgpro_pwr_queryid_hex , 
			count(*) AS wait_event_count
		FROM all_wait_event_type aw
		GROUP BY 
			aw.queryid , 
			aw.pgpro_pwr_queryid_hex
	)
	SELECT 
		aw.queryid , 
		aw.pgpro_pwr_queryid_hex ,
		we.wait_event_count AS wait_event_type_count , 
		(
			select string_agg( c.wait_event_type , ' - ' ) 
			from all_wait_event_type c
			where c.queryid = aw.queryid
		) AS wait_type_events
	FROM 
		all_wait_event_type aw JOIN 
		wait_event_count we ON ( aw.queryid = we.queryid ) 
	GROUP BY 
		1 , 2 , 3 , 4
	ORDER BY 3 DESC 
	LOOP
		result_str[line_count] =	waitings_for_sql_rec.queryid  ||'|'||
									waitings_for_sql_rec.pgpro_pwr_queryid_hex  ||'|'||
									waitings_for_sql_rec.wait_event_type_count  ||'|'||
									waitings_for_sql_rec.wait_type_events  ||'|'									
									;							
		line_count=line_count+1; 
	
	END LOOP;

/*	
	line_count=line_count+1; 
	result_str[line_count] = 'CALLS & WAITINGS STATS FOR SQL' ; 
	line_count=line_count+1; 
	
	
	result_str[line_count] = 	' QUERYID  '||'|'||  
								' PGPRO_PWR QUERYID '||'|'||  
								' WAIT_EVENT_TYPE '||'|'||  
								' CALLS' ||'|'|| 
								' WAITINGS' ||'|'||
								' WAITINGS TO CALLS' ||'|'							
								;	
	line_count=line_count+1; 
	
	FOR wait_event_type_queryid_stats_rec IN 
	SELECT 	
		queryid , 
		pgpro_pwr_queryid_hex , 
		wait_event_type , 
		SUM( calls ) AS calls ,
		SUM( waitings ) AS waitings , 
		SUM( waitings )::numeric / SUM( calls )::numeric AS waitings_to_calls 
	FROM 	wait_event_type_queryid_stats
	GROUP BY  
		queryid , 
		pgpro_pwr_queryid_hex , 
		wait_event_type 
	order by 
		5 DESC
	LOOP
		result_str[line_count] =	wait_event_type_queryid_stats_rec.queryid  ||'|'||
									wait_event_type_queryid_stats_rec.pgpro_pwr_queryid_hex  ||'|'||
									wait_event_type_queryid_stats_rec.wait_event_type  ||'|'||
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.calls::numeric , 10 ) , '000000000000D0000000000' ) , '.' , ',' )  ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.waitings::numeric , 10 ) , '000000000000D0000000000' ) , '.' , ',' )  ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.waitings_to_calls::numeric , 10 ) , '000000000000D0000000000' ) , '.' , ',' )  ||'|'
									;							
		line_count=line_count+1; 
	END LOOP ;
*/		

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
