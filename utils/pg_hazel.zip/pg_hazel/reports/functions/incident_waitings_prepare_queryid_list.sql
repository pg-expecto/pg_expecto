----------------------------------------------------------------------------------------------------------------
-- incident_waitings_prepare_queryid_list.sql
-- version 40.0

CREATE OR REPLACE FUNCTION incident_waitings_prepare_queryid_list(  incident_id integer   , current_wait_event_type text ) RETURNS integer AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 incident_min_timestamp timestamptz ; 
 incident_max_timestamp timestamptz ; 
  
 sql_stats_history_rec record ;  
BEGIN
	---------------------------------------------------
	-- !!! ВНИМАНИЕ !!!
	-- СТАТИСТИКА ПО ИНЦИДЕНТУ НА УРОВНЕ SQL 
	-- СОБИРАЕТСЯ НЕ НА ВРЕМЯ НАЧАЛА ИНЦИДЕНТА 
	-- А НА БЛИЖАЙЩЕЕ ВРЕМЯ ЗАВЕРШЕНИЯ СБОРА СТАТИСТИКИ ПО SQL 
	-- ПОСЛЕ НАЧАЛА ИНЦИДЕНТА 	
	SELECT 	timepoint , 
			(timepoint - (SELECT start_timepoint FROM  performance_incident WHERE id = incident_id ))
	INTO 	sql_stats_history_rec
	FROM 	sql_stats_history 
	WHERE 	( timepoint - (SELECT start_timepoint FROM  performance_incident WHERE id = incident_id )) > interval '0 minute'
	ORDER BY 2  
	LIMIT 1 ;
	-- !!! ВНИМАНИЕ !!!
	---------------------------------------------------
	
	--СТАТИСТИКА ИНЦИДЕНТА 
	incident_min_timestamp = sql_stats_history_rec.timepoint  - interval '1 hour'; 
	incident_max_timestamp = sql_stats_history_rec.timepoint ; 
	--СТАТИСТИКА ИНЦИДЕНТА 	
	
RAISE NOTICE 'incident_id=%',incident_id;	
RAISE NOTICE 'incident_min_timestamp=%',incident_min_timestamp;	
RAISE NOTICE 'incident_min_timestamp=%',incident_max_timestamp;	
	
	TRUNCATE TABLE incident_stats_current_queryid ; 
	ALTER SEQUENCE incident_stats_current_queryid_seq RESTART ;

	INSERT INTO incident_stats_current_queryid
	(
		queryid 
	)
	SELECT 
		DISTINCT queryid
	FROM 
		stat_statement_wait_events_analysis
	WHERE 	
		curr_timestamp  BETWEEN 
		incident_min_timestamp AND incident_max_timestamp 
		AND wait_event_type = current_wait_event_type ;

  return 0 ; 
END
$$ LANGUAGE plpgsql  ;
