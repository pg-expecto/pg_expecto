----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО ТИПУ ОЖИДАНИЙ ЗА ПЕРИОД ПО ИНЦИДЕНТУ И QUERYID
-- incident_waitings_queryid.sql
-- version 40.1

CREATE OR REPLACE FUNCTION incident_waitings_queryid(  incident_id integer  , current_queryid bigint  , current_wait_event_type text ) RETURNS integer  AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
  
  min_max_pct_rec record ;
 
  queryid_waitings_calls_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
  corr_bufferpin DOUBLE PRECISION ; 
  corr_extension DOUBLE PRECISION ; 
  corr_io DOUBLE PRECISION ; 
  corr_ipc DOUBLE PRECISION ; 
  corr_lock DOUBLE PRECISION ; 
  corr_lwlock DOUBLE PRECISION ; 
  
  current_last_sql_statistics timestamp with time zone ; 
  
  current_waitings_calls DOUBLE PRECISION ;   
  all_waitings DOUBLE PRECISION ;   
  total_all_waitings DOUBLE PRECISION ;   
  
  correlation_value_rec record ;   
  curr_wait_event_type_promile DOUBLE PRECISION ;   
  
  queryid_rec record ;	
  temp_incident_sql_for_wait_event_type_rec record ; 
  current_queryid_hex text ;
  
  current_queryid_rec record ; 
 
  incident_min_timestamp timestamptz ; 
  incident_max_timestamp timestamptz ;   
  
  
  temp_queryid_stats_rec record ; 
  wait_event_type_queryid_stats_rec record ; 
  
  sql_stats_history_rec record ; 
  
  tmp_report_string text ;
BEGIN
	line_count = 1 ;

	
	DROP TABLE IF EXISTS temp_queryid_stats ;
	CREATE TEMPORARY TABLE temp_queryid_stats 
	--CREATE TABLE temp_queryid_stats 
	(
	  wait_event_type text , 
	  queryid bigint , 
	  correlation_value numeric , 
	  calls numeric ,
	  waitings numeric ,
	  waitings_calls numeric , 
	  wait_event_type_promile numeric
	);
	
--RAISE NOTICE '%' , current_wait_event_type;
--RAISE NOTICE '%' , min_timestamp;
--RAISE NOTICE '%' , max_timestamp;
	
	
	total_all_waitings = 0 ; 

	---------------------------------------------------
	-- !!! ВНИМАНИЕ !!!
	-- СТАТИСТИКА ПО ИНЦИДЕНТУ НА УРОВНЕ SQL 
	-- СОБИРАЕТСЯ НЕ НА ВРЕМЯ НАЧАЛА ИНЦИДЕНТА 
	-- А НА БЛИЖАЙЩЕЕ ВРЕМЯ ЗАВЕРШЕНИЯ СБОРА СТАТИСТИКИ ПО SQL 
	-- ПОСЛЕ НАЧАЛА ИНЦИДЕНТА 	
	SELECT 	timepoint , 
			(timepoint - (SELECT start_timepoint FROM  performance_incident WHERE id = incident_id ))
	INTO 	sql_stats_history_rec
	FROM 	sql_stats_history 
	WHERE 	( timepoint - (SELECT start_timepoint FROM  performance_incident WHERE id = incident_id )) > interval '0 minute'
	ORDER BY 2  
	LIMIT 1 ;
	-- !!! ВНИМАНИЕ !!!
	---------------------------------------------------
	
	--СТАТИСТИКА ИНЦИДЕНТА 
	incident_min_timestamp = sql_stats_history_rec.timepoint  - interval '1 hour'; 
	incident_max_timestamp = sql_stats_history_rec.timepoint ; 
	--СТАТИСТИКА ИНЦИДЕНТА 	
	
	
		-------------------------------------------------------------------------------------
		-- КОРРЕЛЯЦИЯ , КОЛИЧЕСТВО ВЫЗОВОВ И ОЖИДАНИЙ ПО ТИПУ
		CASE 
			--BufferPin			
			WHEN current_wait_event_type = 'BufferPin' THEN 				
				SELECT 
					SUM( bufferpin_long  )
				INTO all_waitings
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND bufferpin_long > 0 AND calls_long > 0 ;
				
				SELECT 
					SUM( bufferpin_long  ) AS waitings_long , 
					SUM( calls_long ) AS calls_long 
				INTO queryid_waitings_calls_rec
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND bufferpin_long > 0 AND calls_long > 0 
					AND queryid = current_queryid ;
					
				WITH waitings AS
				(
					WITH all_queries AS
					(
						SELECT 
							curr_timestamp ,
							SUM( bufferpin_long  ) AS waitings_long 
						FROM 
							stat_statement_analysis
						WHERE 	
							curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
							AND bufferpin_long > 0 AND calls_long > 0 
						GROUP BY 
							curr_timestamp , queryid 
					)
					SELECT 
						curr_timestamp , 
						SUM( waitings_long  ) AS waitings
					FROM all_queries aq
					GROUP BY curr_timestamp 
				) ,
				wait_event_type_count AS
				(
					SELECT 
						curr_timestamp ,
						SUM( bufferpin_long  ) AS waitings
					FROM 
						stat_statement_analysis
					WHERE 	
						curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
						AND bufferpin_long > 0 AND calls_long > 0 
						AND queryid = current_queryid
					GROUP BY 
							curr_timestamp , queryid
				)
				SELECT corr(  w.waitings , wt.waitings ) AS correlation_value 
				INTO correlation_value_rec
				FROM waitings w JOIN wait_event_type_count wt ON ( w.curr_timestamp = wt.curr_timestamp ) ;

					
			--Extension	
			WHEN current_wait_event_type = 'Extension' THEN 
				SELECT 
					SUM( extension_long  )
				INTO all_waitings
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND extension_long > 0 AND calls_long > 0 ;
					
				SELECT 
					SUM( extension_long  ) AS waitings_long , 
					SUM( calls_long ) AS calls_long 
				INTO queryid_waitings_calls_rec
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND extension_long > 0 AND calls_long > 0 
					AND queryid = current_queryid;
					
				WITH waitings AS
				(
					WITH all_queries AS
					(
						SELECT 
							curr_timestamp ,
							SUM( extension_long  ) AS waitings_long 
						FROM 
							stat_statement_analysis
						WHERE 	
							curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
							AND extension_long > 0 AND calls_long > 0 
						GROUP BY 
							curr_timestamp , queryid 
					)
					SELECT 
						curr_timestamp , 
						SUM( waitings_long  ) AS waitings
					FROM all_queries aq
					GROUP BY curr_timestamp 
				) ,
				wait_event_type_count AS
				(
					SELECT 
						curr_timestamp ,
						SUM( extension_long  ) AS waitings
					FROM 
						stat_statement_analysis
					WHERE 	
						curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
						AND extension_long > 0 AND calls_long > 0 
						AND queryid = current_queryid
					GROUP BY 
							curr_timestamp , queryid
				)
				SELECT corr(  w.waitings , wt.waitings ) AS correlation_value 
				INTO correlation_value_rec
				FROM waitings w JOIN wait_event_type_count wt ON ( w.curr_timestamp = wt.curr_timestamp ) ;
					
			--IO 	
			WHEN current_wait_event_type = 'IO' THEN 
				SELECT 
					SUM( io_long  )
				INTO all_waitings
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND io_long > 0 AND calls_long > 0 ;
					
				
				SELECT 
					SUM( io_long  ) AS waitings_long , 
					SUM( calls_long ) AS calls_long 
				INTO queryid_waitings_calls_rec
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND io_long > 0 AND calls_long > 0 
					AND queryid = current_queryid;
					
				WITH waitings AS
				(
					WITH all_queries AS
					(
						SELECT 
							curr_timestamp ,
							SUM( io_long  ) AS waitings_long 
						FROM 
							stat_statement_analysis
						WHERE 	
							curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
							AND io_long > 0 AND calls_long > 0 
						GROUP BY 
							curr_timestamp , queryid 
					)
					SELECT 
						curr_timestamp , 
						SUM( waitings_long  ) AS waitings
					FROM all_queries aq
					GROUP BY curr_timestamp 
				) ,
				wait_event_type_count AS
				(
					SELECT 
						curr_timestamp ,
						SUM( io_long  ) AS waitings
					FROM 
						stat_statement_analysis
					WHERE 	
						curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
						AND io_long > 0 AND calls_long > 0 
						AND queryid = current_queryid
					GROUP BY 
							curr_timestamp , queryid
				)
				SELECT corr(  w.waitings , wt.waitings ) AS correlation_value 
				INTO correlation_value_rec
				FROM waitings w JOIN wait_event_type_count wt ON ( w.curr_timestamp = wt.curr_timestamp ) ;
					
			--IPC
			WHEN current_wait_event_type = 'IPC' THEN 
				SELECT 
					SUM( ipc_long  )
				INTO all_waitings
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND ipc_long > 0 AND calls_long > 0 ;
					
				
				SELECT 
					SUM( ipc_long  ) AS waitings_long , 
					SUM( calls_long ) AS calls_long 
				INTO queryid_waitings_calls_rec
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND ipc_long > 0 AND calls_long > 0 
					AND queryid = current_queryid;
					
				WITH waitings AS
				(
					WITH all_queries AS
					(
						SELECT 
							curr_timestamp ,
							SUM( ipc_long  ) AS waitings_long 
						FROM 
							stat_statement_analysis
						WHERE 	
							curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
							AND ipc_long > 0 AND calls_long > 0 
						GROUP BY 
							curr_timestamp , queryid 
					)
					SELECT 
						curr_timestamp , 
						SUM( waitings_long  ) AS waitings
					FROM all_queries aq
					GROUP BY curr_timestamp 
				) ,
				wait_event_type_count AS
				(
					SELECT 
						curr_timestamp ,
						SUM( ipc_long  ) AS waitings
					FROM 
						stat_statement_analysis
					WHERE 	
						curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
						AND ipc_long > 0 AND calls_long > 0 
						AND queryid = current_queryid
					GROUP BY 
							curr_timestamp , queryid
				)
				SELECT corr(  w.waitings , wt.waitings ) AS correlation_value 
				INTO correlation_value_rec
				FROM waitings w JOIN wait_event_type_count wt ON ( w.curr_timestamp = wt.curr_timestamp ) ;					
				
			--Lock	
			WHEN current_wait_event_type = 'Lock' THEN 
				SELECT 
					SUM( lock_long  )
				INTO all_waitings
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND lock_long > 0 AND calls_long > 0 ;
					
				
				SELECT 
					SUM( lock_long  ) AS waitings_long , 
					SUM( calls_long ) AS calls_long 
				INTO queryid_waitings_calls_rec
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND lock_long > 0 AND calls_long > 0 
					AND queryid = current_queryid;
					
				WITH waitings AS
				(
					WITH all_queries AS
					(
						SELECT 
							curr_timestamp ,
							SUM( lock_long  ) AS waitings_long 
						FROM 
							stat_statement_analysis
						WHERE 	
							curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
							AND lock_long > 0 AND calls_long > 0 
						GROUP BY 
							curr_timestamp , queryid 
					)
					SELECT 
						curr_timestamp , 
						SUM( waitings_long  ) AS waitings
					FROM all_queries aq
					GROUP BY curr_timestamp 
				) ,
				wait_event_type_count AS
				(
					SELECT 
						curr_timestamp ,
						SUM( lock_long  ) AS waitings
					FROM 
						stat_statement_analysis
					WHERE 	
						curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
						AND lock_long > 0 AND calls_long > 0 
						AND queryid = current_queryid
					GROUP BY 
							curr_timestamp , queryid
				)
				SELECT corr(  w.waitings , wt.waitings ) AS correlation_value 
				INTO correlation_value_rec
				FROM waitings w JOIN wait_event_type_count wt ON ( w.curr_timestamp = wt.curr_timestamp ) ;						
				
			--LWLock
			WHEN current_wait_event_type = 'LWLock' THEN
				SELECT 
					SUM( lwlock_long  )
				INTO all_waitings
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND lwlock_long > 0 AND calls_long > 0 ;
					
				
				SELECT 
					SUM( lwlock_long  ) AS waitings_long , 
					SUM( calls_long ) AS calls_long 
				INTO queryid_waitings_calls_rec
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
					AND lwlock_long > 0 AND calls_long > 0 
					AND queryid = current_queryid;
					
				WITH waitings AS
				(
					WITH all_queries AS
					(
						SELECT 
							curr_timestamp ,
							SUM( lwlock_long  ) AS waitings_long 
						FROM 
							stat_statement_analysis
						WHERE 	
							curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
							AND lwlock_long > 0 AND calls_long > 0 
						GROUP BY 
							curr_timestamp , queryid 
					)
					SELECT 
						curr_timestamp , 
						SUM( waitings_long  ) AS waitings
					FROM all_queries aq
					GROUP BY curr_timestamp 
				) ,
				wait_event_type_count AS
				(
					SELECT 
						curr_timestamp ,
						SUM( lwlock_long  ) AS waitings
					FROM 
						stat_statement_analysis
					WHERE 	
						curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp 
						AND lwlock_long > 0 AND calls_long > 0 
						AND queryid = current_queryid
					GROUP BY 
							curr_timestamp , queryid
				)
				SELECT corr(  w.waitings , wt.waitings ) AS correlation_value 
				INTO correlation_value_rec
				FROM waitings w JOIN wait_event_type_count wt ON ( w.curr_timestamp = wt.curr_timestamp ) ;						
			
		END CASE ;
		-- КОРРЕЛЯЦИЯ , КОЛИЧЕСТВО ВЫЗОВОВ И ОЖИДАНИЙ ПО ТИПУ
		-------------------------------------------------------------------------------------
		
			----------------------------------------------------------------------------------
			IF queryid_waitings_calls_rec.calls_long > 0 
			THEN 
				current_waitings_calls = queryid_waitings_calls_rec.waitings_long / queryid_waitings_calls_rec.calls_long  ; 			
			ELSE
				current_waitings_calls = 0; 
			END IF ;
			
			total_all_waitings = total_all_waitings + all_waitings ; 
			--curr_wait_event_type_promile = queryid_waitings_calls_rec.waitings_long / all_waitings * 1000.0 ;
			
			
			INSERT INTO temp_queryid_stats 
			(
				wait_event_type , 
				queryid  , 
				calls  ,
				waitings    -- количество ожиданий данного типа по queryid			
			)
			VALUES 
			(
				current_wait_event_type , 
				current_queryid ,
				queryid_waitings_calls_rec.calls_long::numeric, 
				queryid_waitings_calls_rec.waitings_long::numeric
			);	
			
			-----------------------------------------------------------
			-- АГРЕГАЦИЯ
			INSERT INTO wait_event_type_queryid_stats
			(
				wait_event_type  ,
				queryid , 
				pgpro_pwr_queryid_hex ,
				calls  , 
				waitings  , 				
				wait_event_type_promile
			)
			SELECT 	wait_event_type , 
					queryid , 
					to_hex( queryid ) , 
					SUM( calls ) ,
					SUM( waitings ) , 					
					SUM( waitings ) / total_all_waitings * 1000.0 
			FROM 
				temp_queryid_stats			
			GROUP BY wait_event_type , queryid ; 
			-- АГРЕГАЦИЯ
			-----------------------------------------------------------
			
			-----------------------------------------------------------
			-- ДЛЯ СВОДНОГО ОТЧЕТА 
			INSERT INTO wait_event_type_queryid_stats_for_incidents_to_timepoint
			(
				wait_event_type  ,
				queryid 
			)
			SELECT 	wait_event_type , 
					queryid 
			FROM 
				temp_queryid_stats
			GROUP BY wait_event_type , queryid ; 
			
			-- ДЛЯ СВОДНОГО ОТЧЕТА 
			-----------------------------------------------------------
			
	-------------------------------------
	-- СОХРАНИТЬ СВЯЗКУ ИНЦИДЕНТ-QUERYID 
	-- ТОЛЬКО ПО QUERYID ПО КОТОРЫМ ЕСТЬ КОРЕЛЯЦИЯ С WAIT_EVENT_TYPE
	INSERT INTO incidents_queryid
	(
		incident_id , 
		queryid 
	)
	VALUES 
	(
		incident_id ,
		current_queryid
	)
	ON CONFLICT  ON CONSTRAINT incidents_queryid_pk DO NOTHING ;
	
	-- ТОЛЬКО ПО QUERYID ПО КОТОРЫМ ЕСТЬ КОРЕЛЯЦИЯ С WAIT_EVENT_TYPE
	-- СОХРАНИТЬ СВЯЗКУ ИНЦИДЕНТ-QUERYID 
	-------------------------------------
	--СОХРАНИТЬ СТАТИСТИКУ WAIT_EVENT_TYPE/WAIT_EVENT QUERYID
	INSERT INTO incident_to_timepoint_wait_event_queryid
	(
		wait_event_type  ,
		wait_event  ,
		queryid 
	)
	SELECT 
		wait_event_type  ,
		wait_event  ,
		queryid 
	FROM 
		stat_statement_wait_events_analysis
	WHERE 
		curr_timestamp  BETWEEN incident_min_timestamp AND incident_max_timestamp
		AND queryid = current_queryid
	GROUP BY 
		wait_event_type  ,
		wait_event  ,
		queryid ;
	--СОХРАНИТЬ СТАТИСТИКУ WAIT_EVENT_TYPE/WAIT_EVENT QUERYID
	-------------------------------------


  return 0;
END
$$ LANGUAGE plpgsql  ;
