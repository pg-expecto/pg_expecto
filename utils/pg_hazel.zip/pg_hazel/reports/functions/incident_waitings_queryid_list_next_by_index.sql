----------------------------------------------------------------------------------------------------------------
-- incident_waitings_queryid_list_next_by_index.sql
-- version 35.0

CREATE OR REPLACE FUNCTION incident_waitings_queryid_list_next_by_index( current_id integer ) RETURNS bigint AS $$
DECLARE
current_queryid bigint ;  
BEGIN
	SELECT queryid 
	INTO current_queryid
	FROM incident_stats_current_queryid
	WHERE id = current_id ;
	
	IF current_queryid IS NULL 
	THEN 
	  current_queryid = -1 ; 
	END IF;
	
  return current_queryid ; 
END
$$ LANGUAGE plpgsql  ;
