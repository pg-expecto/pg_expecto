----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО ТИПУ ОЖИДАНИЙ ЗА ПЕРИОД ПО ИНЦИДЕНТАМ 
-- incident_waitings_queryid_list_size.sql
-- version 35.0

CREATE OR REPLACE FUNCTION incident_waitings_queryid_list_size() RETURNS integer AS $$
DECLARE
counter integer ;  
BEGIN
	SELECT count(*) 
	INTO counter
	FROM incident_stats_current_queryid;
	
	IF counter IS NULL 
	THEN 
		counter = 0 ;
	END IF ; 
	
  return counter ; 
END
$$ LANGUAGE plpgsql  ;
