----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО ТИПУ ОЖИДАНИЙ ЗА ПЕРИОД ПО ИНЦИДЕНТУ И QUERYID
-- incident_waitings_queryid_report.sql
-- version 40.1

CREATE OR REPLACE FUNCTION incident_waitings_queryid_report( current_wait_event_type text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 wait_event_type_queryid_stats_rec record ; 
BEGIN
	line_count = 1 ;
			
	FOR wait_event_type_queryid_stats_rec IN 
	SELECT 
		* 
	FROM 
		wait_event_type_queryid_stats
	WHERE 
		calls IS NOT NULL 
		AND wait_event_type = current_wait_event_type
	ORDER BY waitings_to_calls DESC 
	LOOP 
		result_str[line_count] =	wait_event_type_queryid_stats_rec.queryid  ||'|'||
									wait_event_type_queryid_stats_rec.pgpro_pwr_queryid_hex  ||'|'||
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.calls::numeric ) , '000000000000D0' ) , '.' , ',' )  ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.waitings::numeric ) , '000000000000D0' ) , '.' , ',' )  ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.waitings::numeric / wait_event_type_queryid_stats_rec.calls::numeric  ) , '000000000000D0' ) , '.' , ',' )  ||'|'||
									REPLACE ( TO_CHAR( ROUND( wait_event_type_queryid_stats_rec.wait_event_type_promile::numeric ) , '000000000000D0' ) , '.' , ',' )  ||'|'									
									;							
		line_count = line_count + 1 ;
	END LOOP ;			

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
