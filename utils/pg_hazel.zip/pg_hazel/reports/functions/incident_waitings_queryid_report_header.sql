----------------------------------------------------------------------------------------------------------------
-- incident_waitings_queryid_report_header.sql
-- version 35.1

CREATE OR REPLACE FUNCTION incident_waitings_queryid_report_header(  incident_id integer   , current_wait_event_type text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
  
  min_max_pct_rec record ;
 
  queryid_waitings_calls_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
  corr_bufferpin DOUBLE PRECISION ; 
  corr_extension DOUBLE PRECISION ; 
  corr_io DOUBLE PRECISION ; 
  corr_ipc DOUBLE PRECISION ; 
  corr_lock DOUBLE PRECISION ; 
  corr_lwlock DOUBLE PRECISION ; 
  
  current_last_sql_statistics timestamp with time zone ; 
  
  current_waitings_calls DOUBLE PRECISION ;   
  all_waitings DOUBLE PRECISION ;   
  total_all_waitings DOUBLE PRECISION ;   
  
  correlation_value_rec record ;   
  curr_wait_event_type_promile DOUBLE PRECISION ;   
  
  queryid_rec record ;	
  temp_incident_sql_for_wait_event_type_rec record ; 
  current_queryid_hex text ;
  
  current_queryid_rec record ; 
 
  incident_min_timestamp timestamptz ; 
  incident_max_timestamp timestamptz ;   
  
  
  temp_queryid_stats_rec record ; 
  wait_event_type_queryid_stats_rec record ; 
  
  sql_stats_history_rec record ; 
  query_counter integer ; 
BEGIN
	line_count = 1 ;

	result_str[line_count] = 'incident_waitings_queryid' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'WAIT_EVENT_TYPE' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = current_wait_event_type ; 
	line_count=line_count+1; 



	---------------------------------------------------
	-- !!! ВНИМАНИЕ !!!
	-- СТАТИСТИКА ПО ИНЦИДЕНТУ НА УРОВНЕ SQL 
	-- СОБИРАЕТСЯ НЕ НА ВРЕМЯ НАЧАЛА ИНЦИДЕНТА 
	-- А НА БЛИЖАЙЩЕЕ ВРЕМЯ ЗАВЕРШЕНИЯ СБОРА СТАТИСТИКИ ПО SQL 
	-- ПОСЛЕ НАЧАЛА ИНЦИДЕНТА 	
	SELECT 	timepoint , 
			(timepoint - (SELECT start_timepoint FROM  performance_incident WHERE id = incident_id ))
	INTO 	sql_stats_history_rec
	FROM 	sql_stats_history 
	WHERE 	( timepoint - (SELECT start_timepoint FROM  performance_incident WHERE id = incident_id )) > interval '0 minute'
	ORDER BY 2  
	LIMIT 1 ;
	-- !!! ВНИМАНИЕ !!!
	---------------------------------------------------
	
	--СТАТИСТИКА ИНЦИДЕНТА 
	incident_min_timestamp = sql_stats_history_rec.timepoint  - interval '1 hour'; 
	incident_max_timestamp = sql_stats_history_rec.timepoint ; 
	--СТАТИСТИКА ИНЦИДЕНТА 	
	
	result_str[line_count] = 'START SQL STATS TIMEPOINT' ;
	line_count=line_count+1; 
	result_str[line_count] = incident_min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = 'FINISH SQL STATS TIMEPOINT' ;
	line_count=line_count+1; 
	result_str[line_count] = incident_max_timestamp ;
	line_count=line_count+1; 
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
