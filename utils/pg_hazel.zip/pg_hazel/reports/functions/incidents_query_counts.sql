----------------------------------------------------------------------------------------------------------------
-- Количество queryid по инцидентам
-- incidents_query_counts.sql
-- version 37.2

CREATE OR REPLACE FUNCTION incidents_query_counts(  start_timestamp text , finish_timestamp text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
  
 report_rec record ; 
 
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
BEGIN

	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 

	line_count = 1 ;
	
	result_str[line_count] = 	'INCIDENT ID | QUERYID COUNT';
	line_count=line_count+1;

	FOR report_rec IN 	
	SELECT 
		pi.id ,
		count(*) AS queryid_count
	FROM 
		incidents_queryid iq
		JOIN
		performance_incident pi
		ON ( iq.incident_id = pi.id )
	WHERE 
		pi.start_timepoint BETWEEN 
			min_timestamp
		AND 
			max_timestamp
	GROUP BY 
		pi.id 
	ORDER BY 2 DESC 
	LOOP
		result_str[line_count] = report_rec.id ||'|'|| report_rec.queryid_count;
		line_count=line_count+1;		
	END LOOP ; 
	
return result_str ; 
END
$$ LANGUAGE plpgsql  ;
