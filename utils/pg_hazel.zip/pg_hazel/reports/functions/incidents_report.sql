----------------------------------------------------------------------------------------------------------------
-- ОТЧЕТ ПО ИНЦИДЕНТАМ ПРОИЗВОДИТЕЛЬНОСТИ 
-- incidents_report.sql
-- version 70.0

CREATE OR REPLACE FUNCTION incidents_report(  start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 incidents_rec record ;
BEGIN
  line_count = 1 ;
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;

    result_str[line_count] = 'INCIDENTS' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'incidents_report' ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;	
	line_count=line_count+2; 
	
	result_str[line_count] = 	'№'||'|'||		
								'START TIME'||'|'||
								'PRIORITY '||'|'
									;							
	line_count=line_count+1; 
	
	FOR incidents_rec IN 
	SELECT 
		id, 
		start_timepoint , 
		priority
	FROM 
		performance_incident
	WHERE 
		start_timepoint BETWEEN min_timestamp AND max_timestamp
	ORDER BY 2
	LOOP
		result_str[line_count] = 	incidents_rec.id  ||'|'||
									to_char( incidents_rec.start_timepoint , 'YYYY-MM-DD HH24:MI') ||'|'||
									incidents_rec.priority  ||'|' ;
		line_count = line_count + 1;
	END LOOP ;

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
	
	
