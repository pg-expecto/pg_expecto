----------------------------------------------------------------------------------------------------------------
-- incidents_to_timepoint_list_next_by_index.sql
-- version 36.0

CREATE OR REPLACE FUNCTION incidents_to_timepoint_list_next_by_index( current_id integer ) RETURNS integer AS $$
DECLARE
current_incident_id integer ;  
BEGIN
	SELECT incident_id 
	INTO current_incident_id
	FROM incidents_to_timepoint
	WHERE id = current_id ;
	
	IF current_incident_id IS NULL 
	THEN 
	  current_incident_id = -1 ; 
	END IF;
	
  return current_incident_id ; 
END
$$ LANGUAGE plpgsql  ;
