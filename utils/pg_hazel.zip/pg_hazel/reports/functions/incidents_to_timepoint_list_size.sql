----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО ТИПУ ОЖИДАНИЙ ЗА ПЕРИОД ПО ИНЦИДЕНТАМ 
-- incidents_to_timepoint_list_size.sql
-- version 36.0

CREATE OR REPLACE FUNCTION incidents_to_timepoint_list_size() RETURNS integer AS $$
DECLARE
counter integer ;  
BEGIN
	SELECT count(*) 
	INTO counter
	FROM incidents_to_timepoint;
	
	IF counter IS NULL 
	THEN 
		counter = 0 ;
	END IF ; 
	
  return counter ; 
END
$$ LANGUAGE plpgsql  ;
