----------------------------------------------------------------------------------------------------------------
-- incidents_to_timepoint_prepare_id_list.sql
-- version 36.1

CREATE OR REPLACE FUNCTION incidents_to_timepoint_prepare_id_list(  start_timestamp text , finish_timestamp text ) RETURNS integer AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
BEGIN

	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 

	TRUNCATE TABLE incidents_to_timepoint ; 
	ALTER SEQUENCE incidents_to_timepoint_current_id_seq RESTART ;
	
	INSERT INTO incidents_to_timepoint
	(
		incident_id 
	)
	SELECT 
		id
	FROM 
		performance_incident
	WHERE 	
		start_timepoint BETWEEN min_timestamp AND max_timestamp 
	ORDER BY start_timepoint ;
	
  return 0 ; 
END
$$ LANGUAGE plpgsql  ;
