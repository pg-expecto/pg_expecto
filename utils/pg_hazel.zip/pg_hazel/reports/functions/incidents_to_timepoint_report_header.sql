----------------------------------------------------------------------------------------------------------------
-- incidents_to_timepoint_report_header.sql
-- version 40.1

CREATE OR REPLACE FUNCTION incidents_to_timepoint_report_header(  start_timestamp text , finish_timestamp text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
  
  min_max_pct_rec record ;
 
  queryid_waitings_calls_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
  corr_bufferpin DOUBLE PRECISION ; 
  corr_extension DOUBLE PRECISION ; 
  corr_io DOUBLE PRECISION ; 
  corr_ipc DOUBLE PRECISION ; 
  corr_lock DOUBLE PRECISION ; 
  corr_lwlock DOUBLE PRECISION ; 
  
  current_last_sql_statistics timestamp with time zone ; 
  
  current_waitings_calls DOUBLE PRECISION ;   
  all_waitings DOUBLE PRECISION ;   
  total_all_waitings DOUBLE PRECISION ;   
  
  correlation_value_rec record ;   
  curr_wait_event_type_promile DOUBLE PRECISION ;   
  
  queryid_rec record ;	
  temp_incident_sql_for_wait_event_type_rec record ; 
  current_queryid_hex text ;
  
  current_queryid_rec record ; 
 
  incident_min_timestamp timestamptz ; 
  incident_max_timestamp timestamptz ;   
  
  
  temp_queryid_stats_rec record ; 
  wait_event_type_queryid_stats_rec record ; 
  
  sql_stats_history_rec record ; 
  query_counter integer ; 
BEGIN
	line_count = 1 ;

	IF start_timestamp = 'YESTERDAY'
	THEN 
		SELECT 	date_trunc('day' ,  CURRENT_TIMESTAMP ) 
		INTO 	max_timestamp ; 
		
		SELECT 	date_trunc('day' ,  CURRENT_TIMESTAMP - interval '1 day') 
		INTO 	min_timestamp ; 	
    ELSIF start_timestamp = 'LAST_WEEK'		
	THEN 
		SELECT date_trunc('week' , current_timestamp - interval '1 day') 
		INTO min_timestamp ; 
		
        SELECT date_trunc('week' , current_timestamp - interval '1 day') + interval '1 week'
		INTO max_timestamp ; 
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' )) 
		INTO 	max_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' )) 
		INTO 	min_timestamp ; 			
	END IF;

	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
