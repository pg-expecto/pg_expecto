----------------------------------------------------------------------------------------------------------------
-- IOSTAT_CPU
-- iostat_cpu.sql
-- version 62.0
-- 


CREATE OR REPLACE FUNCTION iostat_cpu(  start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;
  
	corr_cpu_user_pct_long  numeric ; --%user - процент использования процессора программами, запущенными на уровне пользователя;
	corr_cpu_nice_pct_long  numeric ;  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	corr_cpu_system_pct_long  numeric ;  --%system - процент использования процессора ядром;
	corr_cpu_iowait_pct_long  numeric ;  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	corr_cpu_steal_pct_long  numeric ;  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	corr_cpu_idle_pct_long  numeric  ; --%idle - процент времени пока процессор не занят ничем.	
	
  os_stat_iostat_cpu_analysis_rec record ; 
  waitings_min_max_rec record ; 
BEGIN
	line_count = 1 ;
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - IOSTAT_CPU' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'iostat_cpu.sh' ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	SELECT 
		MIN( cl.iostat_analysis_cpu_user_pct_long) AS min_iostat_analysis_cpu_user_pct_long , MAX( cl.iostat_analysis_cpu_user_pct_long) AS max_iostat_analysis_cpu_user_pct_long , 
		MIN( cl.iostat_analysis_cpu_nice_pct_long) AS min_iostat_analysis_cpu_nice_pct_long , MAX( cl.iostat_analysis_cpu_nice_pct_long) AS max_iostat_analysis_cpu_nice_pct_long , 
		MIN( cl.iostat_analysis_cpu_system_pct_long) AS min_iostat_analysis_cpu_system_pct_long , MAX( cl.iostat_analysis_cpu_system_pct_long) AS max_iostat_analysis_cpu_system_pct_long , 
		MIN( cl.iostat_analysis_cpu_iowait_pct_long) AS min_iostat_analysis_cpu_iowait_pct_long , MAX( cl.iostat_analysis_cpu_iowait_pct_long) AS max_iostat_analysis_cpu_iowait_pct_long , 
		MIN( cl.iostat_analysis_cpu_steal_pct_long) AS min_iostat_analysis_cpu_steal_pct_long , MAX( cl.iostat_analysis_cpu_steal_pct_long) AS max_iostat_analysis_cpu_steal_pct_long , 
		MIN( cl.iostat_analysis_cpu_idle_pct_long) AS min_iostat_analysis_cpu_idle_pct_long , MAX( cl.iostat_analysis_cpu_idle_pct_long) AS max_iostat_analysis_cpu_idle_pct_long 		
	INTO  	min_max_rec
	FROM 
		os_stat_iostat_cpu_analysis cl 
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	os_stat_iostat_cpu_analysis
	WHERE 
		curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   %user - процент использования процессора программами, запущенными на уровне пользователя;
    IF min_max_rec.min_iostat_analysis_cpu_user_pct_long = min_max_rec.max_iostat_analysis_cpu_user_pct_long
	THEN 
		corr_cpu_user_pct_long = 0 ;
	ELSE 	
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_user_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_cpu_user_pct_long  AS iostat_analysis_cpu_user_pct_long 
			FROM os_stat_iostat_cpu_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_cpu_user_pct_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_cpu_user_pct_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_user_pct_long
		FROM
			waitings os JOIN cpu_user_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %user - процент использования процессора программами, запущенными на уровне пользователя;
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   %nice - процент использования процессора программами запущеными тоже в пространстве пользователя, но только с изменённым приоритетом;
	IF min_max_rec.min_iostat_analysis_cpu_nice_pct_long = min_max_rec.max_iostat_analysis_cpu_nice_pct_long
	THEN 
		corr_cpu_nice_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_nice_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_cpu_nice_pct_long  AS iostat_analysis_cpu_nice_pct_long 
			FROM os_stat_iostat_cpu_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_cpu_nice_pct_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_cpu_nice_pct_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_nice_pct_long
		FROM
			waitings os JOIN cpu_nice_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	----------------------------------------------------------------------------------------------------
	

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   %system - процент использования процессора ядром;
	IF min_max_rec.min_iostat_analysis_cpu_system_pct_long = min_max_rec.max_iostat_analysis_cpu_system_pct_long
	THEN 
		corr_cpu_system_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_system_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_cpu_system_pct_long  AS iostat_analysis_cpu_system_pct_long
			FROM os_stat_iostat_cpu_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_cpu_system_pct_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_cpu_system_pct_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_system_pct_long
		FROM
			waitings os JOIN cpu_system_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF ;			
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %system - процент использования процессора ядром;
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   %iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	IF min_max_rec.min_iostat_analysis_cpu_iowait_pct_long = min_max_rec.max_iostat_analysis_cpu_iowait_pct_long
	THEN 
		corr_cpu_iowait_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_iowait_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_cpu_iowait_pct_long  AS iostat_analysis_cpu_iowait_pct_long
			FROM os_stat_iostat_cpu_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_cpu_iowait_pct_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_cpu_iowait_pct_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_iowait_pct_long
		FROM
			waitings os JOIN cpu_iowait_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   %steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	IF min_max_rec.min_iostat_analysis_cpu_steal_pct_long = min_max_rec.max_iostat_analysis_cpu_steal_pct_long
	THEN 
		corr_cpu_steal_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_steal_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_cpu_steal_pct_long  AS iostat_analysis_cpu_steal_pct_long
			FROM os_stat_iostat_cpu_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_cpu_steal_pct_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_cpu_steal_pct_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_steal_pct_long
		FROM
			waitings os JOIN cpu_steal_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   %idle - процент времени пока процессор не занят ничем.
	IF min_max_rec.min_iostat_analysis_cpu_idle_pct_long = min_max_rec.max_iostat_analysis_cpu_idle_pct_long
	THEN 
		corr_cpu_idle_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_idle_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_cpu_idle_pct_long  AS iostat_analysis_cpu_idle_pct_long
			FROM os_stat_iostat_cpu_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_cpu_idle_pct_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_cpu_idle_pct_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_idle_pct_long
		FROM
			waitings os JOIN cpu_idle_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %idle - процент времени пока процессор не занят ничем.
	----------------------------------------------------------------------------------------------------


	result_str[line_count] = 'CORRELATION COEFFICIENTS' ; 
	line_count=line_count+1;

	result_str[line_count] = 'WAITINGS - %user (% использования процессора программами,на уровне пользователя)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_user_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %nice(% использования процессора программами запущенными в пространстве пользователя, с изменённым приоритетом)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_nice_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %system(% использования процессора ядром)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_system_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %iowait(% времени ожидания завершения операций I/O)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_iowait_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %steal(% простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_steal_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %idle(% времени пока процессор не занят ничем)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_idle_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	
	  
	SELECT 
		MIN( cl_w.waitings_long) AS min_waitings_long , MAX( cl_w.waitings_long) AS max_waitings_long 
	INTO 
		waitings_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_w
	WHERE 	
		cl_w.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	
	SELECT 
		MIN( cl.iostat_analysis_cpu_user_pct_long) AS min_iostat_analysis_cpu_user_pct_long , MAX( cl.iostat_analysis_cpu_user_pct_long) AS max_iostat_analysis_cpu_user_pct_long , 
		MIN( cl.iostat_analysis_cpu_nice_pct_long) AS min_iostat_analysis_cpu_nice_pct_long , MAX( cl.iostat_analysis_cpu_nice_pct_long) AS max_iostat_analysis_cpu_nice_pct_long , 
		MIN( cl.iostat_analysis_cpu_system_pct_long) AS min_iostat_analysis_cpu_system_pct_long , MAX( cl.iostat_analysis_cpu_system_pct_long) AS max_iostat_analysis_cpu_system_pct_long , 
		MIN( cl.iostat_analysis_cpu_iowait_pct_long) AS min_iostat_analysis_cpu_iowait_pct_long , MAX( cl.iostat_analysis_cpu_iowait_pct_long) AS max_iostat_analysis_cpu_iowait_pct_long , 
		MIN( cl.iostat_analysis_cpu_steal_pct_long) AS min_iostat_analysis_cpu_steal_pct_long , MAX( cl.iostat_analysis_cpu_steal_pct_long) AS max_iostat_analysis_cpu_steal_pct_long , 
		MIN( cl.iostat_analysis_cpu_idle_pct_long) AS min_iostat_analysis_cpu_idle_pct_long , MAX( cl.iostat_analysis_cpu_idle_pct_long) AS max_iostat_analysis_cpu_idle_pct_long 		
	INTO  	min_max_rec
	FROM 
		os_stat_iostat_cpu_analysis cl 
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
	

	result_str[line_count] = 	' '||'|'||
								'№'||'|'||		
								'WAITINGS' ||'|'||
								'%user ' ||'|'||
								'%nice ' ||'|'||
								'%system ' ||'|'||
								'%iowait ' ||'|'||
								'%steal ' ||'|'||
								'%idle ' ||'|'
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( waitings_min_max_rec.min_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_cpu_user_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_cpu_nice_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_cpu_system_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_cpu_iowait_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_cpu_steal_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_cpu_idle_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 
	
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		os_stat_vmstat_analysis
	WHERE 	
		curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( waitings_min_max_rec.max_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||								
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_cpu_user_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_cpu_nice_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_cpu_system_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_cpu_iowait_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_cpu_steal_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_cpu_idle_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								
	line_count=line_count+2; 

	result_str[line_count] = 	'timestamp'||'|'||  --1
								'№'||'|'||	
								'WAITINGS' ||'|'--2
								;
								
	IF min_max_rec.max_iostat_analysis_cpu_user_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%user ' ||'|' --3
								;
	END IF;
	
	IF min_max_rec.max_iostat_analysis_cpu_nice_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%nice ' ||'|'--4
								;
	END IF;
	
	IF min_max_rec.max_iostat_analysis_cpu_system_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%system ' ||'|'--5
								;
	END IF;
	
	IF min_max_rec.max_iostat_analysis_cpu_iowait_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%iowait ' ||'|'--6
								;
	END IF;
	
	IF min_max_rec.max_iostat_analysis_cpu_steal_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%steal ' ||'|'--7
								;
	END IF;
	
	IF min_max_rec.max_iostat_analysis_cpu_idle_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%idle ' ||'|'--8
								;
	END IF;
	line_count=line_count+1; 
	
/*
	result_str[line_count] = 	'timestamp'||'|'||  --1
								'№'||'|'||	
								'WAITINGS' ||'|'||--2
								'%user ' ||'|'||--3
								'%nice ' ||'|'||--4
								'%system ' ||'|'||--5
								'%iowait ' ||'|'||--6
								'%steal ' ||'|'||--7
								'%idle ' ||'|'--8
								;		
	line_count=line_count+1; 
*/
	
	
	counter = 0 ; 
	FOR os_stat_iostat_cpu_analysis_rec IN
	SELECT 
		cl.curr_timestamp , --1
		cl_w.waitings_long ,--2
		cl.iostat_analysis_cpu_user_pct_long ,--3
		cl.iostat_analysis_cpu_nice_pct_long ,--4
		cl.iostat_analysis_cpu_system_pct_long ,--5
		cl.iostat_analysis_cpu_iowait_pct_long ,--6
		cl.iostat_analysis_cpu_steal_pct_long ,--7
		cl.iostat_analysis_cpu_idle_pct_long --8		
	FROM 
		os_stat_iostat_cpu_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
    ORDER BY cl.curr_timestamp 
	LOOP
		counter = counter + 1 ;
		
		result_str[line_count] =
								to_char( os_stat_iostat_cpu_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'|| --1
								counter ||'|'|| 
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.waitings_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --2
								;
		
		IF min_max_rec.max_iostat_analysis_cpu_user_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.iostat_analysis_cpu_user_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --3
								;
		END IF;
		
		IF min_max_rec.max_iostat_analysis_cpu_nice_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.iostat_analysis_cpu_nice_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --4
								;
		END IF;
		
		IF min_max_rec.max_iostat_analysis_cpu_system_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.iostat_analysis_cpu_system_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --5
								;
		END IF;
		
		IF min_max_rec.max_iostat_analysis_cpu_iowait_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.iostat_analysis_cpu_iowait_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --6
								;
		END IF;
		
		IF min_max_rec.max_iostat_analysis_cpu_steal_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.iostat_analysis_cpu_steal_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --7
								;
		END IF;
		
		IF min_max_rec.max_iostat_analysis_cpu_idle_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_cpu_analysis_rec.iostat_analysis_cpu_idle_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --8	
								;
		END IF;
		
		
		
								
	  line_count=line_count+1; 			
	END LOOP;
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;


