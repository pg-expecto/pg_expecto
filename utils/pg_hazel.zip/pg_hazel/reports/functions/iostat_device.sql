----------------------------------------------------------------------------------------------------------------
-- IOSTAT_CPU
-- iostat_device.sql
-- version 64.0
-- 
/*
iostat -d vdb vdc -x -m -t 60
*/

CREATE OR REPLACE FUNCTION iostat_device(  start_timestamp text , finish_timestamp text  , device_name text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;

	corr_dev_rps_long  numeric ;  --r/s Количество операций чтения в секунду.
	corr_dev_rmbs_long  numeric ;  --rMB/s Скорость чтения (МБ/с).
	corr_dev_rrqmps_long  numeric ;  --rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	corr_dev_rrqm_pct_long  numeric ;  --%rrqm Процент операций чтения; слитых перед отправкой на устройство.
	corr_dev_r_await_long  numeric ;  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	corr_dev_rareq_sz_long  numeric ;  --rareq_sz Средний размер запроса чтения (в КБ).
	corr_dev_wps_long  numeric ; --w/s Количество операций записи в секунду.
	corr_dev_wmbps_long  numeric ;  --wMB/s Скорость записи (МБ/с).
	corr_dev_wrqmps_long  numeric ;  --wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	corr_dev_wrqm_pct_long  numeric ;  --%wrqm Процент операций записи; слитых перед отправкой на устройство.
	corr_dev_w_await_long  numeric ;  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	corr_dev_wareq_sz_long  numeric ;  --wareq_sz Средний размер запроса записи (в КБ).
	corr_dev_dps_long  numeric ;  --d/s Операции для discard-запросов (актуально для SSD).
	corr_dev_dmbps_long  numeric ;  --dMB/s скорость для discard-запросов (актуально для SSD).
	corr_dev_drqmps_long  numeric ; --drqm/s Количество запросов; слитых в очередь в секунду для discard-запросов (актуально для SSD).
	corr_dev_drqm_pct_long  numeric ;  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	corr_dev_d_await_long  numeric ;  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	corr_dev_dareq_sz_long  numeric ;  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	corr_dev_aqu_sz_long  numeric ;  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	corr_dev_util_pct_long  numeric ;  --%util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	corr_dev_fps_long  numeric ;  --f/s скорость выполнения запросов от flush-операций.
	corr_dev_f_await_long  numeric;  --f_await Среднее время выполнения запросов от flush-операций.	
	
  os_stat_iostat_device_analysis_rec record ; 
  waitings_min_max_rec record ; 
  
BEGIN
	line_count = 1 ;	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - iostat_device' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'iostat_device.sh' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'DEVICE = '||device_name ; 
	line_count=line_count+1;
	
		
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	
	SELECT 
		MIN( cl_w.waitings_long) AS min_waitings_long , MAX( cl_w.waitings_long) AS max_waitings_long 
	INTO 
		waitings_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_w
	WHERE 	
		cl_w.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	SELECT 
		MIN( cl.iostat_analysis_dev_rps_long) AS min_iostat_analysis_dev_rps_long , MAX( cl.iostat_analysis_dev_rps_long) AS max_iostat_analysis_dev_rps_long,
		MIN( cl.iostat_analysis_dev_rmbs_long) AS min_iostat_analysis_dev_rmbs_long , MAX( cl.iostat_analysis_dev_rmbs_long) AS max_iostat_analysis_dev_rmbs_long ,
		MIN( cl.iostat_analysis_dev_rrqmps_long) AS min_iostat_analysis_dev_rrqmps_long , MAX( cl.iostat_analysis_dev_rrqmps_long) AS max_iostat_analysis_dev_rrqmps_long ,
		MIN( cl.iostat_analysis_dev_rrqm_pct_long) AS min_iostat_analysis_dev_rrqm_pct_long , MAX( cl.iostat_analysis_dev_rrqm_pct_long) AS max_iostat_analysis_dev_rrqm_pct_long ,
		MIN( cl.iostat_analysis_dev_r_await_long) AS min_iostat_analysis_dev_r_await_long , MAX( cl.iostat_analysis_dev_r_await_long) AS max_iostat_analysis_dev_r_await_long ,
		MIN( cl.iostat_analysis_dev_rareq_sz_long) AS min_iostat_analysis_dev_rareq_sz_long , MAX( cl.iostat_analysis_dev_rareq_sz_long) AS max_iostat_analysis_dev_rareq_sz_long ,
		MIN( cl.iostat_analysis_dev_wps_long) AS min_iostat_analysis_dev_wps_long , MAX( cl.iostat_analysis_dev_wps_long) AS max_iostat_analysis_dev_wps_long ,
		MIN( cl.iostat_analysis_dev_wmbps_long) AS min_iostat_analysis_dev_wmbps_long , MAX( cl.iostat_analysis_dev_wmbps_long) AS max_iostat_analysis_dev_wmbps_long,
		MIN( cl.iostat_analysis_dev_wrqmps_long) AS min_iostat_analysis_dev_wrqmps_long , MAX( cl.iostat_analysis_dev_wrqmps_long) AS max_iostat_analysis_dev_wrqmps_long ,
		MIN( cl.iostat_analysis_dev_wrqm_pct_long) AS min_iostat_analysis_dev_wrqm_pct_long , MAX( cl.iostat_analysis_dev_wrqm_pct_long) AS max_iostat_analysis_dev_wrqm_pct_long,
		MIN( cl.iostat_analysis_dev_w_await_long) AS min_iostat_analysis_dev_w_await_long , MAX( cl.iostat_analysis_dev_w_await_long) AS max_iostat_analysis_dev_w_await_long,
		MIN( cl.iostat_analysis_dev_wareq_sz_long) AS min_iostat_analysis_dev_wareq_sz_long , MAX( cl.iostat_analysis_dev_wareq_sz_long) AS max_iostat_analysis_dev_wareq_sz_long,
		MIN( cl.iostat_analysis_dev_dps_long) AS min_iostat_analysis_dev_dps_long , MAX( cl.iostat_analysis_dev_dps_long) AS max_iostat_analysis_dev_dps_long,
		MIN( cl.iostat_analysis_dev_dmbps_long) AS min_iostat_analysis_dev_dmbps_long , MAX( cl.iostat_analysis_dev_dmbps_long) AS max_iostat_analysis_dev_dmbps_long ,
		MIN( cl.iostat_analysis_dev_drqmps_long) AS min_iostat_analysis_dev_drqmps_long, MAX( cl.iostat_analysis_dev_drqmps_long) AS max_iostat_analysis_dev_drqmps_long ,		
		MIN( cl.iostat_analysis_dev_drqm_pct_long) AS min_iostat_analysis_dev_drqm_pct_long , MAX( cl.iostat_analysis_dev_drqm_pct_long) AS max_iostat_analysis_dev_drqm_pct_long ,		
		MIN( cl.iostat_analysis_dev_d_await_long) AS min_iostat_analysis_dev_d_await_long , MAX( cl.iostat_analysis_dev_d_await_long) AS max_iostat_analysis_dev_d_await_long ,
		MIN( cl.iostat_analysis_dev_dareq_sz_long) AS min_iostat_analysis_dev_dareq_sz_long , MAX( cl.iostat_analysis_dev_dareq_sz_long) AS max_iostat_analysis_dev_dareq_sz_long ,
		MIN( cl.iostat_analysis_dev_aqu_sz_long) AS min_iostat_analysis_dev_aqu_sz_long , MAX( cl.iostat_analysis_dev_aqu_sz_long) AS max_iostat_analysis_dev_aqu_sz_long ,
		MIN( cl.iostat_analysis_dev_util_pct_long) AS min_iostat_analysis_dev_util_pct_long , MAX( cl.iostat_analysis_dev_util_pct_long) AS max_iostat_analysis_dev_util_pct_long ,
		MIN( cl.iostat_analysis_dev_fps_long) AS min_iostat_analysis_dev_fps_long , MAX( cl.iostat_analysis_dev_fps_long) AS max_iostat_analysis_dev_fps_long ,
		MIN( cl.iostat_analysis_dev_f_await_long) AS min_iostat_analysis_dev_f_await_long , MAX( cl.iostat_analysis_dev_f_await_long) AS max_iostat_analysis_dev_f_await_long		
	INTO  	min_max_rec
	FROM 
		os_stat_iostat_device_analysis cl 
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
		AND cl.iostat_analysis_device = device_name ;


	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	os_stat_iostat_device_analysis
	WHERE 
		curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;
	
	

	result_str[line_count] = 	' '||'|'||
								'№'||'|'||		
								'WAITINGS' ||'|'||
								'r/s' ||'|'||
								'rMB/s' ||'|'||
								'rrqm/s' ||'|'||
								'%rrqm' ||'|'||
								'r_await' ||'|'||
								'rareq_sz' ||'|'||
								'w/s' ||'|'||
								'wMB/s' ||'|'||
								'wrqm/s' ||'|'||
								'%wrqm' ||'|'||
								'w_await' ||'|'||
								'wareq_sz' ||'|'||
								'd/s' ||'|'||
								'dMB/s' ||'|'||
								'drqm/s' ||'|'||
								'%drqm' ||'|'||
								'd_await' ||'|'||
								'dareq_sz' ||'|'||
								'aqu_sz' ||'|'||
								'%util' ||'|'||
								'f/s' ||'|'||
								'f_await' ||'|'
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( waitings_min_max_rec.min_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rmbs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rrqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rrqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_r_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wrqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wrqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_w_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_dps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_dmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_drqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_drqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_d_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_dareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_aqu_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_util_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_fps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_f_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 	
	
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		os_stat_vmstat_analysis
	WHERE 	
		curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( waitings_min_max_rec.max_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rmbs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rrqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rrqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_r_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wrqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wrqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_w_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_dps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_dmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_drqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_drqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_d_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_dareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_aqu_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_util_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_fps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_f_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 

	result_str[line_count] = 	'timestamp'||'|'||  --1
								'№'||'|'||	
								'WAITINGS' ||'|'--2
								;

	IF min_max_rec.max_iostat_analysis_dev_rps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'r/s' ||'|'--3
								;
	END IF;

								
	IF min_max_rec.max_iostat_analysis_dev_rmbs_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'rMB/s' ||'|'--4
								;
	END IF;
	
	IF min_max_rec.max_iostat_analysis_dev_rrqmps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'rrqm/s' ||'|'--5
								;
	END IF;

							
	IF min_max_rec.max_iostat_analysis_dev_rrqm_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%rrqm' ||'|'--6
								;
	END IF;	

	IF min_max_rec.max_iostat_analysis_dev_r_await_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'r_await' ||'|'--7
								;
	END IF;				

	IF min_max_rec.max_iostat_analysis_dev_rareq_sz_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'rareq_sz' ||'|'--8
								;
	END IF;	

	IF min_max_rec.max_iostat_analysis_dev_wps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'w/s' ||'|'--9
								;
	END IF;	

	IF min_max_rec.max_iostat_analysis_dev_wmbps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'wMB/s' ||'|'--10
								;
	END IF;					

	IF min_max_rec.max_iostat_analysis_dev_wrqmps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'wrqm/s' ||'|'--11
								;
	END IF;					

	IF min_max_rec.max_iostat_analysis_dev_wrqm_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%wrqm' ||'|'--12
								;
	END IF;					

	IF min_max_rec.max_iostat_analysis_dev_w_await_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'w_await' ||'|'--13
								;
	END IF;					

	IF min_max_rec.max_iostat_analysis_dev_wareq_sz_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'wareq_sz' ||'|'--14
								;
	END IF;							

	IF min_max_rec.max_iostat_analysis_dev_dps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'd/s' ||'|'--15
								;
	END IF;							

	IF min_max_rec.max_iostat_analysis_dev_dmbps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'dMB/s' ||'|'--16
								;
	END IF;							

	IF min_max_rec.max_iostat_analysis_dev_drqmps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'drqm/s' ||'|'--17
								;
	END IF;							

    IF min_max_rec.max_iostat_analysis_dev_drqm_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%drqm' ||'|'--18
								;
	END IF;	

    IF min_max_rec.max_iostat_analysis_dev_d_await_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'd_await' ||'|'--19
								;
	END IF;	

    IF min_max_rec.max_iostat_analysis_dev_dareq_sz_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'dareq_sz' ||'|'--20
								;
	END IF;	

    IF min_max_rec.max_iostat_analysis_dev_aqu_sz_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'aqu_sz' ||'|'--21
								;
	END IF;	

    IF min_max_rec.max_iostat_analysis_dev_util_pct_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'%util' ||'|'--22
								;
	END IF;	

    IF min_max_rec.max_iostat_analysis_dev_fps_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'f/s' ||'|'--23
								;
	END IF;	

    IF min_max_rec.max_iostat_analysis_dev_f_await_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'f_await' ||'|'--24	
								;
	END IF;	
	
	line_count=line_count+1; 
	
	counter = 0 ; 
	FOR os_stat_iostat_device_analysis_rec IN
	SELECT 
		cl.curr_timestamp , --1
		cl_w.waitings_long ,--2
		cl.iostat_analysis_dev_rps_long ,--3
		cl.iostat_analysis_dev_rmbs_long ,--4
		cl.iostat_analysis_dev_rrqmps_long ,--5
		cl.iostat_analysis_dev_rrqm_pct_long ,--6
		cl.iostat_analysis_dev_r_await_long ,--7
		cl.iostat_analysis_dev_rareq_sz_long ,--8
		cl.iostat_analysis_dev_wps_long ,--9
		cl.iostat_analysis_dev_wmbps_long ,--10
		cl.iostat_analysis_dev_wrqmps_long ,--11
		cl.iostat_analysis_dev_wrqm_pct_long ,--12
		cl.iostat_analysis_dev_w_await_long ,--13
		cl.iostat_analysis_dev_wareq_sz_long ,--14
		cl.iostat_analysis_dev_dps_long ,--15
		cl.iostat_analysis_dev_dmbps_long ,--16
		cl.iostat_analysis_dev_drqmps_long ,--17
		cl.iostat_analysis_dev_drqm_pct_long ,--18
		cl.iostat_analysis_dev_d_await_long ,--19
		cl.iostat_analysis_dev_dareq_sz_long ,--20
		cl.iostat_analysis_dev_aqu_sz_long ,--21
		cl.iostat_analysis_dev_util_pct_long ,--22
		cl.iostat_analysis_dev_fps_long ,--23
		cl.iostat_analysis_dev_f_await_long --24
	FROM 
		os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
		AND cl.iostat_analysis_device = device_name
    ORDER BY cl.curr_timestamp 
	LOOP
		counter = counter + 1 ;
		result_str[line_count] =
								to_char( os_stat_iostat_device_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'|| --1
								counter ||'|'|| 
								REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.waitings_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --2
								;

		IF min_max_rec.max_iostat_analysis_dev_rps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_rps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --3
									;
		END IF;

									
		IF min_max_rec.max_iostat_analysis_dev_rmbs_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_rmbs_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --4
									;
		END IF;
		
		IF min_max_rec.max_iostat_analysis_dev_rrqmps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_rrqmps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --5
									;
		END IF;

								
		IF min_max_rec.max_iostat_analysis_dev_rrqm_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_rrqm_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --6
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_r_await_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_r_await_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --7
									;
		END IF;				

		IF min_max_rec.max_iostat_analysis_dev_rareq_sz_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_rareq_sz_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --8
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_wps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_wps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --9
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_wmbps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_wmbps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --10
									;
		END IF;					

		IF min_max_rec.max_iostat_analysis_dev_wrqmps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_wrqmps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --11
									;
		END IF;					

		IF min_max_rec.max_iostat_analysis_dev_wrqm_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_wrqm_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --12
									;
		END IF;					

		IF min_max_rec.max_iostat_analysis_dev_w_await_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_w_await_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --13
									;
		END IF;					

		IF min_max_rec.max_iostat_analysis_dev_wareq_sz_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_wareq_sz_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --14
									;
		END IF;							

		IF min_max_rec.max_iostat_analysis_dev_dps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_dps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --15
									;
		END IF;							

		IF min_max_rec.max_iostat_analysis_dev_dmbps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_dmbps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --16
									;
		END IF;							

		IF min_max_rec.max_iostat_analysis_dev_drqmps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_drqmps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --17
									;
		END IF;							

		IF min_max_rec.max_iostat_analysis_dev_drqm_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_drqm_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --18
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_d_await_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_d_await_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --19
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_dareq_sz_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_dareq_sz_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --20
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_aqu_sz_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_aqu_sz_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --21
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_util_pct_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_util_pct_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --22
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_fps_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_fps_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --23
									;
		END IF;	

		IF min_max_rec.max_iostat_analysis_dev_f_await_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
									REPLACE ( TO_CHAR( ROUND( os_stat_iostat_device_analysis_rec.iostat_analysis_dev_f_await_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --23
									;
		END IF;	
		
	  line_count=line_count+1; 			
	END LOOP;		

return result_str ; 	
END
$$ LANGUAGE plpgsql  ;



/*
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   r/s Количество операций чтения в секунду.
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_rps_long = min_max_rec.max_iostat_analysis_dev_rps_long
	THEN 
		corr_dev_rps_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_rps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_rps_long  AS iostat_analysis_dev_rps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_rps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_rps_long
		FROM
			waitings os JOIN dev_rps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp );
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ r/s Количество операций чтения в секунду.
	----------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ -   rMB/s Скорость чтения (МБ/с)
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_rmbs_long = min_max_rec.max_iostat_analysis_dev_rmbs_long
	THEN 
		corr_dev_rmbs_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_rmbs_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_rmbs_long  AS iostat_analysis_dev_rmbs_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rmbs_long > 0 
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_rmbs_long ) , 0 ) AS correlation_value 
		INTO corr_dev_rmbs_long
		FROM
			waitings os JOIN dev_rmbs_waitings  w ON ( os.curr_timestamp = w.curr_timestamp );
	END IF ;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ rMB/s Скорость чтения (МБ/с)
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_rrqmps_long = min_max_rec.max_iostat_analysis_dev_rrqmps_long
	THEN 
		corr_dev_rrqmps_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_rrqmps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_rrqmps_long  AS iostat_analysis_dev_rrqmps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rrqmps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_rrqmps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_rrqmps_long
		FROM
			waitings os JOIN dev_rrqmps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp );
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %rrqm Процент операций чтения; слитых перед отправкой на устройство.
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_rrqm_pct_long = min_max_rec.max_iostat_analysis_dev_rrqm_pct_long
	THEN 
		corr_dev_rrqm_pct_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_rrqm_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_rrqm_pct_long  AS iostat_analysis_dev_rrqm_pct_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rrqm_pct_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_rrqm_pct_long ) , 0 ) AS correlation_value 
		INTO corr_dev_rrqm_pct_long
		FROM
			waitings os JOIN dev_rrqm_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;
	
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %rrqm Процент операций чтения; слитых перед отправкой на устройство.
	----------------------------------------------------------------------------------------------------

	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_r_await_long = min_max_rec.max_iostat_analysis_dev_r_await_long
	THEN 
		corr_dev_r_await_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_r_await_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_r_await_long  AS iostat_analysis_dev_r_await_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_r_await_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_r_await_long ) , 0 ) AS correlation_value 
		INTO corr_dev_r_await_long
		FROM
			waitings os JOIN dev_r_await_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	END IF ;
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ --rareq_sz Средний размер запроса чтения (в КБ).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_rareq_sz_long = min_max_rec.max_iostat_analysis_dev_rareq_sz_long
	THEN 
		corr_dev_rareq_sz_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_rareq_sz_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_rareq_sz_long  AS iostat_analysis_dev_rareq_sz_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rareq_sz_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_rareq_sz_long ) , 0 ) AS correlation_value 
		INTO corr_dev_rareq_sz_long
		FROM
			waitings os JOIN dev_rareq_sz_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ --rareq_sz Средний размер запроса чтения (в КБ).
	----------------------------------------------------------------------------------------------------


	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ w/s Количество операций записи в секунду.
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_wps_long = min_max_rec.max_iostat_analysis_dev_wps_long
	THEN 
		corr_dev_wps_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_wps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_wps_long  AS iostat_analysis_dev_wps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_wps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_wps_long
		FROM
			waitings os JOIN dev_wps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ w/s Количество операций записи в секунду.
	----------------------------------------------------------------------------------------------------
	
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ wMB/s Скорость записи (МБ/с)
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_wmbps_long = min_max_rec.max_iostat_analysis_dev_wmbps_long
	THEN 
		corr_dev_wmbps_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_wmbps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_wmbps_long  AS iostat_analysis_dev_wmbps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wmbps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_wmbps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_wmbps_long
		FROM
			waitings os JOIN dev_wmbps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ wMB/s Скорость записи (МБ/с)
	----------------------------------------------------------------------------------------------------
	
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_wrqmps_long = min_max_rec.max_iostat_analysis_dev_wrqmps_long
	THEN 
		corr_dev_wrqmps_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_wrqmps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_wrqmps_long  AS iostat_analysis_dev_wrqmps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wrqmps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_wrqmps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_wrqmps_long
		FROM
			waitings os JOIN dev_wrqmps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %wrqm Процент операций записи; слитых перед отправкой на устройство.
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_wrqm_pct_long = min_max_rec.max_iostat_analysis_dev_wrqm_pct_long
	THEN 
		corr_dev_wrqm_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0				
		) ,
		dev_wrqm_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_wrqm_pct_long  AS iostat_analysis_dev_wrqm_pct_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wrqm_pct_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_wrqm_pct_long ) , 0 ) AS correlation_value 
		INTO corr_dev_wrqm_pct_long
		FROM
			waitings os JOIN dev_wrqm_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %wrqm Процент операций записи; слитых перед отправкой на устройство.
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_w_await_long = min_max_rec.max_iostat_analysis_dev_w_await_long
	THEN 
		corr_dev_w_await_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_w_await_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_w_await_long  AS iostat_analysis_dev_w_await_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_w_await_long > 0
				AND iostat_analysis_device = device_name				
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_w_await_long ) , 0 ) AS correlation_value 
		INTO corr_dev_w_await_long
		FROM
			waitings os JOIN dev_w_await_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	----------------------------------------------------------------------------------------------------

	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ wareq_sz Средний размер запроса записи (в КБ).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_wareq_sz_long = min_max_rec.max_iostat_analysis_dev_wareq_sz_long
	THEN 
		corr_dev_wareq_sz_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_wareq_sz_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_wareq_sz_long  AS iostat_analysis_dev_wareq_sz_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wareq_sz_long > 0 
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_wareq_sz_long ) , 0 ) AS correlation_value 
		INTO corr_dev_wareq_sz_long
		FROM
			waitings os JOIN dev_wareq_sz_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF;			
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ wareq_sz Средний размер запроса записи (в КБ).
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ d/s Операции для discard-запросов (актуально для SSD).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_dps_long = min_max_rec.max_iostat_analysis_dev_dps_long
	THEN 
		corr_dev_dps_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_dps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_dps_long  AS iostat_analysis_dev_dps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_dps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_dps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_dps_long
		FROM
			waitings os JOIN dev_dps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ d/s Операции для discard-запросов (актуально для SSD).
	----------------------------------------------------------------------------------------------------


	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ dMB/s скорость для discard-запросов (актуально для SSD).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_dmbps_long = min_max_rec.max_iostat_analysis_dev_dmbps_long
	THEN 
		corr_dev_dmbps_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_dmbps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_dmbps_long  AS iostat_analysis_dev_dmbps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_dmbps_long > 0 
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_dmbps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_dmbps_long
		FROM
			waitings os JOIN dev_dmbps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF;			
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ dMB/s скорость для discard-запросов (актуально для SSD).
	----------------------------------------------------------------------------------------------------

		
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ drqm/s Количество запросов; слитых в очередь в секунду для discard-запросов (актуально для SSD).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_drqmps_long = min_max_rec.max_iostat_analysis_dev_drqmps_long
	THEN 
		corr_dev_drqmps_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_drqmps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_drqmps_long  AS iostat_analysis_dev_drqmps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_drqmps_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_drqmps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_drqmps_long
		FROM
			waitings os JOIN dev_drqmps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ drqm/s Количество запросов; слитых в очередь в секунду для discard-запросов (актуально для SSD).
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_drqm_pct_long = min_max_rec.max_iostat_analysis_dev_drqm_pct_long
	THEN 
		corr_dev_drqm_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_drqm_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_drqm_pct_long  AS iostat_analysis_dev_drqm_pct_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_drqm_pct_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_drqm_pct_long ) , 0 ) AS correlation_value 
		INTO corr_dev_drqm_pct_long
		FROM
			waitings os JOIN dev_drqm_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_d_await_long = min_max_rec.max_iostat_analysis_dev_d_await_long
	THEN 
		corr_dev_d_await_long = 0 ;
	ELSE
	
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_d_await_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_d_await_long  AS iostat_analysis_dev_d_await_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_d_await_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_d_await_long ) , 0 ) AS correlation_value 
		INTO corr_dev_d_await_long
		FROM
			waitings os JOIN dev_d_await_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ dareq_sz Средний размер для discard-запросов (актуально для SSD)
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_dareq_sz_long = min_max_rec.max_iostat_analysis_dev_dareq_sz_long
	THEN 
		corr_dev_dareq_sz_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_dareq_sz_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_dareq_sz_long  AS iostat_analysis_dev_dareq_sz_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_dareq_sz_long > 0 
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_dareq_sz_long ) , 0 ) AS correlation_value 
		INTO corr_dev_dareq_sz_long
		FROM
			waitings os JOIN dev_dareq_sz_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ dareq_sz Средний размер для discard-запросов (актуально для SSD)
	----------------------------------------------------------------------------------------------------
	
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ aqu_sz Средняя длина очереди запросов (глубина очереди).
	-- Если одна из величин не меняется, установить значение 0
	IF min_max_rec.min_iostat_analysis_dev_aqu_sz_long = min_max_rec.max_iostat_analysis_dev_aqu_sz_long
	THEN 
		corr_dev_aqu_sz_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_aqu_sz_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_aqu_sz_long  AS iostat_analysis_dev_aqu_sz_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_aqu_sz_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_aqu_sz_long ) , 0 ) AS correlation_value 
		INTO corr_dev_aqu_sz_long
		FROM
			waitings os JOIN dev_aqu_sz_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ aqu_sz Средняя длина очереди запросов (глубина очереди).
	----------------------------------------------------------------------------------------------------
	
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	IF min_max_rec.min_iostat_analysis_dev_util_pct_long = min_max_rec.max_iostat_analysis_dev_util_pct_long
	THEN 
		corr_dev_util_pct_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_util_pct_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_util_pct_long  AS iostat_analysis_dev_util_pct_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_util_pct_long > 0
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_util_pct_long ) , 0 ) AS correlation_value 
		INTO corr_dev_util_pct_long
		FROM
			waitings os JOIN dev_util_pct_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ %util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	----------------------------------------------------------------------------------------------------

	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ f/s скорость выполнения запросов от flush-операций.
	IF min_max_rec.min_iostat_analysis_dev_fps_long = min_max_rec.max_iostat_analysis_dev_fps_long
	THEN 
		corr_dev_fps_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_fps_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_fps_long  AS iostat_analysis_dev_fps_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_fps_long > 0 
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_fps_long ) , 0 ) AS correlation_value 
		INTO corr_dev_fps_long
		FROM
			waitings os JOIN dev_fps_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ f/s скорость выполнения запросов от flush-операций.
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ f_await Среднее время выполнения запросов от flush-операций.
	IF min_max_rec.min_iostat_analysis_dev_f_await_long = min_max_rec.max_iostat_analysis_dev_f_await_long
	THEN 
		corr_dev_f_await_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		dev_f_await_waitings AS
		(
			SELECT 
				curr_timestamp , iostat_analysis_dev_f_await_long  AS iostat_analysis_dev_f_await_long 
			FROM os_stat_iostat_device_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_f_await_long > 0 
				AND iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( waitings_long , iostat_analysis_dev_f_await_long ) , 0 ) AS correlation_value 
		INTO corr_dev_f_await_long
		FROM
			waitings os JOIN dev_f_await_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ f_await Среднее время выполнения запросов от flush-операций.
	----------------------------------------------------------------------------------------------------

	result_str[line_count] = 'CORRELATION COEFFICIENTS' ; 
	line_count=line_count+1;

	result_str[line_count] = 'WAITINGS - r/s Количество операций чтения в секунду' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_rps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - rMB/s Скорость чтения (МБ/с)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_rmbs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - rrqm/s Количество прочитанных запросов;слитых в очередь (merge) в секунду' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_rrqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %rrqm Процент операций чтения; слитых перед отправкой на устройство' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_rrqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_r_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - rareq_sz Средний размер запроса чтения (в КБ)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_rareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - w/s Количество операций записи в секунду' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_wps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - wMB/s Скорость записи (МБ/с)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_wmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - wrqm/s Количество записанных запросов; слитых в очередь в секунду' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_wrqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %wrqm Процент операций записи; слитых перед отправкой на устройство' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_wrqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - w_await (мс) Среднее время выполнения запросов записи (включая время в очереди)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_w_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - wareq_sz Средний размер запроса записи (в КБ)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_wareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - d/s Операции для discard-запросов (актуально для SSD)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_dps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - dMB/s скорость для discard-запросов (актуально для SSD)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_dmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - drqm/s Количество запросов; слитых в очередь в секунду для discard-запросов (актуально для SSD)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_drqmps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_drqm_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_d_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - dareq_sz Средний размер для discard-запросов (актуально для SSD)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_dareq_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - aqu_sz Средняя длина очереди запросов (глубина очереди)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_aqu_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - %util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_util_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - f/s скорость выполнения запросов от flush-операций' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_fps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - f_await Среднее время выполнения запросов от flush-операций' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_dev_f_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	  
*/