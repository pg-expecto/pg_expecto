----------------------------------------------------
-- ОТЧЕТ ПО ТЕКУЩЕМУ СТРЕСС ТЕСТУ по сценарию MIX
-- mix_report.sql
-- version 51.0


CREATE OR REPLACE FUNCTION mix_report() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;

 current_test_id bigint;
 test_statistics_rec record ; 
 test_statistics_pass_rec record ;
 
 current_speed_short DOUBLE PRECISION;
 current_speed_long DOUBLE PRECISION;
 current_median_short DOUBLE PRECISION;
 current_median_long DOUBLE PRECISION;
 
 current_load integer ; 
 pgh_stat_cluster_analysis_rec record ; 
 
 scenario_queryid_rec record ;
 median_duration_1 DOUBLE PRECISION ;
 median_duration_2 DOUBLE PRECISION ;
 median_duration_3 DOUBLE PRECISION ;
 median_duration_4 DOUBLE PRECISION ;
 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id; 		

    line_count = 1 ;
	
	SELECT * 
	INTO test_statistics_rec
	FROM test_statistics
	WHERE test_id = current_test_id;
	
	SELECT get_load()
	INTO current_load ;

	
	
	result_str[line_count] = 'STRESS REPORT' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'mix_report.sh' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'TEST_ID '; 
	line_count=line_count+1; 
	result_str[line_count] = current_test_id ; 
	line_count=line_count+1; 

	------------------------------------------------------
	-- ТЕСТОВЫЕ ЗАПРОСЫ
	SELECT 
	  scenario_1_queryid , scenario_2_queryid  , scenario_3_queryid  , scenario_4_queryid 
	INTO 
	  scenario_queryid_rec 
	FROM 
	  test_statistics 
	WHERE 
	   test_id = current_test_id;
	
	result_str[line_count] = 'SCENARIO-1: SELECT ONLY '; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_1_queryid ; 
	line_count=line_count+2; 

	result_str[line_count] = 'SCENARIO-2: SELECT+UPDATE'; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_2_queryid ; 
	line_count=line_count+2; 

	
	result_str[line_count] = 'SCENARIO-3: INSERT ONLY'; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_3_queryid ; 
	line_count=line_count+2; 
	
	result_str[line_count] = 'SCENARIO-4: CPU LOAD'; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_4_queryid ; 
	line_count=line_count+2; 
	
	-- ТЕСТОВЫЕ ЗАПРОСЫ
	------------------------------------------------------  

	
	result_str[line_count] = ' ' ; 
	line_count=line_count+1; 


	result_str[line_count] = 	'start timestamp'||'|'||
								'finish timestamp'||'|'||
								'PGPRO_PWR SAMPLE'||'|'||
								'PASS'||'|'||
								'LOAD'||'|'||								
								'SQL SPEED'||'|' ||							
								'SCENARIO-1 MEDIAN TIME' ||'|' ||
								'SCENARIO-2 MEDIAN TIME' ||'|' ||
								'SCENARIO-3 MEDIAN TIME' ||'|' ||
								'SCENARIO-4 MEDIAN TIME' ||'|' 
								;							
	line_count=line_count+1; 

	
	FOR test_statistics_pass_rec IN 
	SELECT *
	FROM   test_statistics_pass
	WHERE  test_id = current_test_id AND
		   finish_timestamp IS NOT NULL AND 
           pass_counter >= 6  
	ORDER BY pass_counter
	LOOP
		IF test_statistics_pass_rec.pass_counter < 6 
		THEN 
			continue;
		END IF ;
		
		SELECT
		  op_speed_long
		INTO 
		  pgh_stat_cluster_analysis_rec
		FROM
		  pgh_stat_cluster_analysis cl
		WHERE
		  cl.curr_timestamp = test_statistics_pass_rec.finish_timestamp ; 
		  
		SELECT 
		  median_duration
		INTO 
		  median_duration_1
		FROM 
		  stat_timer_statistics_long
		WHERE 
		  queryid = scenario_queryid_rec.scenario_1_queryid AND 
		  curr_timestamp = test_statistics_pass_rec.finish_timestamp ; 
		  
		SELECT 
		  median_duration
		INTO 
		  median_duration_2
		FROM 
		  stat_timer_statistics_long  
		WHERE 
		  queryid = scenario_queryid_rec.scenario_2_queryid AND 
		  curr_timestamp = test_statistics_pass_rec.finish_timestamp ; 

		SELECT 
		  median_duration
		INTO 
		  median_duration_3
		FROM 
		  stat_timer_statistics_long  
		WHERE 
		  queryid = scenario_queryid_rec.scenario_3_queryid AND 
		  curr_timestamp = test_statistics_pass_rec.finish_timestamp ; 
		 
		SELECT 
		  median_duration
		INTO 
		  median_duration_4
		FROM 
		  stat_timer_statistics_long  
		WHERE 
		  queryid = scenario_queryid_rec.scenario_4_queryid AND 
		  curr_timestamp = test_statistics_pass_rec.finish_timestamp ; 

		  
		result_str[line_count] = 	to_char( test_statistics_pass_rec.start_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'||
									to_char( test_statistics_pass_rec.finish_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'||
									test_statistics_pass_rec.pgpro_pwr_snapshot||'|'||
									test_statistics_pass_rec.pass_counter ||'|'||
									ROUND( test_statistics_pass_rec.load_connections::numeric , 0 ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (pgh_stat_cluster_analysis_rec.op_speed_long::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (median_duration_1::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (median_duration_2::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (median_duration_3::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (median_duration_4::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) 
								;							
	  line_count=line_count+1; 	

	
	END LOOP ;
	



		
	
  return result_str ; 
END
$$ LANGUAGE plpgsql STABLE ;

