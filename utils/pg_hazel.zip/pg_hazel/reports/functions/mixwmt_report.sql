----------------------------------------------------
-- ОТЧЕТ ПО ТЕКУЩЕМУ СТРЕСС ТЕСТУ по сценарию MIX
-- mixwmt_report.sql
-- "$scenario" == "6" 
-- version 65.0



CREATE OR REPLACE FUNCTION mixwmt_report() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;

 current_test_id bigint;
 test_statistics_rec record ; 
 test_statistics_pass_rec record ;
 
 current_speed_short DOUBLE PRECISION;
 current_speed_long DOUBLE PRECISION;
 current_median_short DOUBLE PRECISION;
 current_median_long DOUBLE PRECISION;
 
 current_load integer ; 
 
 scenario_queryid_rec record ;
 
 min_max_rec record ; 
 
 
 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id; 		

    line_count = 1 ;
	
	SELECT * 
	INTO test_statistics_rec
	FROM test_statistics
	WHERE test_id = current_test_id;
	
	SELECT get_load()
	INTO current_load ;

	
	
	result_str[line_count] = 'STRESS REPORT' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'mixwmt_report.sh' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'TEST_ID '; 
	line_count=line_count+1; 
	result_str[line_count] = current_test_id ; 
	line_count=line_count+1; 

	------------------------------------------------------
	-- ТЕСТОВЫЕ ЗАПРОСЫ
	SELECT 
	  scenario_1_queryid , scenario_2_queryid  , scenario_3_queryid  , scenario_4_queryid 
	INTO 
	  scenario_queryid_rec 
	FROM 
	  test_statistics 
	WHERE 
	   test_id = current_test_id;
	
	result_str[line_count] = 'SCENARIO-1: SELECT ONLY '; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_1_queryid ; 
	line_count=line_count+2; 

	result_str[line_count] = 'SCENARIO-2: SELECT+UPDATE'; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_2_queryid ; 
	line_count=line_count+2; 

	
	result_str[line_count] = 'SCENARIO-3: INSERT ONLY'; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_3_queryid ; 
	line_count=line_count+2; 
	
	result_str[line_count] = 'SCENARIO-4: CPU LOAD'; 
	line_count=line_count+1; 
	result_str[line_count] = scenario_queryid_rec.scenario_4_queryid ; 
	line_count=line_count+2; 
	
	-- ТЕСТОВЫЕ ЗАПРОСЫ
	------------------------------------------------------  

	SELECT 
	  MIN(c.op_speed_long) , 
	  MAX(c.op_speed_long)  
	INTO 
		min_max_rec 
	FROM pgh_stat_cluster_analysis c
	WHERE 
	curr_timestamp between 
	(SELECT MIN(p.start_timestamp) 
	 FROM   test_statistics_pass p
	 WHERE  p.test_id = 1 AND
	 p.pass_counter >= 6) 
	AND 
	(SELECT MAX(p.finish_timestamp) 
	 FROM   test_statistics_pass p
	 WHERE  p.test_id = current_test_id AND
	 p.pass_counter >= 6) 
	;

    line_count=line_count+1;
	result_str[line_count] = ' | | MIN SPEED |' || REPLACE ( TO_CHAR( ROUND( (min_max_rec.min::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'; 
	line_count=line_count+1; 
	result_str[line_count] = ' | | MIN SPEED |' || REPLACE ( TO_CHAR( ROUND( (min_max_rec.max::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'; 
	line_count=line_count+2; 

	result_str[line_count] = 	'start timestamp'||'|'||
								'finish timestamp'||'|'||
								'PGPRO_PWR SAMPLE'||'|'||
								'PASS'||'|'||
								'LOAD'||'|'||								
								'open'||'|'||
								'high'||'|'||
								'low'||'|'||
								'close'||'|'								
								;							
	line_count=line_count+1; 

	
	FOR test_statistics_pass_rec IN 
	SELECT 		
		p.pass_counter , 
		p.load_connections ,
		p.start_timestamp ,
		p.finish_timestamp , 
		(SELECT c.op_speed_long 
		FROM pgh_stat_cluster_analysis c
		WHERE 
		curr_timestamp =  
		 ( SELECT MIN(pc.curr_timestamp) 
		   FROM pgh_stat_cluster_analysis pc
		   WHERE pc.curr_timestamp between p.start_timestamp AND p.finish_timestamp         
		 )   
		) AS "open" ,
		(SELECT MAX(c.op_speed_long) 
		FROM pgh_stat_cluster_analysis c
		WHERE 
		curr_timestamp between p.start_timestamp AND p.finish_timestamp
		) AS "high" ,
		(SELECT MIN(c.op_speed_long) 
		FROM pgh_stat_cluster_analysis c
		WHERE 
		curr_timestamp between p.start_timestamp AND p.finish_timestamp
		) AS "low" ,
		(SELECT c.op_speed_long 
		FROM pgh_stat_cluster_analysis c
		WHERE 
		curr_timestamp =  
		 ( SELECT MAX(pc.curr_timestamp) 
		   FROM pgh_stat_cluster_analysis pc
		   WHERE pc.curr_timestamp between p.start_timestamp AND p.finish_timestamp         
		 )   
		) AS "close" ,
		p.pgpro_pwr_snapshot
		FROM   test_statistics_pass p
		WHERE  p.test_id = current_test_id AND
		p.pass_counter >= 6
		order by 1  
	LOOP
		  
		result_str[line_count] = 	to_char( test_statistics_pass_rec.start_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'||
									to_char( test_statistics_pass_rec.finish_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'||
									test_statistics_pass_rec.pgpro_pwr_snapshot||'|'||
									test_statistics_pass_rec.pass_counter ||'|'||
									ROUND( test_statistics_pass_rec.load_connections::numeric , 0 ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (test_statistics_pass_rec.open::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (test_statistics_pass_rec.high::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (test_statistics_pass_rec.low::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (test_statistics_pass_rec.close::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'
								;	
		
	  line_count=line_count+1; 	

	
	END LOOP ;
	



		
	
  return result_str ; 
END
$$ LANGUAGE plpgsql STABLE ;

