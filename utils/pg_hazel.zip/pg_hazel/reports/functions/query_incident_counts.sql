----------------------------------------------------------------------------------------------------------------
-- Количество инцидентов по queryid 
-- query_incident_counts.sql
-- version 37.2

CREATE OR REPLACE FUNCTION query_incident_counts(  start_timestamp text , finish_timestamp text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
  
 report_rec record ; 
 
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
BEGIN

	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 

	line_count = 1 ;

	result_str[line_count] = 	'QUERYID | PGPRO_PWR HEX | INCIDENT COUNT';
	line_count=line_count+1;

	FOR report_rec IN 	
	SELECT 
		iq.queryid  ,
		to_hex( iq.queryid ) AS pgpro_pwr_hex , 
		count(*) AS incident_count
	FROM 
		incidents_queryid iq
	JOIN
		performance_incident pi
		ON ( iq.incident_id = pi.id )
	WHERE 
		pi.start_timepoint BETWEEN 
			min_timestamp
		AND 
			max_timestamp 
	GROUP BY 
		iq.queryid 
	ORDER BY 3 DESC 
	LOOP
		result_str[line_count] = report_rec.queryid ||'|'|| report_rec.pgpro_pwr_hex ||'|'|| report_rec.incident_count;
		line_count=line_count+1;		
	END LOOP ; 
	
return result_str ; 
END
$$ LANGUAGE plpgsql  ;
