----------------------------------------------------------------------------------------------------------------
-- ИСТОРИЯ СОБЫТИЙ ОЖИДАНИЯ НА УРОВНЕ SQL
-- queryid_stat.sql
-- version 73.0


CREATE OR REPLACE FUNCTION queryid_stat(  current_queryid bigint  , current_wait_event_type text , start_timestamp text , finish_timestamp text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 stat_statement_analysis_rec record ;
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 sql_correlation DOUBLE PRECISION;
 
 min_max_pct_rec record ;
 
 bufferpin_value	 text ;
 extension_value text ;
 io_value text ;
 ipc_value text ;
 lock_value text ;
 lwlock_value text ; 
 timeout_value text ; 
 
 queryid_waitings_calls_rec record ; 
 waitings_calls  DOUBLE PRECISION;
 stat_statement_wait_events_analysis_rec record ;
 current_last_sql_statistics timestamp with time zone ; 
 current_queryid_hex text ; 	
 sql_wait_event_type_rec record ;  
 
 wait_event_types_array text[];
 wait_event_types_array_index integer ; 
 temp_queryid_stat_rec record ; 
 
  wait_event_count_rec record  ;
  wait_event_rec record  ;
  current_wait_event_count bigint;
  temp_wait_event_names_rec record ; 
  
  corr_value DOUBLE PRECISION;
  
  current_operating_speed_long numeric ;
  
  
BEGIN
	line_count = 1 ;
	
RAISE NOTICE 'current_queryid = %' , current_queryid ; 	
RAISE NOTICE 'start_timestamp = %' , start_timestamp ; 	
RAISE NOTICE 'finish_timestamp = %' , finish_timestamp ; 	

	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) 
		INTO 	max_timestamp ; 
	
		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' )
		INTO 	min_timestamp ; 
		
		SELECT 	to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) 
		INTO 	max_timestamp ; 		
	END IF ;
	
	result_str[line_count] = 'SQL STATISTICS ' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'queryid_stat.sh' ; 
	line_count=line_count+1; 	
	
	result_str[line_count] = 'WAIT_EVENT_TYPE' ; 
	line_count=line_count+1; 	
	result_str[line_count] = current_wait_event_type ; 
	line_count=line_count+1; 	
	
	
	result_str[line_count] = to_char( min_timestamp , 'YYYY-MM-DD HH24:MI' ) ; 
	line_count=line_count+1; 
	
	result_str[line_count] = to_char( max_timestamp , 'YYYY-MM-DD HH24:MI' ); 
	line_count=line_count+2; 
	
	
	result_str[line_count] = 'queryid'; 
	line_count=line_count+1; 		
	result_str[line_count] = current_queryid; 
	line_count=line_count+1; 		
	
	result_str[line_count] = 'pgpro_pwr_queryid'; 
	line_count=line_count+1; 		
	
	SELECT to_hex( current_queryid ) 
	INTO current_queryid_hex ; 
	
	result_str[line_count] = current_queryid_hex; 
	line_count=line_count+2; 		
	
	DROP TABLE IF EXISTS temp_queryid_stat ;
	--CREATE TEMPORARY TABLE temp_queryid_stat 
	CREATE TABLE temp_queryid_stat 
	(	
		timepoint timestamp with time zone ,  
		wait_event_type text , 
		curr_timestamp timestamp with time zone , 
		curr_datname name ,
		curr_rolename name , 
		calls DOUBLE PRECISION , 
		waitings DOUBLE PRECISION , 
		waitings_calls DOUBLE PRECISION
	);

	
	
	FOR stat_statement_analysis_rec IN 
	WITH ssh 
	AS
	(
	SELECT 
	ssh.timepoint 
	FROM 
	sql_stats_history ssh
	WHERE ssh.timepoint BETWEEN min_timestamp AND max_timestamp
	),
	ssa AS 
	(
	SELECT 
	ssa.curr_timestamp , ssa.dbname , ssa.username
	FROM 
	stat_statement_analysis ssa
	WHERE ssa.curr_timestamp BETWEEN min_timestamp AND max_timestamp
	AND ssa.queryid = current_queryid
	GROUP BY ssa.curr_timestamp , ssa.dbname , ssa.username
	)
	SELECT 
	ssh.timepoint , ssa.curr_timestamp , ssa.dbname , ssa.username
	FROM 
	ssh FULL  JOIN ssa ON ( ssa.curr_timestamp = ssh.timepoint )
	ORDER BY 1	
	LOOP
			-------------------------------------------------------
			-- КОРРЕЛЯЦИЯ , КОЛИЧЕСТВО ВЫЗОВОВ И ОЖИДАНИЙ ПО ТИПУ
			CASE 
			--BufferPin
			WHEN current_wait_event_type = 'BufferPin' THEN 				
				INSERT INTO temp_queryid_stat
				(
					timepoint , 
					wait_event_type ,
					curr_timestamp , 					
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,					
					dbname ,
					username , 
					SUM( calls_long ) AS calls_long ,
					SUM( bufferpin_long  ) AS waitings_count , 
					SUM( bufferpin_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND bufferpin_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username 
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;
					
			--Extension		
			WHEN current_wait_event_type = 'Extension' THEN 
				INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 					
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,
					dbname ,
					username ,
					SUM( calls_long ) AS calls_long ,
					SUM( extension_long  ) AS waitings_count , 					
					SUM( extension_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND extension_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username 
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;
				
			--IO	
			WHEN current_wait_event_type = 'IO' THEN 
				INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,
					dbname ,
					username ,
					SUM( calls_long ) AS calls_long ,
					SUM( io_long  ) AS waitings_count , 
					SUM( io_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND io_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;
			
			--IPC	
			WHEN current_wait_event_type = 'IPC' THEN 
				INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 
					curr_datname ,					
					curr_rolename ,
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,
					dbname ,
					username ,
					SUM( calls_long ) AS calls_long ,
					SUM( ipc_long  ) AS waitings_count , 
					SUM( ipc_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND ipc_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;
					
			--Lock	
			WHEN current_wait_event_type = 'Lock' THEN
				INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,
					dbname ,
					username ,
					SUM( calls_long ) AS calls_long ,
					SUM( lock_long  ) AS waitings_count , 
					SUM( lock_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND lock_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;
					
			--LWLock	
			WHEN current_wait_event_type = 'LWLock' THEN
				INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,
					dbname ,
					username ,
					SUM( calls_long ) AS calls_long ,
					SUM( lwlock_long  ) AS waitings_count , 
					SUM( lwlock_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND lwlock_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;	

			--Timeout	
			WHEN current_wait_event_type = 'Timeout' THEN
				INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type , 
					curr_timestamp ,
					dbname ,
					username ,
					SUM( calls_long ) AS calls_long ,
					SUM( timeout_long  ) AS waitings_count , 
					SUM( timeout_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND timeout_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND dbname = stat_statement_analysis_rec.dbname
					AND username = stat_statement_analysis_rec.username
				GROUP BY 					
					curr_timestamp , queryid , dbname , username ;	
					
			END CASE ;		
			-- КОРРЕЛЯЦИЯ , КОЛИЧЕСТВО ВЫЗОВОВ И ОЖИДАНИЙ ПО ТИПУ
			-------------------------------------------------------------------------------------
	    IF stat_statement_analysis_rec.curr_timestamp IS NULL 
		THEN 
			INSERT INTO temp_queryid_stat
				(
					timepoint ,
					wait_event_type ,
					curr_timestamp , 
					curr_datname ,					
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
			VALUES
				(	
					stat_statement_analysis_rec.timepoint ,
					current_wait_event_type ,
					NULL ,
					NULL ,
					NULL ,
					0 ,
					0 ,
					0 
				) ;
		END IF ;
	END LOOP;			

	line_count=line_count+1; 
	
	result_str[line_count] = 	'timestamp'||'|'||  --1
								'datname'||'|'||   --2	
								'rolname'||'|'||   --3
								'CALLS'||'|'|| --4
								'WAITINGS '||'|'||--5
								'WAITINGS TO CALLS ' ||'|'--6
								;		
	DROP TABLE IF EXISTS temp_wait_event_names ;
	--CREATE TEMPORARY TABLE temp_wait_event_names
	CREATE TABLE temp_wait_event_names 
	(	
		wait_event text 
	);
	
	FOR wait_event_rec IN 
	SELECT DISTINCT wait_event
	FROM stat_statement_wait_events_analysis
	WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp
			AND queryid = current_queryid
			AND wait_event_type = current_wait_event_type 
	ORDER BY wait_event
	LOOP 
		result_str[line_count] = result_str[line_count] || wait_event_rec.wait_event ||'|' ;
		INSERT INTO temp_wait_event_names
		(
			wait_event
		)
		VALUES
		(
			wait_event_rec.wait_event
		);
		
	END LOOP ;
	line_count=line_count+1; 	
	
	DROP TABLE IF EXISTS temp_wait_event_count ;
	--CREATE TEMPORARY TABLE temp_wait_event_count
	CREATE TABLE temp_wait_event_count 
	(	
		curr_timestamp timestamp with time zone ,
		wait_event text , 
		wait_event_count bigint 
	);
	

	FOR temp_queryid_stat_rec IN 
	SELECT * 
	FROM temp_queryid_stat
	WHERE wait_event_type = current_wait_event_type
	ORDER BY timepoint
	LOOP
RAISE NOTICE '% % % % % % % ', temp_queryid_stat_rec.timepoint  ,
 temp_queryid_stat_rec.curr_timestamp ,
 temp_queryid_stat_rec.curr_datname , 
 temp_queryid_stat_rec.curr_rolename , 
 temp_queryid_stat_rec.calls , 
 temp_queryid_stat_rec.waitings ,
 temp_queryid_stat_rec.waitings_calls
 ;		

		IF temp_queryid_stat_rec.curr_timestamp IS NULL 
		THEN 
			result_str[line_count] =	to_char(temp_queryid_stat_rec.timepoint , 'YYYY-MM-DD HH24:MI')  ||'|'||
									' ' ||'|'||
									' ' ||'|'||
									'0' ||'|'||
									'0' ||'|'||
									'0' ||'|'
									;
			line_count = line_count + 1 ;
			continue ;
		END IF ;
		
		result_str[line_count] =	to_char(temp_queryid_stat_rec.timepoint , 'YYYY-MM-DD HH24:MI')  ||'|'||
									temp_queryid_stat_rec.curr_datname ||'|'||
									temp_queryid_stat_rec.curr_rolename ||'|'||
									REPLACE ( TO_CHAR( ROUND( temp_queryid_stat_rec.calls::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( temp_queryid_stat_rec.waitings::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| 
									REPLACE ( TO_CHAR( ROUND( temp_queryid_stat_rec.waitings_calls::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' 
									;		
		FOR temp_wait_event_names_rec IN 
		SELECT 
			wait_event
		FROM
			temp_wait_event_names
		ORDER BY 
			wait_event
		LOOP
			SELECT 
				wait_event , 
				curr_value_long
			INTO 
				stat_statement_wait_events_analysis_rec
			FROM 
				stat_statement_wait_events_analysis
			WHERE 
				curr_timestamp = temp_queryid_stat_rec.curr_timestamp
				AND queryid = current_queryid
				AND dbname = temp_queryid_stat_rec.curr_datname
				AND username = temp_queryid_stat_rec.curr_rolename 
				AND wait_event_type = current_wait_event_type 
				AND wait_event = temp_wait_event_names_rec.wait_event
			GROUP BY wait_event , curr_value_long
			ORDER BY wait_event ; 
				
			IF stat_statement_wait_events_analysis_rec.curr_value_long IS NOT NULL 
			THEN 
				result_str[line_count] = result_str[line_count] || REPLACE ( TO_CHAR( ROUND( stat_statement_wait_events_analysis_rec.curr_value_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ) ||' | ' ;
			ELSE
				result_str[line_count] = result_str[line_count] || '0,0' ||' | ' ;
			END IF ;
			
			INSERT INTO temp_wait_event_count
			( 
				curr_timestamp, 
				wait_event , 
				wait_event_count
			) 
			VALUES 
			(
				temp_queryid_stat_rec.curr_timestamp , 
				stat_statement_wait_events_analysis_rec.wait_event , 
				stat_statement_wait_events_analysis_rec.curr_value_long
			);	
			
		END LOOP ; 
		
		line_count=line_count+1;				

	END LOOP ;	
	
	line_count=line_count+1;
	result_str[line_count] = 	'WAIT_EVENTS | COUNT | WAITINGS CORRELATION(without 0) ';	
	line_count=line_count+1;
	
	FOR wait_event_count_rec IN 
	SELECT 
		wait_event , 
		SUM(wait_event_count) AS wait_event_count
	FROM
		temp_wait_event_count
	GROUP BY 
		wait_event
	ORDER BY 
		2 DESC 
	LOOP 
		SELECT 
			corr ( sa.waitings , wait_event_count )
		INTO 
			corr_value
		FROM 
			temp_wait_event_count tw JOIN temp_queryid_stat sa ON ( tw.curr_timestamp = sa.curr_timestamp  )
		WHERE 
			tw.wait_event = wait_event_count_rec.wait_event ;
			
        IF 	corr_value IS NOT NULL 
		THEN 
			result_str[line_count] = wait_event_count_rec.wait_event ||'|'||
		                         wait_event_count_rec.wait_event_count ||'|'||
								 REPLACE ( TO_CHAR( ROUND( corr_value::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )
								 ;
		
			line_count=line_count+1;
		END IF ; 
		
	END LOOP ;

	
  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
	
	
	
