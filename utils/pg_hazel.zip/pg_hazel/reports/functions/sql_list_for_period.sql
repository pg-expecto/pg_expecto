----------------------------------------------------------------------------------------------------------------
-- sql_list_for_period.sql
-- version 70.0

CREATE OR REPLACE FUNCTION sql_list_for_period(  start_timestamp text , finish_timestamp text ) RETURNS integer AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
BEGIN

	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 

	TRUNCATE TABLE sql_list_for_report ; 
	ALTER SEQUENCE sql_list_for_report_seq RESTART ;
	
	INSERT INTO sql_list_for_report
	(
		queryid 
	)
	SELECT 
		DISTINCT queryid
	FROM 
		stat_statement_analysis 
	WHERE 
		curr_timestamp BETWEEN 
			min_timestamp
		AND 
			max_timestamp
	;
	
  return 0 ; 
END
$$ LANGUAGE plpgsql  ;

