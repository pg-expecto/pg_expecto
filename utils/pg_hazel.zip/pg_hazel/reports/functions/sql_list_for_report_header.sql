----------------------------------------------------------------------------------------------------------------
-- sql_list_for_report_header.sql
-- version 36.1

CREATE OR REPLACE FUNCTION sql_list_for_report_header(  start_timestamp text , finish_timestamp text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;  
 
BEGIN
	line_count = 1 ;

	result_str[line_count] = 'sql_list_for_report' ; 
	line_count=line_count+1; 
	

	IF start_timestamp = 'YESTERDAY'
	THEN 
		SELECT 	date_trunc('day' ,  CURRENT_TIMESTAMP ) 
		INTO 	max_timestamp ; 
		
		SELECT 	date_trunc('day' ,  CURRENT_TIMESTAMP - interval '1 day') 
		INTO 	min_timestamp ; 	
    ELSIF start_timestamp = 'LAST_WEEK'		
	THEN 
		SELECT date_trunc('week' , current_timestamp - interval '1 day') 
		INTO min_timestamp ; 
		
        SELECT date_trunc('week' , current_timestamp - interval '1 day') + interval '1 week'
		INTO max_timestamp ; 
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' )) 
		INTO 	max_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' )) 
		INTO 	min_timestamp ; 			
	END IF;

	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;
