----------------------------------------------------------------------------------------------------------------
-- СТАТИСТИКА ПО ТИПУ ОЖИДАНИЙ ЗА ПЕРИОД ПО ИНЦИДЕНТАМ 
-- sql_list_for_report_list_size.sql
-- version 36.1

CREATE OR REPLACE FUNCTION sql_list_for_report_list_size() RETURNS integer AS $$
DECLARE
counter integer ;  
BEGIN
	SELECT count(*) 
	INTO counter
	FROM sql_list_for_report;
	
	IF counter IS NULL 
	THEN 
		counter = 0 ;
	END IF ; 
	
  return counter ; 
END
$$ LANGUAGE plpgsql  ;
