----------------------------------------------------------------------------------------------------------------
-- sql_list_for_report_next_by_index.sql
-- version 36.1

CREATE OR REPLACE FUNCTION sql_list_for_report_next_by_index( current_id integer ) RETURNS bigint AS $$
DECLARE
current_queryid bigint ;  
BEGIN
	SELECT queryid 
	INTO current_queryid
	FROM sql_list_for_report
	WHERE id = current_id ;
	
	IF current_queryid IS NULL 
	THEN 
	  current_queryid = -1 ; 
	END IF;
	
  return current_queryid ; 
END
$$ LANGUAGE plpgsql  ;
