----------------------------------------------------------------------------------------------------------------
-- sql_list_for_report_prepare_id_list.sql
-- version 40.1

CREATE OR REPLACE FUNCTION sql_list_for_report_prepare_id_list(  start_timestamp text , finish_timestamp text ) RETURNS integer AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
BEGIN

	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 

	TRUNCATE TABLE sql_list_for_report ; 
	ALTER SEQUENCE sql_list_for_report_seq RESTART ;
	
	INSERT INTO sql_list_for_report
	(
		queryid 
	)
	SELECT 
		DISTINCT iq.queryid
	FROM 
		incidents_queryid iq
		JOIN
		performance_incident pi
		ON ( iq.incident_id = pi.id )
	WHERE 
		pi.start_timepoint BETWEEN 
			min_timestamp
		AND 
			max_timestamp
	;
	
  return 0 ; 
END
$$ LANGUAGE plpgsql  ;


CREATE OR REPLACE FUNCTION sql_list_for_report_prepare_id_list(  curr_incident_id bigint ) RETURNS integer AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
 
BEGIN
	SELECT 
		start_timepoint
	INTO 
		max_timestamp
	FROM 
		performance_incident
	WHERE
		id = curr_incident_id ; 
		
	min_timestamp = max_timestamp - interval '1 hour';
  
	
	TRUNCATE TABLE sql_list_for_report ; 
	ALTER SEQUENCE sql_list_for_report_seq RESTART ;
	
	INSERT INTO sql_list_for_report
	(
		queryid 
	)
	SELECT 
		DISTINCT iq.queryid
	FROM 
		incidents_queryid iq
		JOIN
		performance_incident pi
		ON ( iq.incident_id = pi.id )
	WHERE 
		pi.id = curr_incident_id	;
	
  return 0 ; 
END
$$ LANGUAGE plpgsql  ;
