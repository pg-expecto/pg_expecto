----------------------------------------------------------------------------------------------------------------
-- stress_performance.sql
-- RESERVED FOR FUTURE
-- version 54.0
-- 


CREATE OR REPLACE FUNCTION stress_performance(  current_scenario integer , start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  stat_statement_analysis_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
  corr_bufferpin DOUBLE PRECISION ; 
  corr_extension DOUBLE PRECISION ; 
  corr_io DOUBLE PRECISION ; 
  corr_ipc DOUBLE PRECISION ; 
  corr_lock DOUBLE PRECISION ; 
  corr_lwlock DOUBLE PRECISION ; 
  	
  speed_regr_slope_value DOUBLE PRECISION ; 
  waitings_regr_slope_value DOUBLE PRECISION ; 
  
  current_test_id integer ;
  scenario_queryid bigint ;
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'STRESS PERFORMANCE' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'stress_performance.sh' ; 
	line_count=line_count+1;

	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 

	
	SELECT 
		get_test_id_by_timestamp( start_timestamp  , finish_timestamp   ) 
	INTO 
		current_test_id ; 
	
	result_str[line_count] = 'TEST ID ' ; 
	line_count=line_count+1;
	result_str[line_count] = current_test_id ; 
	line_count=line_count+1;
	
	IF current_scenario = 1 
	THEN 
			result_str[line_count] = 'SCENARIO-1 ' ; 
			line_count=line_count+1;
			result_str[line_count] = 'SELECT ONLY' ; 
			line_count=line_count+1;
			SELECT 
				get_scenario_queryid ( current_test_id , 1 )
			INTO
				scenario_queryid ;
			result_str[line_count] = scenario_queryid ; 
			line_count=line_count+2;
	END IF ;
	
	IF  current_scenario = 2 
	THEN 
			result_str[line_count] = 'SCENARIO-2 ' ; 
			line_count=line_count+1;
			result_str[line_count] = 'SELECT+UPDATE' ; 
			line_count=line_count+1;
			SELECT 
				get_scenario_queryid ( current_test_id , 2 )
			INTO
				scenario_queryid ;
			result_str[line_count] = scenario_queryid ; 
			line_count=line_count+2;
	END IF ;
	
	IF current_scenario = 3 
	THEN 
			result_str[line_count] = 'SCENARIO-3 ' ; 
			line_count=line_count+1;
			result_str[line_count] = 'INSERT ONLY' ; 
			line_count=line_count+1;
			SELECT 
				get_scenario_queryid ( current_test_id , 3 )
			INTO
				scenario_queryid ;
			result_str[line_count] = scenario_queryid ; 
			line_count=line_count+2;
	END IF ;

	IF current_scenario = 4 
	THEN 
			result_str[line_count] = 'SCENARIO-4 ' ; 
			line_count=line_count+1;
			result_str[line_count] = 'CPU LOAD' ; 
			line_count=line_count+1;
			SELECT 
				get_scenario_queryid ( current_test_id , 4 )
			INTO
				scenario_queryid ;
			result_str[line_count] = scenario_queryid ; 
			line_count=line_count+2;
	END IF ;
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	stat_statement_analysis
	WHERE 
		curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ		
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , operating_speed_long  AS operating_speed_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 						
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS curr_waitings_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0 
		) 
		SELECT COALESCE( corr( operating_speed_long , curr_waitings_long ) , 0 ) AS correlation_value 
		INTO speed_waitings_correlation
		FROM
			operating_speed os JOIN waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		bufferpin_waitings AS
		(
			SELECT 
				curr_timestamp , bufferpin_long  AS bufferpin_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND bufferpin_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , bufferpin_long ) , 0 ) AS correlation_value 
		INTO corr_bufferpin
		FROM
			waitings os JOIN bufferpin_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		extension_waitings AS
		(
			SELECT 
				curr_timestamp , extension_long  AS extension_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND extension_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , extension_long ) , 0 ) AS correlation_value 
		INTO corr_extension
		FROM
			waitings os JOIN extension_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		io_waitings AS
		(
			SELECT 
				curr_timestamp , io_long  AS io_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND io_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , io_long ) , 0 ) AS correlation_value 
		INTO corr_io
		FROM
			waitings os JOIN io_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		ipc_waitings AS
		(
			SELECT 
				curr_timestamp , ipc_long  AS ipc_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND ipc_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , ipc_long ) , 0 ) AS correlation_value 
		INTO corr_ipc
		FROM
			waitings os JOIN ipc_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		lock_waitings AS
		(
			SELECT 
				curr_timestamp , lock_long  AS lock_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND lock_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , lock_long ) , 0 ) AS correlation_value 
		INTO corr_lock
		FROM
			waitings os JOIN lock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0				
		) ,
		lwlock_waitings AS
		(
			SELECT 
				curr_timestamp , lwlock_long  AS lwlock_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND lwlock_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , lwlock_long ) , 0 ) AS correlation_value 
		INTO corr_lwlock
		FROM
			waitings os JOIN lwlock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock 
	----------------------------------------------------------------------------------------------------
	
	result_str[line_count] = 'STATS FOR ALL PERIOD' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'CORRELATION COEFFICIENTS' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'SPEED - WAITINGS' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_waitings_correlation::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - BUFFERPIN' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_bufferpin::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - EXTENSION' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_extension::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - IO' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_io::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - IPC' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_ipc::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - LOCK' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_lock::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - LWLOCK' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_lwlock::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	
	SELECT 
		MIN( cl.operating_speed_long) AS min_operating_speed_long , MAX( cl.operating_speed_long) AS max_operating_speed_long , 
		MIN( cl.waitings_long) AS min_waitings_long , MAX( cl.waitings_long) AS max_waitings_long , 
		MIN( cl.bufferpin_long) AS min_bufferpin_long , MAX( cl.bufferpin_long) AS max_bufferpin_long , 
		MIN( cl.extension_long) AS min_extension_long , MAX( cl.extension_long) AS max_extension_long , 
		MIN( cl.io_long) AS min_io_long , MAX( cl.io_long) AS max_io_long , 
		MIN( cl.ipc_long) AS min_ipc_long , MAX( cl.ipc_long) AS max_ipc_long , 
		MIN( cl.lock_long) AS min_lock_long , MAX( cl.lock_long) AS max_lock_long , 
		MIN( cl.lwlock_long) AS min_lwlock_long , MAX( cl.lwlock_long) AS max_lwlock_long         		
	INTO  	min_max_rec
	FROM 
		stat_statement_analysis cl 
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
	

	result_str[line_count] = 	' '||'|'||
								'№'||'|'||		
								'SPEED '||'|'||
								'WAITING' ||'|'||
								'BUFFERPIN ' ||'|'||
								'EXTENSION ' ||'|'||
								'IO ' ||'|'||
								'IPC ' ||'|'||
								'LOCK ' ||'|'||
								'LWLOCK ' ||'|'							
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_operating_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_bufferpin_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_extension_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_io_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_ipc_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_lock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_lwlock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 
	
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		stat_statement_analysis
	WHERE 	
		curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_operating_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_bufferpin_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_extension_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_io_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_ipc_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_lock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_lwlock_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								
	line_count=line_count+2; 

	result_str[line_count] = 	'timestamp'||'|'||  --1
								'№'||'|'||--2	
								'SPEED '||'|'|| --3
								'WAITING' ||'|'  --4
								'SPEED-WAITING CORRELATION' ||'|'|| --5
								'BUFFERPIN ' ||'|'|| --6
								'EXTENSION ' ||'|'|| --7
								'IO ' ||'|'|| --8
								'IPC ' ||'|'|| --9
								'LOCK ' ||'|'|| --10
								'LWLOCK ' ||'|'  --11
								;		
	line_count=line_count+1; 
	
	counter = 0 ; 
	FOR stat_statement_analysis_rec IN
	SELECT 
		cl.curr_timestamp , --1
		cl.operating_speed_long AS operating_speed_long ,  --4
		cl.waitings_long AS waitings_long  ,--5
		cl.bufferpin_long AS bufferpin_long , --6
		cl.extension_long AS extension_long , --7
		cl.io_long AS io_long , --8
		cl.ipc_long AS ipc_long , --9
		cl.lock_long AS lock_long , --10
		cl.lwlock_long AS lwlock_long 	 --11
	FROM 
		stat_statement_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
    ORDER BY cl.curr_timestamp 
	LOOP
		counter = counter + 1 ;

		----------------------------------------------------------------------------------------------------
		--СКОЛЬЗЯЩАЯ КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ		
		WITH 
		operating_speed AS
		(
			SELECT 
				curr_timestamp , operating_speed_long  AS operating_speed_long  
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN stat_statement_analysis_rec.curr_timestamp - interval '1 hour' AND stat_statement_analysis_rec.curr_timestamp 						
		) ,
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS curr_waitings_long 
			FROM stat_statement_analysis
			WHERE				
				curr_timestamp BETWEEN stat_statement_analysis_rec.curr_timestamp - interval '1 hour' AND stat_statement_analysis_rec.curr_timestamp 
				AND waitings_long > 0 
		) 
		SELECT COALESCE( corr( operating_speed_long , curr_waitings_long ) , 0 ) AS correlation_value 
		INTO speed_waitings_correlation
		FROM
			operating_speed os JOIN waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
		--СКОЛЬЗЯЩАЯ КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ СКОРОСТЬ - ОЖИДАНИЯ		
		----------------------------------------------------------------------------------------------------	
		
		TRUNCATE TABLE tmp_timepoints ;
	
		INSERT INTO tmp_timepoints
		(
			curr_timestamp ,	
			curr_timepoint 
		)
		SELECT 
			curr_timestamp , 
			row_number() over (order by curr_timestamp) AS x
		FROM
			stat_statement_analysis
		WHERE 
			curr_timestamp BETWEEN stat_statement_analysis_rec.curr_timestamp - interval '1 hour' AND stat_statement_analysis_rec.curr_timestamp
		ORDER BY curr_timestamp	;
	
		result_str[line_count] =
								to_char( stat_statement_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'|| --1
								counter ||'|'|| --2
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.operating_speed_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| --3
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.waitings_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --4
								REPLACE ( TO_CHAR( ROUND( speed_waitings_correlation::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --5
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.bufferpin_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --6
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.extension_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --7
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.io_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --8
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.ipc_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --9
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.lock_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'||  --10
								REPLACE ( TO_CHAR( ROUND( stat_statement_analysis_rec.lwlock_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'  --11
								;							
	  line_count=line_count+1; 			
	END LOOP;
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

