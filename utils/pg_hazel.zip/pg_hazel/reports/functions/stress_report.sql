-- ОТЧЕТ ПО ТЕКУЩЕМУ СТРЕСС ТЕСТУ
-- stress_report.sql
-- version 65.0


CREATE OR REPLACE FUNCTION stress_report() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;

 current_test_id bigint;
 test_statistics_rec record ; 
 test_statistics_pass_rec record ;
 
 current_speed_short DOUBLE PRECISION;
 current_speed_long DOUBLE PRECISION;
 current_median_short DOUBLE PRECISION;
 current_median_long DOUBLE PRECISION;
 
 current_load integer ; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id; 		

    line_count = 1 ;
	
	SELECT * 
	INTO test_statistics_rec
	FROM test_statistics
	WHERE test_id = current_test_id;
	
	SELECT get_load()
	INTO current_load ;

	
	
	result_str[line_count] = 'STRESS REPORT' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'stress_report.sh' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = 'TEST_ID '; 
	line_count=line_count+1; 
	result_str[line_count] = current_test_id ; 
	line_count=line_count+1; 

	result_str[line_count] = 'QUERYID '; 
	line_count=line_count+1; 
	result_str[line_count] = test_statistics_rec.test_queryid ; 
	line_count=line_count+1; 

	
	result_str[line_count] = ' ' ; 
	line_count=line_count+1; 


	result_str[line_count] = 	'start timestamp'||'|'||
								'finish timestamp'||'|'||
								'PGPRO_PWR SAMPLE'||'|'||
								'PASS'||'|'||
								'LOAD'||'|'||								
								'TEST SQL SPEED'||'|'
								;							
	line_count=line_count+1; 

	
	FOR test_statistics_pass_rec IN 
	SELECT *
	FROM   test_statistics_pass
	WHERE  test_id = current_test_id AND
		   finish_timestamp IS NOT NULL AND 
           pass_counter >= 6  
	ORDER BY pass_counter
	LOOP
		IF test_statistics_pass_rec.pass_counter < 6 
		THEN 
			continue;
		END IF ;
	
		---------------------------------------------------------
		-- МЕДИАНА ОПЕРАЦИОННОЙ СКОРОСТИ  
		-- Долгая медиана
		SELECT (percentile_cont(0.5) within group (order by operating_speed_long))::numeric
		INTO current_speed_long
		FROM stat_statement_analysis
		WHERE curr_timestamp BETWEEN test_statistics_pass_rec.finish_timestamp - interval '1 hour' AND test_statistics_pass_rec.finish_timestamp
			  AND queryid = test_statistics_rec.test_queryid ;	
		IF current_speed_long IS NULL THEN current_speed_long = 0 ; END IF;
		-- МЕДИАНА ОПЕРАЦИОННОЙ СКОРОСТИ 
		---------------------------------------------------------

/* --------------------- 58.0 ------------------------------------		
		---------------------------------------------------------
		-- МЕДИАНА ВРЕМЕНИ ОТКЛИКА  
		-- Долгая медиана
		SELECT (percentile_cont(0.5) within group (order by median_duration))::numeric
		INTO current_median_long
		FROM stat_timer_statistics_long
		WHERE curr_timestamp BETWEEN test_statistics_pass_rec.finish_timestamp - interval '1 hour' AND test_statistics_pass_rec.finish_timestamp
		      AND queryid = test_statistics_rec.test_queryid ;	
		IF current_median_long IS NULL THEN current_median_long = 0 ; END IF;
		-- МЕДИАНА ВРЕМЕНИ ОТКЛИКА
		---------------------------------------------------------
--------------------- 58.0 ------------------------------------ */		
			
		result_str[line_count] = 	to_char( test_statistics_pass_rec.start_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'||
									to_char( test_statistics_pass_rec.finish_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'||
									test_statistics_pass_rec.pgpro_pwr_snapshot||'|'||
									test_statistics_pass_rec.pass_counter ||'|'||
									ROUND( test_statistics_pass_rec.load_connections::numeric , 0 ) ||'|'||
									REPLACE ( TO_CHAR( ROUND( (current_speed_long::numeric)::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ||'|'
								;							
	  line_count=line_count+1; 	

	
	END LOOP ;
	



		
	
  return result_str ; 
END
$$ LANGUAGE plpgsql STABLE ;

