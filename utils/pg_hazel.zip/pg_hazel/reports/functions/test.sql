--test.sql
/*
timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")
REPORT_FILE=$REPORT_DIR'/queryid_stat_'$timestamp_label'.txt'

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'
REPORT_FILE=$current_path'/queryid_stat.'$queryid'.'$timestamp_label'.txt'
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( test())" > $REPORT_FILE 2>$ERR_FILE
  
*/

CREATE OR REPLACE FUNCTION test() RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 stat_statement_analysis_rec record ;
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 sql_correlation DOUBLE PRECISION;
 
 min_max_pct_rec record ;
 
 bufferpin_value	 text ;
 extension_value text ;
 io_value text ;
 ipc_value text ;
 lock_value text ;
 lwlock_value text ; 
 
 queryid_waitings_calls_rec record ; 
 waitings_calls  DOUBLE PRECISION;
 stat_statement_wait_events_analysis_rec record ;
 current_last_sql_statistics timestamp with time zone ; 
 current_queryid_hex text ; 	
 sql_wait_event_type_rec record ;  
 
 wait_event_types_array text[];
 wait_event_types_array_index integer ; 
 temp_queryid_stat_rec record ; 

 current_queryid bigint ;
start_timestamp text ;
finish_timestamp text ; 

BEGIN
current_queryid = 7513737040875440920 ;
start_timestamp = '2025-04-17 10:58';
finish_timestamp = '2025-04-17 11:58'; 

	line_count = 1 ;
	
RAISE NOTICE 'current_queryid = %' , current_queryid ; 	
RAISE NOTICE 'start_timestamp = %' , start_timestamp ; 	
RAISE NOTICE 'finish_timestamp = %' , finish_timestamp ; 	

	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) 
		INTO 	max_timestamp ; 
	
		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' )
		INTO 	min_timestamp ; 
		
		SELECT 	to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) 
		INTO 	max_timestamp ; 		
	END IF ;
	
	result_str[line_count] = 'queryid_stat' ; 
	line_count=line_count+1; 
	
	result_str[line_count] = to_char( min_timestamp , 'YYYY-MM-DD HH24:MI' ) ; 
	line_count=line_count+1; 
	
	result_str[line_count] = to_char( max_timestamp , 'YYYY-MM-DD HH24:MI' ); 
	line_count=line_count+2; 
	
	
	result_str[line_count] = 'queryid'; 
	line_count=line_count+1; 		
	result_str[line_count] = current_queryid; 
	line_count=line_count+1; 		
	
	result_str[line_count] = 'pgpro_pwr_queryid'; 
	line_count=line_count+1; 		
	
	SELECT to_hex( current_queryid ) 
	INTO current_queryid_hex ; 
	
	result_str[line_count] = current_queryid_hex; 
	line_count=line_count+2; 		
	
	
	
	-----------------------------------------
	-- Массив wait_event_types_array 
	wait_event_types_array[1] = 'BufferPin';
	wait_event_types_array[2] = 'Extension';
	wait_event_types_array[3] = 'IO';
	wait_event_types_array[4] = 'IPC';
	wait_event_types_array[5] = 'Lock';
	wait_event_types_array[6] = 'LWLock';	
	-- Массив wait_event_types_array 
	-----------------------------------------

	DROP TABLE IF EXISTS temp_queryid_stat ;
	CREATE TEMPORARY TABLE temp_queryid_stat 
	--CREATE TABLE temp_queryid_stat 
	(	
		wait_event_type text , 
		curr_timestamp timestamp with time zone , 		
		
		curr_userid oid , 
		curr_rolename name , 
		calls DOUBLE PRECISION , 
		waitings DOUBLE PRECISION , 
		waitings_calls DOUBLE PRECISION
	);

	
	
	FOR wait_event_types_array_index IN 1..6
	LOOP			
		FOR stat_statement_analysis_rec IN 
		SELECT curr_timestamp ,  userid 
		FROM stat_statement_analysis
		WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp
		AND queryid = current_queryid
		LOOP
			-------------------------------------------------------
			-- КОРРЕЛЯЦИЯ , КОЛИЧЕСТВО ВЫЗОВОВ И ОЖИДАНИЙ ПО ТИПУ
			CASE 
			--BufferPin
			WHEN wait_event_types_array[wait_event_types_array_index] = 'BufferPin' THEN 				
				INSERT INTO temp_queryid_stat
				(
					wait_event_type ,
					curr_timestamp , 
					curr_userid , 
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					wait_event_types_array[wait_event_types_array_index] , 
					curr_timestamp ,
					
					
					userid , 
					(SELECT rolname FROM pg_roles WHERE oid = userid ) ,					
					SUM( calls_long ) AS calls_long ,
					SUM( bufferpin_long  ) AS waitings_count , 
					SUM( bufferpin_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND bufferpin_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					AND userid = stat_statement_analysis_rec.userid 
				GROUP BY 					
					curr_timestamp , queryid , userid ;
					
			--Extension		
			WHEN wait_event_types_array[wait_event_types_array_index] = 'Extension' THEN 
				INSERT INTO temp_queryid_stat
				(
					wait_event_type ,
					curr_timestamp , 
					curr_userid , 
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					wait_event_types_array[wait_event_types_array_index] , 
					curr_timestamp ,
					
					userid , 
					(SELECT rolname FROM pg_roles WHERE oid = userid ) ,
					SUM( calls_long ) AS calls_long ,
					SUM( extension_long  ) AS waitings_count , 					
					SUM( extension_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND extension_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					
					AND userid = stat_statement_analysis_rec.userid 
				GROUP BY 					
					curr_timestamp , queryid , userid ;
				
			--IO	
			WHEN wait_event_types_array[wait_event_types_array_index] = 'IO' THEN 
				INSERT INTO temp_queryid_stat
				(
					wait_event_type ,
					curr_timestamp , 					
					curr_userid , 
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					wait_event_types_array[wait_event_types_array_index] , 
					curr_timestamp ,
					
					
					userid , 
					(SELECT rolname FROM pg_roles WHERE oid = userid ) ,
					SUM( calls_long ) AS calls_long ,
					SUM( io_long  ) AS waitings_count , 
					SUM( io_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND io_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					
					AND userid = stat_statement_analysis_rec.userid 
				GROUP BY 					
					curr_timestamp , queryid , userid ;
			
			--IPC	
			WHEN wait_event_types_array[wait_event_types_array_index] = 'IPC' THEN 
				INSERT INTO temp_queryid_stat
				(
					wait_event_type ,
					curr_timestamp , 					
					curr_userid , 
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					wait_event_types_array[wait_event_types_array_index] , 
					curr_timestamp ,
					
					
					userid , 
					(SELECT rolname FROM pg_roles WHERE oid = userid ) ,
					SUM( calls_long ) AS calls_long ,
					SUM( ipc_long  ) AS waitings_count , 
					SUM( ipc_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND ipc_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					
					AND userid = stat_statement_analysis_rec.userid 
				GROUP BY 					
					curr_timestamp , queryid , userid ;
					
			--Lock	
			WHEN wait_event_types_array[wait_event_types_array_index] = 'Lock' THEN
				INSERT INTO temp_queryid_stat
				(
					wait_event_type ,
					curr_timestamp , 					
					curr_userid , 
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					wait_event_types_array[wait_event_types_array_index] , 
					curr_timestamp ,
					
					
					userid , 
					(SELECT rolname FROM pg_roles WHERE oid = userid ) ,
					SUM( calls_long ) AS calls_long ,
					SUM( lock_long  ) AS waitings_count , 
					SUM( lock_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND lock_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					
					AND userid = stat_statement_analysis_rec.userid 
				GROUP BY 					
					curr_timestamp , queryid , userid ;
					
			--LWLock	
			WHEN wait_event_types_array[wait_event_types_array_index] = 'LWLock' THEN
				INSERT INTO temp_queryid_stat
				(
					wait_event_type ,
					curr_timestamp , 					
					curr_userid , 
					curr_rolename , 
					calls , 
					waitings, 
					waitings_calls 
				)
				SELECT 
					wait_event_types_array[wait_event_types_array_index] , 
					curr_timestamp ,
					
					
					userid , 
					(SELECT rolname FROM pg_roles WHERE oid = userid ) ,
					SUM( calls_long ) AS calls_long ,
					SUM( lwlock_long  ) AS waitings_count , 
					SUM( lwlock_long  ) / SUM( calls_long )
				FROM 
					stat_statement_analysis
				WHERE 	
					curr_timestamp  = stat_statement_analysis_rec.curr_timestamp
					AND lwlock_long > 0 AND calls_long > 0 
					AND queryid = current_queryid
					
					AND userid = stat_statement_analysis_rec.userid 
				GROUP BY 					
					curr_timestamp , queryid , userid ;		
			END CASE ;		
			-- КОРРЕЛЯЦИЯ , КОЛИЧЕСТВО ВЫЗОВОВ И ОЖИДАНИЙ ПО ТИПУ
			-------------------------------------------------------------------------------------		
		END LOOP;			
	END LOOP ;
	
	
	FOR wait_event_types_array_index IN 1..6
	LOOP			
		result_str[line_count] = 'CALLS AND WAITINGS BY WAIT_EVENT_TYPE' ; 
		line_count=line_count+1; 
	
		result_str[line_count] =  wait_event_types_array[wait_event_types_array_index] ; 
		line_count=line_count+1; 
		
		result_str[line_count] = 	'timestamp'||'|'||  --1
									'datname'||'|'||   --2	
									'rolname'||'|'||   --3
									'CALLS'||'|'|| --4
									'WAITINGS '||'|'||--5
									'WAITINGS TO CALLS ' ||'|'--6								
									'WAIT_EVENTS ' ||'|'--7
									;		
		line_count=line_count+1; 	
	
		FOR temp_queryid_stat_rec IN 
		SELECT * 
		FROM temp_queryid_stat
		WHERE wait_event_type = wait_event_types_array[wait_event_types_array_index]
		ORDER BY curr_timestamp 
		LOOP
			result_str[line_count] =	to_char(temp_queryid_stat_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI')  ||'|'||
										'test_pgbench_custom' ||'|'||
										temp_queryid_stat_rec.curr_rolename ||'|'||
										REPLACE ( TO_CHAR( ROUND( temp_queryid_stat_rec.calls::numeric , 5 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| 
										REPLACE ( TO_CHAR( ROUND( temp_queryid_stat_rec.waitings::numeric , 5 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| 
										REPLACE ( TO_CHAR( ROUND( temp_queryid_stat_rec.waitings_calls::numeric , 5 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' 
										;		

			FOR stat_statement_wait_events_analysis_rec IN 
			SELECT curr_timestamp , wait_event 
			FROM stat_statement_wait_events_analysis
			WHERE curr_timestamp = temp_queryid_stat_rec.curr_timestamp
				AND queryid = current_queryid				
				AND userid = temp_queryid_stat_rec.curr_userid 
				AND wait_event_type = wait_event_types_array[wait_event_types_array_index] 
			GROUP BY curr_timestamp , wait_event 
			ORDER BY curr_timestamp , wait_event 
			LOOP
				result_str[line_count] = result_str[line_count] || stat_statement_wait_events_analysis_rec.wait_event ||' ' ;
			END LOOP ;
			result_str[line_count] = result_str[line_count] ||'|' ;
			line_count=line_count+1; 
		END LOOP ;	
		
		line_count=line_count+1; 
		
	END LOOP ;

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

	
	
	
