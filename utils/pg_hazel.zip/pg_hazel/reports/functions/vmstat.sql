----------------------------------------------------------------------------------------------------------------
-- ПРОИЗВОДИТЕЛЬНОСТЬ И ОЖИДАНИЯ НА УРОВНЕ КЛАСТЕРА
-- vmstat.sql
-- version 62.0
-- 


CREATE OR REPLACE FUNCTION vmstat(  start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
	corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

-----------------------------------------------------------------------------------
--Корреляция со скоростью
	speed_corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	speed_corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	speed_corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	speed_corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	speed_corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	speed_corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	speed_corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	speed_corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	speed_corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	speed_corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	speed_corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	speed_corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	speed_corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	speed_corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	speed_corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	speed_corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	speed_corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

--Корреляция со скоростью
-----------------------------------------------------------------------------------


  	
  speed_regr_slope_value DOUBLE PRECISION ; 
  waitings_regr_slope_value DOUBLE PRECISION ; 
  os_stat_vmstat_analysis_rec record ; 
  waitings_min_max_rec record ; 
  speed_min_max_rec record ; 
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - VMSTAT' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'vmstat.sh' ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	os_stat_vmstat_analysis cl
	WHERE 
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;

	SELECT 
		MIN( cl.vmstat_analysis_procs_r_long) AS min_vmstat_analysis_procs_r_long , MAX( cl.vmstat_analysis_procs_r_long) AS max_vmstat_analysis_procs_r_long , 
		MIN( cl.vmstat_analysis_procs_b_long) AS min_vmstat_analysis_procs_b_long , MAX( cl.vmstat_analysis_procs_b_long) AS max_vmstat_analysis_procs_b_long , 		
		MIN( cl.vmstat_analysis_memory_swpd_long) AS min_vmstat_analysis_memory_swpd_long , MAX( cl.vmstat_analysis_memory_swpd_long) AS max_vmstat_analysis_memory_swpd_long , 
		MIN( cl.vmstat_analysis_memory_free_long) AS min_vmstat_analysis_memory_free_long, MAX( cl.vmstat_analysis_memory_free_long) AS max_vmstat_analysis_memory_free_long , 
		MIN( cl.vmstat_analysis_memory_buff_long) AS min_vmstat_analysis_memory_buff_long , MAX( cl.vmstat_analysis_memory_buff_long) AS max_vmstat_analysis_memory_buff_long , 
		MIN( cl.vmstat_analysis_memory_cache_long) AS min_vmstat_analysis_memory_cache_long , MAX( cl.vmstat_analysis_memory_cache_long) AS max_vmstat_analysis_memory_cache_long , 
		MIN( cl.vmstat_analysis_swap_si_long) AS min_vmstat_analysis_swap_si_long , MAX( cl.vmstat_analysis_swap_si_long) AS max_vmstat_analysis_swap_si_long , 
		MIN( cl.vmstat_analysis_swap_so_long) AS min_vmstat_analysis_swap_so_long , MAX( cl.vmstat_analysis_swap_so_long) AS max_vmstat_analysis_swap_so_long ,
		MIN( cl.vmstat_analysis_io_bi_long) AS min_vmstat_analysis_io_bi_long , MAX( cl.vmstat_analysis_io_bi_long) AS max_vmstat_analysis_io_bi_long ,
		MIN( cl.vmstat_analysis_io_bo_long) AS min_vmstat_analysis_io_bo_long , MAX( cl.vmstat_analysis_io_bo_long) AS max_vmstat_analysis_io_bo_long ,
		MIN( cl.vmstat_analysis_system_in_long) AS min_vmstat_analysis_system_in_long , MAX( cl.vmstat_analysis_system_in_long) AS max_vmstat_analysis_system_in_long ,
		MIN( cl.vmstat_analysis_system_cs_long) AS min_vmstat_analysis_system_cs_long , MAX( cl.vmstat_analysis_system_cs_long) AS max_vmstat_analysis_system_cs_long ,
		MIN( cl.vmstat_analysis_cpu_us_long) AS min_vmstat_analysis_cpu_us_long , MAX( cl.vmstat_analysis_cpu_us_long) AS max_vmstat_analysis_cpu_us_long ,
		MIN( cl.vmstat_analysis_cpu_sy_long) AS min_vmstat_analysis_cpu_sy_long , MAX( cl.vmstat_analysis_cpu_sy_long) AS max_vmstat_analysis_cpu_sy_long ,
		MIN( cl.vmstat_analysis_cpu_id_long) AS min_vmstat_analysis_cpu_id_long , MAX( cl.vmstat_analysis_cpu_id_long) AS max_vmstat_analysis_cpu_id_long ,
		MIN( cl.vmstat_analysis_cpu_wa_long) AS min_vmstat_analysis_cpu_wa_long , MAX( cl.vmstat_analysis_cpu_wa_long) AS max_vmstat_analysis_cpu_wa_long ,
		MIN( cl.vmstat_analysis_cpu_st_long) AS min_vmstat_analysis_cpu_st_long , MAX( cl.vmstat_analysis_cpu_st_long) AS max_vmstat_analysis_cpu_st_long 
	INTO  	min_max_rec
	FROM 
		os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
		
	
	SELECT 
		MIN( cl_w.waitings_long) AS min_waitings_long , MAX( cl_w.waitings_long) AS max_waitings_long 
	INTO 
		waitings_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_w
	WHERE 	
		cl_w.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;

    SELECT 
		MIN( cl_s.op_speed_long) AS min_speed_long , MAX( cl_s.op_speed_long) AS max_speed_long 
	INTO 
		speed_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_s
	WHERE 	
		cl_s.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;		
		
		
	
	
	line_count=line_count+1;
	result_str[line_count] = 	' '||'|'||
								'№'||'|'||									
								'WAITINGS' ||'|'||
								'SPEED' ||'|'||
								'procs_r' ||'|'||
								'procs_b ' ||'|'||
								'memory_swpd ' ||'|'||
								'memory_free ' ||'|'||
								'memory_buff ' ||'|'||
								'memory_cache ' ||'|'||
								'swap_si ' ||'|' ||
								'swap_so ' ||'|' ||
								'io_bi ' ||'|' ||
								'io_bo ' ||'|' ||
								'system_in ' ||'|' ||
								'system_cs ' ||'|' ||
								'cpu_us ' ||'|' ||
								'cpu_sy ' ||'|' ||
								'cpu_id ' ||'|' ||
								'cpu_wa ' ||'|' ||
								'cpu_st ' ||'|' 
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( waitings_min_max_rec.min_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( speed_min_max_rec.min_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_procs_r_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_procs_b_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_swpd_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_free_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_buff_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_cache_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_swap_si_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_swap_so_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_io_bi_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_io_bo_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_system_in_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_system_cs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_us_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_sy_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_id_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_st_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 
	
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( waitings_min_max_rec.max_waitings_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( speed_min_max_rec.max_speed_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_procs_r_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_procs_b_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_swpd_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_free_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_buff_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_cache_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_swap_si_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_swap_so_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_io_bi_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_io_bo_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_system_in_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_system_cs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_us_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_sy_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_id_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_st_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								
	line_count=line_count+2; 

							
	result_str[line_count] = 	'timestamp'||'|'||  --1
								'№'||'|'||	
								'WAITINGS' ||'|'||--2
								'SPEED' ||'|'--3
								;
	IF min_max_rec.max_vmstat_analysis_procs_r_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'procs_r' ||'|'; --4
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_procs_b_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'procs_b' ||'|'; --5
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_memory_swpd_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'memory_swpd' ||'|'; --6
	END IF;

	IF min_max_rec.max_vmstat_analysis_memory_free_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'memory_free' ||'|'; --7
	END IF;

	IF min_max_rec.max_vmstat_analysis_memory_buff_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'memory_buff' ||'|'; --8
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_memory_cache_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'memory_cache' ||'|'; --9
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_swap_si_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'swap_si' ||'|'; --10
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_swap_so_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'swap_so' ||'|'; --11
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_io_bi_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'io_bi' ||'|'; --12
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_io_bo_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'io_bo' ||'|'; --13
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_system_in_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'system_in' ||'|'; --14
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_system_cs_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'system_cs' ||'|'; --15
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_cpu_us_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'cpu_us' ||'|'; --16
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_cpu_sy_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'cpu_sy' ||'|'; --17
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_cpu_id_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'cpu_id' ||'|'; --18
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_cpu_wa_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'cpu_wa' ||'|'; --19
	END IF;
	
	IF min_max_rec.max_vmstat_analysis_cpu_st_long > 0 
	THEN 
		result_str[line_count] = result_str[line_count] ||
								'cpu_st' ||'|'; --20
	END IF;
								

	line_count=line_count+1; 
	
	counter = 0 ; 
	FOR os_stat_vmstat_analysis_rec IN
	SELECT 
		cl.curr_timestamp , --1
		cl_w.waitings_long ,--2
		cl_w.op_speed_long ,--3
		cl.vmstat_analysis_procs_r_long ,--4
		cl.vmstat_analysis_procs_b_long ,--5
		cl.vmstat_analysis_memory_swpd_long ,--6
		cl.vmstat_analysis_memory_free_long ,--7
		cl.vmstat_analysis_memory_buff_long ,--8
		cl.vmstat_analysis_memory_cache_long ,--9
		cl.vmstat_analysis_swap_si_long ,--10
		cl.vmstat_analysis_swap_so_long ,--11
		cl.vmstat_analysis_io_bi_long ,--12
		cl.vmstat_analysis_io_bo_long ,--13
		cl.vmstat_analysis_system_in_long ,--14
		cl.vmstat_analysis_system_cs_long ,--15
		cl.vmstat_analysis_cpu_us_long ,--16
		cl.vmstat_analysis_cpu_sy_long ,--17
		cl.vmstat_analysis_cpu_id_long ,--18
		cl.vmstat_analysis_cpu_wa_long ,--19
		cl.vmstat_analysis_cpu_st_long--20
	FROM 
		os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	
    ORDER BY cl.curr_timestamp 
	LOOP
		counter = counter + 1 ;
		
		result_str[line_count] =
								to_char( os_stat_vmstat_analysis_rec.curr_timestamp , 'YYYY-MM-DD HH24:MI') ||'|'|| --1
								counter ||'|'|| 
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.waitings_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|'|| --2
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.op_speed_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --3
								;
								
		IF min_max_rec.max_vmstat_analysis_procs_r_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_procs_r_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --4
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_procs_b_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_procs_b_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --5
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_memory_swpd_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_memory_swpd_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --6
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_memory_free_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_memory_free_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --7
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_memory_buff_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_memory_buff_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --8
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_memory_cache_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_memory_cache_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --9
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_swap_si_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_swap_si_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --10
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_swap_so_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_swap_so_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --11
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_io_bi_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_io_bi_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --12
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_io_bo_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_io_bo_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --13
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_system_in_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_system_in_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --14
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_system_cs_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_system_cs_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --15
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_cpu_us_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_cpu_us_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --16
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_cpu_sy_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_cpu_sy_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --17
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_cpu_id_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_cpu_id_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --18
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_cpu_wa_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --19
								;
		END IF;
		
		IF min_max_rec.max_vmstat_analysis_cpu_st_long > 0 
		THEN 
			result_str[line_count] = result_str[line_count] ||
								REPLACE ( TO_CHAR( ROUND( os_stat_vmstat_analysis_rec.vmstat_analysis_cpu_st_long::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ||'|' --20	
								;
		END IF;
		


								
	  line_count=line_count+1; 			
	END LOOP;
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;


--------------------------------------------------------------------------------------------------------		
--Пока отключено - неясно как использовать при анализе		
/* 
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - procs_r r — процессы в run queue (готовы к выполнению)
	IF min_max_rec.min_vmstat_analysis_procs_r_long = min_max_rec.max_vmstat_analysis_procs_r_long
	THEN 
		corr_procs_r_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		procs_r_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_procs_r_long  AS vmstat_analysis_procs_r_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_procs_r_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_procs_r_long ) , 0 ) AS correlation_value 
		INTO corr_procs_r_long
		FROM
			waitings os JOIN procs_r_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - procs_r r — процессы в run queue (готовы к выполнению)
	----------------------------------------------------------------------------------------------------
		
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - procs_b b — процессы в uninterruptible sleep (обычно ждут IO)
	IF min_max_rec.min_vmstat_analysis_procs_b_long = min_max_rec.max_vmstat_analysis_procs_b_long
	THEN 
		corr_procs_b_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		procs_b_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_procs_b_long  AS vmstat_analysis_procs_b_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_procs_b_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_procs_b_long ) , 0 ) AS correlation_value 
		INTO corr_procs_b_long
		FROM
			waitings os JOIN procs_b_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - procs_b b — процессы в uninterruptible sleep (обычно ждут IO)
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - -- swpd — объём свопа
	IF min_max_rec.min_vmstat_analysis_memory_swpd_long = min_max_rec.max_vmstat_analysis_memory_swpd_long
	THEN 
		corr_memory_swpd_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		memory_swpd_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_swpd_long  AS vmstat_analysis_memory_swpd_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_swpd_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_memory_swpd_long ) , 0 ) AS correlation_value 
		INTO corr_memory_swpd_long
		FROM
			waitings os JOIN memory_swpd_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - -- swpd — объём свопа
	----------------------------------------------------------------------------------------------------
    ----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - memory_free -- free — свободная RAM
	IF min_max_rec.min_vmstat_analysis_memory_free_long = min_max_rec.max_vmstat_analysis_memory_free_long
	THEN 
		corr_memory_free_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		memory_free_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_free_long  AS vmstat_analysis_memory_free_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_free_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_memory_free_long ) , 0 ) AS correlation_value 
		INTO corr_memory_free_long
		FROM
			waitings os JOIN memory_free_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - -- memory_free -- free — свободная RAM
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - memory_buff -- buff — буферы
	IF min_max_rec.min_vmstat_analysis_memory_buff_long = min_max_rec.max_vmstat_analysis_memory_buff_long
	THEN 
		corr_memory_buff_long = 0 ;
	ELSE 
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		memory_buff_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_buff_long  AS vmstat_analysis_memory_buff_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_buff_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_memory_buff_long ) , 0 ) AS correlation_value 
		INTO corr_memory_buff_long
		FROM
			waitings os JOIN memory_buff_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - memory_buff -- buff — буферы
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - memory_cache -- cache — кэш
	IF min_max_rec.min_vmstat_analysis_memory_cache_long = min_max_rec.max_vmstat_analysis_memory_cache_long
	THEN 
		corr_memory_cache_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		memory_cache_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_cache_long  AS vmstat_analysis_memory_cache_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_cache_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_memory_cache_long ) , 0 ) AS correlation_value 
		INTO corr_memory_cache_long
		FROM
			waitings os JOIN memory_cache_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF;			
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - memory_cache -- cache — кэш
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - swap_si -- si — swap in (из swap в RAM)
	IF min_max_rec.min_vmstat_analysis_swap_si_long = min_max_rec.max_vmstat_analysis_swap_si_long
	THEN 
		corr_swap_si_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		swap_si_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_swap_si_long  AS vmstat_analysis_swap_si_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_swap_si_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_swap_si_long ) , 0 ) AS correlation_value 
		INTO corr_swap_si_long
		FROM
			waitings os JOIN swap_si_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF;			
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - swap_si -- si — swap in (из swap в RAM)
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - swap_so -- so — swap out (из RAM в swap)
	IF min_max_rec.min_vmstat_analysis_swap_so_long = min_max_rec.max_vmstat_analysis_swap_so_long
	THEN 
		corr_swap_so_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		swap_so_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_swap_so_long  AS vmstat_analysis_swap_so_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_swap_so_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_swap_so_long ) , 0 ) AS correlation_value 
		INTO corr_swap_so_long
		FROM
			waitings os JOIN swap_so_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - swap_so -- so — swap out (из RAM в swap)
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	IF min_max_rec.min_vmstat_analysis_io_bi_long = min_max_rec.max_vmstat_analysis_io_bi_long
	THEN 
		corr_io_bi_long = 0 ;
	ELSE
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - io_bi -- bi — блоки, считанные с устройств
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		io_bi_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_io_bi_long  AS vmstat_analysis_io_bi_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_io_bi_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_io_bi_long ) , 0 ) AS correlation_value 
		INTO corr_io_bi_long
		FROM
			waitings os JOIN io_bi_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF ;			
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - io_bi -- bi — блоки, считанные с устройств
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - io_bo-- bo — записанные на устройства
	IF min_max_rec.min_vmstat_analysis_io_bo_long = min_max_rec.max_vmstat_analysis_io_bo_long
	THEN 
		corr_io_bo_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		io_bo_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_io_bo_long  AS vmstat_analysis_io_bo_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_io_bo_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_io_bo_long ) , 0 ) AS correlation_value 
		INTO corr_io_bo_long
		FROM
			waitings os JOIN io_bo_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - io_bo-- bo — записанные на устройства 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - system_in -- in — прерывания
	IF min_max_rec.min_vmstat_analysis_system_in_long = min_max_rec.max_vmstat_analysis_system_in_long
	THEN 
		corr_system_in_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		system_in_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_in_long  AS vmstat_analysis_system_in_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_in_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_system_in_long ) , 0 ) AS correlation_value 
		INTO corr_system_in_long
		FROM
			waitings os JOIN system_in_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - system_in -- in — прерывания
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - system_cs -- cs — переключения контекста
	IF min_max_rec.min_vmstat_analysis_system_cs_long = min_max_rec.max_vmstat_analysis_system_cs_long
	THEN 
		corr_system_cs_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		system_cs_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_cs_long  AS vmstat_analysis_system_cs_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_cs_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_system_cs_long ) , 0 ) AS correlation_value 
		INTO corr_system_cs_long
		FROM
			waitings os JOIN system_cs_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - system_cs -- cs — переключения контекста
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_us -- us — user time
	IF min_max_rec.min_vmstat_analysis_cpu_us_long = min_max_rec.max_vmstat_analysis_cpu_us_long
	THEN 
		corr_cpu_us_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_us_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_us_long  AS vmstat_analysis_cpu_us_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_us_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_cpu_us_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_us_long
		FROM
			waitings os JOIN cpu_us_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_us -- us — user time
	----------------------------------------------------------------------------------------------------

    ----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_sy -- sy — system time
	IF min_max_rec.min_vmstat_analysis_cpu_sy_long = min_max_rec.max_vmstat_analysis_cpu_sy_long
	THEN 
		corr_cpu_sy_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_sy_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_sy_long  AS vmstat_analysis_cpu_sy_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_sy_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_cpu_sy_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_sy_long
		FROM
			waitings os JOIN cpu_sy_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_sy -- sy — system time
	----------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------
	IF min_max_rec.min_vmstat_analysis_cpu_id_long = min_max_rec.max_vmstat_analysis_cpu_id_long
	THEN 
		corr_cpu_id_long = 0 ;
	ELSE
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_id -- id — idle
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_id_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_id_long  AS vmstat_analysis_cpu_id_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_id_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_cpu_id_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_id_long
		FROM
			waitings os JOIN cpu_id_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_id -- id — idle
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_wa --  wa — ожидание IO
	IF min_max_rec.min_vmstat_analysis_cpu_wa_long = min_max_rec.max_vmstat_analysis_cpu_wa_long
	THEN 
		corr_cpu_wa_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_wa_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_wa_long  AS vmstat_analysis_cpu_wa_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_wa_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_cpu_wa_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_wa_long
		FROM
			waitings os JOIN cpu_wa_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_wa --  wa — ожидание IO
	----------------------------------------------------------------------------------------------------
			
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_st  --  st — stolen (украдено гипервизором)
	IF min_max_rec.min_vmstat_analysis_cpu_wa_long = min_max_rec.max_vmstat_analysis_cpu_wa_long
	THEN 
		corr_cpu_st_long = 0 ;
	ELSE
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		cpu_st_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_st_long  AS vmstat_analysis_cpu_st_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_st_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , vmstat_analysis_cpu_st_long ) , 0 ) AS correlation_value 
		INTO corr_cpu_st_long
		FROM
			waitings os JOIN cpu_st_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ ОЖИДАНИЯ - cpu_st  --  st — stolen (украдено гипервизором)
	----------------------------------------------------------------------------------------------------

	line_count=line_count+1;
	result_str[line_count] = 'CORRELATION COEFFICIENTS FOR WAITINGS' ; 
	line_count=line_count+1;

	result_str[line_count] = 'WAITINGS - procs_r процессы в run queue (готовы к выполнению)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_procs_r_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - procs_b процессы в uninterruptible sleep (обычно ждут IO)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_procs_b_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - memory_swpd объём свопа ' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_memory_swpd_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - memory_free свободная RAM' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_memory_free_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - memory_buff буферы' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_memory_buff_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - memory_cache кэш ' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_memory_cache_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - swap_si swap in (из swap в RAM)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_swap_si_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - swap_so swap out (из RAM в swap)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_swap_so_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - io_bi блоки, считанные с устройств' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_io_bi_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - io_bo записанные на устройства' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_io_bo_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - system_in прерывания' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_system_in_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - system_cs переключения контекста' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_system_cs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - cpu_us user time' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_us_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - cpu_sy system time ' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_sy_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - cpu_id idle' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_id_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - cpu_wa ожидание IO' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'WAITINGS - cpu_st stolen (украдено гипервизором)' ||'|'|| REPLACE ( TO_CHAR( ROUND( corr_cpu_st_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 


-----------------------------------------------------------------------------------
-- КОРРЕЛЯЦИЯ СО СКОРОСТЬЮ
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- procs_r r — процессы в run queue (готовы к выполнению)
	IF min_max_rec.min_vmstat_analysis_procs_r_long = min_max_rec.max_vmstat_analysis_procs_r_long
	THEN 
		speed_corr_procs_r_long = 0 ;
	ELSE 
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		procs_r_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_procs_r_long  AS vmstat_analysis_procs_r_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_procs_r_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_procs_r_long ) , 0 ) AS correlation_value 
		INTO speed_corr_procs_r_long
		FROM
			speed os JOIN procs_r_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- procs_r r — процессы в run queue (готовы к выполнению)
	----------------------------------------------------------------------------------------------------
		
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- procs_b b — процессы в uninterruptible sleep (обычно ждут IO)
	IF min_max_rec.min_vmstat_analysis_procs_b_long = min_max_rec.max_vmstat_analysis_procs_b_long
	THEN 
		speed_corr_procs_b_long = 0 ;
	ELSE 
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		procs_b_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_procs_b_long  AS vmstat_analysis_procs_b_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_procs_b_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_procs_b_long ) , 0 ) AS correlation_value 
		INTO speed_corr_procs_b_long
		FROM
			speed os JOIN procs_b_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- procs_b b — процессы в uninterruptible sleep (обычно ждут IO)
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- -- swpd — объём свопа
	IF min_max_rec.min_vmstat_analysis_memory_swpd_long = min_max_rec.max_vmstat_analysis_memory_swpd_long
	THEN 
		speed_corr_memory_swpd_long = 0 ;
	ELSE 
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		memory_swpd_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_swpd_long  AS vmstat_analysis_memory_swpd_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_swpd_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_memory_swpd_long ) , 0 ) AS correlation_value 
		INTO speed_corr_memory_swpd_long
		FROM
			speed os JOIN memory_swpd_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- -- swpd — объём свопа
	----------------------------------------------------------------------------------------------------
    ----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- memory_free -- free — свободная RAM
	IF min_max_rec.min_vmstat_analysis_memory_free_long = min_max_rec.max_vmstat_analysis_memory_free_long
	THEN 
		speed_corr_memory_free_long = 0 ;
	ELSE 
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		memory_free_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_free_long  AS vmstat_analysis_memory_free_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_free_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_memory_free_long ) , 0 ) AS correlation_value 
		INTO speed_corr_memory_free_long
		FROM
			speed os JOIN memory_free_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- -- memory_free -- free — свободная RAM
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- memory_buff -- buff — буферы
	IF min_max_rec.min_vmstat_analysis_memory_buff_long = min_max_rec.max_vmstat_analysis_memory_buff_long
	THEN 
		speed_corr_memory_buff_long = 0 ;
	ELSE 
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		memory_buff_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_buff_long  AS vmstat_analysis_memory_buff_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_buff_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_memory_buff_long ) , 0 ) AS correlation_value 
		INTO speed_corr_memory_buff_long
		FROM
			speed os JOIN memory_buff_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- memory_buff -- buff — буферы
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- memory_cache -- cache — кэш
	IF min_max_rec.min_vmstat_analysis_memory_cache_long = min_max_rec.max_vmstat_analysis_memory_cache_long
	THEN 
		speed_corr_memory_cache_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		memory_cache_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_cache_long  AS vmstat_analysis_memory_cache_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_cache_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_memory_cache_long ) , 0 ) AS correlation_value 
		INTO speed_corr_memory_cache_long
		FROM
			speed os JOIN memory_cache_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF;			
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- memory_cache -- cache — кэш
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- swap_si -- si — swap in (из swap в RAM)
	IF min_max_rec.min_vmstat_analysis_swap_si_long = min_max_rec.max_vmstat_analysis_swap_si_long
	THEN 
		speed_corr_swap_si_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		swap_si_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_swap_si_long  AS vmstat_analysis_swap_si_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_swap_si_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_swap_si_long ) , 0 ) AS correlation_value 
		INTO speed_corr_swap_si_long
		FROM
			speed os JOIN swap_si_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF;			
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- swap_si -- si — swap in (из swap в RAM)
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- swap_so -- so — swap out (из RAM в swap)
	IF min_max_rec.min_vmstat_analysis_swap_so_long = min_max_rec.max_vmstat_analysis_swap_so_long
	THEN 
		speed_corr_swap_so_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		swap_so_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_swap_so_long  AS vmstat_analysis_swap_so_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_swap_so_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_swap_so_long ) , 0 ) AS correlation_value 
		INTO speed_corr_swap_so_long
		FROM
			speed os JOIN swap_so_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- swap_so -- so — swap out (из RAM в swap)
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	IF min_max_rec.min_vmstat_analysis_io_bi_long = min_max_rec.max_vmstat_analysis_io_bi_long
	THEN 
		speed_corr_io_bi_long = 0 ;
	ELSE
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- io_bi -- bi — блоки, считанные с устройств
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		io_bi_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_io_bi_long  AS vmstat_analysis_io_bi_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_io_bi_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_io_bi_long ) , 0 ) AS correlation_value 
		INTO speed_corr_io_bi_long
		FROM
			speed os JOIN io_bi_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
    END IF ;			
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- io_bi -- bi — блоки, считанные с устройств
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- io_bo-- bo — записанные на устройства
	IF min_max_rec.min_vmstat_analysis_io_bo_long = min_max_rec.max_vmstat_analysis_io_bo_long
	THEN 
		speed_corr_io_bo_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		io_bo_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_io_bo_long  AS vmstat_analysis_io_bo_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_io_bo_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_io_bo_long ) , 0 ) AS correlation_value 
		INTO speed_corr_io_bo_long
		FROM
			speed os JOIN io_bo_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- io_bo-- bo — записанные на устройства 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- system_in -- in — прерывания
	IF min_max_rec.min_vmstat_analysis_system_in_long = min_max_rec.max_vmstat_analysis_system_in_long
	THEN 
		speed_corr_system_in_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		system_in_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_in_long  AS vmstat_analysis_system_in_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_in_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_system_in_long ) , 0 ) AS correlation_value 
		INTO speed_corr_system_in_long
		FROM
			speed os JOIN system_in_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- system_in -- in — прерывания
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- system_cs -- cs — переключения контекста
	IF min_max_rec.min_vmstat_analysis_system_cs_long = min_max_rec.max_vmstat_analysis_system_cs_long
	THEN 
		speed_corr_system_cs_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		system_cs_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_cs_long  AS vmstat_analysis_system_cs_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_cs_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_system_cs_long ) , 0 ) AS correlation_value 
		INTO speed_corr_system_cs_long
		FROM
			speed os JOIN system_cs_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- system_cs -- cs — переключения контекста
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_us -- us — user time
	IF min_max_rec.min_vmstat_analysis_cpu_us_long = min_max_rec.max_vmstat_analysis_cpu_us_long
	THEN 
		speed_corr_cpu_us_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		cpu_us_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_us_long  AS vmstat_analysis_cpu_us_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_us_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_cpu_us_long ) , 0 ) AS correlation_value 
		INTO speed_corr_cpu_us_long
		FROM
			speed os JOIN cpu_us_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_us -- us — user time
	----------------------------------------------------------------------------------------------------

    ----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_sy -- sy — system time
	IF min_max_rec.min_vmstat_analysis_cpu_sy_long = min_max_rec.max_vmstat_analysis_cpu_sy_long
	THEN 
		speed_corr_cpu_sy_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		cpu_sy_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_sy_long  AS vmstat_analysis_cpu_sy_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_sy_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_cpu_sy_long ) , 0 ) AS correlation_value 
		INTO speed_corr_cpu_sy_long
		FROM
			speed os JOIN cpu_sy_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_sy -- sy — system time
	----------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------
	IF min_max_rec.min_vmstat_analysis_cpu_id_long = min_max_rec.max_vmstat_analysis_cpu_id_long
	THEN 
		speed_corr_cpu_id_long = 0 ;
	ELSE
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_id -- id — idle
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		cpu_id_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_id_long  AS vmstat_analysis_cpu_id_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_id_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_cpu_id_long ) , 0 ) AS correlation_value 
		INTO speed_corr_cpu_id_long
		FROM
			speed os JOIN cpu_id_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_id -- id — idle
	----------------------------------------------------------------------------------------------------

	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_wa --  wa — ожидание IO
	IF min_max_rec.min_vmstat_analysis_cpu_wa_long = min_max_rec.max_vmstat_analysis_cpu_wa_long
	THEN 
		speed_corr_cpu_wa_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		cpu_wa_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_wa_long  AS vmstat_analysis_cpu_wa_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_wa_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_cpu_wa_long ) , 0 ) AS correlation_value 
		INTO speed_corr_cpu_wa_long
		FROM
			speed os JOIN cpu_wa_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_wa --  wa — ожидание IO
	----------------------------------------------------------------------------------------------------
			
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_st  --  st — stolen (украдено гипервизором)
	IF min_max_rec.min_vmstat_analysis_cpu_wa_long = min_max_rec.max_vmstat_analysis_cpu_wa_long
	THEN 
		speed_corr_cpu_st_long = 0 ;
	ELSE
		WITH 
		speed AS
		(
			SELECT 
				curr_timestamp , op_speed_long  AS op_speed_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND op_speed_long > 0
		) ,
		cpu_st_waitings AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_st_long  AS vmstat_analysis_cpu_st_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_st_long > 0 
		) 
		SELECT COALESCE( corr( op_speed_long , vmstat_analysis_cpu_st_long ) , 0 ) AS correlation_value 
		INTO speed_corr_cpu_st_long
		FROM
			speed os JOIN cpu_st_waitings w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	END IF ;		
	--КОРРЕЛЯЦИЯ СКОРОСТЬ- cpu_st  --  st — stolen (украдено гипервизором)
	----------------------------------------------------------------------------------------------------
--Корреляция со скоростью
----------------------------------------------------------------------------------
    line_count=line_count+1;
	result_str[line_count] = 'CORRELATION COEFFICIENTS FOR SPEED' ; 
	line_count=line_count+1;

	result_str[line_count] = 'SPEED - procs_r процессы в run queue (готовы к выполнению)' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_procs_r_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - procs_b процессы в uninterruptible sleep (обычно ждут IO)' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_procs_b_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - memory_swpd объём свопа ' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_memory_swpd_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - memory_free свободная RAM' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_memory_free_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - memory_buff буферы' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_memory_buff_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - memory_cache кэш ' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_memory_cache_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - swap_si swap in (из swap в RAM)' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_swap_si_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - swap_so swap out (из RAM в swap)' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_swap_so_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - io_bi блоки, считанные с устройств' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_io_bi_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - io_bo записанные на устройства' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_io_bo_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - system_in прерывания' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_system_in_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - system_cs переключения контекста' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_system_cs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - cpu_us user time' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_cpu_us_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - cpu_sy system time ' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_cpu_sy_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - cpu_id idle' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_cpu_id_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - cpu_wa ожидание IO' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
	result_str[line_count] = 'SPEED - cpu_st stolen (украдено гипервизором)' ||'|'|| REPLACE ( TO_CHAR( ROUND( speed_corr_cpu_st_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 
*/

--Пока отключено - неясно как использовать при анализе		
--------------------------------------------------------------------------------------------------------		