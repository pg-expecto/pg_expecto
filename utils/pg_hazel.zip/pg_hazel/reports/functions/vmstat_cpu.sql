----------------------------------------------------------------------------------------------------------------
-- vmstat_cpu.sql
-- version 81.3
-- 


CREATE OR REPLACE FUNCTION vmstat_cpu(  cpu_count integer , start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
	corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

-----------------------------------------------------------------------------------
--Корреляция со скоростью
	speed_corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	speed_corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	speed_corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	speed_corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	speed_corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	speed_corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	speed_corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	speed_corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	speed_corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	speed_corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	speed_corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	speed_corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	speed_corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	speed_corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	speed_corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	speed_corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	speed_corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

--Корреляция со скоростью
-----------------------------------------------------------------------------------


  	
  speed_regr_slope_value DOUBLE PRECISION ; 
  waitings_regr_slope_value DOUBLE PRECISION ; 
  os_stat_vmstat_analysis_rec record ; 
  waitings_min_max_rec record ; 
  speed_min_max_rec record ;   
  
  r_pct DOUBLE PRECISION;
  cs_pct DOUBLE PRECISION;
  sy_pct DOUBLE PRECISION;
  
  corr_cs_in DOUBLE PRECISION ; -- Корреляция cs-in
  corr_cs_us DOUBLE PRECISION ; -- Корреляция cs-us
  corr_cs_sy DOUBLE PRECISION ; -- Корреляция cs-sy
  
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - VMSTAT CPU CHECK LIST ' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'vmstat_cpu.sh' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'CPU' ; 
	line_count=line_count+1;
	result_str[line_count] = cpu_count ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	os_stat_vmstat_analysis cl
	WHERE 
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;

	SELECT 
		MIN( cl.vmstat_analysis_procs_r_long) AS min_vmstat_analysis_procs_r_long , MAX( cl.vmstat_analysis_procs_r_long) AS max_vmstat_analysis_procs_r_long , 
		MIN( cl.vmstat_analysis_system_cs_long) AS min_vmstat_analysis_system_cs_long , MAX( cl.vmstat_analysis_system_cs_long) AS max_vmstat_analysis_system_cs_long ,		
		MIN( cl.vmstat_analysis_system_in_long) AS min_vmstat_analysis_system_in_long , MAX( cl.vmstat_analysis_system_in_long) AS max_vmstat_analysis_system_in_long ,
		MIN( cl.vmstat_analysis_cpu_us_long) AS min_vmstat_analysis_cpu_us_long , MAX( cl.vmstat_analysis_cpu_us_long) AS max_vmstat_analysis_cpu_us_long ,
		MIN( cl.vmstat_analysis_cpu_sy_long) AS min_vmstat_analysis_cpu_sy_long , MAX( cl.vmstat_analysis_cpu_sy_long) AS max_vmstat_analysis_cpu_sy_long
	INTO  	min_max_rec
	FROM 
		os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
		
    SELECT 
		MIN( cl_w.waitings_long) AS min_waitings_long , MAX( cl_w.waitings_long) AS max_waitings_long 
	INTO 
		waitings_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_w
	WHERE 	
		cl_w.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;

    SELECT 
		MIN( cl_s.op_speed_long) AS min_speed_long , MAX( cl_s.op_speed_long) AS max_speed_long 
	INTO 
		speed_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_s
	WHERE 	
		cl_s.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	-----------------------------------------------------------------------------
	--r — процессы в run queue (готовы к выполнению)(% превышение CPU)
	WITH 
	  cpu_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_procs_r_long > cpu_count
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		r_pct
	FROM cpu_counter ;

	result_str[line_count] = 'r — процессы в run queue (готовы к выполнению): % превышения ядер CPU | '|| REPLACE ( TO_CHAR( ROUND( r_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF r_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - очередь процессов превышает количество ядер CPU' ; 
		line_count=line_count+1;
	ELSIF r_pct > 25.0 AND r_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - очередь процессов превышает количество ядер CPU' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - очередь процессов превышает количество ядер CPU' ; 
		line_count=line_count+1;
	END IF ;	
	--r — процессы в run queue (готовы к выполнению)(% превышение CPU)
	-----------------------------------------------------------------------------

	
	----------------------------------------------------------------------------
	-- sy — system time(% превышение 30%)
	WITH 
	  sy_counter AS
	  (
		SELECT count(*) AS total_sy_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_cpu_sy_long > 30
	  ) 
	SELECT 
		(total_sy_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		sy_pct
	FROM sy_counter ;

	result_str[line_count] = 'sy — system time: % превышение 30% | '|| REPLACE ( TO_CHAR( ROUND( sy_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF sy_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - доля system time  превышает 30%' ; 
		line_count=line_count+1;
	ELSIF sy_pct > 25.0 AND sy_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - доля system time превышает 30%' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - доля system time превышает 30%' ; 
		line_count=line_count+1;
	END IF ;
	-- sy — system time(% превышение 30%)
	----------------------------------------------------------------------------
	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ system_cs system_in	
	IF min_max_rec.min_vmstat_analysis_system_cs_long != min_max_rec.max_vmstat_analysis_system_cs_long AND 
	   min_max_rec.min_vmstat_analysis_system_in_long != min_max_rec.max_vmstat_analysis_system_in_long
	THEN	
		WITH 
		system_cs_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_cs_long  AS vmstat_analysis_system_cs_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_cs_long > 0 
		) ,
		system_in_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_in_long  AS vmstat_analysis_system_in_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_in_long > 0 
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_system_cs_long , v2.vmstat_analysis_system_in_long ) , 0 ) AS correlation_value 
		INTO corr_cs_in
		FROM
			system_cs_values v1 JOIN system_in_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE 
		corr_cs_in = 0 ;
	END IF;

    result_str[line_count] = 'Корреляция переключений контекста и прерываний(cs - in) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cs_in::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	

	IF corr_cs_in <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cs - in) - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cs_in > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cs - in) - переключения контекста могут быть вызваны прерываниями.' ; 
		line_count=line_count+1;
	ELSIF corr_cs_in > 0.5 AND corr_cs_in <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (cs - in) - переключения контекста могут быть вызваны прерываниями.' ; 
		line_count=line_count+1;
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (cs - in) - переключения контекста могут быть вызваны прерываниями.' ; 
		line_count=line_count+1;
	
	END IF;
	-- КОРРЕЛЯЦИЯ system_cs system_in	
	----------------------------------------------------------------------------

	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ system_cs cpu_us	
	IF min_max_rec.min_vmstat_analysis_system_cs_long != min_max_rec.max_vmstat_analysis_system_cs_long AND 
	   min_max_rec.min_vmstat_analysis_cpu_us_long != min_max_rec.max_vmstat_analysis_cpu_us_long
	THEN 
	WITH 
		system_cs_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_cs_long  AS vmstat_analysis_system_cs_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_cs_long > 0 
		) ,
		cpu_us_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_us_long  AS vmstat_analysis_cpu_us_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_us_long > 0 
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_system_cs_long , v2.vmstat_analysis_cpu_us_long ) , 0 ) AS correlation_value 
		INTO corr_cs_us
		FROM
			system_cs_values v1 JOIN cpu_us_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
		corr_cs_us = 0 ;
	END IF ;

	result_str[line_count] = 'Корреляция переключений контекста и user time(cs - us) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cs_us::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	


	IF corr_cs_us <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cs - us) - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cs_us > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cs - us) - возможно проблема в пользовательском приложении(resource contention).' ; 
		line_count=line_count+1;
	ELSIF corr_cs_us > 0.5 AND corr_cs_us <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (cs - us) - возможно проблема в пользовательском приложении(resource contention).' ; 
		line_count=line_count+1;
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя (cs - us) - возможно проблема в пользовательском приложении(resource contention).' ; 
		line_count=line_count+1;
	
	END IF;
	-- КОРРЕЛЯЦИЯ system_cs cpu_us	
	----------------------------------------------------------------------------

	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ system_cs system_sy
	IF min_max_rec.min_vmstat_analysis_system_cs_long != min_max_rec.max_vmstat_analysis_system_cs_long AND 
	   min_max_rec.min_vmstat_analysis_cpu_sy_long != min_max_rec.max_vmstat_analysis_cpu_sy_long
	THEN 
	WITH 
		system_cs_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_system_cs_long  AS vmstat_analysis_system_cs_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_system_cs_long > 0 
		) ,
		system_sy_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_sy_long  AS vmstat_analysis_cpu_sy_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_sy_long > 0 
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_system_cs_long , v2.vmstat_analysis_cpu_sy_long ) , 0 ) AS correlation_value 
		INTO corr_cs_sy
		FROM
			system_cs_values v1 JOIN system_sy_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE 
		corr_cs_sy = 0 ;
	END IF;
			
	result_str[line_count] = 'Корреляция переключений контекста и system time(cs - sy) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cs_sy::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;		

	IF corr_cs_sy <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cs - sy) - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cs_sy > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cs - sy) - ядро тратит много времени на переключение контекста и планирование, вместо полезной работы.' ; 
		line_count=line_count+1;
	ELSIF corr_cs_sy > 0.5 AND corr_cs_sy <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция(cs - sy) - ядро тратит много времени на переключение контекста и планирование, вместо полезной работы.' ; 
		line_count=line_count+1;
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (cs - sy) - ядро тратит много времени на переключение контекста и планирование, вместо полезной работы.' ; 
		line_count=line_count+1;
	
	END IF;
	-- КОРРЕЛЯЦИЯ system_cs system_sy	
	----------------------------------------------------------------------------
	

	
	
	
	line_count=line_count+1; 
	result_str[line_count] = 	' '||'|'||
								'№'||'|'||									
								'procs_r' ||'|'||
								'system_cs ' ||'|' ||
								'system_in ' ||'|' ||
								'cpu_us ' ||'|' ||
								'cpu_sy ' ||'|'								
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_procs_r_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_system_cs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_system_in_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||								
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_us_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_sy_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_procs_r_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_system_cs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_system_in_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||								
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_us_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_sy_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								
	line_count=line_count+2; 

							
	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;