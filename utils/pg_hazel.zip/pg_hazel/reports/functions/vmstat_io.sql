----------------------------------------------------------------------------------------------------------------
-- vmstat_io.sql
-- version 81.3
-- 


CREATE OR REPLACE FUNCTION vmstat_io( cpu_count integer , start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
	corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

-----------------------------------------------------------------------------------
--Корреляция со скоростью
	speed_corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	speed_corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	speed_corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	speed_corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	speed_corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	speed_corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	speed_corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	speed_corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	speed_corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	speed_corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	speed_corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	speed_corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	speed_corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	speed_corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	speed_corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	speed_corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	speed_corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

--Корреляция со скоростью
-----------------------------------------------------------------------------------


  	
  speed_regr_slope_value DOUBLE PRECISION ; 
  waitings_regr_slope_value DOUBLE PRECISION ; 
  os_stat_vmstat_analysis_rec record ; 
  waitings_min_max_rec record ; 
  speed_min_max_rec record ;   
  
  b_pct DOUBLE PRECISION;
  wa_pct DOUBLE PRECISION;
  
  b_reg_slope DOUBLE PRECISION; -- угол наклона линии регрессии b — процессы в uninterruptible sleep (обычно ждут IO)
  slope DOUBLE PRECISION; -- угол наклона линии регрессии 
  
  b_regr_rec record ;
  
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - VMSTAT IO CHECK LIST ' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'vmstat_io.sh' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'CPU' ; 
	line_count=line_count+1;
	result_str[line_count] = cpu_count ; 
	line_count=line_count+1;
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		cl.curr_timestamp , 
		row_number() over (order by cl.curr_timestamp) AS x
	FROM
	os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)	
	WHERE 
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY cl.curr_timestamp	;

	SELECT 
		MIN( cl.vmstat_analysis_procs_b_long) AS min_vmstat_analysis_procs_b_long , MAX( cl.vmstat_analysis_procs_b_long) AS max_vmstat_analysis_procs_b_long , 
		MIN( cl.vmstat_analysis_cpu_wa_long) AS min_vmstat_analysis_cpu_wa_long , MAX( cl.vmstat_analysis_cpu_wa_long) AS max_vmstat_analysis_cpu_wa_long 
	INTO  	min_max_rec
	FROM 
		os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
		
    SELECT 
		MIN( cl_w.waitings_long) AS min_waitings_long , MAX( cl_w.waitings_long) AS max_waitings_long 
	INTO 
		waitings_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_w
	WHERE 	
		cl_w.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;

    SELECT 
		MIN( cl_s.op_speed_long) AS min_speed_long , MAX( cl_s.op_speed_long) AS max_speed_long 
	INTO 
		speed_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_s
	WHERE 	
		cl_s.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	

	----------------------------------------------------------------------------
	-- wa — ожидание IO
	WITH 
	  wa_counter AS
	  (
		SELECT count(*) AS total_wa_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)			
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_cpu_wa_long > 10
	  ) 
	SELECT 
		(total_wa_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		wa_pct
	FROM wa_counter ;

	result_str[line_count] = 'wa — ожидание IO (% свыше 10%) | '|| REPLACE ( TO_CHAR( ROUND( wa_pct::numeric , 2 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF wa_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - wa > 10%' ; 
		line_count=line_count+1;
	ELSIF wa_pct > 25.0 AND wa_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - wa > 10%' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - wa > 10%' ; 
		line_count=line_count+1;
	END IF ;
	-- wa — ожидание IO
	----------------------------------------------------------------------------
	
	-----------------------------------------------------------------------------
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ b — процессы в uninterruptible sleep (обычно ждут IO)
	-- 	линия регрессии  скорости  : Y = a + bX
	BEGIN
		WITH stats AS 
		(
		  SELECT 
			AVG(t.curr_timepoint::DOUBLE PRECISION) as avg1, 
			STDDEV(t.curr_timepoint::DOUBLE PRECISION) as std1,
			AVG(s.vmstat_analysis_procs_b_long::DOUBLE PRECISION) as avg2, 
			STDDEV(s.vmstat_analysis_procs_b_long::DOUBLE PRECISION) as std2
		  FROM
			os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp )
		  WHERE 
			t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		),
		standardized_data AS 
		(
			SELECT 
				(t.curr_timepoint::DOUBLE PRECISION - avg1) / std1 as x_z,
				(s.vmstat_analysis_procs_b_long::DOUBLE PRECISION - avg2) / std2 as y_z
			FROM
				os_stat_vmstat_analysis s JOIN tmp_timepoints t ON ( s.curr_timestamp  = t.curr_timestamp ) , stats
			WHERE 
				t.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		)	
		SELECT
			REGR_SLOPE(y_z, x_z) as slope, --b
			ATAN(REGR_SLOPE(y_z, x_z)) * 180 / PI() as slope_angle_degrees, --угол наклона
			REGR_R2(y_z, x_z) as r_squared -- Коэффициент детерминации
		INTO 
			b_regr_rec
		FROM standardized_data;
	EXCEPTION
	  --STDDEV(s.op_speed_long::DOUBLE PRECISION) = 0  
	  WHEN division_by_zero THEN  -- Конкретное исключение для деления на ноль
	    SELECT 
			1.0 as slope, --b
			0.0  as slope_angle_degrees, --угол наклона
			0.0  as r_squared -- Коэффициент детерминации
		INTO 
		b_regr_rec ;
	END;
-- 	линия регрессии  скорости  : Y = a + bX

    line_count=line_count+1;
    result_str[line_count] = 'ЛИНИЯ РЕГРЕССИИ: Y = a + bX ' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'b — процессы в uninterruptible sleep (обычно ждут IO)' ; 
	line_count=line_count+1; 
	result_str[line_count] = 'Коэффициент детерминации R^2 ' ||'|'|| REPLACE ( TO_CHAR( ROUND( b_regr_rec.r_squared::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 	
	result_str[line_count] = 'угол наклона  ' ||'|'|| REPLACE ( TO_CHAR( ROUND( b_regr_rec.slope_angle_degrees::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ;
	line_count=line_count+1; 	
	
/*	
	Хотя не существует строгих порогов, часто используют следующую качественную шкалу:

	0.8 ≤ R² ≤ 1.0: Очень сильная объясняющая способность модели.

	0.6 ≤ R² < 0.8: Сильная объясняющая способность.

	0.4 ≤ R² < 0.6: Умеренная объясняющая способность.

	0.2 ≤ R² < 0.4: Слабая объясняющая способность.

	0.0 ≤ R² < 0.2: Объясняющая способность отсутствует или крайне мала.	
*/	
	IF ROUND( b_regr_rec.slope_angle_degrees::numeric , 2 ) = 0 OR ROUND( b_regr_rec.r_squared::numeric , 2 ) < 0.6 
	THEN 
		result_str[line_count] = 'OK: количество процессов в uninterruptible sleep - не возрастает, либо незначительно' ; 
		line_count=line_count+1;
	ELSIF wa_pct < 25.0
	THEN 
		result_str[line_count] = 'WARNING: количество процессов в uninterruptible sleep возрастает, но wa > 10% менее 25% наблюдений.' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'ALARM: количество процессов в uninterruptible sleep возрастает, и wa > 10% более 25% наблюдений.' ; 
		line_count=line_count+1;	
	END IF ;
	line_count=line_count+1; 
	
	-- УГОЛ НАКЛОНА ЛИНИИ НАИМЕНЬШИХ КВАДРАТОВ b — процессы в uninterruptible sleep (обычно ждут IO)
	-----------------------------------------------------------------------------

    -----------------------------------------------------------------------------
	--b — процессы в uninterruptible sleep (обычно ждут IO)(% превышение CPU)
	WITH 
	  cpu_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_procs_b_long > cpu_count
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		b_pct
	FROM cpu_counter ;

	result_str[line_count] = 'b — процессы в uninterruptible sleep (обычно ждут IO): % превышения ядер CPU | '|| REPLACE ( TO_CHAR( ROUND( b_pct::numeric , 2 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF b_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - процессы в uninterruptible sleep превышают количество ядер CPU' ; 
		line_count=line_count+1;
	ELSIF b_pct > 25.0 AND b_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - процессы в uninterruptible sleep превышают количество ядер CPU' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - процессы в uninterruptible sleep превышают количество ядер CPU' ; 
		line_count=line_count+1;
	END IF ;	
	--b — процессы в uninterruptible sleep (обычно ждут IO)(% превышение CPU)
	-----------------------------------------------------------------------------

	
	line_count=line_count+1; 
		

	
	
	line_count=line_count+1;
	result_str[line_count] = 	' '||'|'||
								'№'||'|'||									
								'procs_b' ||'|'||
								'cpu_wa ' ||'|' 
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_procs_b_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;							
	line_count=line_count+1; 
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_procs_b_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								
	line_count=line_count+2; 

							
	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;