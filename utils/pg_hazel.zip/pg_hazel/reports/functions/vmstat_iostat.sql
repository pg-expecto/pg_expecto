----------------------------------------------------------------------------------------------------------------
-- vmstat_iostat.sql
-- version 81.3
-- 

CREATE OR REPLACE FUNCTION vmstat_iostat( start_timestamp text , finish_timestamp text , device_name text  ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
  min_max_pct_rec record ;
  
  corr_wa_util DOUBLE PRECISION ; -- Корреляция 
  
  corr_buff_rps DOUBLE PRECISION ; -- Корреляция 
  corr_buff_wps DOUBLE PRECISION ; -- Корреляция 
  corr_buff_rmbs DOUBLE PRECISION ; -- Корреляция 
  corr_buff_wmbs DOUBLE PRECISION ; -- Корреляция 
  
  corr_cache_rps DOUBLE PRECISION ; -- Корреляция 
  corr_cache_wps DOUBLE PRECISION ; -- Корреляция 
  corr_cache_rmbs DOUBLE PRECISION ; -- Корреляция 
  corr_cache_wmbs DOUBLE PRECISION ; -- Корреляция 
  
  
  
  os_stat_vmstat_iostat_rec record ; 
  
  util_pct DOUBLE PRECISION ; 
  r_await_pct DOUBLE PRECISION ; 
  w_await_pct DOUBLE PRECISION ; 
  aqu_sz_pct  DOUBLE PRECISION ; 
  
  
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - VMSTAT IOSTAT CORRELATION' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'vmstat_iostat.sh' ; 
	line_count=line_count+1;
	
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	result_str[line_count] = 'DEVICE '; 
	line_count=line_count+1;
	result_str[line_count] = device_name ; 
	line_count=line_count+1;
	
	
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		cl.curr_timestamp , 
		row_number() over (order by cl.curr_timestamp) AS x
	FROM
	os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)	
	WHERE 
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY cl.curr_timestamp	;
	
	SELECT 
		MIN( cl.vmstat_analysis_cpu_wa_long) AS min_vmstat_analysis_cpu_wa_long , MAX( cl.vmstat_analysis_cpu_wa_long) AS max_vmstat_analysis_cpu_wa_long , 
		MIN( cl_io.iostat_analysis_dev_util_pct_long) AS min_iostat_analysis_dev_util_pct_long , MAX( cl_io.iostat_analysis_dev_util_pct_long) AS max_iostat_analysis_dev_util_pct_long,
		MIN( cl.vmstat_analysis_memory_buff_long) AS min_vmstat_analysis_memory_buff_long , MAX( cl.vmstat_analysis_memory_buff_long) AS max_vmstat_analysis_memory_buff_long , 
		MIN( cl.vmstat_analysis_memory_cache_long) AS min_vmstat_analysis_memory_cache_long , MAX( cl.vmstat_analysis_memory_cache_long) AS max_vmstat_analysis_memory_cache_long , 
		MIN( cl_io.iostat_analysis_dev_rps_long) AS min_iostat_analysis_dev_rps_long , MAX( cl_io.iostat_analysis_dev_rps_long) AS max_iostat_analysis_dev_rps_long,
		MIN( cl_io.iostat_analysis_dev_rmbs_long) AS min_iostat_analysis_dev_rmbs_long , MAX( cl_io.iostat_analysis_dev_rmbs_long) AS max_iostat_analysis_dev_rmbs_long,
		MIN( cl_io.iostat_analysis_dev_wps_long) AS min_iostat_analysis_dev_wps_long , MAX( cl_io.iostat_analysis_dev_wps_long) AS max_iostat_analysis_dev_wps_long,
		MIN( cl_io.iostat_analysis_dev_wmbps_long) AS min_iostat_analysis_dev_wmbps_long , MAX( cl_io.iostat_analysis_dev_wmbps_long) AS max_iostat_analysis_dev_wmbps_long ,
		MIN( cl_io.iostat_analysis_dev_r_await_long) AS min_iostat_analysis_dev_r_await_long , MAX( cl_io.iostat_analysis_dev_r_await_long) AS max_iostat_analysis_dev_r_await_long ,
		MIN( cl_io.iostat_analysis_dev_w_await_long) AS min_iostat_analysis_dev_w_await_long , MAX( cl_io.iostat_analysis_dev_w_await_long) AS max_iostat_analysis_dev_w_await_long ,
		MIN( cl_io.iostat_analysis_dev_aqu_sz_long) AS min_iostat_analysis_dev_aqu_sz_long , MAX( cl_io.iostat_analysis_dev_aqu_sz_long) AS max_iostat_analysis_dev_aqu_sz_long  		
	INTO  	min_max_rec
	FROM 
		os_stat_vmstat_analysis cl 
		JOIN os_stat_iostat_device_analysis cl_io ON ( cl.curr_timestamp = cl_io.curr_timestamp)
		JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
		AND cl_io.iostat_analysis_device = device_name ;
		
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
		
    line_count=line_count+1; 
	result_str[line_count] = 	' '||'|'||
								'№'||'|'||									
								'cpu_wa ' ||'|' ||
								'device_util ' ||'|'||
                                'memory_buff ' ||'|'||
								'memory_cache ' ||'|'||
								'r/s' ||'|'||
								'rMB/s ' ||'|'||
								'w/s' ||'|'||
								'wMB/s' ||'|'||
								'r_await' ||'|'||
								'w_await' ||'|'||
								'aqu_sz' ||'|'
								;							
	line_count=line_count+1; 
	
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_util_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_buff_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_cache_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_rmbs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_wmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_r_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_w_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_iostat_analysis_dev_aqu_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								
								;							
	line_count=line_count+1; 
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_cpu_wa_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_util_pct_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_buff_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_cache_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_rmbs_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_wmbps_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_r_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_w_await_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_iostat_analysis_dev_aqu_sz_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								
	line_count=line_count+2; 	
	
		
----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ wa util
	IF min_max_rec.min_vmstat_analysis_cpu_wa_long != min_max_rec.max_vmstat_analysis_cpu_wa_long AND 
	   min_max_rec.min_iostat_analysis_dev_util_pct_long != min_max_rec.max_iostat_analysis_dev_util_pct_long
	THEN 
	WITH 
		vmstat_wa_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_cpu_wa_long  AS vmstat_analysis_cpu_wa_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_cpu_wa_long > 0 
		) ,
		iostat_util_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_util_pct_long  AS iostat_analysis_dev_util_pct_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_util_pct_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_cpu_wa_long , v2.iostat_analysis_dev_util_pct_long ) , 0 ) AS correlation_value 
		INTO corr_wa_util
		FROM
			vmstat_wa_values v1 JOIN iostat_util_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
	 corr_wa_util = 0 ;
	END IF;

    result_str[line_count] = 'Корреляция ожидания процессором IO и загруженности диска (wa - util) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_wa_util::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	

	IF corr_wa_util <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (wa - util)  - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_wa_util > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (wa - util)' ; 
		line_count=line_count+1;
		result_str[line_count] = 'процессы не могут работать, потому что ждут диск' ; 
		line_count=line_count+1;
		result_str[line_count] = 'медленный диск, слишком много запросов' ; 
		line_count=line_count+1;
	ELSIF corr_wa_util > 0.5 AND corr_wa_util <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (wa - util)' ; 
		line_count=line_count+1;
        result_str[line_count] = 'процессы не могут работать, потому что ждут диск' ; 
		line_count=line_count+1;
		result_str[line_count] = 'медленный диск, слишком много запросов' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (wa - util)' ; 
		line_count=line_count+1;		
		result_str[line_count] = 'процессы не могут работать, потому что ждут диск' ; 
		line_count=line_count+1;
		result_str[line_count] = 'медленный диск, слишком много запросов' ; 
		line_count=line_count+1;		
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ wa util	
	----------------------------------------------------------------------------	

--------------------------------------------------------------------------------
--БУФЕРИЗОВАННЫЙ ВВОД-ВЫВОД
    ----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ buff_rps
	IF min_max_rec.min_vmstat_analysis_memory_buff_long != min_max_rec.max_vmstat_analysis_memory_buff_long AND 
	   min_max_rec.min_iostat_analysis_dev_rps_long != min_max_rec.max_iostat_analysis_dev_rps_long
	THEN 	
	WITH 
		vmstat_buff_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_buff_long  AS vmstat_analysis_memory_buff_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_buff_long > 0 
		) ,
		iostat_rps_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_rps_long  AS iostat_analysis_dev_rps_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rps_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_buff_long , v2.iostat_analysis_dev_rps_long ) , 0 ) AS correlation_value 
		INTO corr_buff_rps
		FROM
			vmstat_buff_values v1 JOIN iostat_rps_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
		corr_buff_rps = 0 ;
	END IF ;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для буферов и количество операций чтения с диска (buff - r/s) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_buff_rps::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	
	result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	
	

	IF corr_buff_rps <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (buff - r/s)  - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_buff_rps > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (buff - r/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_buff_rps > 0.5 AND corr_buff_rps <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (buff - r/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (buff - r/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ buff_rps	
	----------------------------------------------------------------------------

    ----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ buff_rmbs
	IF min_max_rec.min_vmstat_analysis_memory_buff_long != min_max_rec.max_vmstat_analysis_memory_buff_long AND 
	   min_max_rec.min_iostat_analysis_dev_rmbs_long != min_max_rec.max_iostat_analysis_dev_rmbs_long
	THEN 
	WITH 
		vmstat_buff_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_buff_long  AS vmstat_analysis_memory_buff_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_buff_long > 0 
		) ,
		iostat_rmbs_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_rmbs_long  AS iostat_analysis_dev_rmbs_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rmbs_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_buff_long , v2.iostat_analysis_dev_rmbs_long ) , 0 ) AS correlation_value 
		INTO corr_buff_rmbs
		FROM
			vmstat_buff_values v1 JOIN iostat_rmbs_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
		corr_buff_rmbs = 0 ;
	END IF ;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для буферов  и объём чтения с диска (buff - rMB/s)  | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_buff_rmbs::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	
	result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	

	IF corr_buff_rmbs <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (buff - rMB/s)- отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_buff_rmbs > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (buff - rMB/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_buff_rmbs > 0.5 AND corr_buff_rmbs <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (buff - rMB/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (buff - rMB/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ buff_rmbs	
	----------------------------------------------------------------------------		
	
	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ buff_wps
	IF min_max_rec.min_vmstat_analysis_memory_buff_long != min_max_rec.max_vmstat_analysis_memory_buff_long AND 
	   min_max_rec.min_iostat_analysis_dev_wps_long != min_max_rec.max_iostat_analysis_dev_wps_long
	THEN 
	WITH 
		vmstat_buff_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_buff_long  AS vmstat_analysis_memory_buff_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_buff_long > 0 
		) ,
		iostat_wps_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_wps_long  AS iostat_analysis_dev_wps_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wps_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_buff_long , v2.iostat_analysis_dev_wps_long ) , 0 ) AS correlation_value 
		INTO corr_buff_wps
		FROM
			vmstat_buff_values v1 JOIN iostat_wps_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE 
		corr_buff_wps = 0 ;
	END IF;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для буферов  и количество операций записи на диск (buff - w/s) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_buff_wps::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	
	result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	
	

	IF corr_buff_wps <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (buff - w/s) - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_buff_wps > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (buff - r/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_buff_wps > 0.5 AND corr_buff_wps <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (buff - r/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (buff - r/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ buff_wps	
	----------------------------------------------------------------------------

	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ buff_wmbs
	IF min_max_rec.min_vmstat_analysis_memory_buff_long != min_max_rec.max_vmstat_analysis_memory_buff_long AND 
	   min_max_rec.min_iostat_analysis_dev_wmbps_long != min_max_rec.max_iostat_analysis_dev_wmbps_long
	THEN 
	WITH 
		vmstat_buff_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_buff_long  AS vmstat_analysis_memory_buff_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_buff_long > 0 
		) ,
		iostat_wmbps_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_wmbps_long  AS iostat_analysis_dev_wmbps_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wmbps_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_buff_long , v2.iostat_analysis_dev_wmbps_long ) , 0 ) AS correlation_value 
		INTO corr_buff_wmbs
		FROM
			vmstat_buff_values v1 JOIN iostat_wmbps_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
		corr_buff_wmbs = 0 ;
	END IF ;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для буферов  и объем запись на диск (buff - wMB/s)  | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_buff_wmbs::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;
    result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	

	IF corr_buff_wmbs <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (buff - wMB/s)- отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_buff_wmbs > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (buff - wMB/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_buff_wmbs > 0.5 AND corr_buff_wmbs <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (buff - wMB/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (buff - wMB/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ buff_wps	
	----------------------------------------------------------------------------	
--БУФЕРИЗОВАННЫЙ ВВОД-ВЫВОД
--------------------------------------------------------------------------------
	
	
--------------------------------------------------------------------------------
--КЭШИРОВАНИЕ ВВОД-ВЫВОД

    ----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ cache_rps
	IF min_max_rec.min_vmstat_analysis_memory_cache_long != min_max_rec.max_vmstat_analysis_memory_cache_long AND 
	   min_max_rec.min_iostat_analysis_dev_rps_long != min_max_rec.max_iostat_analysis_dev_rps_long
	THEN 
	WITH 
		vmstat_cache_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_cache_long  AS vmstat_analysis_memory_cache_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_cache_long > 0 
		) ,
		iostat_rps_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_rps_long  AS iostat_analysis_dev_rps_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rps_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_cache_long , v2.iostat_analysis_dev_rps_long ) , 0 ) AS correlation_value 
		INTO corr_cache_rps
		FROM
			vmstat_cache_values v1 JOIN iostat_rps_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
		corr_cache_rps = 0 ; 
	END IF;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для кэширования и количество операций чтения с диска (cache - r/s) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cache_rps::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	
	result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	
	

	IF corr_cache_rps <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cache - r/s)  - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cache_rps > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cache - r/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_cache_rps > 0.5 AND corr_cache_rps <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (cache - r/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (cache - r/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ cache_rps	
	----------------------------------------------------------------------------

    ----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ cache_rmbs
	IF min_max_rec.min_vmstat_analysis_memory_cache_long != min_max_rec.max_vmstat_analysis_memory_cache_long AND 
	   min_max_rec.min_iostat_analysis_dev_rmbs_long != min_max_rec.max_iostat_analysis_dev_rmbs_long
	THEN
	WITH 
		vmstat_cache_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_cache_long  AS vmstat_analysis_memory_cache_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_cache_long > 0 
		) ,
		iostat_rmbs_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_rmbs_long  AS iostat_analysis_dev_rmbs_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_rmbs_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_cache_long , v2.iostat_analysis_dev_rmbs_long ) , 0 ) AS correlation_value 
		INTO corr_cache_rmbs
		FROM
			vmstat_cache_values v1 JOIN iostat_rmbs_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
		corr_cache_rmbs = 0 ;
	END IF;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для кэширования  и объём чтения с диска (cache - rMB/s)  | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cache_rmbs::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	
	result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	

	IF corr_cache_rmbs <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cache - rMB/s)- отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cache_rmbs > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cache - rMB/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_cache_rmbs > 0.5 AND corr_cache_rmbs <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (cache - rMB/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (cache - rMB/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ cache_rmbs	
	----------------------------------------------------------------------------		
	
	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ cache_wps
	IF min_max_rec.min_vmstat_analysis_memory_cache_long != min_max_rec.max_vmstat_analysis_memory_cache_long AND 
	   min_max_rec.min_iostat_analysis_dev_wps_long != min_max_rec.max_iostat_analysis_dev_wps_long
	THEN
	WITH 
		vmstat_cache_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_cache_long  AS vmstat_analysis_memory_cache_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_cache_long > 0 
		) ,
		iostat_wps_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_wps_long  AS iostat_analysis_dev_wps_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wps_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_cache_long , v2.iostat_analysis_dev_wps_long ) , 0 ) AS correlation_value 
		INTO corr_cache_wps
		FROM
			vmstat_cache_values v1 JOIN iostat_wps_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE 
		corr_cache_wps = 0 ;
	END IF;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для кэширования  и количество операций записи на диск (cache - w/s) | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cache_wps::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;	
	result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	
	

	IF corr_cache_wps <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cache - w/s) - отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cache_wps > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cache - r/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_cache_wps > 0.5 AND corr_cache_wps <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (cache - r/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (cache - r/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ cache_wps	
	----------------------------------------------------------------------------

	----------------------------------------------------------------------------
	-- КОРРЕЛЯЦИЯ cache_wmbs
	IF min_max_rec.min_vmstat_analysis_memory_cache_long != min_max_rec.max_vmstat_analysis_memory_cache_long AND 
	   min_max_rec.min_iostat_analysis_dev_wmbps_long != min_max_rec.max_iostat_analysis_dev_wmbps_long
	THEN
	WITH 
		vmstat_cache_values AS
		(
			SELECT 
				cl.curr_timestamp , vmstat_analysis_memory_cache_long  AS vmstat_analysis_memory_cache_long 
			FROM 
				os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND vmstat_analysis_memory_cache_long > 0 
		) ,
		iostat_wmbps_values AS
		(
			SELECT 
				cl.curr_timestamp , iostat_analysis_dev_wmbps_long  AS iostat_analysis_dev_wmbps_long 
			FROM 
				os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
			WHERE				
				cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND iostat_analysis_dev_wmbps_long > 0 
				AND cl.iostat_analysis_device = device_name
		) 
		SELECT COALESCE( corr( v1.vmstat_analysis_memory_cache_long , v2.iostat_analysis_dev_wmbps_long ) , 0 ) AS correlation_value 
		INTO corr_cache_wmbs
		FROM
			vmstat_cache_values v1 JOIN iostat_wmbps_values v2 ON ( v1.curr_timestamp = v2.curr_timestamp ) ;
	ELSE
	 corr_cache_wmbs = 0 ;
	END IF;

    result_str[line_count] = 'Корреляция: объем памяти, используемой для кэширования  и объем запись на диск (cache - wMB/s)  | ' ||
	REPLACE ( TO_CHAR( ROUND( corr_cache_wmbs::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' ); 
	line_count=line_count+1;
    result_str[line_count] = 'Высокое значение - признак не эффективного использование памяти для снижения нагрузки на диск' ; 
	line_count=line_count+1;	

	IF corr_cache_wmbs <= 0 
	THEN 
	    result_str[line_count] = 'OK: Корреляция (cache - wMB/s)- отрицательная или отсутствует' ; 
		line_count=line_count+1;	
	ELSIF corr_cache_wmbs > 0.7 
	THEN 
		result_str[line_count] = 'ALARM : Очень высокая корреляция (cache - wMB/s)' ; 
		line_count=line_count+1;		
	ELSIF corr_cache_wmbs > 0.5 AND corr_cache_wmbs <= 0.7
	THEN 
		result_str[line_count] = 'WARNING : Высокая корреляция (cache - wMB/s)' ; 
		line_count=line_count+1;		
	ELSE
		result_str[line_count] = 'INFO : Слабая или средняя корреляция (cache - wMB/s)' ; 
		line_count=line_count+1;			
	END IF;
	line_count=line_count+1;
	-- КОРРЕЛЯЦИЯ cache_wps	
	----------------------------------------------------------------------------	
--КЭШИРОВАНИЕ ВВОД-ВЫВОД
--------------------------------------------------------------------------------	
	
    -----------------------------------------------------------------------------
	--%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка) свыше 50%.
	WITH 
	  util_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND iostat_analysis_dev_util_pct_long > 50
			AND cl.iostat_analysis_device = device_name
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		util_pct
	FROM util_counter ;

	result_str[line_count] = '%util Процент загрузки устройства свыше 50%| '|| REPLACE ( TO_CHAR( ROUND( util_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF util_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - загрузки устройства свыше 50%' ; 
		line_count=line_count+1;
	ELSIF util_pct > 25.0 AND util_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - загрузки устройства свыше 50%' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - загрузки устройства свыше 50%' ; 
		line_count=line_count+1;
	END IF ;	
	--%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка) свыше 50%.
	-----------------------------------------------------------------------------
	
    -----------------------------------------------------------------------------
	--Среднее время выполнения запросов чтения (включая время в очереди) свыше 5мс.
	WITH 
	  r_await_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND iostat_analysis_dev_r_await_long > 5
			AND cl.iostat_analysis_device = device_name
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		r_await_pct
	FROM r_await_counter ;

    line_count=line_count+1; 
	result_str[line_count] = 'Отклик на чтение свыше 5мс(%наблюдений)| '|| REPLACE ( TO_CHAR( ROUND( r_await_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF r_await_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - Отклик на чтение свыше 5мс' ; 
		line_count=line_count+1;
	ELSIF r_await_pct > 25.0 AND r_await_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - Отклик на чтение свыше 5мс' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - Отклик на чтение свыше 5мс' ; 
		line_count=line_count+1;
	END IF ;	
	--Среднее время выполнения запросов чтения (включая время в очереди) свыше 5мс.
	-----------------------------------------------------------------------------
	
	-----------------------------------------------------------------------------
	--w_await (мс) Среднее время выполнения запросов записи  свыше 5мс.
	WITH 
	  w_await_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND iostat_analysis_dev_w_await_long > 5
			AND cl.iostat_analysis_device = device_name
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		w_await_pct
	FROM w_await_counter ;

	line_count=line_count+1;
	result_str[line_count] = 'Отклик на запись свыше 5мс(%наблюдений)| '|| REPLACE ( TO_CHAR( ROUND( w_await_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF w_await_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - Отклик на запись свыше 5мс' ; 
		line_count=line_count+1;
	ELSIF w_await_pct > 25.0 AND w_await_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - Отклик на запись свыше 5мс' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - Отклик на запись свыше 5мс' ; 
		line_count=line_count+1;
	END IF ;	
	--w_await (мс) Среднее время выполнения запросов записи  свыше 5мс.
	-----------------------------------------------------------------------------
	
	-----------------------------------------------------------------------------
	--aqu_sz Средняя длина очереди запросов (глубина очереди) свыше 1
	WITH 
	  aqu_sz_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_iostat_device_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND iostat_analysis_dev_aqu_sz_long > 1
			AND cl.iostat_analysis_device = device_name
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		aqu_sz_pct
	FROM aqu_sz_counter ;

	line_count=line_count+1;
	result_str[line_count] = 'Средняя длина очереди запросов (глубина очереди) свыше 1 (%наблюдений) | '|| REPLACE ( TO_CHAR( ROUND( aqu_sz_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;

	IF aqu_sz_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - глубина очереди свыше 1' ; 
		line_count=line_count+1;
	ELSIF aqu_sz_pct > 25.0 AND aqu_sz_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - глубина очереди свыше 1' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - глубина очереди) свыше 1' ; 
		line_count=line_count+1;
	END IF ;	
	--aqu_sz Средняя длина очереди запросов (глубина очереди).
	-----------------------------------------------------------------------------



  return result_str ; 
END
$$ LANGUAGE plpgsql  ;