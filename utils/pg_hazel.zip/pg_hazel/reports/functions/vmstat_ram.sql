----------------------------------------------------------------------------------------------------------------
-- ПРОИЗВОДИТЕЛЬНОСТЬ И ОЖИДАНИЯ НА УРОВНЕ КЛАСТЕРА
-- vmstat_ram.sql
-- version 81.3
-- 


CREATE OR REPLACE FUNCTION vmstat_ram(  ram_all integer , start_timestamp text , finish_timestamp text   ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ; 
 
 counter integer ; 
 min_max_rec record ;
 line_counter integer ; 
 
 
  
  min_max_pct_rec record ;
 
  pgh_stat_cluster_analysis_rec record ; 	
  current_test_queryid bigint ;
  
  active_speed_correlation DOUBLE PRECISION;
  speed_waitings_correlation DOUBLE PRECISION;
  
	corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

-----------------------------------------------------------------------------------
--Корреляция со скоростью
	speed_corr_procs_r_long DOUBLE PRECISION ; -- r — процессы в run queue (готовы к выполнению)
	speed_corr_procs_b_long DOUBLE PRECISION ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	speed_corr_memory_swpd_long DOUBLE PRECISION ; -- swpd — объём свопа
	speed_corr_memory_free_long DOUBLE PRECISION ; -- free — свободная RAM
	speed_corr_memory_buff_long DOUBLE PRECISION ; -- buff — буферы
	speed_corr_memory_cache_long DOUBLE PRECISION ;-- cache — кэш
	
	speed_corr_swap_si_long DOUBLE PRECISION ; -- si — swap in (из swap в RAM)
	speed_corr_swap_so_long DOUBLE PRECISION ; -- so — swap out (из RAM в swap)
	
	speed_corr_io_bi_long DOUBLE PRECISION ; -- bi — блоки, считанные с устройств
	speed_corr_io_bo_long DOUBLE PRECISION ; -- bo — записанные на устройства 
	
	speed_corr_system_in_long DOUBLE PRECISION ; -- in — прерывания
	speed_corr_system_cs_long DOUBLE PRECISION ; -- cs — переключения контекста
	
	speed_corr_cpu_us_long DOUBLE PRECISION ; -- us — user time
	speed_corr_cpu_sy_long DOUBLE PRECISION ; -- sy — system time
	speed_corr_cpu_id_long DOUBLE PRECISION ; -- id — idle
	speed_corr_cpu_wa_long DOUBLE PRECISION ; --  wa — ожидание IO
	speed_corr_cpu_st_long DOUBLE PRECISION ;	  --  st — stolen (украдено гипервизором)

--Корреляция со скоростью
-----------------------------------------------------------------------------------


  	
  speed_regr_slope_value DOUBLE PRECISION ; 
  waitings_regr_slope_value DOUBLE PRECISION ; 
  os_stat_vmstat_analysis_rec record ; 
  waitings_min_max_rec record ; 
  speed_min_max_rec record ; 
  
  free_pct DOUBLE PRECISION;
  si_pct DOUBLE PRECISION;
  so_pct DOUBLE PRECISION;
BEGIN
	line_count = 1 ;
	
	
	
	
	IF finish_timestamp = 'CURRENT_TIMESTAMP'
	THEN 
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 

		min_timestamp = max_timestamp - interval '1 hour'; 	
	ELSE
		SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	min_timestamp ; 
		
		SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
		INTO 	max_timestamp ; 
	END IF ;


	
	result_str[line_count] = 'OS STAT - vmstat_ram' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'vmstat_ram.sh' ; 
	line_count=line_count+1;
	
	result_str[line_count] = 'RAM (MB)| '||ram_all;
	line_count=line_count+1;
	
	result_str[line_count] = min_timestamp ;
	line_count=line_count+1; 
	result_str[line_count] = max_timestamp ;
	line_count=line_count+1; 
	
	result_str[line_count] = ' ' ; 
	line_count=line_count+2; 
	
	
	
	DROP TABLE IF EXISTS tmp_timepoints;
	CREATE TEMPORARY TABLE tmp_timepoints
	(
		curr_timestamp timestamptz  ,   
		curr_timepoint integer 
	);


	INSERT INTO tmp_timepoints
	(
		curr_timestamp ,	
		curr_timepoint 
	)
	SELECT 
		curr_timestamp , 
		row_number() over (order by curr_timestamp) AS x
	FROM
	os_stat_vmstat_analysis cl
	WHERE 
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp  
	ORDER BY curr_timestamp	;

	SELECT 
		MIN( cl.vmstat_analysis_memory_free_long) AS min_vmstat_analysis_memory_free_long, MAX( cl.vmstat_analysis_memory_free_long) AS max_vmstat_analysis_memory_free_long , 
		MIN( cl.vmstat_analysis_swap_si_long) AS min_vmstat_analysis_swap_si_long , MAX( cl.vmstat_analysis_swap_si_long) AS max_vmstat_analysis_swap_si_long , 
		MIN( cl.vmstat_analysis_swap_so_long) AS min_vmstat_analysis_swap_so_long , MAX( cl.vmstat_analysis_swap_so_long) AS max_vmstat_analysis_swap_so_long 		
	INTO  	min_max_rec
	FROM 
		os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 	;
		
	SELECT 
		MIN( cl_w.waitings_long) AS min_waitings_long , MAX( cl_w.waitings_long) AS max_waitings_long 
	INTO 
		waitings_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_w
	WHERE 	
		cl_w.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;

    SELECT 
		MIN( cl_s.op_speed_long) AS min_speed_long , MAX( cl_s.op_speed_long) AS max_speed_long 
	INTO 
		speed_min_max_rec
	FROM 
		pgh_stat_cluster_analysis cl_s
	WHERE 	
		cl_s.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
		
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;	
		
	-----------------------------------------------------------------------------
	--free — свободная RAM менее 5%
	WITH 
	  free_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_memory_free_long::numeric < ( ram_all::numeric * 0.05::numeric )
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		free_pct
	FROM free_counter ;

	result_str[line_count] = 'free — свободная RAM  (% менее 5%) | '|| REPLACE ( TO_CHAR( ROUND( free_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF free_pct < 25.0 
	THEN 
		result_str[line_count] = 'OK: менее 25% наблюдений - свободная RAM менее 5%' ; 
		line_count=line_count+1;
	ELSIF free_pct > 25.0 AND free_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - свободная RAM менее 5%' ; 
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM: более 50% наблюдений - свободная RAM менее 5%' ; 
		line_count=line_count+1;
	END IF ;	
	--free — свободная RAM
	-----------------------------------------------------------------------------	
	
	-----------------------------------------------------------------------------
	--swap_si -- si — swap in (из swap в RAM) > 0 
	WITH 
	  si_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_swap_si_long > 0 
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		si_pct
	FROM si_counter ;

	result_str[line_count] = 'swap in (% наблюдений) | '|| REPLACE ( TO_CHAR( ROUND( si_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF si_pct = 0 
	THEN 
		result_str[line_count] = 'ОК : Свопинг в RAM не используется' ; 
		line_count=line_count+1;	
	ELSIF si_pct < 25.0 
	THEN 
		result_str[line_count] = 'INFO: менее 25% наблюдений - используется cвопинг в RAM' ; 
		line_count=line_count+1;
	ELSIF si_pct > 25.0 AND si_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - используется cвопинг в RAM' ;
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM : более 50% наблюдений - используется cвопинг в RAM' ;
		line_count=line_count+1;
	END IF ;	
	--swap_si -- si — swap in (из swap в RAM) > 0 
	-----------------------------------------------------------------------------
	
	-----------------------------------------------------------------------------
	--so — swap out (из RAM в swap) > 0
	WITH 
	  so_counter AS
	  (
		SELECT count(*) AS total_counter
		FROM 
			os_stat_vmstat_analysis cl JOIN pgh_stat_cluster_analysis cl_w ON ( cl.curr_timestamp = cl_w.curr_timestamp)
		WHERE				
			cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp 
			AND vmstat_analysis_swap_so_long > 0 
	  ) 
	SELECT 
		(total_counter::DOUBLE PRECISION / line_counter::DOUBLE PRECISION)*100.0 
	INTO
		so_pct
	FROM so_counter ;

	result_str[line_count] = 'swap out (% наблюдений) | '|| REPLACE ( TO_CHAR( ROUND( so_pct::numeric , 4 ) , '000000000000D0000' ) , '.' , ',' )  ; 
	line_count=line_count+1;
	
	IF so_pct = 0 
	THEN 
		result_str[line_count] = 'ОК : Свопинг из RAM не используется' ; 
		line_count=line_count+1;	
	ELSIF so_pct < 25.0 
	THEN 
		result_str[line_count] = 'INFO: менее 25% наблюдений - используется cвопинг из RAM' ; 
		line_count=line_count+1;
	ELSIF so_pct > 25.0 AND so_pct <= 50.0
	THEN 
		result_str[line_count] = 'WARNING: 25-50% наблюдений - используется cвопинг из RAM' ;
		line_count=line_count+1;
	ELSE 
		result_str[line_count] = 'ALARM : более 50% наблюдений - используется cвопинг из RAM' ;
		line_count=line_count+1;
	END IF ;	
	--so — swap out (из RAM в swap) > 0
	-----------------------------------------------------------------------------
		


	line_count=line_count+1;
	result_str[line_count] = 	' '||'|'||
								'№'||'|'||									
								'memory_free ' ||'|'||								
								'swap_si ' ||'|' ||
								'swap_so ' ||'|' 
								;							
	line_count=line_count+1; 
	
	result_str[line_count] = 	'MIN'||'|'||
								1 ||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_memory_free_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_swap_si_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.min_vmstat_analysis_swap_so_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'								
								;							
	line_count=line_count+1; 
	
	SELECT 
		count(curr_timestamp)
	INTO line_counter
	FROM 
		pgh_stat_cluster_analysis cl
	WHERE 	
		cl.curr_timestamp BETWEEN min_timestamp AND max_timestamp ;
	
	
	result_str[line_count] = 	'MAX'||'|'||
								line_counter||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_memory_free_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_swap_si_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'||
								REPLACE ( TO_CHAR( ROUND( min_max_rec.max_vmstat_analysis_swap_so_long::numeric , 4 ) , '000000000000D0000') , '.' , ',' )||'|'
								;								

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;


