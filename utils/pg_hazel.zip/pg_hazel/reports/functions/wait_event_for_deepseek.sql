----------------------------------------------------------------------------------------------------------------
-- wait_event_for_deepseek.sql
-- version 81.3
-- cd /postgres/scripts/tester/reports/functions
-- psql -d performance_monitoring_db -U performance_monitoring_user -f wait_event_for_deepseek.sql

DROP TABLE IF EXISTS tmp_wait_event_for_deepseek;
CREATE UNLOGGED TABLE tmp_wait_event_for_deepseek
(
	id integer PRIMARY KEY ,
	wait_event_type text  , 
	wait_event text  
);


CREATE OR REPLACE FUNCTION get_min_id_tmp_wait_event_for_deepseek_by_wait_event_type( curr_wait_event_type text ) RETURNS integer AS $$
DECLARE
min_id integer ;
BEGIN
	SELECT MIN(id)
	INTO min_id
	FROM tmp_wait_event_for_deepseek 
	WHERE wait_event_type = curr_wait_event_type; 
	
	IF min_id IS NULL 
	THEN 
	 return 0;
	END IF ;
	
	return min_id ; 
END
$$ LANGUAGE plpgsql  ;

CREATE OR REPLACE FUNCTION get_max_id_tmp_wait_event_for_deepseek_by_wait_event_type( curr_wait_event_type text ) RETURNS integer AS $$
DECLARE
max_id integer ;
BEGIN
	SELECT MAX(id)
	INTO max_id
	FROM tmp_wait_event_for_deepseek 
	WHERE wait_event_type = curr_wait_event_type; 
	
	IF max_id IS NULL 
	THEN 
	 return 0;
	END IF ;
	
	return max_id ; 
END
$$ LANGUAGE plpgsql  ;

CREATE OR REPLACE FUNCTION get_advice_for_id( curr_id integer ) RETURNS text AS $$
DECLARE
html_advice text ;
curr_wait_event text ;
BEGIN
	SELECT wait_event
	INTO curr_wait_event
	FROM tmp_wait_event_for_deepseek
	WHERE id = curr_id; 

	SELECT get_advice_for_wait_event( curr_wait_event )
	INTO html_advice;
	
	return html_advice ; 
END
$$ LANGUAGE plpgsql  ;

CREATE OR REPLACE FUNCTION wait_event_for_deepseek(  start_timestamp text , finish_timestamp text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
 wait_event_queryid_rec record ;
 wait_event_type_rec record ;
 wait_event_rec record ;
 
 
 sql_stats_history_rec record ;  
 
 query_min_timestamp timestamptz ; 
 query_max_timestamp timestamptz ; 
 total_wait_event_count integer ;
 pct_for_80 numeric ;
 
 wait_event_for_deepseek text[];
 wait_event_for_deepseek_count integer ;
 index_for_wait_event integer ;
 
 corr_bufferpin DOUBLE PRECISION ; 
 corr_extension DOUBLE PRECISION ; 
 corr_io DOUBLE PRECISION ; 
 corr_ipc DOUBLE PRECISION ; 
 corr_lock DOUBLE PRECISION ; 
 corr_lwlock DOUBLE PRECISION ; 
 corr_timeout DOUBLE PRECISION ; 
 
 wait_event_type_corr_rec  record ; 
  
 tmp_wait_event_type_corr_index integer ; 
 
BEGIN
	line_count = 1 ;
	
	result_str[line_count] = 'WAIT_EVENT_FOR_DEEPSEEK';	
	line_count=line_count+1;
	
	
	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 
	
	result_str[line_count] = 'min_timestamp';	
	line_count=line_count+1;
	result_str[line_count] = min_timestamp;	
	line_count=line_count+1;
	
	result_str[line_count] = 'max_timestamp';	
	line_count=line_count+1;
	result_str[line_count] = max_timestamp;	
	line_count=line_count+1;
	
	line_count=line_count+1;
	result_str[line_count] = '80% WAIT_EVENT_TYPE/WAIT_EVENT';	
	line_count=line_count+1;	
	
	result_str[line_count] = 'КОРРЕЛЯЦИЯ МЕЖДУ ТИПОМ ОЖИДАНИЯ И ОЖИДАНИЯМИ СУБД';	
	line_count=line_count+1;	
	result_str[line_count] = '0.7 и ВЫШЕ';	
	line_count=line_count+1;	
	
	DROP TABLE IF EXISTS wait_event_type_corr;
	CREATE TEMPORARY TABLE wait_event_type_corr
	(
		wait_event_type text  ,   
		corr_value DOUBLE PRECISION 
	);
	
	TRUNCATE TABLE tmp_wait_event_for_deepseek ; 
	tmp_wait_event_type_corr_index = 0 ; 
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		bufferpin_waitings AS
		(
			SELECT 
				curr_timestamp , bufferpin_long  AS bufferpin_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND bufferpin_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , bufferpin_long ) , 0 ) AS correlation_value 
		INTO corr_bufferpin
		FROM
			waitings os JOIN bufferpin_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			
		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'BufferPin' , corr_bufferpin );
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - bufferpin 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		extension_waitings AS
		(
			SELECT 
				curr_timestamp , extension_long  AS extension_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND extension_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , extension_long ) , 0 ) AS correlation_value 
		INTO corr_extension
		FROM
			waitings os JOIN extension_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		
		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'Extension' , corr_extension );			
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - extension 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		io_waitings AS
		(
			SELECT 
				curr_timestamp , io_long  AS io_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND io_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , io_long ) , 0 ) AS correlation_value 
		INTO corr_io
		FROM
			waitings os JOIN io_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;	
			
		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'IO' , corr_io );			
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - io 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		ipc_waitings AS
		(
			SELECT 
				curr_timestamp , ipc_long  AS ipc_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND ipc_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , ipc_long ) , 0 ) AS correlation_value 
		INTO corr_ipc
		FROM
			waitings os JOIN ipc_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
	
		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'IPC' , corr_ipc );
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - ipc 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp
				AND waitings_long > 0
		) ,
		lock_waitings AS
		(
			SELECT 
				curr_timestamp , lock_long  AS lock_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND lock_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , lock_long ) , 0 ) AS correlation_value 
		INTO corr_lock
		FROM
			waitings os JOIN lock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;

		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'Lock' , corr_lock );			
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lock 
	----------------------------------------------------------------------------------------------------
	
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0				
		) ,
		lwlock_waitings AS
		(
			SELECT 
				curr_timestamp , lwlock_long  AS lwlock_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND lwlock_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , lwlock_long ) , 0 ) AS correlation_value 
		INTO corr_lwlock
		FROM
			waitings os JOIN lwlock_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
			
		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'LWLock' , corr_lwlock );
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - lwlock 
	----------------------------------------------------------------------------------------------------
	
	-- version 60.0
	----------------------------------------------------------------------------------------------------
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - timeout
		WITH 
		waitings AS
		(
			SELECT 
				curr_timestamp , waitings_long  AS waitings_long  
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND waitings_long > 0				
		) ,
		timeout_waitings AS
		(
			SELECT 
				curr_timestamp , timeout_long  AS timeout_long 
			FROM pgh_stat_cluster_analysis
			WHERE				
				curr_timestamp BETWEEN min_timestamp AND max_timestamp 
				AND timeout_long > 0 
		) 
		SELECT COALESCE( corr( waitings_long , timeout_long ) , 0 ) AS correlation_value 
		INTO corr_timeout
		FROM
			waitings os JOIN timeout_waitings  w ON ( os.curr_timestamp = w.curr_timestamp ) ;
		
		INSERT INTO wait_event_type_corr ( wait_event_type , corr_value )
		VALUES ( 'Timeout' , corr_timeout );
	--КОРРЕЛЯЦИЯ ОПЕРАЦИОННАЯ ОЖИДАНИЯ - timeout 
	----------------------------------------------------------------------------------------------------
	
	
	-----------------------------------------------------------------------------
	
	
	FOR wait_event_type_rec IN 
	SELECT 	
		wait_event_type 
	FROM 	
		stat_statement_wait_events_analysis
	WHERE 
		curr_timestamp  BETWEEN min_timestamp AND max_timestamp
	GROUP BY 
		wait_event_type 
	ORDER BY 
		wait_event_type 
	LOOP 
		SELECT *
		INTO wait_event_type_corr_rec
		FROM wait_event_type_corr
		WHERE wait_event_type = wait_event_type_rec.wait_event_type ;
		
		IF wait_event_type_corr_rec.corr_value < 0.7 
		THEN 
			CONTINUE;
		END IF ; 
		
	    line_count=line_count+1;
		result_str[line_count] =' WAIT_EVENT_TYPE = '|| wait_event_type_rec.wait_event_type ||'|';
		line_count=line_count+1;

		
		result_str[line_count] =' WAIT_EVENT  '||'|'||								
								' COUNT '||'|' ||
								' PCT '||'|' 
								;	
		line_count=line_count+1;
		
		pct_for_80 = 0;
		
		FOR wait_event_rec IN 
		SELECT 	
			wait_event , 
			count(*) 
		FROM 	
			stat_statement_wait_events_analysis
		WHERE 
			curr_timestamp  BETWEEN min_timestamp AND max_timestamp
			AND wait_event_type = wait_event_type_rec.wait_event_type 
		GROUP BY 
			wait_event
		ORDER BY 
			2 desc 
		LOOP	
			WITH wait_event_for_deepseek AS
			(
			SELECT 	
				wait_event , 			
				count(*) as counter 
			FROM 	
				stat_statement_wait_events_analysis
			WHERE 
				curr_timestamp  BETWEEN min_timestamp AND max_timestamp
				AND wait_event_type = wait_event_type_rec.wait_event_type
			GROUP BY 				
				wait_event
			)
			SELECT SUM(counter) 
			INTO total_wait_event_count 
			FROM wait_event_for_deepseek ; 
			
			IF pct_for_80 = 0 
			THEN 
				pct_for_80 = (wait_event_rec.count::numeric / total_wait_event_count::numeric *100.0)::numeric ; 
			ELSE
			    pct_for_80 = pct_for_80 + (wait_event_rec.count::numeric / total_wait_event_count::numeric *100.0)::numeric ; 
			END IF;
			
			result_str[line_count] =  wait_event_rec.wait_event  ||'|'||
									  wait_event_rec.count  ||'|'||
									  REPLACE ( TO_CHAR( ROUND( (wait_event_rec.count::numeric / total_wait_event_count::numeric *100.0)::numeric , 2 ) , '000000000000D0000') , '.' , ',' ) ||'|'
									  --||REPLACE ( TO_CHAR( ROUND( pct_for_80 , 2 ) , '000000000000D0000') , '.' , ',' ) ||'|' 
									  ;
			line_count=line_count+1; 
			
			SELECT wait_event_for_deepseek || wait_event_rec.wait_event
			INTO wait_event_for_deepseek ; 
	
			tmp_wait_event_type_corr_index = tmp_wait_event_type_corr_index + 1 ;
			INSERT INTO  tmp_wait_event_for_deepseek 
			( id , wait_event_type , wait_event )
			VALUES 
			( tmp_wait_event_type_corr_index , wait_event_type_rec.wait_event_type , wait_event_rec.wait_event );
			
			IF pct_for_80 > 80.0 
			THEN 
				EXIT;
			END IF;
			
		END LOOP ;		
		--FOR wait_event_rec IN 
	END LOOP;
	--FOR wait_event_type_rec IN 

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

	
	
	
