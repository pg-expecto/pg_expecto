----------------------------------------------------------------------------------------------------------------
-- wait_event_queryid_for_period.sql
-- version 70.1

CREATE OR REPLACE FUNCTION wait_event_queryid_for_period(  start_timestamp text , finish_timestamp text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
 wait_event_queryid_rec record ;
 
 sql_stats_history_rec record ;  
 
 query_min_timestamp timestamptz ; 
 query_max_timestamp timestamptz ; 
 
BEGIN
	line_count = 1 ;
	result_str[line_count] = 'WAIT_EVENT_QUERYID_FOR_PERIOD';	
	line_count=line_count+1;
	

	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 
	
    result_str[line_count] = 'min_timestamp';	
	line_count=line_count+1;
	result_str[line_count] = min_timestamp;	
	line_count=line_count+1;
	
	result_str[line_count] = 'max_timestamp';	
	line_count=line_count+1;
	result_str[line_count] = max_timestamp;	
	line_count=line_count+1;
	
	line_count = 1 ;
	
	result_str[line_count] =' WAIT_EVENT_TYPE  '||'|'|| 
						    ' WAIT_EVENT  '||'|'|| 
							' COUNT '||'|'
							;	
	line_count=line_count+1;
		
	FOR wait_event_queryid_rec IN 
	SELECT 	
		wait_event_type , 
		wait_event , 
		count(*) AS queryid_count
	FROM 	
		stat_statement_wait_events_analysis
	WHERE 
		curr_timestamp  BETWEEN min_timestamp AND max_timestamp 
	GROUP BY 
		wait_event_type , 
		wait_event
	ORDER BY 
		3 DESC
	LOOP 
		result_str[line_count] =wait_event_queryid_rec.wait_event_type  ||'|'||
								wait_event_queryid_rec.wait_event  ||'|'||
								wait_event_queryid_rec.queryid_count  ||'|'
								;							
		line_count=line_count+1; 		
	END LOOP ; 	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

	
	
	
