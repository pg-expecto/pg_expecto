----------------------------------------------------------------------------------------------------------------
-- wait_event_queryid_for_period_stats.sql
-- version 78.1

CREATE OR REPLACE FUNCTION wait_event_queryid_for_period_stats(  start_timestamp text , finish_timestamp text ) RETURNS text[] AS $$
DECLARE
 result_str text[] ;
 line_count integer ;
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;   
 wait_event_queryid_rec record ;
 wait_event_type_rec record ;
 wait_event_rec record ;
 
 
 sql_stats_history_rec record ;  
 
 query_min_timestamp timestamptz ; 
 query_max_timestamp timestamptz ; 
 total_wait_event_count integer ;
 pct_for_80 numeric ;
 
BEGIN
	line_count = 1 ;
	
	result_str[line_count] = 'WAIT_EVENT_QUERYID_FOR_PERIOD_STATS';	
	line_count=line_count+1;
	
	result_str[line_count] = 'Количество wait_evemt_type/wait_event';	
	line_count=line_count+1;
	
	result_str[line_count] = 'по SQL запросу(queryid)';	
	line_count=line_count+1;
	
	result_str[line_count] = 'во всех БД';	
	line_count=line_count+1;
	
	
	SELECT date_trunc( 'minute' , to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    min_timestamp ; 
  
	SELECT date_trunc( 'minute' , to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) )
	INTO    max_timestamp ; 
	
	result_str[line_count] = 'min_timestamp';	
	line_count=line_count+1;
	result_str[line_count] = min_timestamp;	
	line_count=line_count+1;
	
	result_str[line_count] = 'max_timestamp';	
	line_count=line_count+1;
	result_str[line_count] = max_timestamp;	
	line_count=line_count+1;
	
	
	
	line_count=line_count+1;
	result_str[line_count] =' WAIT_EVENT_TYPE  '||'|'|| 
						    ' WAIT_EVENT  '||'|'||
							' QUERYID  '||'|'||
							' COUNT '||'|'
							;	
	line_count=line_count+1;
		
	FOR wait_event_queryid_rec IN 
	SELECT 	
		wait_event_type , 
		wait_event , 
		queryid , 
		count(*) 
	FROM 	
		stat_statement_wait_events_analysis
	WHERE 
		curr_timestamp  BETWEEN min_timestamp AND max_timestamp
	GROUP BY 
		wait_event_type , 
		wait_event, 
		queryid
	ORDER BY 
		wait_event_type , 
		wait_event 
	LOOP 
		result_str[line_count] =wait_event_queryid_rec.wait_event_type  ||'|'||
								wait_event_queryid_rec.wait_event  ||'|'||
								wait_event_queryid_rec.queryid  ||'|'||
								wait_event_queryid_rec.count  ||'|'
								;							
		line_count=line_count+1; 		
	END LOOP ; 	
	
	
	

  return result_str ; 
END
$$ LANGUAGE plpgsql  ;

	
	
	
