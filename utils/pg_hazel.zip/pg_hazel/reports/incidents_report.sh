#!/bin/sh
#incidents_report.sh

script=$(readlink -f $0)
current_path=`dirname $script`


LOG_FILE=$current_path'/incidents_report.log'
ERR_FILE=$current_path'/incidents_report.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  STARTED ' > $LOG_FILE


timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

./clear_report_dir.sh
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : clear_report_dir.sh - ERROR '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : clear_report_dir.sh - ERROR ' >> $LOG_FILE
   exit 200
fi  

if [ $# -eq 0 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST START_TIME MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST START_TIME MUST BE SET ' >> $LOG_FILE
  exit 0
fi 

if [ $# -gt 2 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  ONLY 2 PARAMETERS CAN BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  ONLY 2 PARAMETERS CAN BE SET ' >> $LOG_FILE
  exit 0
fi 

if [ $# -eq 1 ]
then	
  start_timestamp=$1 
  finish_timestamp='CURRENT_TIMESTAMP'
fi

if [ $# -eq 2 ]
then	
  start_timestamp=$1 
  finish_timestamp=$2
fi


echo 'start_timestamp = '$start_timestamp
echo 'finish_timestamp = '$finish_timestamp

REPORT_FILE=$current_path'/_incidents.txt'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' IS PREPARING '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' IS PREPARING ' >> $LOG_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( incidents_report('$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : stat_report_ma_long TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : stat_report_ma_long TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

REPORT_DIR='/tmp/performance_reports/'
chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR>> $LOG_FILE

