################################################################################################################
# ПРОИЗВОДИТЕЛЬНОСТЬ И ОЖИДАНИЯ НА УРОВНЕ ОС - iostat_cpu
#!/bin/sh
# iostat_cpu.sh
# version 61.0
# mkdir /postgres/scripts/tester/reports

script=$(readlink -f $0)
current_path=`dirname $script`


LOG_FILE=$current_path'/iostat_cpu.log'
ERR_FILE=$current_path'/iostat_cpu.err'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")
REPORT_FILE=$current_path'/iostat_cpu.txt'
REPORT_DIR='/tmp/performance_reports/'
rm /tmp/performance_reports/*.txt

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : INFO :  ОТЧЕТ ВРЕМЕННО ОТКЛЮЧЕН '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : INFO :  ОТЧЕТ ВРЕМЕННО ОТКЛЮЧЕН ' >> $LOG_FILE
exit 0

--------------------------------------------------------------------------------------------------------------------------

if [ $# -eq 0 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST START_TIME MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST START_TIME MUST BE SET ' >> $LOG_FILE
  exit 0
fi 

if [ $# -gt 2 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  ONLY 2 PARAMETERS CAN BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  ONLY 2 PARAMETERS CAN BE SET ' >> $LOG_FILE
  exit 0
fi 

if [ $# -eq 1 ]
then	
  start_timestamp=$1 
  finish_timestamp='CURRENT_TIMESTAMP'
fi

if [ $# -eq 2 ]
then	
  start_timestamp=$1 
  finish_timestamp=$2
fi


echo 'start_timestamp = '$start_timestamp
echo 'finish_timestamp = '$finish_timestamp


psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( iostat_cpu('$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : iostat_cpu TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : iostat_cpu TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  ARCHIVING REPORT - STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  ARCHIVING REPORT - STARTED ' >> $LOG_FILE

start_timestamp=${start_timestamp/-} 
start_timestamp=${start_timestamp/-} 
start_timestamp=${start_timestamp/ } 
start_timestamp=${start_timestamp/:} 
echo 'start_timestamp ='$start_timestamp

finish_timestamp=${finish_timestamp/-} 
finish_timestamp=${finish_timestamp/-} 
finish_timestamp=${finish_timestamp/ } 
finish_timestamp=${finish_timestamp/:} 
echo 'finish_timestamp ='$finish_timestamp

  
REPORT_DIR='/tmp/performance_reports/'
ARCHIVE_REPORT_DIR='/tmp/performance_reports_archive/'
ARCHIVE_FILE=$ARCHIVE_REPORT_DIR'iostat_cpu'$start_timestamp'-'$finish_timestamp

cd $ARCHIVE_REPORT_DIR
find $ARCHIVE_FILE'.zip' -delete


zip -1 -r $ARCHIVE_FILE'.zip' $REPORT_DIR
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : WARNING : ZIP - ERROR  '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : WARNING : ZIP - ERROR  ' >> $LOG_FILE
fi  

chmod 777 $ARCHIVE_FILE'.zip'

cd $current_path

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  ARCHIVING REPORT - FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  ARCHIVING REPORT - FINISHED ' >> $LOG_FILE



echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '>> $LOG_FILE
exit 0 

