#!/bin/sh
# performance_report.sh
# version 81.4

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/performance_report.log'
ERR_FILE=$current_path'/performance_report.err'
REPORT_DIR='/tmp/performance_reports/'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")
performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

if [ $# -eq 0 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST 1 PARAMETER MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST 1 PARAMETER MUST BE SET ' > $LOG_FILEexit 0
fi 

start_timestamp=$1 
finish_timestamp=$2
no_sql=$3

if [ $# -eq 1 ]
then
 finish_timestamp=$1
 start_timestamp='HOUR_BEFORE'   
fi 

devices_list=`/postgres/scripts/tester/reports/get_conf_param.sh /postgres/scripts/tester/reports devices_list 2>$ERR_FILE`
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : get_conf_param.sh devices_list - ERROR '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : get_conf_param.sh devices_list - ERROR ' >> $LOG_FILE
   exit 200
fi  
  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list >> $LOG_FILE	
    

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PERFORMANCE REPORT STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PERFORMANCE REPORT STARTED ' > $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : no_sql = '$no_sql
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : no_sql = '$no_sql >> $LOG_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MAKE_SUMMARY - STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MAKE_SUMMARY - STARTED ' >> $LOG_FILE

./clear_report_dir.sh
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : clear_report_dir.sh - ERROR '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : clear_report_dir.sh - ERROR ' >> $LOG_FILE
   exit 200
fi  

./summary.sh "$start_timestamp" "$finish_timestamp" "$devices_list" "$no_sql"

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MAKE_SUMMARY - FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MAKE_SUMMARY - FINISHED ' >> $LOG_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PERFORMANCE REPORT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PERFORMANCE REPORT FINISHED ' >> $LOG_FILE

exit 0 

