#!/bin/sh
#prepare_performance_report.sh
#version 78.1

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/prepare_performance_report.log'
ERR_FILE=$current_path'/prepare_performance_report.err'
REPORT_DIR='/tmp/prepare_performance_reports/'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")
performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

if [ $# -eq 0 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  3 PARAMETERS MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  3 PARAMETERS MUST BE SET ' > $LOG_FILE
  exit 0
fi 

start_timestamp=$1 
finish_timestamp=$2
devices_list=$3

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE PERFORMANCE REPORT STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE PERFORMANCE REPORT STARTED ' > $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - STARTED ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : prepare_stats_for_period '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : prepare_stats_for_period ' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT prepare_stats_for_period('$start_timestamp' , '$finish_timestamp' )" >> $LOG_FILE 2>$ERR_FILE
if [ $? -eq 0 ]
then 
  echo 'OK : PREPARE_STATS_FOR_PERIOD'
  echo 'OK : PREPARE_STATS_FOR_PERIOD'>> $LOG_FILE  
elif [ $? -eq 1 ]
then 
  echo 'ERROR : СНИМКИ PGPRO_PWR НЕ ПОДГОТОВЛЕНЫ. НЕОБХОДИМО МИНИМУМ 2 СНИМКА'
  echo 'ERROR : СНИМКИ PGPRO_PWR НЕ ПОДГОТОВЛЕНЫ. НЕОБХОДИМО МИНИМУМ 2 СНИМКА'>> $LOG_FILE
  exit 100 
else
  echo 'ERROR : prepare_stats_for_period TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : prepare_stats_for_period TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 200
fi

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_stats_for_period '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_stats_for_period ' >> $LOG_FILE
status=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT start_stats_for_period()"`2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : start_stats_for_period TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : start_stats_for_period TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : '$status
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : '$status >> $LOG_FILE


next_timepoint_for_report=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_next_timepoint_for_report()"` 2>$ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : next_timepoint_for_report = '$next_timepoint_for_report
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : next_timepoint_for_report = '$next_timepoint_for_report >> $LOG_FILE
minute_timestamp=$(date "+%M")
while [ "$next_timepoint_for_report" != "FINISH"  ]
do
  next_timepoint_for_report=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_next_timepoint_for_report()"` 2>$ERR_FILE
  
  current_timestamp=$(date "+%M")
  
#echo "minute_timestamp = "$minute_timestamp" current_timestamp = "$current_timestamp
  
  if [ "$minute_timestamp" != "$current_timestamp" ]
  then    
	minute_timestamp=$(date "+%M")
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : next_timepoint_for_report = '$next_timepoint_for_report
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : next_timepoint_for_report = '$next_timepoint_for_report >> $LOG_FILE	
  fi
done

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - FINISHED ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE PERFORMANCE REPORT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE PERFORMANCE REPORT FINISHED ' >> $LOG_FILE

exit 0 

