################################################################################################################
## ИСТОРИЯ СОБЫТИЙ ОЖИДАНИЯ НА УРОВНЕ SQL
#!/bin/sh
# queryid_stat.sh
# version 60.0
# mkdir /postgres/scripts/tester/reports

script=$(readlink -f $0)
current_path=`dirname $script`


LOG_FILE=$current_path'/queryid_stat.log'
ERR_FILE=$current_path'/queryid_stat.err'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")
REPORT_DIR='/tmp/performance_reports/'
rm /tmp/performance_reports/*.txt

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  queryid_stat FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  queryid_stat FINISHED' > $LOG_FILE

if [ $# -eq 0 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST QUERYID AND START_TIME MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST QUERYID AND START_TIME MUST BE SET ' >> $LOG_FILE
  exit 0
fi 

if [ $# -gt 3 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  ONLY 4 PARAMETERS CAN BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  ONLY 4 PARAMETERS CAN BE SET ' >> $LOG_FILE
  exit 0
fi 
	
if [ $# -eq 2 ]
then
 queryid=$1	
 start_timestamp=$2
 finish_timestamp='CURRENT_TIMESTAMP'
fi	

if [ $# -eq 3 ]
then 
 queryid=$1	 
 start_timestamp=$2
 finish_timestamp=$3
fi 


echo 'queryid = '$queryid	
echo 'start_timestamp = '$start_timestamp
echo 'finish_timestamp = '$finish_timestamp
 

#####################################################################################################
## ОЖИДАНИЯ ПО queryid
for wait_event_type in 'BufferPin' 'Extension' 'IO' 'IPC' 'Lock' 'LWLock' 'Timeout'
do 
  REPORT_FILE=$current_path'/queryid_stat.'$queryid'.'$wait_event_type'.txt'
  
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( queryid_stat("$queryid" , '$wait_event_type' , '$start_timestamp' , '$finish_timestamp'))" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
	echo 'ERROR : queryid_stat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : queryid_stat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
  fi

  chmod 777 $REPORT_FILE
  mv $REPORT_FILE $REPORT_DIR

  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
## ОЖИДАНИЯ ПО queryid
#####################################################################################################
done

SQL_TEXT_FILE=$current_path'/queryid_sql_text.'$queryid'.txt'
echo 'SQL' > $SQL_TEXT_FILE 
SQL_QUERY=`psql -d pgpropwr -Aqtc "SELECT get_query_by_id($queryid)" 2>$ERR_FILE`
echo "$SQL_QUERY" >> $SQL_TEXT_FILE  
chmod 777 $SQL_TEXT_FILE
mv $SQL_TEXT_FILE $REPORT_DIR

start_timestamp=${start_timestamp/-} 
start_timestamp=${start_timestamp/-} 
start_timestamp=${start_timestamp/ } 
start_timestamp=${start_timestamp/:} 
echo 'start_timestamp ='$start_timestamp

finish_timestamp=${finish_timestamp/-} 
finish_timestamp=${finish_timestamp/-} 
finish_timestamp=${finish_timestamp/ } 
finish_timestamp=${finish_timestamp/:} 
echo 'finish_timestamp ='$finish_timestamp

ARCHIVE_REPORT_DIR='/tmp/performance_reports_archive/'
ARCHIVE_FILE=$ARCHIVE_REPORT_DIR'queryid_stat.'$queryid'.T'$start_timestamp'-'$finish_timestamp

cd $ARCHIVE_REPORT_DIR
find $ARCHIVE_FILE'.zip' -delete


zip -1 -r $ARCHIVE_FILE'.zip' $REPORT_DIR
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : WARNING : ZIP - ERROR  '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : WARNING : ZIP - ERROR  ' >> $LOG_FILE
fi  

chmod 777 $ARCHIVE_FILE'.zip'

cd $current_path

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  ARCHIVING REPORT - FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  ARCHIVING REPORT - FINISHED ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  queryid_stat FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : incident_to_timepoint :  queryid_stat FINISHED'>> $LOG_FILE

exit 0 

