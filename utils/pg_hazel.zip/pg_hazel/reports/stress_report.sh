#!/bin/sh
####################################################
## ОТЧЕТ ПО ТЕКУЩЕМУ СТРЕСС ТЕСТУ
# stress_report.sh
# version 81.2
#./stress_report.sh 'vdb vdc'


script=$(readlink -f $0)
current_path=`dirname $script`


LOG_FILE=$current_path'/stress_report.log'
ERR_FILE=$current_path'/stress_report.err'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  STARTED ' > $LOG_FILE


timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

./clear_report_dir.sh
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : clear_report_dir.sh - ERROR '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : clear_report_dir.sh - ERROR ' >> $LOG_FILE
   exit 200
fi  

current_test_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_current_test_id()"` 2>$ERR_FILE
echo 'current_test_id = '$current_test_id

start_timestamp=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT TO_CHAR(MIN(p.start_timestamp),'YYYY-MM-DD HH24:MI') FROM   test_statistics_pass p WHERE  p.test_id = $current_test_id AND p.pass_counter >= 6"` 2>$ERR_FILE
echo 'start_timestamp = '$start_timestamp

finish_timestamp=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT TO_CHAR(MAX(p.finish_timestamp),'YYYY-MM-DD HH24:MI') FROM   test_statistics_pass p WHERE  p.test_id = $current_test_id AND p.pass_counter >= 6"` 2>$ERR_FILE
echo 'finish_timestamp = '$finish_timestamp

devices_list=`/postgres/scripts/tester/reports/get_conf_param.sh /postgres/scripts/tester/reports devices_list 2>$ERR_FILE`
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : get_conf_param.sh devices_list - ERROR '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : get_conf_param.sh devices_list - ERROR ' >> $LOG_FILE
   exit 200
fi  
  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list >> $LOG_FILE	

  

if [ "$devices_list" == "" ] 
then 
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : devices_list MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : devices_list MUST BE SET ' >> $LOG_FILE	
  exit 100
fi 


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - STARTED ' >> $LOG_FILE

./prepare_performance_report.sh "$start_timestamp" "$finish_timestamp" "$devices_list"

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - FINISHED ' >> $LOG_FILE

###################################################
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  TEST QUERIES REPORT STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  TEST QUERIES REPORT STARTED ' > $LOG_FILE

/postgres/scripts/tester/reports/testing_queryid_stats.sh

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  TEST QUERIES REPORT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  TEST QUERIES REPORT FINISHED ' > $LOG_FILE
###################################################


scenario=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scenario 2>$ERR_FILE`
if [ $? -ne 0 ]
then
  echo 'ERROR : get_conf_param.sh scenario TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : get_conf_param.sh scenario TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi
  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	



REPORT_FILE=$current_path'/postgres.0.stress_report.txt'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' IS PREPARING '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' IS PREPARING ' >> $LOG_FILE

# Для сценария MIX - отдельный отчет
if [ "$scenario" == "5" ]
then 
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( mix_report())" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
	echo 'ERROR : mix_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : mix_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
  fi
# Для сценария MIX - отдельный отчет
# Для сценария MIXWMT - отдельный отчет
elif [ "$scenario" == "6" ] 
then 
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( mixwmt_report())" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
	echo 'ERROR : mixwmt_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : mixwmt_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
  fi
# Для сценария MIXWMT_WCPU - отдельный отчет
elif [ "$scenario" == "7" ]
then 
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( mixwmt_wcpu_report())" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
	echo 'ERROR : mixwmt_wcpu_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : mixwmt_wcpu_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
  fi
# Для сценария MIXWMT_WCPU - отдельный отчет

# Другие сценарии
else
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( stress_report())" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
	echo 'ERROR : stress_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	echo 'ERROR : stress_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	exit 100
  fi
fi
# Другие сценарии

REPORT_DIR='/tmp/performance_reports/'
chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR>> $LOG_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  SUMMARY STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  SUMMARY STARTED ' >> $LOG_FILE


./summary.sh "$start_timestamp" "$finish_timestamp" "$devices_list" "prepare_performance_report"
if [ $? -ne 0 ]
then
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : summary.sh - ERROR '
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : summary.sh - ERROR ' >> $LOG_FILE
   exit 100
fi  

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  SUMMARY FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  SUMMARY FINISHED ' > $LOG_FILE


exit 0 