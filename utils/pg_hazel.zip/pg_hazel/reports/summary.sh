#!/bin/sh
# Сводный отчет по производительности СУБД 
# summary.sh
# version 81.4

script=$(readlink -f $0)
current_path=`dirname $script`


LOG_FILE=$current_path'/summary.log'
ERR_FILE=$current_path'/summary.err'
REPORT_DIR='/tmp/performance_reports/'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")
performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

if [ $# -eq 0 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST START_TIME MUST BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  AT LEAST START_TIME MUST BE SET ' >> $LOG_FILE
  exit 0
fi 

if [ $# -gt 4 ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  MAX 4 PARAMETERS CAN BE SET '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR :  MAX 4 PARAMETERS CAN BE SET ' >> $LOG_FILE
  exit 0
fi 

start_timestamp=$1 
finish_timestamp=$2
devices_list=$3
prepare_performance_report=$4  

if [ "$start_timestamp" == "HOUR_BEFORE" ]
then 
  start_timestamp=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_hour_before('$finish_timestamp')"` 2>$ERR_FILE  
  if [ $? -ne 0 ]
  then
    echo 'ERROR : get_hour_before TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
    echo 'ERROR : get_hour_before TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
    exit 100
  fi
fi

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SUMMARY REPORT STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SUMMARY REPORT STARTED ' > $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_timestamp = '$start_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : finish_timestamp = '$finish_timestamp >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : devices_list = '$devices_list >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : prepare_performance_report = '$prepare_performance_report
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : prepare_performance_report = '$prepare_performance_report >> $LOG_FILE

report_start=$start_timestamp
report_finish=$finish_timestamp

####################
# TEMPORARY DISABLED 
###################################################################################################################################
## 0. ALERTS REPORT
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT - STARTED'
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT - STARTED ' >> $LOG_FILE
#
#REPORT_FILE=$current_path'/linux.1.alerts_report.txt'
#start_timestamp=$report_start
#finish_timestamp=$report_finish
#
#cpu_count=`nproc --all`
#echo 'cpu_count='$cpu_count
#
#psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( alerts_report($cpu_count , '$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
#if [ $? -ne 0 ]
#then
#  echo 'ERROR : alerts_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
#  echo 'ERROR : alerts_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
#  exit 100
#fi
#
#chmod 777 $REPORT_FILE
#mv $REPORT_FILE $REPORT_DIR
#
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
#
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT - FINISHED '
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT - FINISHED ' >> $LOG_FILE
## 0. ALERTS REPORT
###################################################################################################################################

##################################################################################################################################
## 0. ALERTS REPORT SOURCE 
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT SOURCE - STARTED'
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT SOURCE - STARTED ' >> $LOG_FILE
#
#REPORT_FILE=$current_path'/linux.x.vmstat_src.txt'
#start_timestamp=$report_start
#finish_timestamp=$report_finish
#
#cpu_count=`nproc --all`
#echo 'cpu_count='$cpu_count
#
#psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( alerts_report_src($cpu_count , '$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
#if [ $? -ne 0 ]
#then
#  echo 'ERROR : alerts_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
#  echo 'ERROR : alerts_report TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
#  exit 100
#fi
#
#chmod 777 $REPORT_FILE
#mv $REPORT_FILE $REPORT_DIR
#
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
#
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT SOURCE - FINISHED '
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ALERTS REPORT SOURCE - FINISHED ' >> $LOG_FILE
## 0. ALERTS REPORT SOURCE
##################################################################################################################################
# TEMPORARY DISABLED 
####################



##################################################################################################################################
# 2. OS - VMSTAT CORRELATION
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WAITINGS - VMSTAT CORRELATION STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WAITINGS - VMSTAT CORRELATION STARTED ' >> $LOG_FILE

REPORT_FILE=$current_path'/linux.2.correlations.txt'
start_timestamp=$report_start
finish_timestamp=$report_finish

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( waitings_os_corr('$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : waitings_os_corr TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : waitings_os_corr TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WAITINGS - VMSTAT CORRELATION FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WAITINGS - VMSTAT CORRELATION FINISHED ' >> $LOG_FILE
# 2. OS - VMSTAT CORRELATION
##################################################################################################################################

##################################################################################################################################
# 3.WMSTAT/IOSTAT
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WMSTAT/IOSTAT - STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WMSTAT/IOSTAT - STARETED ' >> $LOG_FILE

start_timestamp=$report_start
finish_timestamp=$report_finish


array=($devices_list)
echo ${array[@]}

let i=0
while :
do  
  device=${array[$i]}
  size=${#device}
	
  if [ "$size" == 0 ];
  then 
   break
  fi 
  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  DEVICE =  '$device
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  DEVICE =  '$device >> $LOG_FILE
  
  REPORT_FILE=$current_path'/linux.3.wmstat_iostat_'$device'.txt'
  
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( vmstat_iostat('$start_timestamp' , '$finish_timestamp' , '$device'))" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
    echo 'ERROR : vmstat_iostat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
    echo 'ERROR : vmstat_iostat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
    exit 100
  fi
  
  chmod 777 $REPORT_FILE
  mv $REPORT_FILE $REPORT_DIR

  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

  let i=i+1
done

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WMSTAT/IOSTAT - FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : WMSTAT/IOSTAT - FINISHED ' >> $LOG_FILE
# 3.WMSTAT/IOSTAT
##################################################################################################################################

##################################################################################################################################
# 4.VMSTAT - IO CHECK
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - IO STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - IO STARTED ' >> $LOG_FILE

REPORT_FILE=$current_path'/linux.4.vmstat_io.txt'
start_timestamp=$report_start
finish_timestamp=$report_finish

cpu_count=`nproc --all`
echo 'cpu_count='$cpu_count


psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( vmstat_io($cpu_count , '$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : vmstat_io TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : vmstat_io TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - IO FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - IO FINISHED ' >> $LOG_FILE

# VMSTAT - IO CHECK
##################################################################################################################################

##################################################################################################################################
# 5.VMSTAT - CPU CHECK
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - CPU STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - CPU STARTED ' >> $LOG_FILE

REPORT_FILE=$current_path'/linux.5.vmstat_cpu.txt'
start_timestamp=$report_start
finish_timestamp=$report_finish

cpu_count=`nproc --all`
echo 'cpu_count='$cpu_count

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( vmstat_cpu($cpu_count , '$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : vmstat_cpu TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : vmstat_cpu TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - CPU FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - CPU FINISHED ' >> $LOG_FILE
# 5.VMSTAT - CPU CHECK
##################################################################################################################################

##################################################################################################################################
# 6.VMSTAT - RAM CHECK
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - RAM STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - RAM STARETED ' >> $LOG_FILE

REPORT_FILE=$current_path'/linux.6.vmstat_ram.txt'
start_timestamp=$report_start
finish_timestamp=$report_finish

ram_all=` free -m | head -2 | tail -1 | awk -F " " '{print $2}'`
echo 'RAM='$ram_all' MB'

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( vmstat_ram($ram_all , '$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : vmstat_ram TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : vmstat_ram TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - RAM FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT - RAM FINISHED ' >> $LOG_FILE
# 6.VMSTAT - RAM CHECK
##################################################################################################################################

##################################################################################################################################
# VMSTAT PERFORMANCE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT STARTED ' >> $LOG_FILE

REPORT_FILE=$current_path'/linux.x.vmstat.txt'
start_timestamp=$report_start
finish_timestamp=$report_finish

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( vmstat('$start_timestamp' , '$finish_timestamp' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : vmstat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : vmstat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : VMSTAT FINISHED ' >> $LOG_FILE
# VMSTAT PERFORMANCE
##################################################################################################################################

##################################################################################################################################
# IOSTAT
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - STARETED ' >> $LOG_FILE

start_timestamp=$report_start
finish_timestamp=$report_finish


array=($devices_list)
echo ${array[@]}

let i=0
while :
do  
  device=${array[$i]}
  size=${#device}
	
  if [ "$size" == 0 ];
  then 
   break
  fi 
  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  DEVICE =  '$device
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  DEVICE =  '$device >> $LOG_FILE
  
  REPORT_FILE=$current_path'/linux.x.iostat_'$device'.txt'
  
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( iostat_device('$start_timestamp' , '$finish_timestamp' , '$device'))" > $REPORT_FILE 2>$ERR_FILE
  if [ $? -ne 0 ]
  then
    echo 'ERROR : iostat_device TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
    echo 'ERROR : iostat_device TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
    exit 100
  fi
  
  chmod 777 $REPORT_FILE
  mv $REPORT_FILE $REPORT_DIR

  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

  let i=i+1
done

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : IOSTAT - FINISHED ' >> $LOG_FILE
# IOSTAT
##################################################################################################################################

##################################################################################################################################
# 1. CLUSTER PERFORMANCE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CLUSTER PERFORMANCE STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CLUSTER PERFORMANCE STARTED ' >> $LOG_FILE

REPORT_FILE=$current_path'/postgres.1.cluster_performance.txt'

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( cluster_performance('$report_start' , '$report_finish' ))" > $REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
  echo 'ERROR : cluster_performance TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
  echo 'ERROR : cluster_performance TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
  exit 100
fi

chmod 777 $REPORT_FILE
mv $REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CLUSTER PERFORMANCE FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CLUSTER PERFORMANCE FINISHED ' >> $LOG_FILE
# CLUSTER PERFORMANCE
##################################################################################################################################



if [ "$prepare_performance_report" == "NO_SQL" ]
then 
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : INFO : NO SQL '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : INFO : NO SQL ' >> $LOG_FILE
  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SUMMARY REPORT FINISHED '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SUMMARY REPORT FINISHED ' >> $LOG_FILE

exit 0 
fi


if [ "$prepare_performance_report" != "prepare_performance_report" ]
then 
 echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - STARTED'
 echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - STARTED ' >> $LOG_FILE

 ./prepare_performance_report.sh "$start_timestamp" "$finish_timestamp" "$devices_list"

 echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - FINISHED'
 echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PREPARE STATS TABLES - FINISHED ' >> $LOG_FILE
else
 echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : prepare_performance_report HAS BEEN DONE '
 echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : prepare_performance_report HAS BEEN DONE  ' >> $LOG_FILE
fi 

############################################
# QUERYID FOR PARETO
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : QUERYID FOR PARETO '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : QUERYID FOR PARETO ' >> $LOG_FILE

start_timestamp=$report_start
finish_timestamp=$report_finish
QUERYID_STATS_REPORT_FILE=$current_path'/postgres.3.queryid.txt'
echo 'QUERYID FOR PARETO' > $QUERYID_STATS_REPORT_FILE
echo $start_timepoint >> $QUERYID_STATS_REPORT_FILE
echo $finish_timepoint >> $QUERYID_STATS_REPORT_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( wait_event_queryid_for_deepseek( '$start_timestamp' , '$finish_timestamp' )) " >>$QUERYID_STATS_REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
 echo 'ERROR : wait_event_queryid_for_deepseek TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
 echo 'ERROR : wait_event_queryid_for_deepseek TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
 exit 100
fi 	

chmod 777 $QUERYID_STATS_REPORT_FILE
mv $QUERYID_STATS_REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$QUERYID_STATS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$QUERYID_STATS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

# WAIT_EVENT_TYPE/WAIT_EVENT FOR PARETO
####################################################################################################################################

############################################
# WAIT_EVENT_TYPE/WAIT_EVENT
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  WAIT_EVENT_TYPE/WAIT_EVENT STATS  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  WAIT_EVENT_TYPE/WAIT_EVENT STATS  ' >> $LOG_FILE

start_timestamp=$report_start
finish_timestamp=$report_finish
WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE=$current_path'/postgres.x.wait_event_queryid.txt'
echo 'WAIT_EVENT_TYPE/WAIT_EVENT STATS' > $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE
echo $start_timepoint >> $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE
echo $finish_timepoint >> $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( wait_event_queryid_for_period_stats( '$start_timestamp' , '$finish_timestamp' )) " >>$WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
 echo 'ERROR : wait_event_queryid_for_period_stats TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
 echo 'ERROR : wait_event_queryid_for_period_stats TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
 exit 100
fi 	

chmod 777 $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE
mv $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

# WAIT_EVENT_TYPE/WAIT_EVENT
####################################################################################################################################

############################################
# WAIT_EVENT_TYPE/WAIT_EVENT FOR PARETO
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  WAIT_EVENT_TYPE/WAIT_EVENT STATS  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  WAIT_EVENT_TYPE/WAIT_EVENT STATS  ' >> $LOG_FILE

start_timestamp=$report_start
finish_timestamp=$report_finish
WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE=$current_path'/postgres.2.wait_event.txt'
echo 'WAIT_EVENT_TYPE/WAIT_EVENT STATS' > $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE
echo $start_timepoint >> $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE
echo $finish_timepoint >> $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( wait_event_for_deepseek( '$start_timestamp' , '$finish_timestamp' )) " >>$WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
 echo 'ERROR : wait_event_for_deepseek TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
 echo 'ERROR : wait_event_for_deepseek TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
 exit 100
fi 	

chmod 777 $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE
mv $WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_TYPE_WAIT_EVENT_STATS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE

# WAIT_EVENT_TYPE/WAIT_EVENT FOR PARETO
####################################################################################################################################

############################################
# СЕМАНТИЧЕСКИЙ АНАЛИЗ ОПТИМИЗАЦИИ WAIT_EVENT
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR WAIT_EVENT STARTED  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR WAIT_EVENT STARTED  ' >> $LOG_FILE
start_timestamp=$report_start
finish_timestamp=$report_finish

PROMPT_FILE=$current_path'/deepseek.1.prompt.txt' 
echo 'Выдели общие части из текста и найти смысловые совпадения. Сформируй краткий итог по необходимым мероприятиям в виде сводной таблицы.' > $PROMPT_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : PROMPT FILE = '$PROMPT_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : PROMPT FILE = '$PROMPT_FILE >> $LOG_FILE
chmod 777 $PROMPT_FILE
mv $PROMPT_FILE $REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$PROMPT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$PROMPT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE		
  
  
for wait_event_type in 'BufferPin' 'Extension' 'IO' 'IPC' 'Lock' 'LWLock' 'Timeout'
do 
echo  'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : '$wait_event_type
echo  'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : '$wait_event_type >> $LOG_FILE

  WAIT_EVENT_ADVICE_FILE=$current_path'/deepseek.1.'$wait_event_type'.txt'
  let min_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_min_id_tmp_wait_event_for_deepseek_by_wait_event_type('$wait_event_type')"` 2>$ERR_FILE
  let max_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_max_id_tmp_wait_event_for_deepseek_by_wait_event_type('$wait_event_type')"` 2>$ERR_FILE
  echo 'min_id = '$min_id
  echo 'min_id = '$min_id >> $LOG_FILE
  echo 'max_id = '$max_id
  echo 'max_id = '$max_id >> $LOG_FILE
  
  if [ $min_id -gt 0 ]
  then   
   
    for ((curr_id=$min_id; curr_id <= $max_id; curr_id++))
    do
      curr_wait_event=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT wait_event FROM tmp_wait_event_for_deepseek WHERE id = $curr_id AND wait_event_type='$wait_event_type'"`
	  echo 'curr_wait_event = '$curr_wait_event
      echo 'curr_wait_event = '$curr_wait_event >> $LOG_FILE
	
      advice_text=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_advice_for_id( $curr_id ) "` 2>$ERR_FILE
	  if [ "$advice_text" == "NEW" ]
	  then 
	    NEW_PROMPT_FILE=$current_path'/deepseek.1.new_prompt.'$curr_wait_event'.txt' 
		echo 'Запрос к нейросети: Как уменьшить количество событий ожидания wait_event= '$curr_wait_event' для СУБД PostgreSQL?' > $NEW_PROMPT_FILE    
		echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : NEW_PROMPT FILE = '$NEW_PROMPT_FILE
        echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : NEW_PROMPT FILE = '$NEW_PROMPT_FILE >> $LOG_FILE
		chmod 777 $NEW_PROMPT_FILE
        mv $NEW_PROMPT_FILE $REPORT_DIR
        echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$NEW_PROMPT_FILE' HAS BEEN MOVED to '$REPORT_DIR
        echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$NEW_PROMPT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE		
	  else 
	   echo $advice_text >> $WAIT_EVENT_ADVICE_FILE
	   echo ' ' >> $WAIT_EVENT_ADVICE_FILE
	  fi 
    done	
	
   chmod 777 $WAIT_EVENT_ADVICE_FILE
   mv $WAIT_EVENT_ADVICE_FILE $REPORT_DIR
  
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_ADVICE_FILE' HAS BEEN MOVED to '$REPORT_DIR
   echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_ADVICE_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE		
  fi
  
done

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR WAIT_EVENT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR WAIT_EVENT FINISHED ' >> $LOG_FILE

# СЕМАНТИЧЕСКИЙ АНАЛИЗ ОПТИМИЗАЦИИ WAIT_EVENT
####################################################################################################################################

############################################
# СЕМАНТИЧЕСКИЙ АНАЛИЗ SQL 
start_timestamp=$report_start
finish_timestamp=$report_finish

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR QUERYID  STARTED  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR QUERYID  STARTED  ' >> $LOG_FILE

PROMPT_FILE=$current_path'/deepseek.2.prompt.sql.txt' 
echo 'Выдели ключевые паттерны SQL запросов , с уточнением - сколько раз встречается паттерн. Сформируй итоговую таблицу - какие паттерны используются для каждого queryid. Выдели ключевые особенности SQL запроса, использующего наибольшее количество паттернов.' > $PROMPT_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : PROMPT FILE = '$PROMPT_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : PROMPT FILE = '$PROMPT_FILE >> $LOG_FILE
chmod 777 $PROMPT_FILE
mv $PROMPT_FILE $REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$PROMPT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$PROMPT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE	


for wait_event_type in 'BufferPin' 'Extension' 'IO' 'IPC' 'Lock' 'LWLock' 'Timeout'
do 
echo  'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : '$wait_event_type
echo  'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : '$wait_event_type >> $LOG_FILE
  
  QUERYID_ADVICE_FILE=$current_path'/deepseek.2.queryid.'$wait_event_type'.txt'
  let min_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_min_id_tmp_queryid_for_deepseek_by_wait_event_type('$wait_event_type')"` 2>$ERR_FILE
  let max_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_max_id_tmp_queryid_for_deepseek_by_wait_event_type('$wait_event_type')"` 2>$ERR_FILE
  echo 'min_id = '$min_id
  echo 'min_id = '$min_id >> $LOG_FILE
  echo 'max_id = '$max_id
  echo 'max_id = '$max_id >> $LOG_FILE
  
  if [ $min_id -gt 0 ]
  then     
     
    for ((curr_id=$min_id; curr_id <= $max_id; curr_id++))
    do
		query_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_queryid_by_id_from_tmp_queryid_for_deepseek("$curr_id")"` 2>$ERR_FILE
        SQL_QUERY=`psql -d pgpropwr -Aqtc "SELECT get_query_by_id($query_id)" 2>$ERR_FILE`
		echo ' ' >> $QUERYID_ADVICE_FILE 
		echo $query_id >> $QUERYID_ADVICE_FILE 
		echo ' ' >> $QUERYID_ADVICE_FILE 
		echo "$SQL_QUERY" >> $QUERYID_ADVICE_FILE 		
    done
	
	chmod 777 $QUERYID_ADVICE_FILE
    mv $QUERYID_ADVICE_FILE $REPORT_DIR

    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$QUERYID_ADVICE_FILE' HAS BEEN MOVED to '$REPORT_DIR
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$QUERYID_ADVICE_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
  fi
done

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR QUERYID  FINISHED  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  ADVICES FOR QUERYID  FINISHED  ' >> $LOG_FILE

# СЕМАНТИЧЕСКИЙ АНАЛИЗ ОПТИМИЗАЦИИ WAIT_EVENT
######################################

############################################
# Список текстов SQL
start_timestamp=$report_start
finish_timestamp=$report_finish

SQL_LIST_REPORT_FILE=$current_path'/postgres.xx.sql_list.txt'
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT sql_list_for_period ('$start_timestamp' , '$finish_timestamp' ) " 2>$ERR_FILE
if [ $? -ne 0 ]
then
 echo 'ERROR : sql_list_for_period '$incident_id' '$wait_event_type' TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
 echo 'ERROR : sql_list_for_period '$incident_id' '$wait_event_type' TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
 exit 100
fi 

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( sql_list_for_report_header (  '$start_timestamp' , '$finish_timestamp' )) " > $SQL_LIST_REPORT_FILE 2>$ERR_FILE
if [ $? -ne 0 ]
then
 echo 'ERROR : sql_list_for_report_header TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
 echo 'ERROR : sql_list_for_report_header TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
 exit 100
fi 

sql_list_for_report_list_size=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT sql_list_for_report_list_size () " 2>$ERR_FILE`
if [ $? -ne 0 ]
then
 echo 'ERROR : sql_list_for_report_list_size TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
 echo 'ERROR : sql_list_for_report_list_size TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
 exit 100
fi 
echo 'OK : sql_list_for_report_list_size = ' $sql_list_for_report_list_size

echo 'SQL COUNTER' >> $SQL_LIST_REPORT_FILE
echo $sql_list_for_report_list_size >> $SQL_LIST_REPORT_FILE
echo ' | '  >> $SQL_LIST_REPORT_FILE
echo 'QUERYID | PGPRO_PWR HEX QUERYID | SQL TEXT '  >> $SQL_LIST_REPORT_FILE
	
# Если есть SQL
if [ "$sql_list_for_report_list_size" != "0" ]
then
	echo $start_timestamp' '$finish_timestamp' SQL queries = '$sql_list_for_report_list_size
	let sql_list_for_report_list_size=sql_list_for_report_list_size-1
	
	let current_id=0 
	query_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT sql_list_for_report_next_by_index (  "$current_id" ) " 2>$ERR_FILE`
	if [ $? -ne 0 ]
	then
	  echo 'ERROR : sql_list_for_report_next_by_index TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
	  echo 'ERROR : sql_list_for_report_next_by_index TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
	  exit 100
	fi	
	
	minute_timestamp=$(date "+%M")
	while [ "$query_id" != "-1" ]
	do
		current_timestamp=$(date "+%M")
		if [ "$minute_timestamp" != "$current_timestamp" ]
		then    
			minute_timestamp=$(date "+%M")
			echo 'OK :' $current_id' / '$sql_list_for_report_list_size
		fi
		
		SQL_QUERY=`psql -d pgpropwr -Aqtc "SELECT get_query_by_id($query_id)" 2>$ERR_FILE`
		PGPRO_PWR_HEX=`psql -d pgpropwr -Aqtc "SELECT to_hex($query_id)" 2>$ERR_FILE`
		echo "$query_id"' | '"$PGPRO_PWR_HEX"' | '"$SQL_QUERY" >> $SQL_LIST_REPORT_FILE  		
		
		let current_id=$current_id+1
		query_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT sql_list_for_report_next_by_index (  "$current_id" ) " 2>$ERR_FILE`
		if [ $? -ne 0 ]
		then
			echo 'ERROR : sql_list_for_report_next_by_index TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
			echo 'ERROR : sql_list_for_report_next_by_index TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
			exit 100
		fi
	done
fi
# Если есть SQL

chmod 777 $SQL_LIST_REPORT_FILE
mv $SQL_LIST_REPORT_FILE $REPORT_DIR

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$SQL_LIST_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$SQL_LIST_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
# Список текстов SQL
######################################


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SUMMARY REPORT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SUMMARY REPORT FINISHED ' >> $LOG_FILE

exit 0 

############################################
#DISABLED
############################################
# QUERYID ПО WAIT_EVENT_TYPE/WAIT_EVENT
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  QUERYID ПО WAIT_EVENT_TYPE/WAIT_EVENT '
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  QUERYID ПО WAIT_EVENT_TYPE/WAIT_EVENT ' >> $LOG_FILE
#
#start_timestamp=$report_start
#finish_timestamp=$report_finish
#WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE=$current_path'/x.wait_event_queryid.txt'
#echo 'QUERYID WAIT_EVENT_TYPE/WAIT_EVENT' > $WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE
#echo $start_timepoint >> $WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE
#echo $finish_timepoint >> $WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE
#
#psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( wait_event_queryid_for_period( '$start_timestamp' , '$finish_timestamp' )) " >>$WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE 2>$ERR_FILE
#if [ $? -ne 0 ]
#then
# echo 'ERROR : wait_event_queryid_for_period TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
# echo 'ERROR : wait_event_queryid_for_period TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
# exit 100
#fi 	
#
#chmod 777 $WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE
#mv $WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE $REPORT_DIR
#
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
#echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$WAIT_EVENT_QUERYID_COUNTS_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
#
# QUERYID ПО WAIT_EVENT_TYPE/WAIT_EVENT
####################################################################################################################################
#DISABLED
############################################