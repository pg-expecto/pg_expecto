#!/bin/sh
# testing_queryid_stats.sh
# version 70.0

script=$(readlink -f $0)
current_path=`dirname $script`


LOG_FILE=$current_path'/test_queries.log'
ERR_FILE=$current_path'/test_queries.err'
REPORT_DIR='/tmp/performance_reports/'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M")


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : TEST_QUERIES REPORT STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : TEST_QUERIES REPORT STARTED ' >> $LOG_FILE

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

current_test_id=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT get_current_test_id()"` 2>$ERR_FILE
echo 'current_test_id = '$current_test_id


scenario_1_queryid=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT scenario_1_queryid FROM test_statistics WHERE test_id = $current_test_id"` 2>$ERR_FILE
echo 'scenario_1_queryid = '$scenario_1_queryid

scenario_2_queryid=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT scenario_2_queryid FROM test_statistics WHERE test_id = $current_test_id"` 2>$ERR_FILE
echo 'scenario_2_queryid = '$scenario_2_queryid

scenario_3_queryid=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT scenario_3_queryid FROM test_statistics WHERE test_id = $current_test_id"` 2>$ERR_FILE
echo 'scenario_3_queryid = '$scenario_3_queryid

scenario_4_queryid=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT scenario_4_queryid FROM test_statistics WHERE test_id = $current_test_id"` 2>$ERR_FILE
echo 'scenario_4_queryid = '$scenario_4_queryid

start_timestamp=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT TO_CHAR(MIN(p.start_timestamp),'YYYY-MM-DD HH24:MI') FROM   test_statistics_pass p WHERE  p.test_id = $current_test_id AND p.pass_counter >= 6"` 2>$ERR_FILE
echo 'start_timestamp = '$start_timestamp

finish_timestamp=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT TO_CHAR(MAX(p.finish_timestamp),'YYYY-MM-DD HH24:MI') FROM   test_statistics_pass p WHERE  p.test_id = $current_test_id AND p.pass_counter >= 6"` 2>$ERR_FILE
echo 'finish_timestamp = '$finish_timestamp

report_start=$start_timestamp
report_finish=$finish_timestamp 



##################################################################################################################################
# 1. SCENARIO-1 REPORT
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SCENARIO-1 REPORT - STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SCENARIO-1 REPORT - STARTED ' >> $LOG_FILE

for ((sc_count=1; sc_count <= 4; sc_count++ )) 
do 
	if [ "$sc_count" == "1" ]
	then 
	  let queryid=scenario_1_queryid
	fi 
	
	if [ "$sc_count" == "2" ]
	then 
	  let queryid=scenario_2_queryid
	fi 
	
	if [ "$sc_count" == "3" ]
	then 
	  let queryid=scenario_3_queryid
	fi 
	
	if [ "$sc_count" == "4" ]
	then 
	  let queryid=scenario_4_queryid
	fi 
	
	
	if [ "$queryid" == "0" ]
	then 
	  break
	fi 
	
	echo "queryid="$queryid

	#REPORT_FILE=$current_path'/scenario.'$sc_count'.txt'
	start_timestamp=$report_start
	finish_timestamp=$report_finish
	#------------------------------------------------------------
		#####################################################################################################
		## ОЖИДАНИЯ ПО queryid
		for wait_event_type in 'BufferPin' 'Extension' 'IO' 'IPC' 'Lock' 'LWLock' 'Timeout'
		do 
		  QUERYID_REPORT_FILE=$current_path'/scenario.'$sc_count'.'$wait_event_type'.txt'
		  
		  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "SELECT unnest( queryid_stat("$queryid" , '$wait_event_type' , '$start_timestamp' , '$finish_timestamp'))" > $QUERYID_REPORT_FILE 2>$ERR_FILE
		  if [ $? -ne 0 ]
		  then
			echo 'ERROR : queryid_stat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE
			echo 'ERROR : queryid_stat TERMINATED WITH ERROR. SEE DETAILS IN '$ERR_FILE >> $LOG_FILE
			exit 100
		  fi

		  chmod 777 $QUERYID_REPORT_FILE
		  mv $QUERYID_REPORT_FILE $REPORT_DIR

		  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$QUERYID_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR
		  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK :  REPORT FILE '$QUERYID_REPORT_FILE' HAS BEEN MOVED to '$REPORT_DIR >> $LOG_FILE
		done  
		## ОЖИДАНИЯ ПО queryid
		#####################################################################################################


		SQL_TEXT_FILE=$current_path'/scenario.'$sc_count'.'$queryid'.txt'
		echo 'SQL' > $SQL_TEXT_FILE 
		SQL_QUERY=`psql -d pgpropwr -Aqtc "SELECT get_query_by_id($queryid)" 2>$ERR_FILE`
		echo "$SQL_QUERY" >> $SQL_TEXT_FILE  
		chmod 777 $SQL_TEXT_FILE
		mv $SQL_TEXT_FILE $REPORT_DIR	
	
	#------------------------------------------------------------

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SCENARIO-'$sc_count' REPORT - FINISHED '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : SCENARIO-'$sc_count' REPORT - FINISHED ' >> $LOG_FILE
	
done



echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : TEST_QUERIES REPORT FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : TEST_QUERIES REPORT FINISHED ' >> $LOG_FILE

exit 0 

