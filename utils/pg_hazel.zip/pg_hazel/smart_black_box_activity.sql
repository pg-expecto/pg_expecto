--smart_black_box_activity.sql
 SELECT 
   pid ,    
   backend_type    ,
   to_char( backend_start  , 'YYYY-MM-DD HH24:MI:SS' ) AS "backend_start" , 
   to_char( xact_start  , 'YYYY-MM-DD HH24:MI:SS' ) AS "xact_start" , 
   to_char( query_start  , 'YYYY-MM-DD HH24:MI:SS' ) AS "query_start" , 
   to_char( state_change  , 'YYYY-MM-DD HH24:MI:SS' ) AS "state_change" , 
   datid , 
   datname , 
   usesysid  ,
   usename   ,
   application_name,
   client_addr     ,
   client_hostname ,
   client_port     ,
   state           , 
   backend_xid     , 
   backend_xmin    ,   
   wait_event_type , 
   wait_event ,     
   blocking_pids ,
   regexp_replace( regexp_replace(regexp_replace( regexp_replace(regexp_replace( regexp_replace(query,'\$\$','##','g') ,'\n+',' ','g'),'\t+',' ','g') ,' +',' ','g') ,';','','g') ,'\$.','%','g')   AS "query"
 FROM
   activity_snapshot;

