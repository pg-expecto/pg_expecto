--smart_black_box_locks.sql
SELECT 
  w_pid AS "waiting pid",
  w_mode AS "waiting mode" , 
  b_pid AS "locking pid",
  b_mode AS "locking mode" , 
  w_locktype AS "Тип объекта",
  w_database AS "База данных",
  w_relation AS "Отношение",
  w_page AS "Страница" ,
  w_tuple AS "Кортеж"  ,
  w_virtualxid AS "virtualxid"   ,
  w_transactionid  AS "transactionid" , 
  w_classid  AS "Системный каталог" , 
  w_objid  AS "Цель в сист.каталоге"  , 
  w_objsubid   "objsubid"  ,
  w_virtualtransaction AS "waiting virtualxid",   
  b_virtualtransaction AS "locking virtualxid",   
  b_fastpath AS "fastpath" 
FROM 
  locks_snapshot;
