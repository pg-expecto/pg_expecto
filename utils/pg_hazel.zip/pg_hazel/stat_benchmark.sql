﻿-- stat_benchmark.sql
-- version 10.0

--Получить queryid
CREATE OR REPLACE FUNCTION benchmark_queryid() RETURNS bigint AS $$
DECLARE 
  current_test_queryid bigint ;
  configuration_rec record ;
  queryid_for_median_rec record ; 
BEGIN

	SELECT * 
	INTO configuration_rec
	FROM configuration ; 
	
	SELECT queryid 
	INTO current_test_queryid
	FROM benchmark_queries 
	WHERE query like 'select pg_hazel%';	

	----------------------------------
	--ОБНОВИТЬ QUERYID ДЛЯ BENCHMARK
	IF configuration_rec.benchmark_queryid IS NULL OR configuration_rec.benchmark_queryid != current_test_queryid
	THEN 
		UPDATE configuration 
		SET benchmark_queryid = current_test_queryid ; 		
		
		DELETE FROM stat_timer_history
		WHERE queryid = configuration_rec.benchmark_queryid ; 
		
		DELETE FROM stat_timer_statistics_short
		WHERE queryid = configuration_rec.benchmark_queryid ; 
		
		DELETE FROM stat_timer_statistics_long
		WHERE queryid = configuration_rec.benchmark_queryid ; 
	END IF ; 
	--ОБНОВИТЬ QUERYID ДЛЯ BENCHMARK
	----------------------------------
	
	return current_test_queryid;
	
END
$$ LANGUAGE plpgsql;



--Сформировать статистику по benchmark
CREATE OR REPLACE FUNCTION benchmark_stats() RETURNS TABLE 
(
  median_time_short DOUBLE PRECISION ,
  median_time_long DOUBLE PRECISION 
)
AS $$
DECLARE 
  current_test_queryid bigint ;
  
  start_timestamp timestamp with time zone ;
  finish_timestamp timestamp with time zone ;
  stats_res integer ;
  configuration_rec record ;
  current_day_for_store integer ;  
  
  benchmark_median_time_short DOUBLE PRECISION ;
  benchmark_median_time_long DOUBLE PRECISION ;
  
  result_str text ;
  
  timepoint timestamp with time zone ;
BEGIN
	SELECT benchmark_queryid()
	INTO current_test_queryid ;

	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP  ) 
	INTO timepoint ; 
	
	SELECT median_duration
	INTO benchmark_median_time_short
	FROM stat_timer_statistics_short
	WHERE queryid = current_test_queryid AND curr_timestamp = timepoint ; 

	SELECT median_duration
	INTO benchmark_median_time_long
	FROM stat_timer_statistics_long
	WHERE queryid = current_test_queryid AND curr_timestamp = timepoint ; 

    DROP TABLE IF EXISTS current_stat_benchmark ; 
	CREATE TEMPORARY TABLE current_stat_benchmark
	(
		current_median_time_short DOUBLE PRECISION ,
		current_median_time_long DOUBLE PRECISION 		
	);
	
	INSERT INTO current_stat_benchmark
	(
		current_median_time_short ,
		current_median_time_long 
	)
	VALUES 
	(
		benchmark_median_time_short , 
		benchmark_median_time_long
	);	

RETURN QUERY
SELECT 
	current_median_time_short ,
	current_median_time_long 
FROM 
	current_stat_benchmark ;
END
$$ LANGUAGE plpgsql;

/*
DROP TABLE IF EXISTS benchmark_table ; 
CREATE UNLOGGED TABLE benchmark_table
(
	id BIGSERIAL ,
	curr_value double precision 
);
ALTER TABLE benchmark_table ADD CONSTRAINT benchmark_table_pk PRIMARY KEY (id);

--Заполнить таблицу bemchmark
CREATE OR REPLACE FUNCTION fill_benchmark_table() RETURNS integer AS $$
BEGIN
	INSERT INTO benchmark_table (curr_value)
	SELECT random()
	FROM generate_series(1, 10000) s;

	return 0; 
END
$$ LANGUAGE plpgsql;



--Тестовый запрос bemchmark
CREATE OR REPLACE FUNCTION do_benchmark() RETURNS integer AS $$
DECLARE 
  counter numeric ;
  max_id bigint ;
  current_id bigint;
  current_value double precision ;
  current_test_queryid bigint ;
  
  start_timestamp timestamp with time zone ;
  finish_timestamp timestamp with time zone ;  
BEGIN
	SELECT clock_timestamp() 
	INTO start_timestamp ;

   WITH even_values AS 
   (
		SELECT row_number() over() AS row_num , ceil(curr_value*1000000)::numeric AS test_value
		FROM benchmark_table
		WHERE id % 2 = 0 
	) ,	odd_values AS 
	(
		SELECT row_number() over() AS row_num , ceil(curr_value*1000000)::numeric AS test_value 
		FROM benchmark_table
		WHERE id % 2 != 0 
	)
	SELECT SUM( gcd( even.test_value , odd.test_value ) )
	INTO counter
	FROM even_values even JOIN odd_values odd ON ( even.row_num = odd.row_num );
RAISE NOTICE 'SUM = %',counter;

	SELECT MAX(id)
	INTO max_id
	FROM benchmark_table ;
RAISE NOTICE 'max_id = %',max_id;

	current_id = ceil( max_id::numeric * random()::numeric) ; 
RAISE NOTICE 'current_id = %',current_id;

	SELECT curr_value 
	INTO current_value
	FROM benchmark_table
	WHERE id = current_id ; 
RAISE NOTICE 'current_value = %',current_value;

	SELECT clock_timestamp()  
	INTO finish_timestamp ;
	
	SELECT benchmark_queryid()
	INTO current_test_queryid ;
	
	IF current_test_queryid = 0  
	THEN 
		RAISE NOTICE ' do_benchmark : WARINIG : queryid = 0 !';
		return 0;
	END IF;

RAISE NOTICE 'current_test_queryid = %',current_test_queryid;

	-- Добавить точку в историю запроса 
	PERFORM stat_timer_add_action ( current_test_queryid , to_char(start_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')  , to_char(finish_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')  );	
	
	return 0; 
END
$$ LANGUAGE plpgsql;
*/

