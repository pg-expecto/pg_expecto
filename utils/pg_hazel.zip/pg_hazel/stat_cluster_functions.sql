﻿-- stat_cluster_functions.sql
-- version 76.1
-- Статистика производительности по кластеру

--Сформировать таблицу показателей CPI и таблицу ожиданий 
CREATE OR REPLACE FUNCTION pgh_stat_cluster() RETURNS TABLE
(
-------------------------------------------------------
-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
  current_operating_speed_short numeric ,
  current_operating_speed_long numeric ,   
-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
--------------------------------------------------
-- ОЖИДАНИЯ  
  current_waiting_events_short numeric ,
  current_waiting_events_long numeric ,  
-- ОЖИДАНИЯ  
--------------------------------------------------
-- WAIT_EVENT_TYPE 
  current_bufferpin_short  numeric,
  current_extension_short  numeric,
  current_io_short  numeric,
  current_ipc_short  numeric,
  current_lock_short  numeric,
  current_lwlock_short numeric,
  current_timeout_short numeric,
	
  current_bufferpin_long  numeric,
  current_extension_long  numeric,
  current_io_long  numeric,
  current_ipc_long  numeric,
  current_lock_long  numeric,
  current_lwlock_long numeric,
  current_timeout_long numeric
 -- WAIT_EVENT_TYPE 
)
AS $$
DECLARE
  current_mean_time numeric ; 
  
  
  current_calls numeric ; 
  current_rows numeric ; 
  current_delta_calls numeric ; 
  current_delta_rows numeric ; 
  prev_stat_cluster_rec record ; 
  current_stat_cluster_rec record ; 
  
  -------------------------------------------
  -- ОПЕРАЦИОННАЯ СКОРОСТЬ
  current_delta_calls_short numeric ; 
  current_delta_rows_short numeric ; 
  current_delta_calls_long numeric ; 
  current_delta_rows_long numeric ;   
  curr_operating_speed_short numeric ;
  curr_operating_speed_long numeric ; 
  -- ОПЕРАЦИОННАЯ СКОРОСТЬ
  -------------------------------------------
  
  
  --------------------------------------------
  -- ОЖИДАНИЯ
  pg_cluster_rec record ; 
  current_wait_stats jsonb ;  
  
  bufferpin_short  numeric ;
  extension_short  numeric ;
  io_short  numeric ;
  ipc_short  numeric ;
  lock_short  numeric ;
  lwlock_short  numeric ;
  timeout_short  numeric ;
  bufferpin_long numeric ;
  extension_long numeric ;
  io_long numeric ;
  ipc_long numeric ;
  lock_long numeric ;
  lwlock_long numeric ;
  timeout_long numeric ;
  
  current_bufferpin  bigint  ;
  current_extension  bigint  ;
  current_io  bigint  ;
  current_ipc  bigint  ;
  current_lock  bigint  ;
  current_lwlock  bigint  ;
  current_timeout  bigint  ;
  
  new_bufferpin  bigint  ;
  new_extension  bigint  ;
  new_io  bigint  ;
  new_ipc  bigint  ;
  new_lock  bigint  ;
  new_lwlock  bigint  ;
  new_timeout  bigint  ;

  current_delta_bufferpin  bigint  ;
  current_delta_extension  bigint  ;
  current_delta_io  bigint  ;
  current_delta_ipc  bigint  ;
  current_delta_lock  bigint  ;
  current_delta_lwlock  bigint    ;
  current_delta_timeout  bigint    ;
  
  curr_waiting_events_short numeric ;
  curr_waiting_events_long numeric ;   
  
  curr_bufferpin_short  bigint  ;
  curr_extension_short  bigint  ;
  curr_io_short  bigint  ;
  curr_ipc_short  bigint  ;
  curr_lock_short  bigint  ;
  curr_lwlock_short  bigint  ;
  curr_timeout_short  bigint  ;

  curr_bufferpin_long  bigint  ;
  curr_extension_long  bigint  ;
  curr_io_long  bigint  ;
  curr_ipc_long  bigint  ;
  curr_lock_long  bigint  ;
  curr_lwlock_long  bigint  ;
  curr_timeout_long  bigint  ;
  
  
  -- ОЖИДАНИЯ
  --------------------------------------------

  --------------------------------------------
  -- КОЭФФИЦИЕНТ ПОЛЕЗНОГО ДЕЙСТВИЯ
  --curr_waiting_ratio_short numeric ;
  --curr_waiting_ratio_long numeric ;
  
  waiting_ratio_short numeric ;
  waiting_ratio_long numeric ;
  
  current_total_exec_time numeric ;  
  current_waitings_time numeric ;
  current_delta_total_exec_time numeric ;
  current_delta_waitings_time numeric ;
  
  current_delta_total_exec_time_short numeric ; 
  current_delta_waitings_time_short numeric ; 
  current_delta_total_exec_time_long numeric ; 
  current_delta_waitings_time_long numeric ;     
  -- КОЭФФИЦИЕНТ ПОЛЕЗНОГО ДЕЙСТВИЯ
  --------------------------------------------
  
  curr_cpi_short numeric ;
  curr_cpi_long numeric ;
  
  benchmark_stats_rec record ;
  current_cpi DOUBLE PRECISION ;
  
  
  current_active_sessions integer ; 
  current_delta_active_session integer ; 

  current_active_short DOUBLE PRECISION ;
  current_active_long DOUBLE PRECISION ;	
  
  current_corr_active_speed_short DOUBLE PRECISION ;
  current_corr_active_speed_long DOUBLE PRECISION ;	
  
  
	current_corr_speed_waitings_short DOUBLE PRECISION ;
	current_corr_speed_bufferpin_short DOUBLE PRECISION ;
	current_corr_speed_extension_short DOUBLE PRECISION ;
	current_corr_speed_io_short DOUBLE PRECISION ;
	current_corr_speed_ipc_short DOUBLE PRECISION ;
	current_corr_speed_lock_short DOUBLE PRECISION ;
	current_corr_speed_lwlock_short DOUBLE PRECISION ;	
	current_corr_speed_timeout_short DOUBLE PRECISION ;	
	current_corr_speed_waitings_long DOUBLE PRECISION ;
	current_corr_speed_bufferpin_long DOUBLE PRECISION ;
	current_corr_speed_extension_long DOUBLE PRECISION ;
	current_corr_speed_io_long DOUBLE PRECISION ;
	current_corr_speed_ipc_long DOUBLE PRECISION ;
	current_corr_speed_lock_long DOUBLE PRECISION ;
	current_corr_speed_lwlock_long DOUBLE PRECISION  ;
	current_corr_speed_timeout_long DOUBLE PRECISION  ;
	
    wait_event_type_rec record ;
    current_wait_event_type_jsonb jsonb;
 
    wait_event_rec record ;
    current_wait_event_jsonb jsonb;
    current_value integer ;
	wait_event_short DOUBLE PRECISION ;
	wait_event_long DOUBLE PRECISION ;
	
	pgh_stat_cluster_wait_events_rec record ;
	
	current_pgh_stat_cluster_wait_events_rec record ;
	prev_pgh_stat_cluster_wait_events_rec record ;

    configuration_rec record ;
	
	min_timestamp timestamptz ; 
	max_timestamp timestamptz ; 
	
	reset_flag BOOLEAN ;
	
	last_pgh_stat_cluster_analysis_rec record ;
    stat_paused_flag BOOLEAN ;
	
	pgpro_pwr_sample_time timestamptz ; 
BEGIN	
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP ) 
	INTO 		max_timestamp ;
	
RAISE NOTICE 'max_timestamp=%',max_timestamp;	

	SELECT is_new_pgpro_pwr_sample_for_cluster( max_timestamp )
	INTO reset_flag ; 
	
	IF reset_flag
	THEN
		RAISE NOTICE ' INFO : NEW_PGPRO_PWR_SAMPLE ';		
	ELSE
		RAISE NOTICE ' INFO : OLD_PGPRO_PWR_SAMPLE '; 			
	END IF ;     


	
    DROP TABLE IF EXISTS current_stat_cluster ; 
	CREATE TEMPORARY TABLE current_stat_cluster
	(
		temp_operating_speed_short numeric ,
		temp_operating_speed_long numeric ,   
		
		temp_waiting_events_short numeric ,
		temp_waiting_events_long numeric ,
		
		temp_bufferpin_short  numeric,
		temp_extension_short  numeric,
		temp_io_short  numeric,
		temp_ipc_short  numeric,
		temp_lock_short  numeric,
		temp_lwlock_short numeric,
		temp_timeout_short numeric,
	
		temp_bufferpin_long  numeric,
		temp_extension_long  numeric,
		temp_io_long  numeric,
		temp_ipc_long  numeric,
		temp_lock_long  numeric,
		temp_lwlock_long numeric, 
		temp_timeout_long numeric
	);


	---------------------------------------------------------------------------------------------------------------------
	-- ЕСЛИ СБОР СТАТИСТИКИ НА ПАУЗЕ - ЗНАЧЕНИЯ СОБИРАЮТСЯ
	SELECT has_stats_paused()
	INTO stat_paused_flag;
	
	IF stat_paused_flag
	THEN 
		RETURN ;
	END IF ; 
	-- ЕСЛИ СБОР СТАТИСТИКИ НА ПАУЗЕ - ЗНАЧЕНИЯ СОБИРАЮТСЯ
	---------------------------------------------------------------------------------------------------------------------
	
		
RAISE NOTICE '-- ТЕКУЩИЕ ЗНАЧЕНИЯ';	
-------------------------------------------------------------------------------------------------------------------------
-- ТЕКУЩИЕ ЗНАЧЕНИЯ
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ
	SELECT SUM ( queries_executed )
	INTO current_calls
	FROM pgpro_stats_totals  
	WHERE object_type = 'database' AND object_name NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) ;

	---------------------------------------------
	-- Если нет активности по пользовательским БД
	IF current_calls = 0 
	THEN 
		RETURN;
	END IF ;
	-- Если нет активности по пользовательским БД
	---------------------------------------------

	SELECT SUM ( rows )
	INTO current_rows
	FROM pgpro_stats_totals  
	WHERE object_type = 'database' AND object_name NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) ;
	IF current_rows IS NULL THEN current_rows = 0 ; END IF ;
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ
	---------------------------------------------------------------

-- RAISE NOTICE 'current_calls = % , current_rows = % ',current_calls , current_rows ;

	

		
	---------------------------------------------------------------
	-- ОЖИДАНИЯ	
	current_bufferpin = 0 ;
	current_extension = 0 ;
	current_io = 0 ;
	current_ipc = 0 ; 
	current_lock = 0 ;
	current_lwlock = 0 ;
	current_timeout = 0 ;
	
	FOR current_wait_stats IN 
	SELECT wait_stats 
	FROM pgpro_stats_totals
	WHERE object_type = 'database' AND object_name NOT IN ('postgres' , 'template1' , 'template0' , 'pgpropwr' , 'performance_monitoring_db' ) 
	LOOP
		SELECT to_number( ((current_wait_stats)->'Total')->>'BufferPin' , '0000000000') / 10  
		INTO new_bufferpin  ;
		IF new_bufferpin IS NULL THEN new_bufferpin = 0 ; END IF ;
	
		SELECT to_number( ((current_wait_stats)->'Total')->>'Extension' , '0000000000') / 10  
		INTO new_extension  ;
		IF new_extension IS NULL THEN new_extension = 0 ; END IF ;
	
		SELECT to_number( ((current_wait_stats)->'Total')->>'IO' , '0000000000')  / 10 
		INTO new_io  ;
		IF new_io IS NULL THEN new_io = 0 ; END IF ;
	
		SELECT to_number( ((current_wait_stats)->'Total')->>'IPC' , '0000000000')  / 10 
		INTO new_ipc  ;
		IF new_ipc IS NULL THEN new_ipc = 0 ; END IF ;
	
		SELECT to_number( ((current_wait_stats)->'Total')->>'Lock' , '0000000000')  / 10 
		INTO new_lock  ;
		IF new_lock IS NULL THEN new_lock = 0 ; END IF ;
	
		SELECT to_number( ((current_wait_stats)->'Total')->>'LWLock' , '0000000000')  / 10 
		INTO new_lwlock  ;
		IF new_lwlock IS NULL THEN new_lwlock = 0 ; END IF ;

		SELECT to_number( ((current_wait_stats)->'Total')->>'Timeout' , '0000000000')  / 10 
		INTO new_timeout  ;
		IF new_timeout IS NULL THEN new_timeout = 0 ; END IF ;


		current_bufferpin = current_bufferpin + new_bufferpin ;
		current_extension = current_extension + new_extension ;
		current_io = current_io +  new_io ;
		current_ipc = current_ipc + new_ipc ; 
		current_lock = current_lock + new_lock ;
		current_lwlock = current_lwlock + new_lwlock ;	
		current_timeout = current_timeout + new_timeout ;	
	END LOOP;



	INSERT INTO pgh_stat_cluster
	(
		curr_timestamp  , 
		curr_calls ,
		curr_rows ,
		curr_bufferpin  ,
		curr_extension  ,
		curr_io  ,
		curr_ipc  ,
		curr_lock  ,
		curr_lwlock ,
		curr_timeout
	)
	VALUES 
	( 
		max_timestamp , 
		current_calls , 
		current_rows , 
		current_bufferpin  ,
		current_extension  ,
		current_io    ,
		current_ipc   ,
		current_lock  ,
		current_lwlock ,
		current_timeout 
	);		
-- ТЕКУЩИЕ ЗНАЧЕНИЯ	
-------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------
-- ПРИРАЩЕНИЕ ЗНАЧЕНИЯ   
	
	SELECT 	*
	INTO 	current_stat_cluster_rec
	FROM  pgh_stat_cluster
	WHERE 	id = ( SELECT MAX (id) FROM pgh_stat_cluster );	
	
	SELECT 	*
	INTO 	prev_stat_cluster_rec
	FROM  pgh_stat_cluster
	ORDER BY id DESC 
	LIMIT 1 
	OFFSET 1;

	--------------------------------------
	-- ЕСЛИ БЫЛ СБРОС СТАТИСТИКИ 
	-- ИЛИ ПЕРВОЕ ЗНАЧЕНИЕ 	
	IF reset_flag = TRUE OR prev_stat_cluster_rec.curr_calls IS NULL 
	THEN 
		current_delta_calls = current_stat_cluster_rec.curr_calls; 
	    current_delta_rows =  current_stat_cluster_rec.curr_rows ; 
		
		current_delta_bufferpin   = current_stat_cluster_rec.curr_bufferpin ; 
		current_delta_extension   = current_stat_cluster_rec.curr_extension ; 
		current_delta_io   = current_stat_cluster_rec.curr_io ;
		current_delta_ipc   = current_stat_cluster_rec.curr_ipc ; 
		current_delta_lock   = current_stat_cluster_rec.curr_lock ; 
		current_delta_lwlock   = current_stat_cluster_rec.curr_lwlock ;
		current_delta_timeout   = current_stat_cluster_rec.curr_timeout ;
		
	END IF ;
	-- ЕСЛИ БЫЛ СБРОС СТАТИСТИКИ 
	-- ИЛИ ПЕРВОЕ ЗНАЧЕНИЕ 	
	--------------------------------------
	
	--------------------------------------
	-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ 	
	IF reset_flag = FALSE
	THEN 
		current_delta_calls = current_stat_cluster_rec.curr_calls - prev_stat_cluster_rec.curr_calls; 
		current_delta_rows =  current_stat_cluster_rec.curr_rows - prev_stat_cluster_rec.curr_rows; 
		
		current_delta_bufferpin   = current_stat_cluster_rec.curr_bufferpin - prev_stat_cluster_rec.curr_bufferpin ; 
		current_delta_extension   = current_stat_cluster_rec.curr_extension - prev_stat_cluster_rec.curr_extension ; 
		current_delta_io   = current_stat_cluster_rec.curr_io - prev_stat_cluster_rec.curr_io ;
		current_delta_ipc   = current_stat_cluster_rec.curr_ipc - prev_stat_cluster_rec.curr_ipc ; 
		current_delta_lock   = current_stat_cluster_rec.curr_lock - prev_stat_cluster_rec.curr_lock ; 
		current_delta_lwlock   = current_stat_cluster_rec.curr_lwlock - prev_stat_cluster_rec.curr_lwlock ;
		current_delta_timeout   = current_stat_cluster_rec.curr_timeout - prev_stat_cluster_rec.curr_timeout ;
	
	END IF ;
	-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ 	
	--------------------------------------
	
	
	-----------------------------------------------------
	-- СОХРАНИТЬ  ПРИРАЩЕНИЕ 
	UPDATE pgh_stat_cluster
	SET delta_calls = current_delta_calls , 
		delta_rows = current_delta_rows		,
		delta_bufferpin  = current_delta_bufferpin ,
		delta_extension  = current_delta_extension ,
		delta_io  = current_delta_io ,
		delta_ipc = current_delta_ipc ,
		delta_lock = current_delta_lock ,
		delta_lwlock = current_delta_lwlock ,
		delta_timeout = current_delta_timeout
	WHERE 
		id = current_stat_cluster_rec.id ;
	-- СОХРАНИТЬ  ПРИРАЩЕНИЕ 
	-----------------------------------------------------

-- ПРИРАЩЕНИЕ ЗНАЧЕНИЯ   
-------------------------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------
-- МЕДИАНЫ 
	-----------------------------------------------------------------------------
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ
	--Короткая медиана calls	
	SELECT (percentile_cont(0.5) within group (order by delta_calls))::numeric
	INTO current_delta_calls_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;
	IF current_delta_calls_short IS NULL THEN current_delta_calls_short = 0 ; END IF ;	
	
	--Короткая медиана rows
	SELECT (percentile_cont(0.5) within group (order by delta_rows))::numeric
	INTO current_delta_rows_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF current_delta_rows_short IS NULL THEN current_delta_rows_short = 0 ; END IF ;	
	
	--Долгая медиана calls	
	SELECT (percentile_cont(0.5) within group (order by delta_calls))::numeric
	INTO current_delta_calls_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF current_delta_calls_long IS NULL THEN current_delta_calls_long = 0 ; END IF ;	
	
	--Долгая медиана rows
	SELECT (percentile_cont(0.5) within group (order by delta_rows))::numeric
	INTO current_delta_rows_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF current_delta_rows_long IS NULL THEN current_delta_rows_long = 0 ; END IF ;	
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ
	-----------------------------------------------------------------------------
	
	---------------------------------------------------------------------
	-- ОЖИДАНИЯ
	-- Короткая медиана по wait_event_type
	SELECT (percentile_cont(0.5) within group (order by delta_bufferpin))::numeric
	INTO bufferpin_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF bufferpin_short IS NULL THEN bufferpin_short = 0 ; END IF ; 
	
	SELECT (percentile_cont(0.5) within group (order by delta_extension))::numeric
	INTO extension_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF extension_short IS NULL THEN extension_short = 0 ; END IF ; 

	SELECT (percentile_cont(0.5) within group (order by delta_io))::numeric
	INTO io_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF io_short IS NULL THEN io_short = 0 ; END IF ; 
		
	SELECT (percentile_cont(0.5) within group (order by delta_ipc))::numeric
	INTO ipc_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF ipc_short IS NULL THEN ipc_short = 0 ; END IF ; 

	SELECT (percentile_cont(0.5) within group (order by delta_lock))::numeric
	INTO lock_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF lock_short IS NULL THEN lock_short = 0 ; END IF ; 

	SELECT (percentile_cont(0.5) within group (order by delta_lwlock))::numeric
	INTO lwlock_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF lwlock_short IS NULL THEN lwlock_short = 0 ; END IF ; 
	
	SELECT (percentile_cont(0.5) within group (order by delta_timeout))::numeric
	INTO timeout_short
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp ;	
	IF timeout_short IS NULL THEN timeout_short = 0 ; END IF ; 
	
	-- Короткая медиана по wait_event_type
	---------------------------------------------------------------------
	-- Долгая медиана по wait_event_type
	SELECT (percentile_cont(0.5) within group (order by delta_bufferpin))::numeric
	INTO bufferpin_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF bufferpin_long IS NULL THEN bufferpin_long = 0 ; END IF ; 
	
	SELECT (percentile_cont(0.5) within group (order by delta_extension))::numeric
	INTO extension_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF extension_long IS NULL THEN extension_long = 0 ; END IF ; 

	SELECT (percentile_cont(0.5) within group (order by delta_io))::numeric
	INTO io_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF io_long IS NULL THEN io_long = 0 ; END IF ; 
		
	SELECT (percentile_cont(0.5) within group (order by delta_ipc))::numeric
	INTO ipc_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF ipc_long IS NULL THEN ipc_long = 0 ; END IF ; 

	SELECT (percentile_cont(0.5) within group (order by delta_lock))::numeric
	INTO lock_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF lock_long IS NULL THEN lock_long = 0 ; END IF ; 

	SELECT (percentile_cont(0.5) within group (order by delta_lwlock))::numeric
	INTO lwlock_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF lwlock_long IS NULL THEN lwlock_long = 0 ; END IF ; 
	
	SELECT (percentile_cont(0.5) within group (order by delta_timeout))::numeric
	INTO timeout_long
	FROM pgh_stat_cluster
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF timeout_long IS NULL THEN timeout_long = 0 ; END IF ; 
	
	
	-- Долгая медиана по wait_event_type
	---------------------------------------------------------------------
	-- ОЖИДАНИЯ
	---------------------------------------------------------------------
-- МЕДИАНЫ 
-----------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------
-- РАСЧЕТ МЕТРИК ПРОИЗВОДИТЕЛЬНОСТИ	
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
		curr_operating_speed_short = ( current_delta_calls_short + current_delta_rows_short )  ;
		curr_operating_speed_long =  ( current_delta_calls_long + current_delta_rows_long  )  ;

RAISE NOTICE 'curr_operating_speed_short=%',curr_operating_speed_short ;
RAISE NOTICE 'curr_operating_speed_long=%',curr_operating_speed_long ;
		
		IF curr_operating_speed_short = 0 AND curr_operating_speed_long = 0 THEN 
		 RETURN ;
		END IF ;
	-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
	
	-- ОЖИДАНИЯ  
		curr_waiting_events_short = bufferpin_short + extension_short +  io_short + ipc_short + lock_short + lwlock_short + timeout_short  ;  
		curr_waiting_events_long = bufferpin_long + extension_long +  io_long + ipc_long + lock_long + lwlock_long + timeout_long; 
	-- ОЖИДАНИЯ  
	
-- РАСЧЕТ МЕТРИК ПРОИЗВОДИТЕЛЬНОСТИ 	
-------------------------------------------------------------------------------------------------------------------------
RAISE NOTICE 'СОХРАНИТЬ СТАТИСТИКУ';

-- СОХРАНИТЬ СТАТИСТИКУ
INSERT INTO pgh_stat_cluster_analysis 
	(
		curr_timestamp, 
		
	
		op_speed_short,
		op_speed_long ,
		
		waitings_short,
		waitings_long ,	
		
		bufferpin_short  ,
		extension_short  ,
		io_short  ,
		ipc_short  ,
		lock_short  ,
		lwlock_short ,
		timeout_short ,
	
		bufferpin_long  ,
		extension_long  ,
		io_long  ,
		ipc_long  ,
		lock_long  ,
		lwlock_long ,  
		timeout_long
	)
	VALUES 
	(
		max_timestamp , 

		curr_operating_speed_short , 
		curr_operating_speed_long , 
		
		curr_waiting_events_short , 
		curr_waiting_events_long , 
		
		bufferpin_short ,
		extension_short ,
		io_short ,
		ipc_short ,
		lock_short ,
		lwlock_short ,
		timeout_short ,
		
		bufferpin_long ,
		extension_long ,
		io_long ,
		ipc_long ,
		lock_long ,
		lwlock_long ,
		timeout_long 
		
	);
-- СОХРАНИТЬ СТАТИСТИКУ
----------------------------------------------------------------------------

	INSERT INTO current_stat_cluster
	(
		temp_operating_speed_short ,
		temp_operating_speed_long ,   
		
		temp_waiting_events_short ,
		temp_waiting_events_long ,
		
		temp_bufferpin_short  ,
		temp_extension_short  ,
		temp_io_short  ,
		temp_ipc_short  ,
		temp_lock_short  ,
		temp_lwlock_short ,
		temp_timeout_short ,
	
		temp_bufferpin_long  ,
		temp_extension_long  ,
		temp_io_long  ,
		temp_ipc_long  ,
		temp_lock_long  ,
		temp_lwlock_long ,
		temp_timeout_long
  	)
	VALUES
	(
		curr_operating_speed_short , 
		curr_operating_speed_long , 
		
		curr_waiting_events_short , 
		curr_waiting_events_long , 

		
		bufferpin_short ,
		extension_short ,
		io_short ,
		ipc_short ,
		lock_short ,
		lwlock_short ,
		timeout_short ,
		
		bufferpin_long ,
		extension_long ,
		io_long ,
		ipc_long ,
		lock_long ,
		lwlock_long , 
		timeout_long 
	);


RETURN QUERY
SELECT 
		temp_operating_speed_short ,
		temp_operating_speed_long ,   
		
		temp_waiting_events_short ,
		temp_waiting_events_long ,
		
		temp_bufferpin_short  ,
		temp_extension_short  ,
		temp_io_short  ,
		temp_ipc_short  ,
		temp_lock_short  ,
		temp_lwlock_short ,
		temp_timeout_short ,
	
		temp_bufferpin_long  ,
		temp_extension_long  ,
		temp_io_long  ,
		temp_ipc_long  ,
		temp_lock_long  ,
		temp_lwlock_long , 
		temp_timeout_long 
FROM
	current_stat_cluster
;

END
$$ LANGUAGE plpgsql; 

