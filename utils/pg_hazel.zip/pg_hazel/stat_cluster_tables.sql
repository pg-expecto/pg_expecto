﻿-- stat_cluster_tables.sql
-- version 60.0
--Статистика уровня кластера 
DROP TABLE IF EXISTS pgh_stat_cluster;
CREATE UNLOGGED TABLE pgh_stat_cluster 
(
  
	id SERIAL , 	
	curr_timestamp timestamp with time zone , 

	curr_calls bigint,
	curr_rows bigint,
	
	curr_bufferpin  bigint,
	curr_extension  bigint,
	curr_io  bigint,
	curr_ipc  bigint,
	curr_lock  bigint,
	curr_lwlock bigint,
	curr_timeout bigint,
	
	
    delta_calls bigint ,
    delta_rows bigint , 
	
	delta_bufferpin  bigint ,
	delta_extension  bigint ,
	delta_io  bigint ,
	delta_ipc  bigint ,
	delta_lock  bigint ,
	delta_lwlock  bigint ,
	delta_timeout  bigint
		
);

--Скользящие медианы
DROP TABLE IF EXISTS pgh_stat_cluster_analysis;
CREATE UNLOGGED TABLE pgh_stat_cluster_analysis 
(
	id SERIAL , 
	curr_timestamp timestamp with time zone , 
	
	op_speed_short numeric ,
	op_speed_long numeric ,
	
	waitings_short numeric ,
	waitings_long numeric ,		
    
	bufferpin_short  numeric,
	extension_short  numeric,
	io_short  numeric,
	ipc_short  numeric,
	lock_short  numeric,
	lwlock_short numeric,
	timeout_short numeric,
	
	bufferpin_long  numeric,
	extension_long  numeric,
	io_long  numeric,
	ipc_long  numeric,
	lock_long  numeric,
	lwlock_long numeric , 
	timeout_long numeric
);

--------------------------------------------------------------------------------------------------------------------------
-- Индексы и ограничения 
ALTER TABLE pgh_stat_cluster ADD CONSTRAINT pgh_stat_cluster_pk PRIMARY KEY (id);
CREATE INDEX pgh_stat_cluster_idx ON pgh_stat_cluster ( curr_timestamp );

ALTER TABLE pgh_stat_cluster_analysis ADD CONSTRAINT pgh_stat_cluster_analysis_pk PRIMARY KEY (id);
CREATE INDEX pgh_stat_cluster_analysis_idx ON pgh_stat_cluster_analysis ( curr_timestamp );





