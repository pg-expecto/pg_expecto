-- stat_os_functions.sql
-- version 75.2
-- Статистика уровня ОС 

--Сформировать таблицу показателей vmstat
-- $  vmstat  -S M | tail -1 | sed -e "s/[[:space:]]\+/ /g"
-- 2 8 92 136 11 7089 0 0 943 729 5 3 7 1 84 8 0
-- vmstat  -S M
-- procs -----------memory---------- ---swap-- -----io---- -system-- ------cpu-----
-- r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st
-- 2  5     92    137     11   7203    0    0   943   728    4    3  7  1 84  8  0

CREATE OR REPLACE FUNCTION os_stat_vmstat( vmstat_string text ) RETURNS TABLE
(
    procs_r_long numeric , -- r — процессы в run queue (готовы к выполнению)
	procs_b_long numeric , -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	memory_swpd_long numeric , -- swpd — объём свопа
	memory_free_long numeric , -- free — свободная RAM
	memory_buff_long numeric , -- buff — буферы
	memory_cache_long numeric ,-- cache — кэш
	
	swap_si_long numeric , -- si — swap in (из swap в RAM)
	swap_so_long numeric , -- so — swap out (из RAM в swap)
	
	io_bi_long numeric, -- bi — блоки, считанные с устройств
	io_bo_long numeric, -- bo — записанные на устройства 
	
	system_in_long numeric, -- in — прерывания
	system_cs_long numeric, -- cs — переключения контекста
	
	cpu_us_long numeric , -- us — user time
	cpu_sy_long numeric , -- sy — system time
	cpu_id_long numeric , -- id — idle
	cpu_wa_long numeric , --  wa — ожидание IO
	cpu_st_long numeric	  --  st — stolen (украдено гипервизором)
)
AS $$
DECLARE
    current_procs_r numeric ; -- r — процессы в run queue (готовы к выполнению)
	current_procs_b numeric ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	current_memory_swpd numeric ; -- swpd — объём свопа
	current_memory_free numeric ; -- free — свободная RAM
	current_memory_buff numeric ; -- buff — буферы
	current_memory_cache numeric ;-- cache — кэш
	
	current_swap_si numeric ; -- si — swap in (из swap в RAM)
	current_swap_so numeric ; -- so — swap out (из RAM в swap)
	
	current_io_bi numeric; -- bi — блоки, считанные с устройств
	current_io_bo numeric; -- bo — записанные на устройства 
	
	current_system_in numeric; -- in — прерывания
	current_system_cs numeric; -- cs — переключения контекста
	
	current_cpu_us numeric ; -- us — user time
	current_cpu_sy numeric ; -- sy — system time
	current_cpu_id numeric ; -- id — idle
	current_cpu_wa numeric ; --  wa — ожидание IO
	current_cpu_st numeric ;  --  st — stolen (украдено гипервизором)
	
    procs_r_long numeric ; -- r — процессы в run queue (готовы к выполнению)
	procs_b_long numeric ; -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	memory_swpd_long numeric ; -- swpd — объём свопа
	memory_free_long numeric ; -- free — свободная RAM
	memory_buff_long numeric ; -- buff — буферы
	memory_cache_long numeric ;-- cache — кэш
	
	swap_si_long numeric ; -- si — swap in (из swap в RAM)
	swap_so_long numeric ; -- so — swap out (из RAM в swap)
	
	io_bi_long numeric ; -- bi — блоки, считанные с устройств
	io_bo_long numeric ;-- bo — записанные на устройства 
	
	system_in_long numeric ; -- in — прерывания
	system_cs_long numeric ; -- cs — переключения контекста
	
	cpu_us_long numeric ; -- us — user time
	cpu_sy_long numeric ; -- sy — system time
	cpu_id_long numeric ; -- id — idle
	cpu_wa_long numeric ; --  wa — ожидание IO
	cpu_st_long numeric	;  --  st — stolen (украдено гипервизором)
	
	vmstat_array  text[] ;
	
	min_timestamp timestamptz ; 
	max_timestamp timestamptz ;  
	
BEGIN	
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP ) 
	INTO 		max_timestamp ;

	--SELECT regexp_split_to_array(vmstat_string , '\s+' )
	--INTO vmstat_array ;
	
	SELECT string_to_array(vmstat_string , ' ' )
	INTO vmstat_array ;
	
-- procs -----------memory---------- ---swap-- -----io---- -system-- ------cpu-----
-- r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st

RAISE NOTICE '%',vmstat_array;
	
	-- r — процессы в run queue (готовы к выполнению)
RAISE NOTICE '%',vmstat_array[1];		
	current_procs_r = vmstat_array[1]::numeric ; 
RAISE NOTICE '%',current_procs_r;	
	-- b — процессы в uninterruptible sleep (обычно ждут IO)
	current_procs_b = vmstat_array[2]::numeric ; 
RAISE NOTICE '%',current_procs_b;		
	-- swpd — объём свопа
	current_memory_swpd = vmstat_array[3]::numeric ; 
RAISE NOTICE '%',current_memory_swpd;			
	-- free — свободная RAM
	current_memory_free = vmstat_array[4]::numeric ; 
RAISE NOTICE '%',current_memory_free;
	-- buff — буферы
	current_memory_buff = vmstat_array[5]::numeric ; 
RAISE NOTICE '%',current_memory_buff;	
	-- cache — кэш
	current_memory_cache = vmstat_array[6]::numeric ; 
RAISE NOTICE '%',current_memory_cache;		
	-- si — swap in (из swap в RAM)
	current_swap_si = vmstat_array[7]::numeric ; 
RAISE NOTICE '%',current_swap_si;			
	-- so — swap out (из RAM в swap)
	current_swap_so = vmstat_array[8]::numeric ; 
RAISE NOTICE '%',current_swap_so;				
	-- bi — блоки, считанные с устройств
	current_io_bi = vmstat_array[9]::numeric ; 
RAISE NOTICE '%',current_io_bi;					
	-- bo — записанные на устройства 
	current_io_bo = vmstat_array[10]::numeric ; 
RAISE NOTICE '%',current_io_bo;						
	-- in — прерывания
	current_system_in = vmstat_array[11]::numeric ; 
RAISE NOTICE '%',current_system_in;
	-- cs — переключения контекста
	current_system_cs = vmstat_array[12]::numeric ; 
RAISE NOTICE '%',current_system_cs;	
	-- us — user time
	current_cpu_us = vmstat_array[13]::numeric ; 
RAISE NOTICE '%',current_cpu_us;	
	-- sy — system time
	current_cpu_sy = vmstat_array[14]::numeric ; 
RAISE NOTICE '%',current_cpu_sy;	
	-- id — idle
	current_cpu_id = vmstat_array[15]::numeric ; 
RAISE NOTICE '%',current_cpu_id;		
	--  wa — ожидание IO
	current_cpu_wa = vmstat_array[16]::numeric ; 
RAISE NOTICE '%',current_cpu_wa;			
	--  st — stolen (украдено гипервизором)
	current_cpu_st = vmstat_array[17]::numeric ; 
RAISE NOTICE '%',current_cpu_st;				
--Сохранить текущие значения
	INSERT INTO os_stat_vmstat
	(
		curr_timestamp , 

		procs_r  , -- r — процессы в run queue (готовы к выполнению)
		procs_b  , -- b — процессы в uninterruptible sleep (обычно ждут IO)
		
		memory_swpd  , -- swpd — объём свопа
		memory_free  , -- free — свободная RAM
		memory_buff  , -- buff — буферы
		memory_cache  ,-- cache — кэш
		
		swap_si  , -- si — swap in (из swap в RAM)
		swap_so  , -- so — swap out (из RAM в swap)
		
		io_bi , -- bi — блоки, считанные с устройств
		io_bo , -- bo — записанные на устройства 
		
		system_in , -- in — прерывания
		system_cs , -- cs — переключения контекста
		
		cpu_us  , -- us — user time
		cpu_sy   , -- sy — system time
		cpu_id   , -- id — idle
		cpu_wa   , --  wa — ожидание IO
		cpu_st 	  --  st — stolen (украдено гипервизором)
	)
	VALUES 
	(
		max_timestamp ,
		current_procs_r  , -- r — процессы в run queue (готовы к выполнению)
		current_procs_b  , -- b — процессы в uninterruptible sleep (обычно ждут IO)
		
		current_memory_swpd  , -- swpd — объём свопа
		current_memory_free  , -- free — свободная RAM
		current_memory_buff  , -- buff — буферы
		current_memory_cache  ,-- cache — кэш
		
		current_swap_si  , -- si — swap in (из swap в RAM)
		current_swap_so  , -- so — swap out (из RAM в swap)
		
		current_io_bi , -- bi — блоки, считанные с устройств
		current_io_bo , -- bo — записанные на устройства 
		
		current_system_in , -- in — прерывания
		current_system_cs , -- cs — переключения контекста
		
		current_cpu_us  , -- us — user time
		current_cpu_sy  , -- sy — system time
		current_cpu_id  , -- id — idle
		current_cpu_wa  , --  wa — ожидание IO
		current_cpu_st 	
	);
--Сохранить текущие значения	
	
--Скользящие медианы
	-- r — процессы в run queue (готовы к выполнению)
	SELECT (percentile_cont(0.5) within group (order by procs_r))::numeric
	INTO procs_r_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF procs_r_long IS NULL THEN procs_r_long = 0 ; END IF ; 
	
	-- b — процессы в uninterruptible sleep (обычно ждут IO)
	SELECT (percentile_cont(0.5) within group (order by procs_b))::numeric
	INTO procs_b_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF procs_b_long IS NULL THEN procs_b_long = 0 ; END IF ; 
	
	-- swpd — объём свопа
	SELECT (percentile_cont(0.5) within group (order by memory_swpd))::numeric
	INTO memory_swpd_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF memory_swpd_long IS NULL THEN memory_swpd_long = 0 ; END IF ; 
	
	-- free — свободная RAM
	SELECT (percentile_cont(0.5) within group (order by memory_free))::numeric
	INTO memory_free_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF memory_free_long IS NULL THEN memory_free_long = 0 ; END IF ;
	
	-- buff — буферы
	SELECT (percentile_cont(0.5) within group (order by memory_buff))::numeric
	INTO memory_buff_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF memory_buff_long IS NULL THEN memory_buff_long = 0 ; END IF ;
	
	-- cache — кэш
	SELECT (percentile_cont(0.5) within group (order by memory_cache))::numeric
	INTO memory_cache_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF memory_cache_long IS NULL THEN memory_cache_long = 0 ; END IF ;
	
	-- si — swap in (из swap в RAM)
	SELECT (percentile_cont(0.5) within group (order by swap_si))::numeric
	INTO swap_si_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF swap_si_long IS NULL THEN swap_si_long = 0 ; END IF ;
	
	-- so — swap out (из RAM в swap)
	SELECT (percentile_cont(0.5) within group (order by swap_so))::numeric
	INTO swap_so_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF swap_so_long IS NULL THEN swap_so_long = 0 ; END IF ;
	
	-- bi — блоки, считанные с устройств
	SELECT (percentile_cont(0.5) within group (order by io_bi))::numeric
	INTO io_bi_long
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF io_bi_long IS NULL THEN io_bi_long = 0 ; END IF ;
	
	-- bo — записанные на устройства 
	SELECT (percentile_cont(0.5) within group (order by io_bo))::numeric
	INTO io_bo_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF io_bo_long  IS NULL THEN io_bo_long  = 0 ; END IF ;
	
	-- in — прерывания	
	SELECT (percentile_cont(0.5) within group (order by system_in))::numeric
	INTO system_in_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF system_in_long  IS NULL THEN system_in_long  = 0 ; END IF;
	
	-- cs — переключения контекста
	SELECT (percentile_cont(0.5) within group (order by system_cs))::numeric
	INTO system_cs_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF system_cs_long  IS NULL THEN system_cs_long  = 0 ; END IF;
	
	-- us — user time
	SELECT (percentile_cont(0.5) within group (order by cpu_us))::numeric
	INTO cpu_us_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_us_long  IS NULL THEN cpu_us_long  = 0 ; END IF;
	
	-- sy — system time
	SELECT (percentile_cont(0.5) within group (order by cpu_sy))::numeric
	INTO cpu_sy_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_sy_long  IS NULL THEN cpu_sy_long  = 0 ; END IF;
	
	-- id — idle
	SELECT (percentile_cont(0.5) within group (order by cpu_id))::numeric
	INTO cpu_id_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_id_long  IS NULL THEN cpu_id_long  = 0 ; END IF;
	
	--  wa — ожидание IO
	SELECT (percentile_cont(0.5) within group (order by cpu_wa))::numeric
	INTO cpu_wa_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_wa_long  IS NULL THEN cpu_wa_long  = 0 ; END IF;
	
	--  st — stolen (украдено гипервизором)
	SELECT (percentile_cont(0.5) within group (order by cpu_st))::numeric
	INTO cpu_st_long 
	FROM os_stat_vmstat
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_st_long  IS NULL THEN cpu_st_long  = 0 ; END IF;
--Скользящие медианы	

--Сохранить статистические данные
	INSERT INTO os_stat_vmstat_analysis
	(
		curr_timestamp , 
		
		vmstat_analysis_procs_r_long  , -- r — процессы в run queue (готовы к выполнению)
		vmstat_analysis_procs_b_long  , -- b — процессы в uninterruptible sleep (обычно ждут IO)
		
		vmstat_analysis_memory_swpd_long  , -- swpd — объём свопа
		vmstat_analysis_memory_free_long  , -- free — свободная RAM
		vmstat_analysis_memory_buff_long  , -- buff — буферы
		vmstat_analysis_memory_cache_long  ,-- cache — кэш
		
		vmstat_analysis_swap_si_long  , -- si — swap in (из swap в RAM)
		vmstat_analysis_swap_so_long  , -- so — swap out (из RAM в swap)
		
		vmstat_analysis_io_bi_long , -- bi — блоки, считанные с устройств
		vmstat_analysis_io_bo_long , -- bo — записанные на устройства 
		
		vmstat_analysis_system_in_long , -- in — прерывания
		vmstat_analysis_system_cs_long , -- cs — переключения контекста
		
		vmstat_analysis_cpu_us_long  , -- us — user time
		vmstat_analysis_cpu_sy_long  , -- sy — system time
		vmstat_analysis_cpu_id_long  , -- id — idle
		vmstat_analysis_cpu_wa_long  , --  wa — ожидание IO
		vmstat_analysis_cpu_st_long ,	  --  st — stolen (украдено гипервизором)
		vmstat_analysis_procs_r_source , -- ИСХОДНОЕ ЗНАЧЕНИЕ r — процессы в run queue (готовы к выполнению)
		vmstat_analysis_swap_si_source , -- ИСХОДНОЕ ЗНАЧЕНИЕ si — swap in (из swap в RAM)
		vmstat_analysis_swap_so_source , -- ИСХОДНОЕ ЗНАЧЕНИЕ so — swap out (из RAM в swap)
		vmstat_analysis_cpu_id_source  , -- ИСХОДНОЕ ЗНАЧЕНИЕ id — idle		
		vmstat_analysis_cpu_wa_source ,  --  ИСХОДНОЕ ЗНАЧЕНИЕ wa — ожидание IO
		vmstat_analysis_cpu_st_source 	  --  ИСХОДНОЕ ЗНАЧЕНИЕ st — stolen (украдено гипервизором)		
	)
	VALUES 
	(
		max_timestamp , 
		procs_r_long  , -- r — процессы в run queue (готовы к выполнению)
		procs_b_long  , -- b — процессы в uninterruptible sleep (обычно ждут IO)
		
		memory_swpd_long  , -- swpd — объём свопа
		memory_free_long  , -- free — свободная RAM
		memory_buff_long  , -- buff — буферы
		memory_cache_long  ,-- cache — кэш
		
		swap_si_long  , -- si — swap in (из swap в RAM)
		swap_so_long  , -- so — swap out (из RAM в swap)	
		
		io_bi_long , -- bi — блоки, считанные с устройств
		io_bo_long , -- bo — записанные на устройства 
		
		system_in_long , -- in — прерывания
		system_cs_long , -- cs — переключения контекста
		
		cpu_us_long  , -- us — user time
		cpu_sy_long  , -- sy — system time
		cpu_id_long  , -- id — idle
		cpu_wa_long  , --  wa — ожидание IO
		cpu_st_long  ,  --  st — stolen (украдено гипервизором)
		
		current_procs_r  , -- r — процессы в run queue (готовы к выполнению)
		current_swap_si  , -- ИСХОДНОЕ ЗНАЧЕНИЕ si — swap in (из swap в RAM)
		current_swap_so  , -- ИСХОДНОЕ ЗНАЧЕНИЕ so — swap out (из RAM в swap)
		current_cpu_id   , -- id — idle
		current_cpu_wa    , --  wa — ожидание IO
		current_cpu_st      --  st — stolen (украдено гипервизором)		
	);
--Сохранить статистические данные
	
RETURN QUERY
SELECT 
		vmstat_analysis_procs_r_long  , -- r — процессы в run queue (готовы к выполнению)
		vmstat_analysis_procs_b_long  , -- b — процессы в uninterruptible sleep (обычно ждут IO)
		
		vmstat_analysis_memory_swpd_long  , -- swpd — объём свопа
		vmstat_analysis_memory_free_long  , -- free — свободная RAM
		vmstat_analysis_memory_buff_long  , -- buff — буферы
		vmstat_analysis_memory_cache_long  ,-- cache — кэш
		
		vmstat_analysis_swap_si_long  , -- si — swap in (из swap в RAM)
		vmstat_analysis_swap_so_long  , -- so — swap out (из RAM в swap)
		
		vmstat_analysis_io_bi_long , -- bi — блоки, считанные с устройств
		vmstat_analysis_io_bo_long , -- bo — записанные на устройства 
		
		vmstat_analysis_system_in_long , -- in — прерывания
		vmstat_analysis_system_cs_long , -- cs — переключения контекста
		
		vmstat_analysis_cpu_us_long  , -- us — user time
		vmstat_analysis_cpu_sy_long  , -- sy — system time
		vmstat_analysis_cpu_id_long  , -- id — idle
		vmstat_analysis_cpu_wa_long  , --  wa — ожидание IO
		vmstat_analysis_cpu_st_long 	  --  st — stolen (украдено гипервизором)
FROM
	os_stat_vmstat_analysis
WHERE 
	curr_timestamp = max_timestamp ;
END
$$ LANGUAGE plpgsql; 

---------------------------------------------------------------------------------------------------------------------------
-- iostat
--avg-cpu:  %user   %nice %system %iowait  %steal   %idle
--           5.50    0.00    4.04    0.38    0.00   90.07
--Device            r/s     rMB/s   rrqm/s  %rrqm r_await rareq-sz     w/s     wMB/s   wrqm/s  %wrqm w_await wareq-sz     d/s     dMB/s   drqm/s  %drqm d_await dareq-sz     f/s f_await  aqu-sz  %util
--dm-0             0.12      0.00     0.00   0.00    3.13     4.90    0.62      0.00     0.00   0.00    0.53     4.79    0.00      0.00     0.00   0.00    0.00     0.00    0.00    0.00    0.00   0.09
--
--CPU
--%user - процент использования процессора программами, запущенными на уровне пользователя;
--%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
--%system - процент использования процессора ядром;
--%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
--%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
--%idle - процент времени пока процессор не занят ничем.
--
--DEVICE
--r/s Количество операций чтения в секунду.
--rMB/s Скорость чтения (МБ/с).
--rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
--%rrqm Процент операций чтения, слитых перед отправкой на устройство.
--r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
--rareq-sz Средний размер запроса чтения (в КБ).
--w/s Количество операций записи в секунду.
--wMB/s Скорость записи (МБ/с).
--wrqm/s Количество записанных запросов, слитых в очередь в секунду.
--%wrqm Процент операций записи, слитых перед отправкой на устройство.
--w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
--wareq-sz Средний размер запроса записи (в КБ).
--d/s Операции для discard-запросов (актуально для SSD).
--dMB/s скорость для discard-запросов (актуально для SSD).
--%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
--d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
--dareq-sz Средний размер для discard-запросов (актуально для SSD)..
--aqu-sz Средняя длина очереди запросов (глубина очереди).
--%utilПроцент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
--f/s скорость выполнения запросов от flush-операций.
--f_await Среднее время выполнения запросов от flush-операций.

CREATE OR REPLACE FUNCTION os_stat_iostat_cpu( iostat_string text ) RETURNS TABLE
(
	cpu_user_pct_long  numeric , --%user - процент использования процессора программами, запущенными на уровне пользователя;
	cpu_nice_pct_long  numeric ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	cpu_system_pct_long  numeric ,  --%system - процент использования процессора ядром;
	cpu_iowait_pct_long  numeric ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	cpu_steal_pct_long  numeric ,  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	cpu_idle_pct_long  numeric  --%idle - процент времени пока процессор не занят ничем.	
)
AS $$
DECLARE
--CPU
	current_cpu_user_pct double precision ; --%user - процент использования процессора программами, запущенными на уровне пользователя;
	current_cpu_nice_pct double precision ;  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	current_cpu_system_pct double precision ;  --%system - процент использования процессора ядром;
	current_cpu_iowait_pct double precision ;  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	current_cpu_steal_pct double precision ; --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	current_cpu_idle_pct double precision ; --%idle - процент времени пока процессор не занят ничем.	
	
	
	cpu_user_pct_long numeric ; --%user - процент использования процессора программами, запущенными на уровне пользователя;
	cpu_nice_pct_long numeric ;  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	cpu_system_pct_long numeric ;  --%system - процент использования процессора ядром;
	cpu_iowait_pct_long numeric ;  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	cpu_steal_pct_long numeric ; --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	cpu_idle_pct_long numeric ; --%idle - процент времени пока процессор не занят ничем.	
		
	iostat_array  text[] ;
	
	min_timestamp timestamptz ; 
	max_timestamp timestamptz ;  
	
BEGIN	
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP ) 
	INTO 		max_timestamp ;

	--SELECT regexp_split_to_array(iostat_string , '\s+' )
	--INTO iostat_array ;
	
	SELECT string_to_array(iostat_string , ' ' )
	INTO iostat_array ;
	
	
    --%user - процент использования процессора программами, запущенными на уровне пользователя;
	current_cpu_user_pct = iostat_array[1]::double precision; 
	
	--%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	current_cpu_nice_pct = iostat_array[2]::double precision; 
	
	--%system - процент использования процессора ядром;
	current_cpu_system_pct = iostat_array[3]::double precision; 
	
	--%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	current_cpu_iowait_pct = iostat_array[4]::double precision; 
	
	--%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	current_cpu_steal_pct = iostat_array[5]::double precision; 
	
	--%idle - процент времени пока процессор не занят ничем.	
	current_cpu_idle_pct = iostat_array[6]::double precision; 
	
	
	--Сохранить текущие значения
	INSERT INTO os_stat_iostat_cpu
	(
		curr_timestamp , 
		--CPU
		cpu_user_pct  , --%user - процент использования процессора программами, запущенными на уровне пользователя;
		cpu_nice_pct  ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
		cpu_system_pct  ,  --%system - процент использования процессора ядром;
		cpu_iowait_pct  ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
		cpu_steal_pct  ,  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
		cpu_idle_pct   --%idle - процент времени пока процессор не занят ничем.	

	)
	VALUES 
	(
		max_timestamp ,
		current_cpu_user_pct , --%user - процент использования процессора программами, запущенными на уровне пользователя;
		current_cpu_nice_pct ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
		current_cpu_system_pct ,  --%system - процент использования процессора ядром;
		current_cpu_iowait_pct ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
		current_cpu_steal_pct , --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
		current_cpu_idle_pct  --%idle - процент времени пока процессор не занят ничем.
	);
--Сохранить текущие значения	
	
--Скользящие медианы
	--%user - процент использования процессора программами, запущенными на уровне пользователя;
	SELECT (percentile_cont(0.5) within group (order by cpu_user_pct))::numeric
	INTO cpu_user_pct_long
	FROM os_stat_iostat_cpu
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_user_pct_long IS NULL THEN cpu_user_pct_long = 0 ; END IF ; 

	--%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	SELECT (percentile_cont(0.5) within group (order by cpu_nice_pct))::numeric
	INTO cpu_nice_pct_long
	FROM os_stat_iostat_cpu
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_nice_pct_long IS NULL THEN cpu_nice_pct_long = 0 ; END IF ; 
	
	--%system - процент использования процессора ядром;
	SELECT (percentile_cont(0.5) within group (order by cpu_system_pct))::numeric
	INTO cpu_system_pct_long
	FROM os_stat_iostat_cpu
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_system_pct_long IS NULL THEN cpu_system_pct_long = 0 ; END IF ; 
	
	--%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	SELECT (percentile_cont(0.5) within group (order by cpu_iowait_pct))::numeric
	INTO cpu_iowait_pct_long
	FROM os_stat_iostat_cpu
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_iowait_pct_long IS NULL THEN cpu_iowait_pct_long = 0 ; END IF ; 
	
	--%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	SELECT (percentile_cont(0.5) within group (order by cpu_steal_pct))::numeric
	INTO cpu_steal_pct_long
	FROM os_stat_iostat_cpu
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_steal_pct_long IS NULL THEN cpu_steal_pct_long = 0 ; END IF ; 
	
	--%idle - процент времени пока процессор не занят ничем.
	SELECT (percentile_cont(0.5) within group (order by cpu_idle_pct))::numeric
	INTO cpu_idle_pct_long
	FROM os_stat_iostat_cpu
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp ;	
	IF cpu_idle_pct_long IS NULL THEN cpu_idle_pct_long = 0 ; END IF ; 	
--Скользящие медианы

--Сохранить статистические данные
	INSERT INTO os_stat_iostat_cpu_analysis
	(
		curr_timestamp , 
	--CPU
		iostat_analysis_cpu_user_pct_long   , --%user - процент использования процессора программами, запущенными на уровне пользователя;
		iostat_analysis_cpu_nice_pct_long   ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
		iostat_analysis_cpu_system_pct_long   ,  --%system - процент использования процессора ядром;
		iostat_analysis_cpu_iowait_pct_long   ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
		iostat_analysis_cpu_steal_pct_long   ,  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
		iostat_analysis_cpu_idle_pct_long    --%idle - процент времени пока процессор не занят ничем.			
	)
	VALUES 
	(
		max_timestamp , 
		cpu_user_pct_long  , --%user - процент использования процессора программами, запущенными на уровне пользователя,
		cpu_nice_pct_long  ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом,
		cpu_system_pct_long  ,  --%system - процент использования процессора ядром,
		cpu_iowait_pct_long  ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода,
		cpu_steal_pct_long  , --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору,
		cpu_idle_pct_long   --%idle - процент времени пока процессор не занят ничем.	

	);
--Сохранить статистические данные
	
RETURN QUERY
SELECT 
		iostat_analysis_cpu_user_pct_long   , --%user - процент использования процессора программами, запущенными на уровне пользователя;
		iostat_analysis_cpu_nice_pct_long   ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
		iostat_analysis_cpu_system_pct_long   ,  --%system - процент использования процессора ядром;
		iostat_analysis_cpu_iowait_pct_long   ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
		iostat_analysis_cpu_steal_pct_long   ,  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
		iostat_analysis_cpu_idle_pct_long    --%idle - процент времени пока процессор не занят ничем.	
FROM
	os_stat_iostat_cpu_analysis
WHERE 
	curr_timestamp = max_timestamp ;
END
$$ LANGUAGE plpgsql; 

CREATE OR REPLACE FUNCTION os_stat_iostat_device( iostat_string text ) RETURNS TABLE
(
    device  text ,  		    --Device
	dev_rps_long  numeric ,  --r/s Количество операций чтения в секунду.
	dev_rmbs_long  numeric ,  --rMB/s Скорость чтения (МБ/с).
	dev_rrqmps_long  numeric ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
	dev_rrqm_pct_long  numeric ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
	dev_r_await_long  numeric ,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	dev_rareq_sz_long  numeric ,  --rareq_sz Средний размер запроса чтения (в КБ).
	dev_wps_long  numeric , --w/s Количество операций записи в секунду.
	dev_wmbps_long  numeric ,  --wMB/s Скорость записи (МБ/с).
	dev_wrqmps_long  numeric ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
	dev_wrqm_pct_long  numeric ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
	dev_w_await_long  numeric ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	dev_wareq_sz_long  numeric ,  --wareq_sz Средний размер запроса записи (в КБ).
	dev_dps_long  numeric ,  --d/s Операции для discard-запросов (актуально для SSD).
	dev_dmbps_long  numeric ,  --dMB/s скорость для discard-запросов (актуально для SSD).
	dev_drqmps_long numeric , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	dev_drqm_pct_long  numeric ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	dev_d_await_long  numeric ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	dev_dareq_sz_long  numeric ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	dev_aqu_sz_long  numeric ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	dev_util_pct_long  numeric ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
	dev_fps_long  numeric ,  --f/s скорость выполнения запросов от flush-операций.
	dev_f_await_long  numeric  --f_await Среднее время выполнения запросов от flush-операций.	
)
AS $$
DECLARE
--DEVICE
	device_name text ;
	current_dev_rps double precision ;  --r/s Количество операций чтения в секунду.
	current_dev_rmbs double precision ;  --rMB/s Скорость чтения (МБ/с).
	current_dev_rrqmps double precision ;  --rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	current_dev_rrqm_pct double precision ;  --%rrqm Процент операций чтения; слитых перед отправкой на устройство.
	current_dev_r_await double precision ;  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	current_dev_rareq_sz double precision ;  --rareq-sz Средний размер запроса чтения (в КБ).
	current_dev_wps double precision ; --w/s Количество операций записи в секунду.
	current_dev_wmbps double precision ;  --wMB/s Скорость записи (МБ/с).
	current_dev_wrqmps double precision ;  --wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	current_dev_wrqm_pct double precision ;  --%wrqm Процент операций записи; слитых перед отправкой на устройство.
	current_dev_w_await double precision ;  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	current_dev_wareq_sz double precision ;  --wareq_sz Средний размер запроса записи (в КБ).
	current_dev_dps double precision ;  --d/s Операции для discard-запросов (актуально для SSD).
	current_dev_dmbps double precision ;  --dMB/s скорость для discard-запросов (актуально для SSD).
	current_dev_drqmps double precision ; --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	current_dev_drqm_pct double precision ;  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	current_dev_d_await double precision ;  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	current_dev_dareq_sz double precision ;  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	current_dev_aqu_sz double precision ;  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	current_dev_util_pct double precision ;  --%util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	current_dev_fps double precision ;  --f/s скорость выполнения запросов от flush-операций.
	current_dev_f_await double precision ; --f_await Среднее время выполнения запросов от flush-операций.	
	
	dev_rps_long  numeric ;  --r/s Количество операций чтения в секунду.
	dev_rmbs_long  numeric ;  --rMB/s Скорость чтения (МБ/с).
	dev_rrqmps_long  numeric ;  --rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	dev_rrqm_pct_long  numeric ;  --%rrqm Процент операций чтения; слитых перед отправкой на устройство.
	dev_r_await_long  numeric ;  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	dev_rareq_sz_long  numeric ;  --rareq_sz Средний размер запроса чтения (в КБ).
	dev_wps_long  numeric ; --w/s Количество операций записи в секунду.
	dev_wmbps_long  numeric ;  --wMB/s Скорость записи (МБ/с).
	dev_wrqmps_long  numeric ;  --wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	dev_wrqm_pct_long  numeric ;  --%wrqm Процент операций записи; слитых перед отправкой на устройство.
	dev_w_await_long  numeric ;  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	dev_wareq_sz_long  numeric ;  --wareq_sz Средний размер запроса записи (в КБ).
	dev_dps_long  numeric ;  --d/s Операции для discard-запросов (актуально для SSD).
	dev_dmbps_long  numeric ;  --dMB/s скорость для discard-запросов (актуально для SSD).
	dev_drqmps_long  numeric ; --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	dev_drqm_pct_long  numeric ;  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	dev_d_await_long  numeric ;  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	dev_dareq_sz_long  numeric ;  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	dev_aqu_sz_long  numeric ;  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	dev_util_pct_long  numeric ;  --%util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	dev_fps_long  numeric ;  --f/s скорость выполнения запросов от flush-операций.
	dev_f_await_long  numeric ; --f_await Среднее время выполнения запросов от flush-операций.
	
		
	iostat_array  text[] ;
	
	min_timestamp timestamptz ; 
	max_timestamp timestamptz ;  
	
BEGIN	
	SELECT 	date_trunc( 'minute' , CURRENT_TIMESTAMP ) 
	INTO 		max_timestamp ; 

	--SELECT regexp_split_to_array(iostat_string , '\s+' )
	--INTO iostat_array ;

--------------------------------------------------------
-- EXCEPTION 	
BEGIN 	
	SELECT string_to_array(iostat_string , ' ' )
	INTO iostat_array ;
	
--Device            r/s     rMB/s   rrqm/s  %rrqm r_await rareq-sz     w/s     wMB/s   wrqm/s  %wrqm w_await wareq-sz     d/s     dMB/s   drqm/s  %drqm d_await dareq-sz     f/s f_await  aqu-sz  %util
--dm-0             0.12      0.00     0.00   0.00    3.13     4.90    0.62      0.00     0.00   0.00    0.53     4.79    0.00      0.00     0.00   0.00    0.00     0.00    0.00    0.00    0.00   0.09
--Device-1	r/s-2	rMB/s-3	rrqm/s-4	%rrqm-5	r_await-6	rareq-sz-7	w/s-8	wMB/s-9	wrqm/s-10	%wrqm-11	w_await-12	wareq-sz-13	d/s-14	dMB/s-15	drqm/s-16	%drqm-17	d_await-18	dareq-sz-19	f/s-20	f_await-21	aqu-sz-22	%util-23

	--Device-1
	device_name= iostat_array[1]; 
	
	--r/s-2
    --r/s Количество операций чтения в секунду.
	current_dev_rps = iostat_array[2]::double precision; 
	
	--rMB/s-3
	--rMB/s Скорость чтения (МБ/с).
	current_dev_rmbs = iostat_array[3]::double precision; 

    --rrqm/s-4
	--rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	current_dev_rrqmps = iostat_array[4]::double precision; 
	
	--%rrqm-5
	--%rrqm Процент операций чтения; слитых перед отправкой на устройство.
	current_dev_rrqm_pct = iostat_array[5]::double precision; 
	
	--r_await-6
	--r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	current_dev_r_await = iostat_array[6]::double precision; 
	
	--rareq-sz-7
	--rareq-sz Средний размер запроса чтения (в КБ).
	current_dev_rareq_sz = iostat_array[7]::double precision; 
	
	--w/s-8
	--w/s Количество операций записи в секунду.
	current_dev_wps = iostat_array[8]::double precision; 
	
	--wMB/s-9
	--wMB/s Скорость записи (МБ/с).
	current_dev_wmbps = iostat_array[9]::double precision; 
	
	--wrqm/s-10
	--wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	current_dev_wrqmps = iostat_array[10]::double precision; 
	
	--%wrqm-11
	--%wrqm Процент операций записи; слитых перед отправкой на устройство.
	current_dev_wrqm_pct = iostat_array[11]::double precision; 
	
	--w_await-12
	--w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	current_dev_w_await = iostat_array[12]::double precision; 
	
	--wareq-sz-13
	--wareq_sz Средний размер запроса записи (в КБ).
	current_dev_wareq_sz = iostat_array[13]::double precision; 
	
	--d/s-14
	--d/s Операции для discard-запросов (актуально для SSD).
	current_dev_dps = iostat_array[14]::double precision; 
	
	--dMB/s-15
	--dMB/s скорость для discard-запросов (актуально для SSD).
	current_dev_dmbps = iostat_array[15]::double precision; 
	
	--drqm/s-16
	--drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	current_dev_drqmps = iostat_array[16]::double precision; 
	
	--%drqm-17
	--%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	current_dev_drqm_pct = iostat_array[17]::double precision; 
	
	--d_await-18
	--d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	current_dev_d_await = iostat_array[18]::double precision; 
	
	--dareq-sz-19
	--dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	current_dev_dareq_sz = iostat_array[19]::double precision; 
	
	--f/s-20
	--f/s скорость выполнения запросов от flush-операций.
	current_dev_fps = iostat_array[20]::double precision; 
	
	--f_await-21
	--f_await Среднее время выполнения запросов от flush-операций.	
	current_dev_f_await = iostat_array[21]::double precision; 
	
	--aqu-sz-22
	--aqu_sz Средняя длина очереди запросов (глубина очереди).
	current_dev_aqu_sz = iostat_array[22]::double precision; 
	
	--	%util-23
	--%util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	current_dev_util_pct = iostat_array[23]::double precision; 
	
	
	
	
	
	--Сохранить текущие значения
	INSERT INTO os_stat_iostat_device
	(
		device , 
		curr_timestamp ,
		dev_rps  ,  --r/s Количество операций чтения в секунду.
		dev_rmbs ,  --rMB/s Скорость чтения (МБ/с).
		dev_rrqmps ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
		dev_rrqm_pct ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
		dev_r_await,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
		dev_rareq_sz  ,  --rareq-sz Средний размер запроса чтения (в КБ).
		dev_wps     , --w/s Количество операций записи в секунду.
		dev_wmbps   ,  --wMB/s Скорость записи (МБ/с).
		dev_wrqmps  ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
		dev_wrqm_pct  ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
		dev_w_await   ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
		dev_wareq_sz  ,  --wareq_sz Средний размер запроса записи (в КБ).
		dev_dps    ,  --d/s Операции для discard-запросов (актуально для SSD).
		dev_dmbps  ,  --dMB/s скорость для discard-запросов (актуально для SSD).
		dev_drqmps , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
		dev_drqm_pct  ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
		dev_d_await   ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
		dev_dareq_sz  ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
		dev_aqu_sz    ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
		dev_util_pct  ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
		dev_fps     ,  --f/s скорость выполнения запросов от flush-операций.
		dev_f_await    --f_await Среднее время выполнения запросов от flush-операций.
	)
	VALUES
	(
		 device_name ,
		 max_timestamp		,
		 current_dev_rps ,  --r/s Количество операций чтения в секунду.
		 current_dev_rmbs ,  --rMB/s Скорость чтения (МБ/с).
		 current_dev_rrqmps,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
		 current_dev_rrqm_pct,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
		 current_dev_r_await,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
		 current_dev_rareq_sz  ,  --rareq-sz Средний размер запроса чтения (в КБ).
		 current_dev_wps  , --w/s Количество операций записи в секунду.
		 current_dev_wmbps  ,  --wMB/s Скорость записи (МБ/с).
		 current_dev_wrqmps  ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
		 current_dev_wrqm_pct  ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
		 current_dev_w_await  ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
		 current_dev_wareq_sz  ,  --wareq_sz Средний размер запроса записи (в КБ).
		 current_dev_dps  ,  --d/s Операции для discard-запросов (актуально для SSD).
		 current_dev_dmbps  ,  --dMB/s скорость для discard-запросов (актуально для SSD).
		 current_dev_drqmps , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
		 current_dev_drqm_pct  ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
		 current_dev_d_await  ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
		 current_dev_dareq_sz  ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
		 current_dev_aqu_sz  ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
		 current_dev_util_pct  ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
		 current_dev_fps  ,  --f/s скорость выполнения запросов от flush-операций.
		 current_dev_f_await    --f_await Среднее время выполнения запросов от flush-операций.
	);
--Сохранить текущие значения	
	
--Скользящие медианы
	--r/s Количество операций чтения в секунду.
	SELECT (percentile_cont(0.5) within group (order by dev_rps))::numeric
	INTO dev_rps_long
	FROM os_stat_iostat_device osd
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;	
	IF dev_rps_long IS NULL THEN dev_rps_long = 0 ; END IF ; 

	--rMB/s Скорость чтения (МБ/с).
	SELECT (percentile_cont(0.5) within group (order by dev_rmbs))::numeric
	INTO dev_rmbs_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_rmbs_long IS NULL THEN dev_rmbs_long = 0 ; END IF ; 

	--rrqm/s Количество прочитанных запросов; слитых в очередь (merge) в секунду.
	SELECT (percentile_cont(0.5) within group (order by dev_rrqmps))::numeric
	INTO dev_rrqmps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_rrqmps_long IS NULL THEN dev_rrqmps_long = 0 ; END IF ; 

	--%rrqm Процент операций чтения; слитых перед отправкой на устройство.
	SELECT (percentile_cont(0.5) within group (order by dev_rrqm_pct))::numeric
	INTO dev_rrqm_pct_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_rrqm_pct_long IS NULL THEN dev_rrqm_pct_long = 0 ; END IF ; 

	--r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	SELECT (percentile_cont(0.5) within group (order by dev_r_await))::numeric
	INTO dev_r_await_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_r_await_long IS NULL THEN dev_r_await_long = 0 ; END IF ; 
	
	--rareq_sz Средний размер запроса чтения (в КБ).
	SELECT (percentile_cont(0.5) within group (order by dev_rareq_sz))::numeric
	INTO dev_rareq_sz_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_rareq_sz_long IS NULL THEN dev_rareq_sz_long = 0 ; END IF ; 
	
	--w/s Количество операций записи в секунду.
	SELECT (percentile_cont(0.5) within group (order by dev_wps))::numeric
	INTO dev_wps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_wps_long IS NULL THEN dev_wps_long = 0 ; END IF ; 
	
	--wMB/s Скорость записи (МБ/с).
	SELECT (percentile_cont(0.5) within group (order by dev_wmbps))::numeric
	INTO dev_wmbps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_wmbps_long IS NULL THEN dev_wmbps_long = 0 ; END IF ; 
	
	--wrqm/s Количество записанных запросов; слитых в очередь в секунду.
	SELECT (percentile_cont(0.5) within group (order by dev_wrqmps))::numeric
	INTO dev_wrqmps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_wrqmps_long IS NULL THEN dev_wrqmps_long = 0 ; END IF ; 
	
	--%wrqm Процент операций записи; слитых перед отправкой на устройство.
	SELECT (percentile_cont(0.5) within group (order by dev_wrqm_pct))::numeric
	INTO dev_wrqm_pct_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_wrqm_pct_long IS NULL THEN dev_wrqm_pct_long = 0 ; END IF ;
	
	--w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	SELECT (percentile_cont(0.5) within group (order by dev_w_await))::numeric
	INTO dev_w_await_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_w_await_long IS NULL THEN dev_w_await_long = 0 ; END IF ;
	
	--wareq_sz Средний размер запроса записи (в КБ).
	SELECT (percentile_cont(0.5) within group (order by dev_wareq_sz))::numeric
	INTO dev_wareq_sz_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_wareq_sz_long IS NULL THEN dev_wareq_sz_long = 0 ; END IF ;
	
	--d/s Операции для discard-запросов (актуально для SSD).
	SELECT (percentile_cont(0.5) within group (order by dev_dps))::numeric
	INTO dev_dps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_dps_long IS NULL THEN dev_dps_long = 0 ; END IF ;
	
	--dMB/s скорость для discard-запросов (актуально для SSD).
	SELECT (percentile_cont(0.5) within group (order by dev_dmbps))::numeric
	INTO dev_dmbps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_dmbps_long IS NULL THEN dev_dmbps_long = 0 ; END IF ;
	
	--drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	SELECT (percentile_cont(0.5) within group (order by dev_drqmps))::numeric
	INTO dev_drqmps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_drqmps_long IS NULL THEN dev_drqmps_long = 0 ; END IF ;
	
	--%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	SELECT (percentile_cont(0.5) within group (order by dev_drqm_pct))::numeric
	INTO dev_drqm_pct_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_drqm_pct_long IS NULL THEN dev_drqm_pct_long = 0 ; END IF ;
	
	--d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	SELECT (percentile_cont(0.5) within group (order by dev_d_await))::numeric
	INTO dev_d_await_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_d_await_long IS NULL THEN dev_d_await_long = 0 ; END IF ;
	
	--dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	SELECT (percentile_cont(0.5) within group (order by dev_d_await))::numeric
	INTO dev_dareq_sz_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_dareq_sz_long IS NULL THEN dev_dareq_sz_long = 0 ; END IF ;

	--aqu_sz Средняя длина очереди запросов (глубина очереди).
	SELECT (percentile_cont(0.5) within group (order by dev_aqu_sz))::numeric
	INTO dev_aqu_sz_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_aqu_sz_long IS NULL THEN dev_aqu_sz_long = 0 ; END IF ;

	--%util Процент загрузки устройства (чем ближе к 100%; тем выше нагрузка).
	SELECT (percentile_cont(0.5) within group (order by dev_util_pct))::numeric
	INTO dev_util_pct_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_util_pct_long IS NULL THEN dev_util_pct_long = 0 ; END IF ;
	
	--f/s скорость выполнения запросов от flush-операций.
	SELECT (percentile_cont(0.5) within group (order by dev_fps))::numeric
	INTO dev_fps_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_fps_long IS NULL THEN dev_fps_long = 0 ; END IF ;

	--f_await Среднее время выполнения запросов от flush-операций.
	SELECT (percentile_cont(0.5) within group (order by dev_f_await))::numeric
	INTO dev_f_await_long
	FROM os_stat_iostat_device osd 
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp AND osd.device = device_name ;
	IF dev_f_await_long IS NULL THEN dev_f_await_long = 0 ; END IF ;
--Скользящие медианы

--Сохранить статистические данные
	INSERT INTO  os_stat_iostat_device_analysis
	(
		iostat_analysis_device ,
		curr_timestamp ,
		iostat_analysis_dev_rps_long   ,  --r/s Количество операций чтения в секунду.
		iostat_analysis_dev_rmbs_long  ,  --rMB/s Скорость чтения (МБ/с).
		iostat_analysis_dev_rrqmps_long ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
		iostat_analysis_dev_rrqm_pct_long ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
		iostat_analysis_dev_r_await_long  ,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
		iostat_analysis_dev_rareq_sz_long ,  --rareq_sz Средний размер запроса чтения (в КБ).
		iostat_analysis_dev_wps_long  , --w/s Количество операций записи в секунду.
		iostat_analysis_dev_wmbps_long  ,  --wMB/s Скорость записи (МБ/с).
		iostat_analysis_dev_wrqmps_long ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
		iostat_analysis_dev_wrqm_pct_long  ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
		iostat_analysis_dev_w_await_long   ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
		iostat_analysis_dev_wareq_sz_long  ,  --wareq_sz Средний размер запроса записи (в КБ).
		iostat_analysis_dev_dps_long ,  --d/s Операции для discard-запросов (актуально для SSD).
		iostat_analysis_dev_dmbps_long ,  --dMB/s скорость для discard-запросов (актуально для SSD).
		iostat_analysis_dev_drqmps_long , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
		iostat_analysis_dev_drqm_pct_long ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
		iostat_analysis_dev_d_await_long  ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
		iostat_analysis_dev_dareq_sz_long ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
		iostat_analysis_dev_aqu_sz_long   ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
		iostat_analysis_dev_util_pct_long ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
		iostat_analysis_dev_fps_long   ,  --f/s скорость выполнения запросов от flush-операций.
		iostat_analysis_dev_f_await_long --f_await Среднее время выполнения запросов от flush-операций.
	)
	VALUES 
	(
		device_name ,
		max_timestamp ,
		 dev_rps_long ,  --r/s Количество операций чтения в секунду.
		 dev_rmbs_long ,  --rMB/s Скорость чтения (МБ/с).
		 dev_rrqmps_long ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
		 dev_rrqm_pct_long ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
		 dev_r_await_long ,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
		 dev_rareq_sz_long ,  --rareq_sz Средний размер запроса чтения (в КБ).
		 dev_wps_long , --w/s Количество операций записи в секунду.
		 dev_wmbps_long ,  --wMB/s Скорость записи (МБ/с).
		 dev_wrqmps_long ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
		 dev_wrqm_pct_long ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
		 dev_w_await_long ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
		 dev_wareq_sz_long ,  --wareq_sz Средний размер запроса записи (в КБ).
		 dev_dps_long ,  --d/s Операции для discard-запросов (актуально для SSD).
		 dev_dmbps_long ,  --dMB/s скорость для discard-запросов (актуально для SSD).
		 dev_drqmps_long , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
		 dev_drqm_pct_long ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
		 dev_d_await_long ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
		 dev_dareq_sz_long ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
		 dev_aqu_sz_long ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
		 dev_util_pct_long ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
		 dev_fps_long ,  --f/s скорость выполнения запросов от flush-операций.
		 dev_f_await_long --f_await Среднее время выполнения запросов от flush-операций.
	
	);
--Сохранить статистические данные

EXCEPTION
    WHEN invalid_text_representation THEN
            -- Логируем ошибку, но не прерываем функцию
            RAISE NOTICE 'Не удалось преобразовать значение "%"', iostat_string;
    END;	
-- EXCEPTION 	
--------------------------------------------------------

RETURN QUERY
SELECT 
	iostat_analysis_device   ,  		    --Device	
	iostat_analysis_dev_rps_long   ,  --r/s Количество операций чтения в секунду.
	iostat_analysis_dev_rmbs_long   ,  --rMB/s Скорость чтения (МБ/с).
	iostat_analysis_dev_rrqmps_long   ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
	iostat_analysis_dev_rrqm_pct_long   ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
	iostat_analysis_dev_r_await_long   ,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	iostat_analysis_dev_rareq_sz_long   ,  --rareq_sz Средний размер запроса чтения (в КБ).
	iostat_analysis_dev_wps_long   , --w/s Количество операций записи в секунду.
	iostat_analysis_dev_wmbps_long   ,  --wMB/s Скорость записи (МБ/с).
	iostat_analysis_dev_wrqmps_long   ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
	iostat_analysis_dev_wrqm_pct_long   ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
	iostat_analysis_dev_w_await_long   ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	iostat_analysis_dev_wareq_sz_long   ,  --wareq_sz Средний размер запроса записи (в КБ).
	iostat_analysis_dev_dps_long   ,  --d/s Операции для discard-запросов (актуально для SSD).
	iostat_analysis_dev_dmbps_long   ,  --dMB/s скорость для discard-запросов (актуально для SSD).
	iostat_analysis_dev_drqmps_long   , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	iostat_analysis_dev_drqm_pct_long   ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	iostat_analysis_dev_d_await_long   ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	iostat_analysis_dev_dareq_sz_long   ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	iostat_analysis_dev_aqu_sz_long   ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	iostat_analysis_dev_util_pct_long   ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
	iostat_analysis_dev_fps_long   ,  --f/s скорость выполнения запросов от flush-операций.
	iostat_analysis_dev_f_await_long    --f_await Среднее время выполнения запросов от flush-операций.
FROM
	os_stat_iostat_device_analysis
WHERE 
	curr_timestamp = max_timestamp AND
	iostat_analysis_device = device_name ;


END
$$ LANGUAGE plpgsql; 