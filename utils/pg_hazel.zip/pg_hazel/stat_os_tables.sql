-- stat_os_tables.sql
-- version 75.0
--Статистика уровня ОС 

--vmstat
--vmstat -S M -t 
--procs: запущенные процессы (r — выполняемые, b — заблокированные).
--memory: статистика использования памяти.
--swap: сведения об использовании файла подкачки.
--io: активность ввода-вывода.
--system: системные прерывания и переключения контекста.
--cpu: нагрузка на центральный процессор.
--
--Группа	Поля	Что показывает
--procs	r, b	r — процессы в run queue (готовы к выполнению), b — процессы в uninterruptible sleep (обычно ждут IO)
--memory	swpd, free, buff, cache	swpd — объём свопа, free — свободная RAM, buff — буферы, cache — кэш
--swap	si, so	si — swap in (из swap в RAM), so — swap out (из RAM в swap)
--io	bi, bo	bi — блоки, считанные с устройств, bo — записанные на устройства
--system	in, cs	in — прерывания, cs — переключения контекста
--cpu	us, sy, id, wa, st	us — user time, sy — system time, id — idle, wa — ожидание IO, st — stolen (украдено гипервизором)

DROP TABLE IF EXISTS os_stat_vmstat;
CREATE UNLOGGED TABLE os_stat_vmstat 
(
  
	id SERIAL , 	
	curr_timestamp timestamp with time zone , 

	procs_r integer , -- r — процессы в run queue (готовы к выполнению)
	procs_b integer , -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	memory_swpd integer , -- swpd — объём свопа
	memory_free integer , -- free — свободная RAM
	memory_buff integer , -- buff — буферы
	memory_cache integer ,-- cache — кэш
	
	swap_si integer , -- si — swap in (из swap в RAM)
	swap_so integer , -- so — swap out (из RAM в swap)
	
	io_bi bigint, -- bi — блоки, считанные с устройств
	io_bo bigint, -- bo — записанные на устройства 
	
	system_in bigint, -- in — прерывания
	system_cs bigint, -- cs — переключения контекста
	
	cpu_us integer , -- us — user time
	cpu_sy  integer , -- sy — system time
	cpu_id  integer , -- id — idle
	cpu_wa  integer , --  wa — ожидание IO
	cpu_st integer	  --  st — stolen (украдено гипервизором)
);

--Скользящие медианы
DROP TABLE IF EXISTS os_stat_vmstat_analysis;
CREATE UNLOGGED TABLE os_stat_vmstat_analysis 
(
	id SERIAL , 
	curr_timestamp timestamp with time zone , 
	
	vmstat_analysis_procs_r_long numeric , -- r — процессы в run queue (готовы к выполнению)
	vmstat_analysis_procs_r_source numeric , -- ИСХОДНОЕ ЗНАЧЕНИЕ r — процессы в run queue (готовы к выполнению)
	vmstat_analysis_procs_b_long numeric , -- b — процессы в uninterruptible sleep (обычно ждут IO)
	
	vmstat_analysis_memory_swpd_long numeric , -- swpd — объём свопа
	vmstat_analysis_memory_free_long numeric , -- free — свободная RAM
	vmstat_analysis_memory_buff_long numeric , -- buff — буферы
	vmstat_analysis_memory_cache_long numeric ,-- cache — кэш
	
	vmstat_analysis_swap_si_long numeric , -- si — swap in (из swap в RAM)
	vmstat_analysis_swap_so_long numeric , -- so — swap out (из RAM в swap)
	
	vmstat_analysis_swap_si_source numeric , -- ИСХОДНОЕ ЗНАЧЕНИЕ si — swap in (из swap в RAM)
	vmstat_analysis_swap_so_source numeric , -- ИСХОДНОЕ ЗНАЧЕНИЕ so — swap out (из RAM в swap)
	
	vmstat_analysis_io_bi_long numeric, -- bi — блоки, считанные с устройств
	vmstat_analysis_io_bo_long numeric, -- bo — записанные на устройства 
	
	vmstat_analysis_system_in_long numeric, -- in — прерывания
	vmstat_analysis_system_cs_long numeric, -- cs — переключения контекста
	
	vmstat_analysis_cpu_us_long numeric , -- us — user time
	vmstat_analysis_cpu_sy_long numeric , -- sy — system time
	vmstat_analysis_cpu_id_long numeric , -- id — idle
	vmstat_analysis_cpu_id_source numeric , -- ИСХОДНОЕ ЗНАЧЕНИЕ id — idle
	vmstat_analysis_cpu_wa_long numeric , --  wa — ожидание IO
	vmstat_analysis_cpu_wa_source numeric , --  ИСХОДНОЕ ЗНАЧЕНИЕ wa — ожидание IO
	vmstat_analysis_cpu_st_long numeric , 	  --  st — stolen (украдено гипервизором)
	vmstat_analysis_cpu_st_source numeric  	  --  ИСХОДНОЕ ЗНАЧЕНИЕ st — stolen (украдено гипервизором)
	
);
-- Индексы и ограничения 
ALTER TABLE os_stat_vmstat ADD CONSTRAINT os_stat_vmstat_pk PRIMARY KEY (id);
CREATE INDEX os_stat_vmstat_idx ON os_stat_vmstat ( curr_timestamp );

ALTER TABLE os_stat_vmstat_analysis ADD CONSTRAINT os_stat_vmstat_analysis_pk PRIMARY KEY (id);
CREATE INDEX os_stat_vmstat_analysis_idx ON os_stat_vmstat_analysis ( curr_timestamp );


---------------------------------------------------------------------------------------------------------------------------
-- iostat
--avg-cpu:  %user   %nice %system %iowait  %steal   %idle
--           5.50    0.00    4.04    0.38    0.00   90.07
--Device            r/s     rMB/s   rrqm/s  %rrqm r_await rareq-sz     w/s     wMB/s   wrqm/s  %wrqm w_await wareq-sz     d/s     dMB/s   drqm/s  %drqm d_await dareq-sz     f/s f_await  aqu-sz  %util
--dm-0             0.12      0.00     0.00   0.00    3.13     4.90    0.62      0.00     0.00   0.00    0.53     4.79    0.00      0.00     0.00   0.00    0.00     0.00    0.00    0.00    0.00   0.09
--
--CPU
--%user - процент использования процессора программами, запущенными на уровне пользователя;
--%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
--%system - процент использования процессора ядром;
--%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
--%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
--%idle - процент времени пока процессор не занят ничем.
--
--DEVICE
--r/s Количество операций чтения в секунду.
--rMB/s Скорость чтения (МБ/с).
--rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
--%rrqm Процент операций чтения, слитых перед отправкой на устройство.
--r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
--rareq-sz Средний размер запроса чтения (в КБ).
--w/s Количество операций записи в секунду.
--wMB/s Скорость записи (МБ/с).
--wrqm/s Количество записанных запросов, слитых в очередь в секунду.
--%wrqm Процент операций записи, слитых перед отправкой на устройство.
--w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
--wareq-sz Средний размер запроса записи (в КБ).
--d/s Операции для discard-запросов (актуально для SSD).
--dMB/s скорость для discard-запросов (актуально для SSD).
--drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
--%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
--d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
--dareq-sz Средний размер для discard-запросов (актуально для SSD)..
--aqu-sz Средняя длина очереди запросов (глубина очереди).
--%utilПроцент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
--f/s скорость выполнения запросов от flush-операций.
--f_await Среднее время выполнения запросов от flush-операций.
DROP TABLE IF EXISTS os_stat_iostat_cpu;
CREATE UNLOGGED TABLE os_stat_iostat_cpu 
(
  
	id SERIAL , 	
	curr_timestamp timestamp with time zone ,
	
--CPU
	cpu_user_pct double precision , --%user - процент использования процессора программами, запущенными на уровне пользователя;
	cpu_nice_pct double precision ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	cpu_system_pct double precision ,  --%system - процент использования процессора ядром;
	cpu_iowait_pct double precision ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	cpu_steal_pct double precision ,  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	cpu_idle_pct double precision   --%idle - процент времени пока процессор не занят ничем.	

);

DROP TABLE IF EXISTS os_stat_iostat_device;
CREATE UNLOGGED TABLE os_stat_iostat_device 
(
  
	id SERIAL , 	
	curr_timestamp timestamp with time zone ,

--DEVICE
	device  text ,  		    --Device
	dev_rps double precision ,  --r/s Количество операций чтения в секунду.
	dev_rmbs double precision ,  --rMB/s Скорость чтения (МБ/с).
	dev_rrqmps double precision ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
	dev_rrqm_pct double precision ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
	dev_r_await double precision ,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	dev_rareq_sz double precision ,  --rareq-sz Средний размер запроса чтения (в КБ).
	dev_wps double precision , --w/s Количество операций записи в секунду.
	dev_wmbps double precision ,  --wMB/s Скорость записи (МБ/с).
	dev_wrqmps double precision ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
	dev_wrqm_pct double precision ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
	dev_w_await double precision ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	dev_wareq_sz double precision ,  --wareq_sz Средний размер запроса записи (в КБ).
	dev_dps double precision ,  --d/s Операции для discard-запросов (актуально для SSD).
	dev_dmbps double precision ,  --dMB/s скорость для discard-запросов (актуально для SSD).
	dev_drqmps double precision , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	dev_drqm_pct double precision ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	dev_d_await double precision ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	dev_dareq_sz double precision ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	dev_aqu_sz double precision ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	dev_util_pct double precision ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
	dev_fps double precision ,  --f/s скорость выполнения запросов от flush-операций.
	dev_f_await double precision  --f_await Среднее время выполнения запросов от flush-операций.	
		
);

--Скользящие медианы
DROP TABLE IF EXISTS os_stat_iostat_cpu_analysis;
CREATE UNLOGGED TABLE os_stat_iostat_cpu_analysis 
(
	id SERIAL , 
	curr_timestamp timestamp with time zone ,	

--CPU
	iostat_analysis_cpu_user_pct_long  numeric , --%user - процент использования процессора программами, запущенными на уровне пользователя;
	iostat_analysis_cpu_nice_pct_long  numeric ,  --%nice - процент использования процессора программами запущенными тоже в пространстве пользователя, но только с изменённым приоритетом;
	iostat_analysis_cpu_system_pct_long  numeric ,  --%system - процент использования процессора ядром;
	iostat_analysis_cpu_iowait_pct_long  numeric ,  --%iowait - процент времени затраченного на ожидание завершения операций ввода/вывода;
	iostat_analysis_cpu_steal_pct_long  numeric ,  --%steal - процент простоя виртуального процессора, пока гипервизор отдаёт мощность другому виртуальному процессору;
	iostat_analysis_cpu_idle_pct_long  numeric   --%idle - процент времени пока процессор не занят ничем.	
);

--Скользящие медианы
DROP TABLE IF EXISTS os_stat_iostat_device_analysis;
CREATE UNLOGGED TABLE os_stat_iostat_device_analysis 
(
	id SERIAL , 
	curr_timestamp timestamp with time zone ,	
--DEVICE
	iostat_analysis_device  text ,  		    --Device
	iostat_analysis_dev_rps_long  numeric ,  --r/s Количество операций чтения в секунду.
	iostat_analysis_dev_rmbs_long  numeric ,  --rMB/s Скорость чтения (МБ/с).
	iostat_analysis_dev_rrqmps_long  numeric ,  --rrqm/s Количество прочитанных запросов, слитых в очередь (merge) в секунду.
	iostat_analysis_dev_rrqm_pct_long  numeric ,  --%rrqm Процент операций чтения, слитых перед отправкой на устройство.
	iostat_analysis_dev_r_await_long  numeric ,  --r_await (мс) Среднее время выполнения запросов чтения (включая время в очереди).
	iostat_analysis_dev_rareq_sz_long  numeric ,  --rareq_sz Средний размер запроса чтения (в КБ).
	iostat_analysis_dev_wps_long  numeric , --w/s Количество операций записи в секунду.
	iostat_analysis_dev_wmbps_long  numeric ,  --wMB/s Скорость записи (МБ/с).
	iostat_analysis_dev_wrqmps_long  numeric ,  --wrqm/s Количество записанных запросов, слитых в очередь в секунду.
	iostat_analysis_dev_wrqm_pct_long  numeric ,  --%wrqm Процент операций записи, слитых перед отправкой на устройство.
	iostat_analysis_dev_w_await_long  numeric ,  --w_await (мс) Среднее время выполнения запросов записи (включая время в очереди).
	iostat_analysis_dev_wareq_sz_long  numeric ,  --wareq_sz Средний размер запроса записи (в КБ).
	iostat_analysis_dev_dps_long  numeric ,  --d/s Операции для discard-запросов (актуально для SSD).
	iostat_analysis_dev_dmbps_long  numeric ,  --dMB/s скорость для discard-запросов (актуально для SSD).
	iostat_analysis_dev_drqmps_long  numeric , --drqm/s Количество запросов, слитых в очередь в секунду для discard-запросов (актуально для SSD).
	iostat_analysis_dev_drqm_pct_long  numeric ,  --%drqm Процент операций слитых перед отправкой на устройство для discard-запросов (актуально для SSD).
	iostat_analysis_dev_d_await_long  numeric ,  --d_await Среднее время выполнения (включая время в очереди) для discard-запросов (актуально для SSD).
	iostat_analysis_dev_dareq_sz_long  numeric ,  --dareq_sz Средний размер для discard-запросов (актуально для SSD)..
	iostat_analysis_dev_aqu_sz_long  numeric ,  --aqu_sz Средняя длина очереди запросов (глубина очереди).
	iostat_analysis_dev_util_pct_long  numeric ,  --%util Процент загрузки устройства (чем ближе к 100%, тем выше нагрузка).
	iostat_analysis_dev_fps_long  numeric ,  --f/s скорость выполнения запросов от flush-операций.
	iostat_analysis_dev_f_await_long  numeric   --f_await Среднее время выполнения запросов от flush-операций.	
);

-- Индексы и ограничения 
ALTER TABLE os_stat_iostat_cpu ADD CONSTRAINT os_stat_iostat_cpu_pk PRIMARY KEY (id);
CREATE INDEX os_stat_iostat_cpu_idx ON os_stat_iostat_cpu ( curr_timestamp );

ALTER TABLE os_stat_iostat_device ADD CONSTRAINT os_stat_iostat_device_pk PRIMARY KEY (id);
CREATE INDEX os_stat_iostat_device_idx ON os_stat_iostat_device ( curr_timestamp );
CREATE INDEX os_stat_iostat_device_idx2 ON os_stat_iostat_device ( device );

ALTER TABLE os_stat_iostat_cpu_analysis ADD CONSTRAINT os_stat_iostat_cpu_analysis_pk PRIMARY KEY (id);
CREATE INDEX os_stat_iostat_cpu_analysis_idx ON os_stat_iostat_cpu_analysis ( curr_timestamp );

ALTER TABLE os_stat_iostat_device_analysis ADD CONSTRAINT os_stat_iostat_device_analysis_pk PRIMARY KEY (id);
CREATE INDEX os_stat_iostat_device_analysis_idx ON os_stat_iostat_device_analysis ( curr_timestamp );
CREATE INDEX os_stat_iostat_device_analysis_idx2 ON os_stat_iostat_device_analysis ( iostat_analysis_device );