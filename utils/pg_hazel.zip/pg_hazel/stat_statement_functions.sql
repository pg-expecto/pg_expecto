﻿-- stat_statement_functions.sql
-- version 78.0
-- Статистика производительности по отдельному SQL запросу
/*
save_source_stat_statement() - собрать исходные данные в таблицу stat_statement
start_sql_stats() - начать агрегирование
calculate_sql_stats - агрегирование за минуту 
check_pgpro_pwr_sample_for_current_timestamp - проверить создан ли новый снимок на текущее время
is_new_pgpro_pwr_sample_for_cluster - проверить создан ли новый снимок для статистики кластера
is_new_pgpro_pwr_sample_for_sql - проверить создан ли новый снимок для статистики SQL
prepare_stat_statement_analysis - агрегирование за минуту 
*/

CREATE OR REPLACE FUNCTION 	save_source_stat_statement() RETURNS integer 
AS $$
DECLARE
  curr_datname name ;
  curr_username name ;
  curr_pgpro_pwr_sample timestamp with time zone  ; 
  pgpro_pwr_samples_count integer ;
BEGIN
		
	SELECT MAX(p.curr_timestamp)
	INTO curr_pgpro_pwr_sample 
	FROM pgpro_pwr_samples p; 
	
	INSERT INTO stat_statement
	(
		pgpro_pwr_sample , 
		dbname , 
		username , 
		queryid  ,  		 		--queryid тестового запроса
		curr_timestamp  , 
		curr_wait_stats ,  --Объект типа jsonb, содержащий статистику по событиям ожидания для каждого выполнения запроса по соответствующему плану
		curr_calls ,
		curr_rows ,
		delta_calls ,
		delta_rows 
	)
	SELECT
    curr_pgpro_pwr_sample , 
    d.datname,
    (SELECT rolname FROM pg_roles WHERE oid = s.userid) AS rolname,
    s.queryid,
    date_trunc('minute', CURRENT_TIMESTAMP) AS ts,
    s.wait_stats,
    s.calls,
    s.rows , 
	s.calls,
    s.rows 
	FROM
    pgpro_stats_statements(FALSE) s
    CROSS JOIN LATERAL (
        SELECT datname
        FROM pg_database
        WHERE oid = s.dbid
    ) d
	WHERE
    s.dbid NOT IN (
        SELECT oid
        FROM pg_database
        WHERE datname IN ('postgres', 'template1', 'template0', 'pgpropwr', 'performance_monitoring_db')
    )
    AND s.dbid IS NOT NULL
    AND s.userid IS NOT NULL
    AND s.queryid IS NOT NULL	
	ON CONFLICT ON CONSTRAINT stat_statement_pk DO NOTHING;
			
	return 0 ;
	
END
$$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION 	start_sql_stats() RETURNS text 
AS $$
DECLARE
  pgpwr_pro_sample_count integer ; 
  sql_stats_history_count integer ;
  min_sql_stats_history timestamp with time zone ;
  max_sql_stats_history timestamp with time zone ;
  min_stat_statement timestamp with time zone ;
  next_stat_statement timestamp with time zone ;
  min_timestamp timestamptz ;  
BEGIN
	SELECT 
		COUNT(curr_timestamp) 
	INTO	
		pgpwr_pro_sample_count
	FROM 
		pgpro_pwr_samples ; 

	
	IF pgpwr_pro_sample_count < 2
	THEN 
		return 'INSUFFICIENT_DATA';
	END IF ;
	
	SELECT 
		MIN(timepoint)
	INTO 
		min_sql_stats_history
	FROM 
		sql_stats_history ;
		
	
	IF min_sql_stats_history IS NULL 
	THEN 	
		SELECT 
			MIN(curr_timestamp)
		INTO 
			min_stat_statement
		FROM 
			stat_statement ;
			
		-------------------------------------------------------------
		-- ПЕРВЫЙ ОТРЕЗОК
		return to_char( min_stat_statement , 'YYYY-MM-DD HH24:MI') ;
		-- ПЕРВЫЙ ОТРЕЗОК
		-------------------------------------------------------------
	END IF ;
	
	SELECT 
		MAX(timepoint)
	INTO 
		max_sql_stats_history
	FROM 
		sql_stats_history ;		

	-------------------------------------------------------------
	-- ПЕРЕЙТИ К СЛЕДУЮЩЕМУ МИНУТНОМУ ОТРЕЗКУ
	next_stat_statement = max_sql_stats_history + interval '1 minute';
	
	return to_char( next_stat_statement , 'YYYY-MM-DD HH24:MI') ;
	-- ПЕРЕЙТИ К СЛЕДУЮЩЕМУ МИНУТНОМУ ОТРЕЗКУ
	-------------------------------------------------------------
END
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION 	calculate_sql_stats( start_timestamp text ) RETURNS integer 
AS $$
DECLARE
  min_timestamp timestamptz ;
  max_timestamp timestamptz ;
  res integer ;
BEGIN

    	
	SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
	INTO 	min_timestamp ; 	
	
	SELECT 	min_timestamp + interval '1 minute' 
	INTO 	max_timestamp ; 	
	
	
	SELECT prepare_stat_statement_analysis( to_char( min_timestamp , 'YYYY-MM-DD HH24:MI ') , 
											to_char( max_timestamp , 'YYYY-MM-DD HH24:MI ') )
	INTO res ;
	
	INSERT INTO sql_stats_history 
	(
		timepoint
	)
	VALUES 
	(
		min_timestamp
	);

	
return res ;

END
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION 	check_pgpro_pwr_sample_for_current_timestamp() RETURNS integer AS $$
DECLARE
check_pgpro_pwr_sample boolean ;
BEGIN
	
	SELECT is_new_pgpro_pwr_sample_for_cluster( CURRENT_TIMESTAMP )
	INTO check_pgpro_pwr_sample ;
	
	IF check_pgpro_pwr_sample
	THEN 
		return 1 ; 
	ELSE	
		return 0 ; 
	END IF ;
END
$$ LANGUAGE plpgsql  ;

CREATE OR REPLACE FUNCTION 	is_new_pgpro_pwr_sample_for_cluster( test_timestamp timestamptz  ) RETURNS BOOLEAN AS $$
DECLARE
is_new_pgpro_pwr_sample_flag boolean ;
pgpro_pwr_samples_count integer ;
max_curr_timestamp_pgpro_pwr_samples timestamptz;
count_pgh_stat_cluster integer ;
BEGIN
	
	SELECT 
		MAX(curr_timestamp) 
	INTO	
		max_curr_timestamp_pgpro_pwr_samples
	FROM 
		pgpro_pwr_samples 
	WHERE 
		curr_timestamp <= test_timestamp;
--78.0
/*		
RAISE NOTICE 'max_curr_timestamp_pgpro_pwr_samples=%',max_curr_timestamp_pgpro_pwr_samples ;
*/
    SELECT 
		count(curr_timestamp) 
	INTO 
		count_pgh_stat_cluster
	FROM 
		pgh_stat_cluster
	WHERE 
		curr_timestamp BETWEEN max_curr_timestamp_pgpro_pwr_samples AND test_timestamp ; 
--78.0
/*			
RAISE NOTICE 'count_pgh_stat_cluster=%',count_pgh_stat_cluster ;	
*/

    ---------------------------------------------
	-- ПЕРВАЯ ТОЧКА В ОТРЕЗКЕ 
	IF count_pgh_stat_cluster = 0 
	THEN 
		return TRUE ;
	ELSE 
		return FALSE ;
	END IF ; 
	-- ПЕРВАЯ ТОЧКА В ОТРЕЗКЕ 
	---------------------------------------------
	

END
$$ LANGUAGE plpgsql  ;

-- Если был сделан новый снимок pgpro_pwr 
CREATE OR REPLACE FUNCTION 	is_new_pgpro_pwr_sample_for_sql( test_timestamp timestamptz  ) RETURNS BOOLEAN AS $$
DECLARE
pgpro_pwr_sample_time timestamptz ; 
delta_timestamp timestamptz ;
is_new_pgpro_pwr_sample_flag BOOLEAN ; 
flag BOOLEAN;
min_sql_stats_history timestamptz ; 
count_timepoint_sql_stats_history integer ;
max_curr_timestamp_pgpro_pwr_samples timestamptz ;
pgpro_pwr_samples_count integer  ;
BEGIN

	SELECT 
		MAX(curr_timestamp) 
	INTO	
		max_curr_timestamp_pgpro_pwr_samples
	FROM 
		pgpro_pwr_samples 
	WHERE 
		curr_timestamp <= test_timestamp;
--78.0
/*				
RAISE NOTICE 'max_curr_timestamp_pgpro_pwr_samples=%',max_curr_timestamp_pgpro_pwr_samples ;			
*/
	
	SELECT 
		count(timepoint) 
	INTO 
		count_timepoint_sql_stats_history
	FROM 
		sql_stats_history
	WHERE 
		timepoint BETWEEN max_curr_timestamp_pgpro_pwr_samples AND test_timestamp ; 
--78.0
/*				
RAISE NOTICE 'count_timepoint_sql_stats_history=%',count_timepoint_sql_stats_history ;					
*/

	---------------------------------------------
	-- ПЕРВАЯ ТОЧКА В ОТРЕЗКЕ 
	IF count_timepoint_sql_stats_history = 0 
	THEN 
		return TRUE ;
	ELSE 
		return FALSE ;
	END IF ; 
	-- ПЕРВАЯ ТОЧКА В ОТРЕЗКЕ 
	---------------------------------------------
	
END
$$ LANGUAGE plpgsql  ;

CREATE OR REPLACE FUNCTION 	prepare_stat_statement_analysis( start_timestamp text , finish_timestamp text   ) RETURNS integer 
AS $$
DECLARE
  min_timestamp timestamptz ;
  max_timestamp timestamptz ;
  res integer ;
  stat_statement_rec record ;
  current_wait_stats jsonb ;  
  --wait_event_type_jsonb jsonb ;  
  wait_event_type_rec record ; 
  wait_event_rec record ; 
  
  current_dbid oid ; 
  current_userid oid ;
  current_queryid bigint ; 
  curr_datname name ;
  curr_username name ;
  
  current_value integer ;
  
  current_bufferpin  bigint  ;
  current_extension  bigint  ;
  current_io  bigint  ;
  current_ipc  bigint  ;
  current_lock  bigint  ;
  current_lwlock  bigint  ;
  current_timeout  bigint  ;
  
  current_calls numeric ; 
  current_rows numeric ; 
  current_delta_calls numeric ; 
  current_delta_rows numeric ; 
  
  
  current_wait_event_type_jsonb jsonb;
  
  current_stat_statement_rec record ; 
  
  current_delta_bufferpin  bigint  ;
  current_delta_extension  bigint  ;
  current_delta_io  bigint  ;
  current_delta_ipc  bigint  ;
  current_delta_lock  bigint  ;
  current_delta_lwlock  bigint    ;
  current_delta_timeout  bigint    ;
  
  curr_waiting_events_short numeric ;
  curr_waiting_events_long numeric ;
  
  stat_statement_wait_events_rec record ;
  
  prev_stat_statement_wait_events_rec record ;
  prev_stat_statement_rec record ;
  
  current_delta_waitings bigint ;
  
  
  -------------------------------------
  -- Медианы
  bufferpin_long numeric ;
  extension_long numeric ;
  io_long numeric ;
  ipc_long numeric ;
  lock_long numeric ;
  lwlock_long numeric ;
  timeout_long numeric ;

  calls_long DOUBLE PRECISION  ;	
  rows_long DOUBLE PRECISION ;
  
  current_delta_calls_long DOUBLE PRECISION ; 
  current_delta_rows_long DOUBLE PRECISION ;   
  
  -- Медианы
  -------------------------------------
  wait_event_long DOUBLE PRECISION ;
  curr_operating_speed_long numeric ; 
  
  timepoint_pct numeric;
  test_timestamp timestamptz;
  info_flag BOOLEAN;
  
  last_minute integer ;
  test_minute integer ;
    
  is_new_pgpro_pwr_sample_flag BOOLEAN ;
  
  total_rows integer ;
BEGIN
	SELECT 	date_trunc('minute' ,  to_timestamp( start_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
	INTO 	min_timestamp ; 
		
	SELECT 	date_trunc('minute' ,  to_timestamp( finish_timestamp , 'YYYY-MM-DD HH24:MI' ) ) 
	INTO 	max_timestamp ; 
	
	SELECT is_new_pgpro_pwr_sample_for_sql( min_timestamp )
	INTO is_new_pgpro_pwr_sample_flag ; 

--78.0
/*	
	IF is_new_pgpro_pwr_sample_flag
	THEN
		RAISE NOTICE ' SQL_STATEMENT_ANALYSIS : NEW_PGPRO_PWR_SAMPLE FOR % TO % ', start_timestamp , finish_timestamp ;		
	ELSE
		RAISE NOTICE ' SQL_STATEMENT_ANALYSIS : OLD_PGPRO_PWR_SAMPLE FOR % TO % ', start_timestamp , finish_timestamp ;		
	END IF ; 
*/	
	
	res = 0; 
	
	SELECT clock_timestamp() 
	INTO test_timestamp ;
--78.0
/*		
	RAISE NOTICE 'SQL_STATEMENT_ANALYSIS : started % ',test_timestamp ;
	RAISE NOTICE 'SQL_STATEMENT_ANALYSIS : min_timestamp % ',min_timestamp ;
	RAISE NOTICE 'SQL_STATEMENT_ANALYSIS : max_timestamp % ',max_timestamp ;
*/

	info_flag	= TRUE ;

	SELECT 
		count(id) 
	INTO 
		total_rows
	FROM 
		stat_statement 
	WHERE curr_timestamp 
		BETWEEN min_timestamp AND max_timestamp ; 
--78.0
/*	
	RAISE NOTICE 'SQL_STATEMENT_ANALYSIS : total % rows ', total_rows ; 
*/
	
	
	-----------------------------------------------------
	-- ИСХОДНЫЕ ДАННЫЕ 	
	FOR stat_statement_rec IN 
	SELECT *
	FROM stat_statement
	WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp
	ORDER BY id
	LOOP 
	
		current_queryid = stat_statement_rec.queryid ; 
		curr_datname  = stat_statement_rec.dbname ;
		curr_username = stat_statement_rec.username ;

		current_wait_stats = stat_statement_rec.curr_wait_stats ;
		
		SELECT to_number( ((current_wait_stats)->'Total')->>'BufferPin' , '0000000000') / 10  
		INTO current_bufferpin  ;
		IF current_bufferpin IS NULL THEN current_bufferpin = 0 ; END IF ;
		
		SELECT to_number( ((current_wait_stats)->'Total')->>'Extension' , '0000000000') / 10  
		INTO current_extension  ;
		IF current_extension IS NULL THEN current_extension = 0 ; END IF ;
		
		SELECT to_number( ((current_wait_stats)->'Total')->>'IO' , '0000000000')  / 10 
		INTO current_io  ;
		IF current_io IS NULL THEN current_io = 0 ; END IF ;
		
		SELECT to_number( ((current_wait_stats)->'Total')->>'IPC' , '0000000000')  / 10 
		INTO current_ipc  ;
		IF current_ipc IS NULL THEN current_ipc = 0 ; END IF ;
		
		SELECT to_number( ((current_wait_stats)->'Total')->>'Lock' , '0000000000')  / 10 
		INTO current_lock  ;
		IF current_lock IS NULL THEN current_lock = 0 ; END IF ;
		
		SELECT to_number( ((current_wait_stats)->'Total')->>'LWLock' , '0000000000')  / 10 
		INTO current_lwlock  ;
		IF current_lwlock IS NULL THEN current_lwlock = 0 ; END IF ;
	
		SELECT to_number( ((current_wait_stats)->'Total')->>'Timeout' , '0000000000')  / 10 
		INTO current_timeout  ;
		IF current_timeout IS NULL THEN current_timeout = 0 ; END IF ;	
		
		SELECT oid
		INTO current_dbid
		FROM pg_database
		WHERE datname = stat_statement_rec.dbname ; 
		
		SELECT oid
		INTO current_userid
		FROM pg_roles
		WHERE rolname = stat_statement_rec.username ; 
		
		current_queryid = stat_statement_rec.queryid ; 
		
--IF current_queryid = 8714894111950726696 
--THEN 
--RAISE NOTICE 'current_wait_stats=%',current_wait_stats;
--END IF ;
		
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- ЕСЛИ НОВЫЙ СНИМОК ПОСЛЕ СБРОСА СТАТИСТИКИ 
		IF is_new_pgpro_pwr_sample_flag
		THEN
			-----------------------
			--1. UPDATE stat_statement
			UPDATE stat_statement
			SET 
				curr_bufferpin = current_bufferpin ,
				curr_extension = current_extension ,
				curr_io  = current_io ,
				curr_ipc = current_ipc ,
				curr_lock = current_lock ,
				curr_lwlock = current_lwlock ,
				curr_timeout = current_timeout	,
				delta_bufferpin = current_bufferpin,
				delta_extension = current_extension,
				delta_io = current_io,
				delta_ipc = current_ipc,
				delta_lock = current_lock,
				delta_lwlock = current_lwlock,
				delta_timeout = current_timeout 
			WHERE 
				id =  stat_statement_rec.id ;
			--1. UPDATE stat_statement
			-----------------------

			------------------------------------------------------------
			--WAIT_EVENT_TYPE
			FOR wait_event_type_rec in 
			WITH wait_event_type_jsonb AS
			(
			  SELECT jsonb_object_keys (current_wait_stats)  AS wait_event_type_key 
			)
			SELECT * 
			FROM wait_event_type_jsonb	
			WHERE  wait_event_type_key NOT IN ('Total' , 'Client' , 'Activity') 	       
			LOOP 
			
				SELECT stat_statement_rec.curr_wait_stats->>wait_event_type_rec.wait_event_type_key
				INTO current_wait_event_type_jsonb ;
				
	--RAISE NOTICE 'wait_event_type_key = %' , wait_event_type_rec.wait_event_type_key ;	

				FOR wait_event_rec IN 
				WITH wait_event_jsonb AS
				(
					SELECT jsonb_object_keys( current_wait_stats->wait_event_type_rec.wait_event_type_key )  AS wait_event_key 
				)
				SELECT * 
				FROM wait_event_jsonb
				LOOP 
	--RAISE NOTICE 'wait_event = %' , wait_event_rec.wait_event_key ;
					
					SELECT to_number( current_wait_event_type_jsonb->>wait_event_rec.wait_event_key , '0000000000')  / 10 
					INTO current_value  ;


					SELECT * 
					INTO stat_statement_wait_events_rec
					FROM stat_statement_wait_events
					WHERE queryid = current_queryid AND dbname = curr_datname AND username = curr_username  AND 
						  curr_timestamp  = stat_statement_rec.curr_timestamp AND 
						  wait_event_type = wait_event_type_rec.wait_event_type_key AND 
						  wait_event = wait_event_rec.wait_event_key ; 

					---------------------------------------
					--2. INSERT INTO stat_statement_wait_events
					INSERT INTO stat_statement_wait_events
						(
							curr_timestamp ,
							dbname ,
							username , 
							queryid ,
							wait_event_type , 
							wait_event , 
							curr_value ,
							delta_value
						)
					VALUES 
						(
							stat_statement_rec.curr_timestamp , 
							curr_datname , 
							curr_username , 
							current_queryid , 
							wait_event_type_rec.wait_event_type_key  , 
							wait_event_rec.wait_event_key ,
							current_value , 
							current_value
						);
					--2. INSERT INTO stat_statement_wait_events
					---------------------------------------
					
				END LOOP; 
				--FOR wait_event_rec IN 	
				
			END LOOP;
			--FOR wait_event_type_rec in 
			--WAIT_EVENT_TYPE
			------------------------------------------------------------
			
			----------------------------------------------------------------------------
			-- МЕДИТАНЫ		
				--Долгая медиана calls	
				SELECT (percentile_cont(0.5) within group (order by delta_calls))::numeric
				INTO current_delta_calls_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
					  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF current_delta_calls_long IS NULL THEN current_delta_calls_long = 0 ; END IF ;	

				--Долгая медиана rows
				SELECT (percentile_cont(0.5) within group (order by delta_rows))::numeric
				INTO current_delta_rows_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
					  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF current_delta_rows_long IS NULL THEN current_delta_rows_long = 0 ; END IF ;	
				
				-----------------------------------------------------------------------------
				-- Долгая медиана по wait_event_type
				SELECT (percentile_cont(0.5) within group (order by delta_bufferpin))::numeric
				INTO bufferpin_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF bufferpin_long IS NULL THEN bufferpin_long = 0 ; END IF ; 
			
				SELECT (percentile_cont(0.5) within group (order by delta_extension))::numeric
				INTO extension_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF extension_long IS NULL THEN extension_long = 0 ; END IF ; 

				SELECT (percentile_cont(0.5) within group (order by delta_io))::numeric
				INTO io_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF io_long IS NULL THEN io_long = 0 ; END IF ; 
				
				SELECT (percentile_cont(0.5) within group (order by delta_ipc))::numeric
				INTO ipc_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF ipc_long IS NULL THEN ipc_long = 0 ; END IF ; 

				SELECT (percentile_cont(0.5) within group (order by delta_lock))::numeric
				INTO lock_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF lock_long IS NULL THEN lock_long = 0 ; END IF ; 

				SELECT (percentile_cont(0.5) within group (order by delta_lwlock))::numeric
				INTO lwlock_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF lwlock_long IS NULL THEN lwlock_long = 0 ; END IF ; 
				
				SELECT (percentile_cont(0.5) within group (order by delta_timeout))::numeric
				INTO timeout_long
				FROM stat_statement
				WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
				  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
				IF timeout_long IS NULL THEN timeout_long = 0 ; END IF ; 	
				-- Долгая медиана по wait_event_type
				---------------------------------------------------------------------

				--------------------------------------------------
				-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
				curr_operating_speed_long =  ( current_delta_calls_long + current_delta_rows_long  )  ;
				-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
				--------------------------------------------------
				-- ОЖИДАНИЯ  
				curr_waiting_events_long = bufferpin_long + extension_long +  io_long + ipc_long + lock_long + lwlock_long + timeout_long; 
				-- ОЖИДАНИЯ  
				--------------------------------------------------
		
				-------------------------------------------------------------------------------------------------------------------------
				--3. INSERT INTO stat_statement_analysis 
				INSERT INTO stat_statement_analysis 
				(
					dbname , 
					username , 
					queryid ,
					hex_queryid , 

					curr_timestamp, 
					
					curr_wait_stats , 
					operating_speed_long ,
					waitings_long ,
					
					bufferpin_long ,
					extension_long ,
					io_long ,
					ipc_long ,
					lock_long ,
					lwlock_long ,
					timeout_long ,
					calls_long ,
					rows_long 
				)
				VALUES 
				(
					curr_datname ,
					curr_username ,
					current_queryid , 
					to_hex( current_queryid ) ,
					
					stat_statement_rec.curr_timestamp , 
					
					current_wait_stats ,
					curr_operating_speed_long , 
					curr_waiting_events_long , 
				
					bufferpin_long , 
					extension_long , 
					io_long , 
					ipc_long , 
					lock_long , 
					lwlock_long , 
					timeout_long , 

					current_delta_calls_long , 
					current_delta_rows_long				
				);			
				--3. INSERT INTO stat_statement_analysis 
				-------------------------------------------------------------------------------------------------------------------------
			
			-----------------------
			-- СЛЕДУЮЩАЯ СТРОКА
			continue;	
			-- СЛЕДУЮЩАЯ СТРОКА
			-----------------------
			
		END IF ;
		-- ЕСЛИ НОВЫЙ СНИМОК ПОСЛЕ СБРОСА СТАТИСТИКИ 
		
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ПОСЛЕ СБРОСА СТАТИСТИКИ - ДЕЛЬТА 		
		------------------------------------------------------------------------------------------------------------------------
		-- ПРЕДЫДУЩЕЕ ЗНАЧЕНИЕ
		SELECT 	*
		INTO 	prev_stat_statement_rec
		FROM 	stat_statement
		WHERE   queryid = current_queryid AND 
				dbname = curr_datname AND 
				username = curr_username AND 
				curr_timestamp = (SELECT MAX(curr_timestamp) FROM stat_statement WHERE curr_timestamp < stat_statement_rec.curr_timestamp );

		-- ЕСЛИ ПЕРВОЕ ЗНАЧЕНИЕ 	
		IF prev_stat_statement_rec.curr_calls IS NULL 
		THEN 
			-----------------------
			--1. UPDATE stat_statement
			UPDATE stat_statement
			SET 			    
				curr_bufferpin = current_bufferpin ,
				curr_extension = current_extension ,
				curr_io  = current_io ,
				curr_ipc = current_ipc ,
				curr_lock = current_lock ,
				curr_lwlock = current_lwlock ,
				curr_timeout = current_timeout	,
				delta_bufferpin = current_bufferpin,
				delta_extension = current_extension,
				delta_io = current_io,
				delta_ipc = current_ipc,
				delta_lock = current_lock,
				delta_lwlock = current_lwlock,
				delta_timeout = current_timeout 
			WHERE 
				id =  stat_statement_rec.id ;
			--1. UPDATE stat_statement
			-----------------------
		--------------------------------------
		-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ stat_statement
		ELSE
			current_delta_calls = stat_statement_rec.curr_calls - COALESCE( prev_stat_statement_rec.curr_calls , 0 ); 
			IF current_delta_calls < 0 THEN current_delta_calls = prev_stat_statement_rec.curr_calls; END IF ;
			
			current_delta_rows =  stat_statement_rec.curr_rows -  COALESCE( prev_stat_statement_rec.curr_rows , 0 ); 
			IF current_delta_rows < 0 THEN current_delta_rows = prev_stat_statement_rec.curr_rows; END IF ;
			
			current_delta_bufferpin   = stat_statement_rec.curr_bufferpin - COALESCE( prev_stat_statement_rec.curr_bufferpin , 0 ); 
			IF current_delta_bufferpin < 0 THEN current_delta_bufferpin = prev_stat_statement_rec.curr_bufferpin; END IF ;
			
			current_delta_extension   = stat_statement_rec.curr_extension - COALESCE( prev_stat_statement_rec.curr_extension  , 0 ); 
			IF current_delta_extension < 0 THEN current_delta_extension = prev_stat_statement_rec.curr_extension; END IF ;
			
			current_delta_io   = stat_statement_rec.curr_io - COALESCE( prev_stat_statement_rec.curr_io  , 0 ); 
			IF current_delta_io < 0 THEN current_delta_io = prev_stat_statement_rec.curr_io; END IF ;
			
			current_delta_ipc   = stat_statement_rec.curr_ipc - COALESCE( prev_stat_statement_rec.curr_ipc  , 0 ); 
			IF current_delta_ipc < 0 THEN current_delta_ipc = prev_stat_statement_rec.curr_ipc; END IF ;
			
			current_delta_lock   = stat_statement_rec.curr_lock - COALESCE( prev_stat_statement_rec.curr_lock  , 0 ); 
			IF current_delta_lock < 0 THEN current_delta_lock = prev_stat_statement_rec.curr_lock; END IF ;
			
			current_delta_lwlock   = stat_statement_rec.curr_lwlock - COALESCE( prev_stat_statement_rec.curr_lwlock  , 0 ); 
			IF current_delta_lwlock < 0 THEN current_delta_lwlock = prev_stat_statement_rec.curr_lwlock; END IF ;
			
			current_delta_timeout   = stat_statement_rec.curr_timeout - COALESCE( prev_stat_statement_rec.curr_timeout  , 0 ); 
			IF current_delta_timeout < 0 THEN current_delta_timeout = prev_stat_statement_rec.curr_timeout; END IF ;
			
			-----------------------
			--1. UPDATE stat_statement
			UPDATE stat_statement
			SET 
				delta_calls = current_delta_calls ,
				delta_rows = current_delta_rows ,
				curr_bufferpin = current_bufferpin ,
				curr_extension = current_extension ,
				curr_io  = current_io ,
				curr_ipc = current_ipc ,
				curr_lock = current_lock ,
				curr_lwlock = current_lwlock ,
				curr_timeout = current_timeout	,
				delta_bufferpin = current_bufferpin,
				delta_extension = current_extension,
				delta_io = current_io,
				delta_ipc = current_ipc,
				delta_lock = current_lock,
				delta_lwlock = current_lwlock,
				delta_timeout = current_timeout 
			WHERE 
				id =  stat_statement_rec.id ;
			--1. UPDATE stat_statement
			-----------------------
		END IF ;
		-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ stat_statement
		--------------------------------------        		
		
		
		------------------------------------------------------------
		--WAIT_EVENT_TYPE
		FOR wait_event_type_rec in 
		WITH wait_event_type_jsonb AS
		(
		  SELECT jsonb_object_keys (current_wait_stats)  AS wait_event_type_key 
		)
		SELECT * 
		FROM wait_event_type_jsonb	
		WHERE  wait_event_type_key NOT IN ('Total' , 'Client' , 'Activity') 	       
		LOOP 
		
			SELECT stat_statement_rec.curr_wait_stats->>wait_event_type_rec.wait_event_type_key
			INTO current_wait_event_type_jsonb ;
			
--RAISE NOTICE 'wait_event_type_key = %' , wait_event_type_rec.wait_event_type_key ;	

			--WAIT_EVENT
			FOR wait_event_rec IN 
			WITH wait_event_jsonb AS
			(
				SELECT jsonb_object_keys( current_wait_stats->wait_event_type_rec.wait_event_type_key )  AS wait_event_key 
			)
			SELECT * 
			FROM wait_event_jsonb
			LOOP 
--RAISE NOTICE 'wait_event = %' , wait_event_rec.wait_event_key ;
				
				SELECT to_number( current_wait_event_type_jsonb->>wait_event_rec.wait_event_key , '0000000000')  / 10 
				INTO current_value  ;
				--------------------------------------------
				--1. stat_statement_wait_events
				INSERT INTO stat_statement_wait_events
				(
					curr_timestamp ,
					dbname ,
					username , 
					queryid ,
					wait_event_type , 
					wait_event , 
					curr_value ,
					delta_value
				)
				VALUES 
				(
					stat_statement_rec.curr_timestamp , 
					curr_datname , 
					curr_username , 
					current_queryid , 
					wait_event_type_rec.wait_event_type_key  , 
					wait_event_rec.wait_event_key ,
					current_value , 
					current_value
				);
				--1. INSERT INTO stat_statement_wait_events
				---------------------------------------------		
				
				SELECT 	*
				INTO 	prev_stat_statement_wait_events_rec
				FROM 	stat_statement_wait_events
				WHERE   queryid = current_queryid AND 
						dbname = curr_datname AND 
						username = curr_username AND 
						wait_event_type = wait_event_type_rec.wait_event_type_key AND
						wait_event = wait_event_rec.wait_event_key AND  
						curr_timestamp = (SELECT MAX(curr_timestamp) 
					                  FROM stat_statement_wait_events 
									  WHERE curr_timestamp < stat_statement_rec.curr_timestamp AND 
											queryid = current_queryid AND 
											dbname = curr_datname AND 
											username = curr_username AND 
											wait_event_type = wait_event_type_rec.wait_event_type_key AND
											wait_event = wait_event_rec.wait_event_key
									  );

				--------------------------------------
				-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ 	
				-- ЕСЛИ ПЕРВОЕ ЗНАЧЕНИЕ 	
				IF prev_stat_statement_wait_events_rec.id IS NULL 
				THEN 
					current_delta_waitings = current_value; 			
				-- ПЕРВОЕ ЗНАЧЕНИЕ 	
				--------------------------------------
				-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ 	
				ELSE
					current_delta_waitings = current_value - COALESCE( prev_stat_statement_wait_events_rec.curr_value , 0 ); 
					
					--КОСТЫЛЬ !!!!!
					IF current_delta_waitings < 0 THEN current_delta_waitings = prev_stat_statement_wait_events_rec.curr_value; END IF ;
					--КОСТЫЛЬ !!!!!
					
				END IF ;
				-- ПРИРАЩЕНИЕ ЗНАЧЕНИЙ 	
				--------------------------------------
				
				-----------------------------------------------------
				-- СОХРАНИТЬ  ПРИРАЩЕНИЕ 
				UPDATE stat_statement_wait_events
				SET 		
					delta_value = current_delta_waitings
				WHERE   queryid = current_queryid AND 
						dbname = curr_datname AND 
						username = curr_username AND 
						wait_event_type = wait_event_type_rec.wait_event_type_key AND
						wait_event = wait_event_rec.wait_event_key AND  
						curr_timestamp = stat_statement_rec.curr_timestamp ;
				-- СОХРАНИТЬ  ПРИРАЩЕНИЕ 
				-----------------------------------------------------	
				--1. stat_statement_wait_events
				
				--2. stat_statement_wait_events_analysis
				SELECT (percentile_cont(0.5) within group (order by delta_value))::numeric
				INTO wait_event_long
				FROM stat_statement_wait_events
				WHERE   queryid = current_queryid AND 
						dbname = curr_datname AND 
						username = curr_username AND 
						wait_event_type = wait_event_type_rec.wait_event_type_key AND
						wait_event = wait_event_rec.wait_event_key AND  
						curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp ;
		
				IF  wait_event_long IS NOT NULL 
				THEN				
					INSERT INTO stat_statement_wait_events_analysis
					(
						dbname, 
						username,  
						queryid ,  
						curr_timestamp ,
						wait_event_type,
						wait_event     ,				
						curr_value_long 
					)
					VALUES 
					( 
						curr_datname , 
						curr_username , 
						current_queryid , 
						stat_statement_rec.curr_timestamp , 
						wait_event_type_rec.wait_event_type_key , 
						wait_event_rec.wait_event_key ,				
						wait_event_long		
					);	
				END IF ; 
				--2. stat_statement_wait_events_analysis
			END LOOP;
			--WAIT_EVENT		
		END LOOP;	
		--WAIT_EVENT_TYPE
		
		--3. stat_statement_analysis
		----------------------------------------------------------------------------
		-- ОПЕРАЦИОННАЯ СКОРОСТЬ
		--Долгая медиана calls	
		SELECT (percentile_cont(0.5) within group (order by delta_calls))::numeric
		INTO current_delta_calls_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
			  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF current_delta_calls_long IS NULL THEN current_delta_calls_long = 0 ; END IF ;	

		--Долгая медиана rows
		SELECT (percentile_cont(0.5) within group (order by delta_rows))::numeric
		INTO current_delta_rows_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
			  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF current_delta_rows_long IS NULL THEN current_delta_rows_long = 0 ; END IF ;	
		-- ОПЕРАЦИОННАЯ СКОРОСТЬ
		-----------------------------------------------------------------------------
		-- Долгая медиана по wait_event_type
		SELECT (percentile_cont(0.5) within group (order by delta_bufferpin))::numeric
		INTO bufferpin_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF bufferpin_long IS NULL THEN bufferpin_long = 0 ; END IF ; 
	
		SELECT (percentile_cont(0.5) within group (order by delta_extension))::numeric
		INTO extension_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF extension_long IS NULL THEN extension_long = 0 ; END IF ; 

		SELECT (percentile_cont(0.5) within group (order by delta_io))::numeric
		INTO io_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF io_long IS NULL THEN io_long = 0 ; END IF ; 
		
		SELECT (percentile_cont(0.5) within group (order by delta_ipc))::numeric
		INTO ipc_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF ipc_long IS NULL THEN ipc_long = 0 ; END IF ; 

		SELECT (percentile_cont(0.5) within group (order by delta_lock))::numeric
		INTO lock_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF lock_long IS NULL THEN lock_long = 0 ; END IF ; 

		SELECT (percentile_cont(0.5) within group (order by delta_lwlock))::numeric
		INTO lwlock_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF lwlock_long IS NULL THEN lwlock_long = 0 ; END IF ; 
		
		SELECT (percentile_cont(0.5) within group (order by delta_timeout))::numeric
		INTO timeout_long
		FROM stat_statement
		WHERE curr_timestamp BETWEEN stat_statement_rec.curr_timestamp - (interval '60 minute') AND stat_statement_rec.curr_timestamp 
		  AND queryid = current_queryid AND dbname = curr_datname AND username = curr_username;
		IF timeout_long IS NULL THEN timeout_long = 0 ; END IF ; 	
		-- Долгая медиана по wait_event_type
		---------------------------------------------------------------------

		--------------------------------------------------
		-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
		curr_operating_speed_long =  ( current_delta_calls_long + current_delta_rows_long  )  ;
		-- ОПЕРАЦИОННАЯ СКОРОСТЬ 
		--------------------------------------------------
		-- ОЖИДАНИЯ  
		curr_waiting_events_long = bufferpin_long + extension_long +  io_long + ipc_long + lock_long + lwlock_long + timeout_long; 
		-- ОЖИДАНИЯ  
		--------------------------------------------------
		INSERT INTO stat_statement_analysis 
		(
			dbname , 
			username , 
			queryid ,
			hex_queryid , 

			curr_timestamp, 
			
			curr_wait_stats , 
			operating_speed_long ,
			waitings_long ,
			
			bufferpin_long ,
			extension_long ,
			io_long ,
			ipc_long ,
			lock_long ,
			lwlock_long ,
			timeout_long ,
			calls_long ,
			rows_long 
		)
		VALUES 
		(
			curr_datname ,
			curr_username ,
			current_queryid , 
			to_hex( current_queryid ) ,
			
			stat_statement_rec.curr_timestamp , 
			
			current_wait_stats ,
			curr_operating_speed_long , 
			curr_waiting_events_long , 
		
			bufferpin_long , 
			extension_long , 
			io_long , 
			ipc_long , 
			lock_long , 
			lwlock_long , 
			timeout_long , 

			current_delta_calls_long , 
			current_delta_rows_long				
		);								
		--3. stat_statement_analysis
-- ПОСЛЕ СБРОСА СТАТИСТИКИ - ДЕЛЬТА 				
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	END LOOP ;
	--FOR stat_statement_rec IN 
	
	SELECT clock_timestamp() 
	INTO test_timestamp ;
--78.0
/*	
	RAISE NOTICE 'SQL_STATEMENT_ANALYSIS : finished % ',test_timestamp ;
*/

return res ;

END
$$ LANGUAGE plpgsql;


--------------------------------------------------------
/*
CREATE OR REPLACE FUNCTION 	update_stat_statement_analysis() RETURNS integer 
AS $$
DECLARE
  min_timestamp timestamptz ;
  max_timestamp timestamptz ;
  res integer ;
BEGIN
res = 0; 
	
	SELECT MAX(timepoint) 
	INTO min_timestamp
	FROM sql_stats_history ;
	
	SELECT date_trunc('minute' , CURRENT_TIMESTAMP )
	INTO max_timestamp ; 
	
	SELECT prepare_stat_statement_analysis( to_char( min_timestamp , 'YYYY-MM-DD HH24:MI ') , 
											to_char( max_timestamp , 'YYYY-MM-DD HH24:MI ') )
	INTO res ;

	
	
	--PERFORM log_sql_statistics_timestamp( curr_timestamp );	

return res ;

END
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION 	update_stat_statement_analysis_for_current_minute() RETURNS integer 
AS $$
DECLARE
  min_timestamp timestamptz ;
  max_timestamp timestamptz ;
  res integer ;
BEGIN

	SELECT date_trunc('minute' , CURRENT_TIMESTAMP )
	INTO max_timestamp ; 
	
	SELECT max_timestamp - interval '1 minute'
	INTO min_timestamp ;
	
	SELECT prepare_stat_statement_analysis( to_char( min_timestamp , 'YYYY-MM-DD HH24:MI ') , 
											to_char( max_timestamp , 'YYYY-MM-DD HH24:MI ') )
	INTO res ;

return res ;

END
$$ LANGUAGE plpgsql;

*/