﻿-- stat_statement_tables.sql
-- version 77.6

-- Текущая статистика тестового SQL-запроса
DROP TABLE IF EXISTS stat_statement;
CREATE UNLOGGED TABLE stat_statement 
(
  id SERIAL , 	
  curr_timestamp timestamp with time zone , 
  -----------------------------------------
  -- PRIMARY KEY
  pgpro_pwr_sample timestamp with time zone , 
  dbname 				name, 
  username			name ,   
  queryid bigint ,
  curr_calls bigint ,
  -- PRIMARY KEY  
  -----------------------------------------
  
  
  curr_rows bigint ,  
  
  delta_calls bigint ,
  delta_rows bigint , 
  
  curr_wait_stats	jsonb ,--Объект типа jsonb, содержащий статистику по событиям ожидания для каждого выполнения запроса по соответствующему плану
 
  curr_bufferpin  bigint ,
  curr_extension  bigint ,
  curr_io  bigint ,
  curr_ipc  bigint ,
  curr_lock  bigint ,
  curr_lwlock  bigint ,
  curr_timeout  bigint ,
  delta_bufferpin  bigint ,
  delta_extension  bigint ,
  delta_io  bigint ,
  delta_ipc  bigint ,
  delta_lock  bigint ,
  delta_lwlock  bigint ,
  delta_timeout  bigint  
);
--ALTER TABLE stat_statement ADD CONSTRAINT stat_statement_pk PRIMARY KEY (id);
ALTER TABLE stat_statement ADD CONSTRAINT stat_statement_pk PRIMARY KEY ( pgpro_pwr_sample , dbname , username , curr_calls  );
CREATE INDEX stat_statement_id_idx ON stat_statement ( id );
CREATE INDEX stat_statement_idx ON stat_statement ( curr_timestamp );
--77.4
--CREATE INDEX stat_statement_idx ON stat_statement ( curr_timestamp );
--77.4

-------------------------------------------------------------
-- история снимков pgpro_pwr
DROP TABLE IF EXISTS pgpro_pwr_samples ; 
CREATE UNLOGGED TABLE pgpro_pwr_samples
(  
  curr_timestamp timestamp with time zone PRIMARY KEY
);
-- история снимков pgpro_pwr
-------------------------------------------------------------

-------------------------------------------------------------
--точки времени завершения расчета статистики для уровня SQL
DROP TABLE IF EXISTS sql_stats_history ;
CREATE UNLOGGED TABLE sql_stats_history
(
	timepoint timestamptz PRIMARY KEY
);
--точки времени завершения расчета статистики для уровня SQL
-------------------------------------------------------------





--ожидания на уровне SQL
DROP TABLE IF EXISTS stat_statement_wait_events;
CREATE UNLOGGED TABLE stat_statement_wait_events 
(
  id SERIAL , 
  curr_timestamp timestamp with time zone ,
  dbname 				name, 
  username			name , 
  queryid 			bigint ,
  wait_event_type  	text ,
  wait_event       	text ,
  curr_value       	bigint ,
  delta_value      	bigint   
);
ALTER TABLE stat_statement_wait_events ADD CONSTRAINT stat_statement_wait_events_pk PRIMARY KEY (id);
CREATE INDEX stat_statement_wait_events_idx ON stat_statement_wait_events ( curr_timestamp );
CREATE INDEX stat_statement_wait_events_current_queryid_idx ON stat_statement_wait_events ( queryid );
CREATE INDEX stat_statement_wait_events_dbname_idx ON stat_statement_wait_events ( dbname );
CREATE INDEX stat_statement_wait_events_usename_idx ON stat_statement_wait_events ( username );
CREATE INDEX stat_statement_wait_events_wait_event_type_idx ON stat_statement_wait_events ( wait_event_type );
CREATE INDEX stat_statement_wait_events_wait_event_idx ON stat_statement_wait_events ( wait_event );

--Скользящие медианы на уровне SQL
DROP TABLE IF EXISTS stat_statement_analysis;
CREATE UNLOGGED TABLE stat_statement_analysis 
(
	id SERIAL , 
    --dbid 				oid, 
	dbname 				name, 
	--userid 			oid ,  
	username			name , 
    queryid bigint ,	
	hex_queryid text , 
	
	curr_wait_stats	jsonb ,--Объект типа jsonb, содержащий статистику по событиям ожидания для каждого выполнения запроса по соответствующему плану

	curr_timestamp timestamp with time zone , 

	--operating_speed_short numeric ,
	operating_speed_long numeric ,
	
	--calls_short numeric ,
	calls_long numeric ,
	
	--rows_short numeric ,
	rows_long numeric ,
	
	--waitings_short numeric ,	
	--bufferpin_short numeric ,
	--extension_short numeric ,
	--io_short numeric ,
	--ipc_short numeric ,
	--lock_short numeric ,
	--lwlock_short numeric ,

	waitings_long numeric ,	
	bufferpin_long numeric ,
	extension_long numeric ,
	io_long numeric ,
	ipc_long numeric ,
	lock_long numeric ,
	lwlock_long numeric ,
	timeout_long numeric 
	
);

ALTER TABLE stat_statement_analysis ADD CONSTRAINT stat_statement_analysis_pk PRIMARY KEY (id);
CREATE INDEX stat_statement_analysis_idx ON stat_statement_analysis ( curr_timestamp );


DROP TABLE IF EXISTS stat_statement_wait_events_analysis;
CREATE UNLOGGED TABLE stat_statement_wait_events_analysis 
(
  id SERIAL , 
  curr_timestamp timestamp with time zone ,
  --dbid 				oid, 
  dbname 				name, 
  --userid 			oid ,  
  username			name ,
  queryid 			bigint ,  
  wait_event_type  text ,
  wait_event       text ,
  --curr_value_short       bigint ,
  curr_value_long       bigint 

);
ALTER TABLE stat_statement_wait_events_analysis ADD CONSTRAINT stat_statement_wait_events_analysis_pk PRIMARY KEY (id);
CREATE INDEX stat_statement_wait_events_analysis_idx ON stat_statement_wait_events_analysis ( curr_timestamp );
/*
CREATE INDEX stat_statement_wait_events_analysis_idx ON stat_statement_wait_events_analysis ( curr_timestamp );
CREATE INDEX stat_statement_wait_events_analysis_current_queryid_idx ON stat_statement_wait_events_analysis ( current_queryid );
CREATE INDEX stat_statement_wait_events_analysis_dbid_idx ON stat_statement_wait_events_analysis ( dbid );
CREATE INDEX stat_statement_wait_events_analysis_userid_idx ON stat_statement_wait_events_analysis ( userid );
CREATE INDEX stat_statement_wait_events_analysis_wait_event_type_idx ON stat_statement_wait_events_analysis ( wait_event_type );
CREATE INDEX stat_statement_wait_events_analysis_wait_event_idx ON stat_statement_wait_events_analysis ( wait_event );
*/