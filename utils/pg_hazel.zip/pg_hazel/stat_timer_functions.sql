-- stat_timer_functions.sql
-- psql -d stat_tester_db -U stat_tester_user -f stat_timer_functions.sql
-- version 6.1

-----------------------------------------------------------
-- ФУНКЦИИ 
-- stat_timer_add_action( curr_queryid bigint , start_timestamp timestamp with time zone  , finish_timestamp timestamp with time zone ) RETURNS integer	Добавить точку в историю запроса 
-- stat_timer_calc_statistics( curr_queryid bigint , new_timepoint timestamp with time zone  )  Рассчитать статистику 


-- get_duration( start_timestamp timestamp with time zone  , finish_timestamp timestamp with time zone ) RETURNS DOUBLE PRECISION 		Длительность в миллисекундах между двумя точками
-- 

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ФУНКЦИИ 
-----------------------------------------------------------

-- test_timer.sql

-- Добавить точку в историю запроса 
CREATE OR REPLACE FUNCTION stat_timer_add_action ( curr_queryid bigint , new_start_timestamp text  , new_finish_timestamp text  ) RETURNS integer AS $$
DECLARE
  duration_ms  DOUBLE PRECISION; 
  flag BOOLEAN ;
  start_timestamp timestamp with time zone ;
  finish_timestamp timestamp with time zone;
BEGIN

	SELECT to_timestamp(new_start_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')
	INTO start_timestamp;
	
	SELECT to_timestamp(new_finish_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')
	INTO finish_timestamp;

	SELECT stat_timer_get_duration( start_timestamp , finish_timestamp ) 
	INTO duration_ms ; 

--RAISE NOTICE 'new_start_timestamp = %', new_start_timestamp;	
--RAISE NOTICE 'new_finish_timestamp = %', new_finish_timestamp;	
	
--RAISE NOTICE 'start_timestamp = %', start_timestamp;	
--RAISE NOTICE 'finish_timestamp = %', finish_timestamp;	
--RAISE NOTICE 'duration_ms = %', duration_ms;	


	INSERT INTO stat_timer_history 
	(
		queryid , 
		curr_timestamp , 
		duration 
	)
	VALUES
	(
		curr_queryid , 
		start_timestamp , 
		duration_ms
	);

	
	return 0 ; 
END
$$ LANGUAGE plpgsql ;
GRANT EXECUTE ON FUNCTION stat_timer_add_action ( curr_queryid bigint , new_start_timestamp text  , finish_timestamp text  ) TO pgpropwr ;

-- Рассчитать статистику 
CREATE OR REPLACE FUNCTION stat_timer_calc_statistics( curr_queryid bigint , new_timepoint timestamp with time zone  ) RETURNS integer AS $$
DECLARE
  mean_exec_time_short DOUBLE PRECISION;
  mean_exec_time_long  DOUBLE PRECISION;
  
  max_timestamp timestamp with time zone  ;
  
BEGIN
RAISE NOTICE 'curr_queryid = %',curr_queryid;
RAISE NOTICE 'new_timepoint = %',new_timepoint;

	
	
	SELECT 	date_trunc( 'minute' , new_timepoint  ) 
	INTO max_timestamp ; 
	
	
	--Короткая медиана duration
	SELECT (percentile_cont(0.5) within group (order by duration))::numeric
	INTO mean_exec_time_short
	FROM stat_timer_history
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '10 minute') AND max_timestamp 
	      AND queryid = curr_queryid  ;	

	--Долгая медиана duration
	SELECT (percentile_cont(0.5) within group (order by duration))::numeric
	INTO mean_exec_time_long
	FROM stat_timer_history
	WHERE curr_timestamp BETWEEN max_timestamp - (interval '60 minute') AND max_timestamp 
	      AND 	queryid = curr_queryid  ;	

	INSERT INTO stat_timer_statistics_short
	(
		queryid , 
		curr_timestamp , 
		median_duration 
	)
	VALUES 
	(
		curr_queryid ,
		max_timestamp ,
		mean_exec_time_short
	);

	INSERT INTO stat_timer_statistics_long
	(
		queryid , 
		curr_timestamp , 
		median_duration 
	)
	VALUES 
	(
		curr_queryid ,
		max_timestamp ,
		mean_exec_time_long
	) ;
	
	return 0 ; 
END
$$ LANGUAGE plpgsql ;

--Длительность в миллисекундах между двумя точками
CREATE OR REPLACE FUNCTION stat_timer_get_duration( start_timestamp timestamp with time zone  , finish_timestamp timestamp with time zone ) RETURNS DOUBLE PRECISION AS $$
DECLARE
  current_duration interval ;
  duration_ms  DOUBLE PRECISION; 
BEGIN
	current_duration = finish_timestamp - start_timestamp ;
	
RAISE NOTICE 'current_duration = %', current_duration   ;
	
	SELECT EXTRACT(MILLISECONDS FROM current_duration)
	INTO duration_ms ; 
	
RAISE NOTICE 'duration_ms = %', duration_ms   ;

	return duration_ms ;
END
$$ LANGUAGE plpgsql STABLE ;

/*
CREATE OR REPLACE FUNCTION stat_timer_calc_statistics( curr_queryid bigint , new_start_timestamp text  , new_finish_timestamp text  ) RETURNS integer AS $$
DECLARE
  mean_exec_time_short DOUBLE PRECISION;
  mean_exec_time_long  DOUBLE PRECISION;
  
  min_timestamp timestamp with time zone  ;
  max_timestamp timestamp with time zone  ;
  timepoint timestamp with time zone  ;
  
  flag BOOLEAN ;
  start_timestamp timestamp with time zone ;
  finish_timestamp timestamp with time zone;
BEGIN
RAISE NOTICE 'curr_queryid = %',curr_queryid;
RAISE NOTICE 'new_start_timestamp = %',new_start_timestamp;
RAISE NOTICE 'new_finish_timestamp = %',new_finish_timestamp;


	SELECT to_timestamp(new_start_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')
	INTO start_timestamp;
	
	SELECT to_timestamp(new_finish_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')
	INTO finish_timestamp;
	
	SELECT 	date_trunc( 'minute' , start_timestamp ) 
	INTO min_timestamp ; 
	
	SELECT 	date_trunc( 'minute' , finish_timestamp ) 
	INTO max_timestamp ; 
	
	timepoint = min_timestamp + interval '1 minute';
	
	WHILE timepoint <= max_timestamp
	LOOP 
		-------------------------------------------------------------------------------------------------------------------------
		-- МЕДИАНЫ 
		-----------------------------------------------------------------------------
		-- ВРЕМЯ ВЫПОЛНЕНИЯ
		--Короткая медиана duration
		SELECT (percentile_cont(0.5) within group (order by duration))::numeric
		INTO mean_exec_time_short
		FROM stat_timer_history
		WHERE curr_timestamp BETWEEN timepoint - (interval '10 minute') AND timepoint 
		      AND queryid = curr_queryid  ;	

RAISE NOTICE 'mean_exec_time_short = %',mean_exec_time_short;			  
			  
		IF mean_exec_time_short IS NOT NULL 
		THEN
			INSERT INTO stat_timer_statistics_short
			(
				queryid , 
				curr_timestamp , 
				median_duration 
			)
			VALUES 
			(
				curr_queryid ,
				timepoint ,
				mean_exec_time_short
			)
			ON CONFLICT ( queryid , curr_timestamp ) DO NOTHING ;		
		END IF ;
	
	
	
		--Долгая медиана duration
		SELECT (percentile_cont(0.5) within group (order by median_duration))::numeric
		INTO mean_exec_time_long
		FROM stat_timer_statistics_short
		WHERE curr_timestamp BETWEEN timepoint - (interval '60 minute') AND timepoint 
		      AND 	queryid = curr_queryid  ;	
			
RAISE NOTICE 'mean_exec_time_long = %',mean_exec_time_long;			  

		IF mean_exec_time_long IS NOT NULL 
		THEN
			INSERT INTO stat_timer_statistics_long
			(
				queryid , 
				curr_timestamp , 
				median_duration 
			)
			VALUES 
			(
				curr_queryid ,
				timepoint ,
				mean_exec_time_long
			) 
			ON CONFLICT ( queryid , curr_timestamp ) DO NOTHING ;		
		END IF ;
		-- ВРЕМЯ ВЫПОЛНЕНИЯ
		-----------------------------------------------------------------------------		
		-- МЕДИАНЫ 
		-------------------------------------------------------------------------------------------------------------------------

		timepoint = timepoint + interval '1 minute';
	END LOOP;

	DELETE FROM stat_timer_history WHERE queryid = curr_queryid AND curr_timestamp < start_timestamp ;
	
	return 0 ; 
END
$$ LANGUAGE plpgsql ;
*/


