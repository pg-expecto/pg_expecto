-- stat_timer_tables.sql
-- version 1.0
DROP TABLE IF EXISTS stat_timer_history;
CREATE UNLOGGED TABLE stat_timer_history 
(  
  id SERIAL ,
  curr_timestamp timestamp with time zone , 
  queryid bigint ,   
  duration DOUBLE PRECISION  
);

ALTER TABLE stat_timer_history SET ( autovacuum_enabled = false, toast.autovacuum_enabled = false );

DROP TABLE IF EXISTS stat_timer_statistics_short;
CREATE UNLOGGED TABLE stat_timer_statistics_short
(  
  queryid bigint , 
  curr_timestamp timestamp with time zone , 
  median_duration DOUBLE PRECISION 
);

DROP TABLE IF EXISTS stat_timer_statistics_long;
CREATE UNLOGGED TABLE stat_timer_statistics_long
(  
  queryid bigint , 
  curr_timestamp timestamp with time zone , 
  median_duration DOUBLE PRECISION 
);

--------------------------------------------------------------------------------------------------------------------------
-- Индексы и ограничения 
ALTER TABLE stat_timer_statistics_short ADD CONSTRAINT stat_timer_statistics_short_pk PRIMARY KEY (queryid , curr_timestamp);
ALTER TABLE stat_timer_statistics_long ADD CONSTRAINT stat_timer_statistics_long_pk PRIMARY KEY (queryid , curr_timestamp);

CREATE INDEX stat_timer_statistics_short_idx ON stat_timer_statistics_short ( queryid , curr_timestamp );
CREATE INDEX stat_timer_statistics_short_idx2 ON stat_timer_statistics_short ( queryid );

CREATE INDEX stat_timer_statistics_long_idx ON stat_timer_statistics_long ( queryid , curr_timestamp );
CREATE INDEX stat_timer_statistics_long_idx2 ON stat_timer_statistics_long ( queryid );
