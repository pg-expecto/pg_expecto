--statemts_stats_update_workers.sql
SELECT 
psa.pid , 
to_char(psa.query_start,'YYYY-MM-DD HH24:MI') ,
( 
  WITH 
  get_max_id AS
  (
     SELECT 
		MAX(id) AS max_id
	FROM stat_statement
	WHERE 
	  curr_timestamp 
	    BETWEEN 
	      date_trunc( 'minute', ( SELECT query_start FROM pg_stat_activity WHERE pid = psa.pid )  - interval '1 minute')  AND 
		  date_trunc( 'minute', ( SELECT query_start FROM pg_stat_activity WHERE pid = psa.pid ) ) 
  ),
  get_min_id AS
  (
     SELECT 
		MIN(id) AS min_id
	FROM stat_statement
	WHERE 
	  curr_timestamp 
	    BETWEEN 
	      date_trunc( 'minute', ( SELECT query_start FROM pg_stat_activity WHERE pid = psa.pid ) - interval '1 minute')  AND 
		  date_trunc( 'minute', ( SELECT query_start FROM pg_stat_activity WHERE pid = psa.pid ) ) 
  )
  SELECT 
    ROUND( (st.id - mn.min_id )::numeric / 
           (mx.max_id - mn.min_id)::numeric * 100 , 2) 
  FROM 
    stat_statement st , get_max_id mx , get_min_id mn 
) AS pct 
FROM 
pg_stat_activity psa
WHERE query ='SELECT update_stat_statement_analysis_for_current_minute()' AND pid != pg_backend_pid() 
ORDER BY 2 ;