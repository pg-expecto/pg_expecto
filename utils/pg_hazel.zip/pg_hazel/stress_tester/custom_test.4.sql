-- custom_test.4.sql
-- version 65.0
CREATE OR REPLACE FUNCTION custom_test4() RETURNS bigint AS $$
DECLARE
 counter bigint;
 current_result numeric ;
 result_rec record ;
BEGIN

---------------------------------------------------
--СЦЕНАРИЙ 4 - HEAVYWEIGHT
--СЦЕНАРИЙ 4.2 - HEAVYWEIGHT CPU 
--                                        QUERY PLAN
------------------------------------------------------------------------------------------
-- Result  (cost=0.00..0.26 rows=1 width=4) (actual time=5295.066..5295.066 rows=1 loops=1)
--   Buffers: shared hit=15
-- Planning Time: 0.018 ms
-- Execution Time: 5295.090 ms
--(4 rows)

FOR counter IN 1..10000
LOOP
SELECT 
	gcd( ((random()*100.0) * (random()*100.0))::numeric , ((random()*100.0) * (random()*100.0))::numeric ) * 
	lcm( ((random()*100.0) * (random()*100.0))::numeric , ((random()*100.0) * (random()*100.0))::numeric ) 
	*
	power
	( 
	gcd( ((random()*100.0) * (random()*100.0))::numeric , ((random()*100.0) * (random()*100.0))::numeric ) ,
	lcm( ((random()*100.0) * (random()*100.0))::numeric , ((random()*100.0) * (random()*100.0))::numeric )
	)
INTO current_result ; 
END LOOP;

--СЦЕНАРИЙ 4 - HEAVYWEIGHT
---------------------------------------------------

SELECT 
	abalance 
INTO 
	result_rec
FROM 
	pgbench_accounts 
ORDER BY abalance 
LIMIT 1 ;


 return counter ; 
END
$$ LANGUAGE plpgsql;

