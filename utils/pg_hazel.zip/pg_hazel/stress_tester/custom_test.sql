﻿-- custom_test.sql
-- cat ~/.pgpass | grep postgres
-- psql -d test_pgbench_custom -U pgpropwr -f custom_test.sql 
-- version 58.0
CREATE OR REPLACE FUNCTION custom_test(  current_scenario integer ) RETURNS integer AS $$
DECLARE
  start_timestamp timestamp with time zone ;
  finish_timestamp timestamp with time zone ;
  
  dblink_string text ;
  result_rec record ;
  current_result record ;
  current_test_queryid bigint ; 
  current_queryid bigint;
  
  count integer  ; 
  result_text text ;
  result_int integer ; 
 
BEGIN
/* --------------------- 58.0 ------------------------------------
 SELECT clock_timestamp() 
 INTO start_timestamp ;

PERFORM dblink_connect_u('current_connection' , 'dbname=performance_monitoring_db  user=performance_monitoring_user  password=144513122024$Uimap!#15');

	SELECT 	* 
	INTO 	current_queryid
	FROM 	dblink( 'current_connection' , 'SELECT get_test_queryid()' ) AS t1(queryid bigint);

PERFORM dblink_disconnect('current_connection');

RAISE NOTICE 'current_queryid = %',current_queryid;	

    IF current_queryid = 0 
	THEN 
		SELECT queryid 
		INTO current_test_queryid
		FROM pgpro_stats_statements 
		WHERE query like 'select custom_test%';	
	ELSE 
		current_test_queryid = current_queryid ; 
	END IF ;

RAISE NOTICE 'current_test_queryid = %',current_test_queryid;	
--------------------- 58.0 ------------------------------------ */

 ------------------------------------------------------------------
 -- СЦЕНАРИЙ 1 - SELECT ONLY
 IF current_scenario = 1
 THEN 
	SELECT custom_test1() 
	INTO current_result ; 
 END IF ;
 -- СЦЕНАРИЙ 1 - SELECT ONLY
 ------------------------------------------------------------------
  
 ------------------------------------------------------------------
 -- СЦЕНАРИЙ 2 - OLTP
 IF current_scenario = 2
 THEN 
	SELECT custom_test2() 
	INTO current_result ; 
 END IF ;
 -- СЦЕНАРИЙ 2 - OLTP
 ------------------------------------------------------------------

------------------------------------------------------------------
 -- СЦЕНАРИЙ 3 - INSERT ONLY
 IF current_scenario = 3
 THEN 
	SELECT custom_test3() 
	INTO current_result ; 
 END IF ;
 -- СЦЕНАРИЙ 3 - INSERT ONLY
 ------------------------------------------------------------------


------------------------------------------------------------------
-- СЦЕНАРИЙ 4 - HEAVYWEIGHT
 IF current_scenario = 4
 THEN 
	SELECT custom_test4() 
	INTO current_result ;   
 END IF ;
-- СЦЕНАРИЙ 4 - HEAVYWEIGHT
------------------------------------------------------------------

/* --------------------- 58.0 ------------------------------------
 SELECT clock_timestamp()  
 INTO finish_timestamp ;

 IF current_test_queryid IS NULL
 THEN
	return 0 ;
 END IF;

PERFORM dblink_connect_u('current_connection' , 'dbname=performance_monitoring_db  user=performance_monitoring_user  password=144513122024$Uimap!#15');
	
	dblink_string = 'SELECT stat_timer_add_action( '||current_test_queryid||' , '
	                                                         ||''''||to_char(start_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')||''''||' , '
															 ||''''||to_char(finish_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')||''''||' ) ' ;

	RAISE NOTICE ' dblink_string = %',dblink_string ;	

	-----------------------------------------------------------------------------
	-- ЗАЛОГИРОВАТЬ
	SELECT * 
	INTO result_int 
	FROM dblink( 'current_connection' , dblink_string ) AS t1( res integer );
	
	
	SELECT dblink_error_message('current_connection')
	INTO result_text ;
	
	RAISE NOTICE '%',result_text ;
	-- ЗАЛОГИРОВАТЬ
	-----------------------------------------------------------------------------
	
PERFORM dblink_disconnect('current_connection');
--------------------- 58.0 ------------------------------------ */
	
 return result_int ; 
END
$$ LANGUAGE plpgsql;

