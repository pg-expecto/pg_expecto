﻿-- customized_test.sql
-- version 58.0
CREATE OR REPLACE FUNCTION customized_test() RETURNS integer AS $$
DECLARE 
 min_i bigint ; 
 max_i bigint ;
 current_aid bigint ; 
 current_tid bigint ; 
 current_bid bigint ; 
 current_delta bigint ; 
 counter bigint;
BEGIN
---------------------------------------------------
--КАСТОМНЫЙ СЦЕНАРИЙ 
-- 58.0 UPDATE ONLY 
--1)UPDATE pgbench_accounts SET abalance = abalance + :delta WHERE aid = :aid;
--2)UPDATE pgbench_tellers SET tbalance = tbalance + :delta WHERE tid = :tid;
--3)UPDATE pgbench_branches SET bbalance = bbalance + :delta WHERE bid = :bid;

	FOR counter IN 1..10
	LOOP 
		current_delta = (ROUND( random ())::bigint)*10 + 1 ;

		SELECT MIN(aid) INTO min_i FROM pgbench_accounts ; 
		SELECT MAX(aid) INTO max_i FROM pgbench_accounts ; 
		current_aid = floor(random() * (max_i - min_i + 1)) + min_i ;
		UPDATE pgbench_accounts SET abalance = abalance + current_delta WHERE  aid = current_aid ; 
	END LOOP ;

	FOR counter IN 1..10
	LOOP 
		SELECT MIN(tid) INTO min_i FROM pgbench_tellers ; 
		SELECT MAX(tid) INTO max_i FROM pgbench_tellers ; 
		current_tid = floor(random() * (max_i - min_i + 1)) + min_i ;
		UPDATE pgbench_tellers SET tbalance = tbalance + current_delta WHERE tid = current_tid ;
	END LOOP ;
	
	FOR counter IN 1..10
	LOOP 
	
		SELECT MIN(bid) INTO min_i FROM pgbench_branches ; 
		SELECT MAX(bid) INTO max_i FROM pgbench_branches ; 
		current_bid = floor(random() * (max_i - min_i + 1)) + min_i ;
		UPDATE pgbench_branches SET bbalance = bbalance + current_delta WHERE bid = current_bid ; 
	END LOOP;
--КАСТОМНЫЙ СЦЕНАРИЙ 
-- 58.0 UPDATE ONLY 
---------------------------------------------------
 return 0 ; 
END
$$ LANGUAGE plpgsql;

