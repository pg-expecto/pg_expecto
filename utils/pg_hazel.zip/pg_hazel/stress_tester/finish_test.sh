#!/bin/sh
# finish_test.sh
# version 5.0

#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
	/postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

stat_tester_db='stat_tester_db'
stat_tester_user='stat_tester_user'


LOG_FILE=$current_path'/pg_stat_tester.log'
ERR_FILE=$current_path'/pg_stat_tester.err'



echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : FINAL REPORT  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : FINAL REPORT  ' >> $LOG_FILE

  timestamp_label=$(date "+%Y%m%dT%H%M")
  ARCHIVE_DIR='/tmp/cpi_waitings_report'
  REPORT_ZIP=$ARCHIVE_DIR'/cpi_waitings_report.'$timestamp_label'.zip'

  find $ARCHIVE_DIR -type f -mtime +7 -delete >> $LOG_FILE 2>>$ERR_FILE	

  LOGS=$current_path'/*.log'
  TXTS=$current_path'/*.txt'
  CONFS=$current_path'/*.conf'

  zip $REPORT_ZIP $LOGS $TXTS $CONFS 2>$ERR_FILE  
  exit_code $? $LOG_FILE $ERR_FILE  
  chmod 777  $REPORT_ZIP

	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : DELETING REPORT FILES'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : DELETING REPORT FILES' >> $LOG_FILE
	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : TEST - STOPPING '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : TEST - STOPPING ' >> $LOG_FILE
  /postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : TEST HAS FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : finish_test : OK : TEST HAS FINISHED ' >> $LOG_FILE
	
exit 0	