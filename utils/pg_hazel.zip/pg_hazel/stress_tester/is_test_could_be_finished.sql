-- is_test_could_be_finished.sql
-- version 5.0
--Если тест может быть остановлен 
CREATE OR REPLACE FUNCTION is_test_could_be_finished() RETURNS integer AS $$
DECLARE
 test_statistics_rec record ;
 test_statistics_pass_rec record ; 
 curr_id bigint;  
 current_test_id bigint ;  
 min_response_time_long numeric ;
 current_pass_counter bigint ;  
 is_first bigint ;
 param_list text ;
 
 is_finished_status bigint ;
 current_load_mode bigint ; 
 
 has_the_first_hour_passed integer ;
 curr_descent_pct DOUBLE PRECISION;
 descent_reference_list_of_values_rec record ;
 start_param_start_value integer ;
 
 current_load integer ;
BEGIN
  SELECT get_current_test_id()
  INTO current_test_id;
  
  SELECT get_load()
  INTO current_load ;

  SELECT * 
  INTO test_statistics_rec
  FROM test_statistics 
  WHERE test_id = current_test_id;
	
  	
  IF current_load > test_statistics_rec.max_load
  THEN 
    PERFORM set_test_status( 1 ) ;
	return 1 ;
  ELSE
	PERFORM set_test_status( 0 ) ;
	return 0 ; 	
  END IF ;
  
END
$$ LANGUAGE plpgsql;