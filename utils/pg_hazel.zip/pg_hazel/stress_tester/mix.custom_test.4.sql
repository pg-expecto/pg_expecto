﻿-- mix.custom_test4.sql
-- cat ~/.pgpass | grep postgres
-- psql -d test_pgbench_custom -U pgpropwr -f mix.custom_test4.sql 
-- version 51.0
CREATE OR REPLACE FUNCTION mix_custom_test4() RETURNS integer AS $$
DECLARE
  start_timestamp timestamp with time zone ;
  finish_timestamp timestamp with time zone ;
  
  dblink_string text ;
  result_rec record ;
  current_result record ;
  current_test_queryid bigint ; 
  current_queryid bigint;
  
  count integer  ; 
  result_text text ;
  result_int integer ; 
 
BEGIN
 SELECT clock_timestamp() 
 INTO start_timestamp ;

PERFORM dblink_connect_u('current_connection' , 'dbname=performance_monitoring_db  user=performance_monitoring_user  password=144513122024$Uimap!#15');

	SELECT 	* 
	INTO 	current_queryid
	FROM 	dblink( 'current_connection' , 'SELECT get_test_queryid_for_scenario(4)' ) AS t1(queryid bigint);

PERFORM dblink_disconnect('current_connection');

RAISE NOTICE 'current_queryid = %',current_queryid;	

    IF current_queryid = 0 
	THEN 
		SELECT queryid 
		INTO current_test_queryid
		FROM pgpro_stats_statements 
		WHERE query like 'select custom_test4%';	
	ELSE 
		current_test_queryid = current_queryid ; 
	END IF ;

RAISE NOTICE 'current_test_queryid = %',current_test_queryid;	
		
------------------------------------------------------------------
-- СЦЕНАРИЙ 4 - HEAVYWEIGHT
 SELECT custom_test4() 
 INTO current_result ;   
-- СЦЕНАРИЙ 4 - HEAVYWEIGHT
------------------------------------------------------------------


 SELECT clock_timestamp()  
 INTO finish_timestamp ;

 IF current_test_queryid IS NULL
 THEN
	return 0 ;
 END IF;

PERFORM dblink_connect_u('current_connection' , 'dbname=performance_monitoring_db  user=performance_monitoring_user  password=144513122024$Uimap!#15');
	
	dblink_string = 'SELECT stat_timer_add_action( '||current_test_queryid||' , '
	                                                         ||''''||to_char(start_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')||''''||' , '
															 ||''''||to_char(finish_timestamp , 'YYYY-MM-DD HH24:MI:SS.MS')||''''||' ) ' ;

	RAISE NOTICE ' dblink_string = %',dblink_string ;	

	-----------------------------------------------------------------------------
	-- ЗАЛОГИРОВАТЬ
	SELECT * 
	INTO result_int 
	FROM dblink( 'current_connection' , dblink_string ) AS t1( res integer );
	
	
	SELECT dblink_error_message('current_connection')
	INTO result_text ;
	
	RAISE NOTICE '%',result_text ;
	-- ЗАЛОГИРОВАТЬ
	-----------------------------------------------------------------------------
	
PERFORM dblink_disconnect('current_connection');
	
 return result_int ; 
END
$$ LANGUAGE plpgsql;

