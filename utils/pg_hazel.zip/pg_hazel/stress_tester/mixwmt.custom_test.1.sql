﻿-- mixwmt.custom_test1.sql
-- cat ~/.pgpass | grep postgres
-- psql -d test_pgbench_custom -U pgpropwr -f mixwmt.custom_test1.sql 
-- version 52.0
CREATE OR REPLACE FUNCTION mixwmt_custom_test1() RETURNS integer AS $$
DECLARE
  current_result record ;
BEGIN
 		
 ------------------------------------------------------------------
 -- СЦЕНАРИЙ 1 - SELECT ONLY
 SELECT custom_test1() 
 INTO current_result ; 
 -- СЦЕНАРИЙ 1 - SELECT ONLY
 ------------------------------------------------------------------
 	
 return 0 ; 
END
$$ LANGUAGE plpgsql;

