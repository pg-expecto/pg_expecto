﻿-- mixwmt.custom_test2.sql
-- cat ~/.pgpass | grep postgres
-- psql -d test_pgbench_custom -U pgpropwr -f mixwmt.custom_test2.sql 
-- version 52.0
CREATE OR REPLACE FUNCTION mixwmt_custom_test2() RETURNS integer AS $$
DECLARE
  current_result record ;
BEGIN
		
 ------------------------------------------------------------------
 -- СЦЕНАРИЙ 2 - OLTP
 SELECT custom_test2() 
 INTO current_result ; 
 -- СЦЕНАРИЙ 2 - OLTP
 ------------------------------------------------------------------

	
 return 0 ; 
END
$$ LANGUAGE plpgsql;

