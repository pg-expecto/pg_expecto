﻿-- mixwmt.custom_test3.sql
-- cat ~/.pgpass | grep postgres
-- psql -d test_pgbench_custom -U pgpropwr -f mixwmt.custom_test3.sql 
-- version 52.0
CREATE OR REPLACE FUNCTION mixwmt_custom_test3() RETURNS integer AS $$
DECLARE
  current_result record ;
BEGIN
		
------------------------------------------------------------------
 -- СЦЕНАРИЙ 3 - INSERT ONLY
 SELECT custom_test3() 
 INTO current_result ; 
 -- СЦЕНАРИЙ 3 - INSERT ONLY
 ------------------------------------------------------------------
	
 return 0 ; 
END
$$ LANGUAGE plpgsql;

