﻿-- mixwmt.custom_test4.sql
-- cat ~/.pgpass | grep postgres
-- psql -d test_pgbench_custom -U pgpropwr -f mixwmt.custom_test4.sql 
-- version 52.0
CREATE OR REPLACE FUNCTION mixwmt_custom_test4() RETURNS integer AS $$
DECLARE
  current_result record ;
BEGIN
		
------------------------------------------------------------------
-- СЦЕНАРИЙ 4 - HEAVYWEIGHT
 SELECT custom_test4() 
 INTO current_result ;   
-- СЦЕНАРИЙ 4 - HEAVYWEIGHT
------------------------------------------------------------------
	
 return 0 ; 
END
$$ LANGUAGE plpgsql;

