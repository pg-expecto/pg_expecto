#!/bin/sh
# pg_stat_tester.create_db.sh 
# Создать тестовую БД
# Инициировать тестовую БД
# version 58.0


#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/pg_stat_tester.create_db.log'
ERR_FILE=$current_path'/pg_stat_tester.create_db.err'


timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M%S")

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE

######################################################################
# Инициализировать тестовую БД ?
init_test_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path init_test_db 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : init_test_db = '$init_test_db
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : init_test_db = '$init_test_db >> $LOG_FILE	

#################################################################################
# НЕ ИНИЦИАЛИЗИРОВАТЬ ТЕСТОВУЮ БД
if [ "$init_test_db" == "off" ]
then 
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : FINISHED '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : FINISHED ' >> $LOG_FILE
  exit 0  
fi



######################################################################
# Сценарий 
scenario=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scenario 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : СЦЕНАРИЙ = '$scenario
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	

#################################################################################
# СЦЕНАРИЙ pgbench
if [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ] || [ "$scenario" == "5" ] || [ "$scenario" == "6" ] || [ "$scenario" == "7" ] || 
   [ "$scenario" == "100" ] || 
   [ "$scenario" == "11" ] || [ "$scenario" == "12" ] || [ "$scenario" == "13" ] || [ "$scenario" == "14" ] || [ "$scenario" == "15" ] || [ "$scenario" == "16" ] 
then 
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DATABASE test_pgbench_custom CREATION IS STARTED '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DATABASE test_pgbench_custom CREATION IS STARTED ' >> $LOG_FILE
	  
	psql -c "DROP DATABASE IF EXISTS test_pgbench_custom ( FORCE ) " 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	psql -c "CREATE DATABASE test_pgbench_custom WITH OWNER = pgpropwr" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	psql -d test_pgbench_custom -c "CREATE EXTENSION IF NOT EXISTS dblink" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DBLINK HAS BEEN CREATED '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DBLINK HAS BEEN CREATED ' >> $LOG_FILE
	
	psql -d test_pgbench_custom -c "GRANT EXECUTE ON FUNCTION dblink_connect_u ( text , text ) TO pgpropwr" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : GRANT DBLINK  '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : GRANT DBLINK  ' >> $LOG_FILE
	
	
    psql -d test_pgbench_custom -c "CREATE EXTENSION IF NOT EXISTS pgpro_stats" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_STATS HAS BEEN CREATED '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_STATS HAS BEEN CREATED ' >> $LOG_FILE
	

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 1'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 1' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/custom_test.1.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 2'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 2' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/custom_test.2.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 3'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 3' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/custom_test.3.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 4'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST 4' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/custom_test.4.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOM TEST' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/custom_test.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOMIZED TEST'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : CUSTOMIZED TEST' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/customized_test.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 1'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 1' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mix.custom_test.1.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 2'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 2' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mix.custom_test.2.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 3'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 3' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mix.custom_test.3.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 4'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIX SCENARIO 4' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mix.custom_test.4.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 1'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 1' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mixwmt.custom_test.1.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 2'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 2' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mixwmt.custom_test.2.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 3'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 3' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mixwmt.custom_test.3.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 4'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : MIXWMT SCENARIO 4' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d test_pgbench_custom -U pgpropwr -f /postgres/scripts/tester/stress_tester/mixwmt.custom_test.4.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DATABASE test_pgbench_custom HAS BEEN CREATED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DATABASE test_pgbench_custom HAS BEEN CREATED ' >> $LOG_FILE

fi
# СЦЕНАРИЙ pgbench
#################################################################################

#################################################################################
# СЦЕНАРИЙ в пользовательской БД
if [ "$scenario" == "101" ] || [ "$scenario" == "102" ]
then 
  test_user_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path test_user_db 2>$ERR_FILE`
  exit_code $? $LOG_FILE $ERR_FILE
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : test_user_db = '$test_user_db
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : OK : test_user_db = '$test_user_db >> $LOG_FILE	
  
  if [ "$test_user_db" == "" ]
  then 
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : ERROR : test_user_db IS EMPTY '
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : ERROR : test_user_db IS EMPTY ' >> $LOG_FILE	
    exit 10
  fi
  
  psql -d $test_user_db -c 'SELECT 1 '   
  if [ $? -ne 0 ]
  then 
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : ERROR : test_user_db = '$test_user_db' NOT EXISTS '
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.create_db : ERROR : test_user_db = '$test_user_db' NOT EXISTS ' >> $LOG_FILE	
    exit 20  
  fi
  
    psql -d $test_user_db -c "CREATE EXTENSION IF NOT EXISTS dblink" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DBLINK HAS BEEN CREATED '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : DBLINK HAS BEEN CREATED ' >> $LOG_FILE
	
	psql -d $test_user_db -c "GRANT EXECUTE ON FUNCTION dblink_connect_u ( text , text ) TO pgpropwr" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : GRANT DBLINK  '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : GRANT DBLINK  ' >> $LOG_FILE
	

    psql -d $test_user_db -c "CREATE EXTENSION IF NOT EXISTS pgpro_stats" 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_STATS HAS BEEN CREATED '
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PGPRO_STATS HAS BEEN CREATED ' >> $LOG_FILE

	#########################################################################
	# ВАЖНО - НУЖНО ОПРЕДЕЛИТЬ ВЛАДЕЛЬЦА ПОЛЬЗОВАТЕЛЬСКОЙ БД
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : USER TEST 101'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : USER TEST 101' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d $test_user_db -f /postgres/scripts/tester/stress_tester/user_test.101.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : USER TEST 102'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : USER TEST 102' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d $test_user_db -f /postgres/scripts/tester/stress_tester/user_test.102.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : USER TEST 102'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : USER TEST 102' >> $LOG_FILE
	psql -v ON_ERROR_STOP=on --echo-errors -v ON_ERROR_STOP=on --echo-errors -d $test_user_db -f /postgres/scripts/tester/stress_tester/user_test.sql >> $LOG_FILE 2>>$ERR_FILE
	exit_code $? $LOG_FILE $ERR_FILE
  
fi
# СЦЕНАРИЙ в пользовательской БД
######################################################################
# Сценарий 
######################################################################

echo 'select custom_test( '$scenario' );' > /postgres/scripts/tester/stress_tester/do_custom_test.sql  
		

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : FINISHED ' >> $LOG_FILE
exit 0 

