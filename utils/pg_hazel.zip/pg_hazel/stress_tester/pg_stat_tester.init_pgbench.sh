#!/bin/sh
#!/bin/sh
# pg_stat_tester.init_pgbench.sh
# Инициировать тестовую БД
# version 58.0


#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

LOG_FILE=$current_path'/pg_stat_tester.init_pgbench_db.log'
ERR_FILE=$current_path'/pg_stat_tester.init_pgbench_db.err'


timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M%S")

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK  : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : STARTED '> $LOG_FILE


##############################################################
# РЕЖИМ РАБОТЫ
load_mode=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'SELECT get_load_mode()'` 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK  : load_mode =  '$load_mode
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : load_mode =  '$load_mode >> $LOG_FILE
# РЕЖИМ РАБОТЫ
##############################################################

##############################################################
# РЕЖИМ НАГРУЗКИ
pgbench_clients=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'SELECT get_base_load()'` 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
# РЕЖИМ НАГРУЗКИ
##############################################################

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : pgbench_clients = '$pgbench_clients
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : pgbench_clients = '$pgbench_clients >> $LOG_FILE

######################################################################
# Сценарий 
scenario=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scenario 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : СЦЕНАРИЙ = '$scenario
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	

######################################################################
# Инициализировать тестовую БД ?
init_test_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path init_test_db 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : init_test_db = '$init_test_db
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : init_test_db = '$init_test_db >> $LOG_FILE	

#################################################################################
# НЕ ИНИЦИАЛИЗИРОВАТЬ ТЕСТОВУЮ БД
if [ "$init_test_db" == "off" ]
then 
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom STARTED'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom STARTED' >> $LOG_FILE

  #psql -d test_pgbench_custom -c 'VACUUM ANALYZE' >>$LOG_FILE 2>$ERR_FILE
  /postgres/scripts/tester/stress_tester/vacuum_analyze.sh 2>$ERR_FILE
  exit_code $? $LOG_FILE $ERR_FILE
  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom FINISHED'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom FINISHED' >> $LOG_FILE
 
  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : FINISHED '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : FINISHED ' >> $LOG_FILE  
  exit 0  
fi

#################################################################################
# ИНИЦИАЛИЗИРОВАТЬ ТЕСТОВУЮ БД
#################################################################################
# СЦЕНАРИЙ pgbench
if [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ] || [ "$scenario" == "5" ] || [ "$scenario" == "6" ] || [ "$scenario" == "7" ] ||
   [ "$scenario" == "100" ] ||
   [ "$scenario" == "11" ] || [ "$scenario" == "12" ] || [ "$scenario" == "13" ] || [ "$scenario" == "14" ] || [ "$scenario" == "15" ] || [ "$scenario" == "16" ]
then 
	#########################################################################################################
	#Параметры инициализации	
	#pgbench_init_param='--quiet --foreign-keys --scale='"$pgbench_clients"' -i test_pgbench_custom'
	scale_factor=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scale 2>$ERR_FILE`
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : МАСШТАБ = '$scale_factor
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : МАСШТАБ = '$scale_factor >> $LOG_FILE	
	
	pgbench_init_param='--quiet --foreign-keys --scale='"$scale_factor"' -i test_pgbench_custom'	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : pgbench_init_param= '$pgbench_init_param
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : pgbench_init_param= '$pgbench_init_param>> $LOG_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : INITIALIZATION OF pg_bench STARTED'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : INITIALIZATION OF pg_bench STARTED' >> $LOG_FILE

	pgbench --username=pgpropwr $pgbench_init_param >>$LOG_FILE
	exit_code $? $LOG_FILE $LOG_FILE

	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : INITIALIZATION OF pg_bench FINISHED'
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : INITIALIZATION OF pg_bench FINISHED' >> $LOG_FILE
fi
# СЦЕНАРИЙ pgbench
#################################################################################
# Сценарий 
######################################################################

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom STARTED' >> $LOG_FILE

#psql -d test_pgbench_custom -c 'VACUUM ANALYZE' >>$LOG_FILE 2>$ERR_FILE
/postgres/scripts/tester/stress_tester/vacuum_analyze.sh 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : ANALYZE test_pgbench_custom FINISHED' >> $LOG_FILE
  

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.init_pgbench : OK : FINISHED ' >> $LOG_FILE
exit 0 

