#!/bin/sh
# pg_stat_tester.sh
# mkdir /postgres/scripts/tester
# Tester
# */1 * * * * /postgres/scripts/tester/stress_tester/pg_stat_tester.sh
# version 81.2
 
#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
	/postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'


LOG_FILE=$current_path'/pg_stat_tester.log'
ERR_FILE=$current_path'/pg_stat_tester.err'
PROGRESS_FILE=$current_path'/pg_stat_tester.progress'
TIMESTAMP_LOG_FILE=$current_path'/timestamp.log'

#################################################
#Если тест не начат - выход
if [ ! -f /postgres/scripts/tester/stress_tester/TESTER_STARTED ]; 
then
  exit 0
fi
#################################################

#################################################
#Если идет вакуум таблицы stat_timer_history
if [ -f /postgres/scripts/tester/stress_tester/VACUUM_FULL_STAT_TIMER_HISTORY ]; 
then
  exit 0
fi
#################################################

#################################################
#Если идет транкейт таблицы stat_timer_history и вакуум тестовой БД
if [ -f /postgres/scripts/tester/stress_tester/TRUNCATE_PGBENCH_HISTORY_VACUUM_ANALYZE_FULL ]; 
then
  exit 0
fi
#################################################


#################################################
# Если флаг поднят - выход
if [ -f /postgres/scripts/tester/stress_tester/TESTER_IN_PROGRESS ]; 
then
  current_pass=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select current_pass()' 2>$ERR_FILE`
  exit_code $? $LOG_FILE $ERR_FILE
  
  curr_timestamp=`echo $(date "+%Y-%m-%d %H:%M")`
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : TIMESTAMP_LOG_FILE : OK : curr_timestamp = '$curr_timestamp > $TIMESTAMP_LOG_FILE

#####################################################
# RESERVED FOR FUTURE   
#  is_timestamp_exists=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "select is_timestamp_exists('$curr_timestamp')" 2>$ERR_FILE`
#  exit_code $? $LOG_FILE $ERR_FILE
#  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : TIMESTAMP_LOG_FILE : OK : is_timestamp_exists = '$is_timestamp_exists >> $TIMESTAMP_LOG_FILE
#
#  
#  while [ "$is_timestamp_exists" == "0" ]
#  do 
#	sleep 10s
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : TIMESTAMP_LOG_FILE : OK : waitings for timestamp' >> $TIMESTAMP_LOG_FILE
#	
#   is_timestamp_exists=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "select is_timestamp_exists('$curr_timestamp')" 2>$ERR_FILE`
#    exit_code $? $LOG_FILE $ERR_FILE
#    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : TIMESTAMP_LOG_FILE : OK : is_timestamp_exists = '$is_timestamp_exists >> $TIMESTAMP_LOG_FILE
#  done 
# RESERVED FOR FUTURE     
#####################################################

  
  pgbench_clients=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select get_load()'` 2>$ERR_FILE
  #exit_code $? $LOG_FILE $ERR_FILE


  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester.log : PASS : '$current_pass' LOAD : '$pgbench_clients >> $LOG_FILE

  exit 0
fi
#################################################

#################################################
# Поднять флаг
touch /postgres/scripts/tester/stress_tester/TESTER_IN_PROGRESS
#################################################


get_test_mode=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select get_test_mode()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : TESTER MODE IS '$get_test_mode
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : TESTER MODE IS '$get_test_mode >> $LOG_FILE

get_test_status=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select get_test_status()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : BEFORE START - get_test_status = '$get_test_status
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : BEFORE START - get_test_status = '$get_test_status >> $LOG_FILE

###########################################################################################################
# НАЧАТЬ СБОР ДАННЫХ 	
start_collect_data_result=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select start_collect_data()' 2>>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : START TO COLLECT DATA FOR STATS'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : START TO COLLECT DATA FOR STATS' >> $LOG_FILE
# НАЧАТЬ СБОР ДАННЫХ 	
###########################################################################################################

get_test_status=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select get_test_status()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : 1st - get_test_status = '$get_test_status
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : 1st - get_test_status = '$get_test_status >> $LOG_FILE

##############################################################################################################
# КЛИЕНТЫ И ВРЕМЯ - PGBENCH
current_pass=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select current_pass()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE

pgbench_clients=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select set_load()'` 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

if [ "$current_pass" == "1" ]
 then 
    #Базовый период 
    pg_bench_time=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path base_duration 2>$ERR_FILE`
    exit_code $? $LOG_FILE $ERR_FILE
else
    #Тестовый период
    pg_bench_time=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path test_duration 2>$ERR_FILE`
    exit_code $? $LOG_FILE $ERR_FILE
fi

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : Текущий проход: '$current_pass
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : Текущий проход: '$current_pass >> $LOG_FILE	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : Количество клиентов: '$pgbench_clients
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : Количество клиентов: '$pgbench_clients >> $LOG_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : Время теста в секундах: '$pg_bench_time
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : Время теста в секундах: '$pg_bench_time >> $LOG_FILE

	
	
#--jobs=потоки Число рабочих потоков в pgbench. Использовать нескольких потоков может быть полезно на многопроцессорных компьютерах
jobs=`cat /proc/cpuinfo|grep processor|wc -l`
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : jobs= '$jobs
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : jobs= '$jobs>> $LOG_FILE

#######################################################################################
# connect
connect_mode=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path connect_mode 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : connect_mode = '$connect_mode
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : connect_mode = '$connect_mode >> $LOG_FILE	

if [ "$connect_mode" == "0" ]
then 
	pgbench_param=' '
else
	pgbench_param='--connect '
fi 

# connect
#######################################################################################

#######################################################################################
# СЦЕНАРИЙ
scenario=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scenario 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	

psql -d $performance_monitoring_db -U $performance_monitoring_user -c "select  set_scenario("$scenario")" >>$LOG_FILE 2>$PROGRESS_FILE
exit_code $? $LOG_FILE $PROGRESS_FILE


#################################################################################
# СЦЕНАРИЙ pgbench
if [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ] 
then 
  pgbench_param=$pgbench_param'--file=/postgres/scripts/tester/stress_tester/do_custom_test.sql --protocol=extended --report-per-command --jobs='"$jobs"' --client='"$pgbench_clients"' --time='"$pg_bench_time"' test_pgbench_custom'			
fi

# СЦЕНАРИЙ pgbench
#################################################################################

#################################################################################
# СЦЕНАРИЙ в пользовательской БД
if [ "$scenario" == "101" ] || [ "$scenario" == "102" ]
then 
  test_user_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path test_user_db 2>$ERR_FILE`
  exit_code $? $LOG_FILE $ERR_FILE
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_user_db = '$test_user_db
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_user_db = '$test_user_db >> $LOG_FILE	
  
  pgbench_param=$pgbench_param'--no-vacuum --file=/postgres/scripts/tester/stress_tester/do_custom_test.sql --report-per-command --jobs='"$jobs"' --client='"$pgbench_clients"' --time='"$pg_bench_time"' '$test_user_db
fi 
# СЦЕНАРИЙ в пользовательской БД
#################################################################################

# СЦЕНАРИЙ
#################################
 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench READY FOR START '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench READY FOR START ' >> $LOG_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench progress stored in file :'$PROGRESS_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench progress stored in file :'$PROGRESS_FILE  >> $LOG_FILE


psql -d $performance_monitoring_db -U $performance_monitoring_user -c 'select  start_test()' >>$LOG_FILE 2>$PROGRESS_FILE
exit_code $? $LOG_FILE $PROGRESS_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : STORE START TIME  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : STORE START TIME ' >> $LOG_FILE

#############################################################################
# PGBENCH
touch /postgres/scripts/tester/stress_tester/PGBENCH_WORKING
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	


if [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ]  
then 
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench_param= '$pgbench_param
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench_param= '$pgbench_param>> $LOG_FILE
		
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench STARTED' >> $LOG_FILE	

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

	pgbench --username=pgpropwr $pgbench_param >>$LOG_FILE 2>$PROGRESS_FILE
	exit_code $? $LOG_FILE $PROGRESS_FILE

test_queryid=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select  get_test_queryid()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_queryid= '$test_queryid
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_queryid= '$test_queryid>> $LOG_FILE

	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_pause()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

fi 

#############################################
# Кастомный сценарий
if [ "$scenario" == "100" ] 
then 
pgbench_param=$pgbench_param'--file=/postgres/scripts/tester/stress_tester/do_customized_test.sql --protocol=extended --report-per-command --jobs='"$jobs"' --client='"$pgbench_clients"' --time='"$pg_bench_time"' test_pgbench_custom'			

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench_param= '$pgbench_param
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench_param= '$pgbench_param>> $LOG_FILE
		
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench STARTED' >> $LOG_FILE		

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

	pgbench --username=pgpropwr $pgbench_param >>$LOG_FILE 2>$PROGRESS_FILE
	exit_code $? $LOG_FILE $PROGRESS_FILE

test_queryid=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select  get_test_queryid()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_queryid= '$test_queryid
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_queryid= '$test_queryid>> $LOG_FILE
	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_pause()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

fi 
# Кастомный сценарий
#############################################

#############################################
# Сценарий MIX	
if [ "$scenario" == "5" ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO STARTED'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO STARTED' >> $LOG_FILE	

  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

  for i in {1..4}
  do
    pgbench_clients=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "select get_load_by_scenario("$i" )"` 2>$ERR_FILE
    exit_code $? $LOG_FILE $ERR_FILE

	pgbench_param_mix=$pgbench_param'--file=/postgres/scripts/tester/stress_tester/do_custom_test.'$i'.sql --protocol=extended --report-per-command --jobs='"$jobs"' --client='"$pgbench_clients"' --time='"$pg_bench_time"' test_pgbench_custom'			
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_clients= '$pgbench_clients
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_clients= '$pgbench_clients>> $LOG_FILE
	
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_param_mix= '$pgbench_param_mix
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_param_mix= '$pgbench_param_mix>> $LOG_FILE
	
	pgbench --username=pgpropwr $pgbench_param_mix & >>$LOG_FILE 2>$PROGRESS_FILE
  done
  wait
  
  exit_code $? $LOG_FILE $PROGRESS_FILE  

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select  set_scenario_queryid_for_mix()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : set_scenario_queryid_for_mix'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : set_scenario_queryid_for_mix'>> $LOG_FILE
  

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_pause()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
  	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO FINISHED' >> $LOG_FILE		

fi
# Сценарий MIX	
#############################################

#############################################
# Сценарий MIX WITHOUT MEDIAN TIME 	
if [ "$scenario" == "6" ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX WITHOUT MEDIAN TIME  SCENARIO STARTED'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX WITHOUT MEDIAN TIME  SCENARIO STARTED' >> $LOG_FILE	

 
  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

  for i in {1..4}
  do
    pgbench_clients=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "select get_load_by_scenario("$i" )"` 2>$ERR_FILE
    exit_code $? $LOG_FILE $ERR_FILE

	pgbench_param_mix=$pgbench_param'--file=/postgres/scripts/tester/stress_tester/mixwmt.do_custom_test.'$i'.sql --protocol=extended --report-per-command --jobs='"$jobs"' --client='"$pgbench_clients"' --time='"$pg_bench_time"' test_pgbench_custom'			
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_clients= '$pgbench_clients
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_clients= '$pgbench_clients>> $LOG_FILE
	
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_param_mix= '$pgbench_param_mix
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_param_mix= '$pgbench_param_mix>> $LOG_FILE
	
	pgbench --username=pgpropwr $pgbench_param_mix & >>$LOG_FILE 2>$PROGRESS_FILE
  done
  wait
  
  exit_code $? $LOG_FILE $PROGRESS_FILE  		
  
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select  set_scenario_queryid_for_mix()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : set_scenario_queryid_for_mix'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : set_scenario_queryid_for_mix'>> $LOG_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_pause()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

  	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO FINISHED' >> $LOG_FILE		

fi
# Сценарий MIX WITHOUT MEDIAN TIME 
#############################################

#############################################
# Сценарий MIX WITHOUT MEDIAN TIME WITHOUT CPU LOAD	
if [ "$scenario" == "7" ]
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX WITHOUT MEDIAN TIME WITHOUT CPU LOAD SCENARIO STARTED'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX WITHOUT MEDIAN TIME WITHOUT CPU LOAD SCENARIO STARTED' >> $LOG_FILE	

  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

  for i in {1..3}
  do
    pgbench_clients=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "select get_load_by_scenario("$i" )"` 2>$ERR_FILE
    exit_code $? $LOG_FILE $ERR_FILE

	pgbench_param_mix=$pgbench_param'--file=/postgres/scripts/tester/stress_tester/mixwmt.do_custom_test.'$i'.sql --protocol=extended --report-per-command --jobs='"$jobs"' --client='"$pgbench_clients"' --time='"$pg_bench_time"' test_pgbench_custom'			
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_clients= '$pgbench_clients
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_clients= '$pgbench_clients>> $LOG_FILE
	
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_param_mix= '$pgbench_param_mix
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : SCENARIO '$i': pgbench_param_mix= '$pgbench_param_mix>> $LOG_FILE
	
	pgbench --username=pgpropwr $pgbench_param_mix & >>$LOG_FILE 2>$PROGRESS_FILE
  done
  wait
  
  exit_code $? $LOG_FILE $PROGRESS_FILE  	

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select  set_scenario_queryid_for_mix()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : set_scenario_queryid_for_mix'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : set_scenario_queryid_for_mix'>> $LOG_FILE
  

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_pause()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

  	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pgbench MIX SCENARIO FINISHED' >> $LOG_FILE		

fi
# Сценарий MIX WITHOUT MEDIAN TIME 
#############################################
	
rm /postgres/scripts/tester/stress_tester/PGBENCH_WORKING	
# PGBENCH
#############################################################################
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : pg_bench FINISHED' >> $LOG_FILE		

	
psql -d $performance_monitoring_db -U $performance_monitoring_user -c 'select  stop_test()' >>$LOG_FILE 2>$PROGRESS_FILE
exit_code $? $LOG_FILE $PROGRESS_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : STORE FINISH TIME  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : STORE FINISH TIME ' >> $LOG_FILE
		
###########################################################################################################
# ОСТАНОВИТЬ СБОР ДАННЫХ 	
psql -d $performance_monitoring_db -U $performance_monitoring_user -c 'select  stop_collect_data()' >>$LOG_FILE 2>$PROGRESS_FILE
exit_code $? $LOG_FILE $PROGRESS_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : STOP TO COLLECT DATA FOR STATS '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : STOP TO COLLECT DATA FOR STATS ' >> $LOG_FILE
# ОСТАНОВИТЬ СБОР ДАННЫХ 	
###########################################################################################################

###########################################################################################################
# СНИМОК PGPRO_PWR
#################################################
# NEW PGPRO_PWR SNAPSHOT
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : NEW PGPRO_PWR SAMPLE '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : NEW PGPRO_PWR SAMPLE ' >> $LOG_FILE

/postgres/scripts/tester/pgpro_pwr_snapshot.sh 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
# NEW PGPRO_PWR SNAPSHOT
#################################################
	
pgpro_pwr_sample=`psql -d pgpropwr -Aqtc 'SELECT sample FROM profile.show_samples() ORDER BY 1 DESC LIMIT 1'`>> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_pwr_sample= '$pgpro_pwr_sample
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_pwr_sample= '$pgpro_pwr_sample >> $LOG_FILE  


##########################################
# UPDATE test_statistics_pass
psql  -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc "select add_pgpro_pwr_sample('$pgpro_pwr_sample')" >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ADD_PGPRO_PWR_SAMPLE'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : ADD_PGPRO_PWR_SAMPLE' >> $LOG_FILE  
# UPDATE test_statistics_pass
##########################################



# СНИМОК PGPRO_PWR
###########################################################################################################

		
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : VACUUM FULL stat_timer_history STARTED  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : VACUUM FULL stat_timer_history STARTED  ' >> $LOG_FILE
#################################################
# Поднять флаг VACUUM_FULL_STAT_TIMER_HISTORY
touch /postgres/scripts/tester/stress_tester/VACUUM_FULL_STAT_TIMER_HISTORY
#################################################
 psql -d $performance_monitoring_db -U $performance_monitoring_user -c 'VACUUM FULL stat_timer_history' >>$LOG_FILE 2>$PROGRESS_FILE
 exit_code $? $LOG_FILE $PROGRESS_FILE
#################################################
# опустить флаг VACUUM_FULL_STAT_TIMER_HISTORY
rm /postgres/scripts/tester/stress_tester/VACUUM_FULL_STAT_TIMER_HISTORY
#################################################

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : VACUUM FULL stat_timer_history FINISHED  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : VACUUM FULL stat_timer_history FINISHED  ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : CALC STATISTICS FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : CALC STATISTICS FINISHED' >> $LOG_FILE	
		



###########################################################
# Дождаться окончания сбора стистики pg_hazel
while [ -f /postgres/scripts/tester/stress_tester/PG_HAZEL_IN_PROGRESS ]
do
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : CALC STATISTICS FINISHED'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : CALC STATISTICS FINISHED' >> $LOG_FILE	
  sleep 5
done 
###########################################################

STAT_RESULTS=$current_path'/result_stats.txt'
PLAN_STAT_RESULTS=$current_path'/result_plan_stats.txt'
STATS_FOR_PASS_ERR=$current_path'/stats_for_pass.err'

 
 
			
	echo '*******************************************************' >> $PLAN_STAT_RESULTS
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M") >> $PLAN_STAT_RESULTS
	echo 'current_pass='$current_pass >> $PLAN_STAT_RESULTS
	echo 'pgbench_clients='$pgbench_clients >> $PLAN_STAT_RESULTS		
	echo ' ' >> $PLAN_STAT_RESULTS		

##############################################################################################################################################################################
# RESERVED FOR FUTURE 
#	###################################
#	# СТАТИСТИКА ПЛАНА ВЫПОЛНЕНИЯ 
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : EXPLAIN PLAN STARTED '
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : EXPLAIN PLAN STARTED ' >> $LOG_FILE	
#			
#	######################################################################
#	# Сценарий 
#	scenario=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scenario 2>$ERR_FILE`
#	exit_code $? $LOG_FILE $ERR_FILE
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	
#			
#	#################################################################################
#	# СЦЕНАРИЙ pgbench
#	if [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ] || [ "$scenario" == "5" ] || [ "$scenario" == "6" ] ||
#	   [ "$scenario" == "11" ] || [ "$scenario" == "12" ] || [ "$scenario" == "13" ] || [ "$scenario" == "14" ] || [ "$scenario" == "15" ] || [ "$scenario" == "16" ]
#	then 
#		test_user_db='test_pgbench_custom'
#	fi 
#	
#	# СЦЕНАРИЙ pgbench
#	#################################################################################
#			
#	#################################################################################
#	# СЦЕНАРИЙ в пользовательской БД
#	if [ "$scenario" == "101" ] || [ "$scenario" == "102" ]
#	then 
#		test_user_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path test_user_db 2>$ERR_FILE`
#		exit_code $? $LOG_FILE $ERR_FILE
#	fi
#			
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_user_db = '$test_user_db
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_user_db = '$test_user_db >> $LOG_FILE	
#			
#	psql -d $test_user_db -c 'explain ( analyze, costs , verbose , buffers , settings , timing , summary ) select * from custom_test('$scenario')' >> $PLAN_STAT_RESULTS
#	exit_code $? $LOG_FILE $ERR_FILE
#			  
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : EXPLAIN PLAN ADDED'
#	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : EXPLAIN PLAN ADDED' >> $LOG_FILE				
#	# СТАТИСТИКА ПЛАНА ВЫПОЛНЕНИЯ 
#	##################################
# RESERVED FOR FUTURE 	
##############################################################################################################################################################################

			

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : COLLECT DATA HAS BEEN FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : COLLECT DATA HAS BEEN FINISHED ' >> $LOG_FILE

#################################################
#Если тест завершен принудительно - выход
#Отчет не формировать
if [ ! -f /postgres/scripts/tester/stress_tester/TESTER_STARTED ]; 
then
  /postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
  exit 0
fi

# CHECK FINISH 
is_test_could_be_finished=`psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select is_test_could_be_finished()' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
# CHECK FINISH 

#################################################
#ЕСЛИ ТЕСТ МОЖЕТ БЫТЬ ЗАВЕРШЕН
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : is_test_could_be_finished = '$is_test_could_be_finished
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : is_test_could_be_finished = '$is_test_could_be_finished >> $LOG_FILE
if [ "$is_test_could_be_finished" == "1" ];
then 	
#################################################################################
# ФИНАЛЬНЫЙ ОТЧЕТ ПО autovacuum
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : AUTOVACUUM HISTORY - STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : AUTOVACUUM HISTORY - STARTED ' >> $LOG_FILE

LOG_DIR='/log/pg_log'
cd $LOG_DIR
CURRENT_LOG=`ls -trh | tail -1`

cat $CURRENT_LOG | grep "vacuum" | grep "public.pgbench_accounts" > /tmp/vacuum_history_pgbench_accounts.txt
cat $CURRENT_LOG | grep "vacuum" | grep "public.pgbench_branches" > /tmp/vacuum_history_pgbench_branches.txt
cat $CURRENT_LOG | grep "vacuum" | grep "public.pgbench_history" > /tmp/vacuum_history_pgbench_history.txt
cat $CURRENT_LOG | grep "vacuum" | grep "public.pgbench_tellers" > /tmp/vacuum_history_pgbench_tellers.txt

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : AUTOVACUUM HISTORY - FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : AUTOVACUUM HISTORY - FINISHED ' >> $LOG_FILE
# ФИНАЛЬНЫЙ ОТЧЕТ ПО autovacuum
#################################################################################

  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
  psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
  exit_code $? $LOG_FILE $ERR_FILE
  
  #################################################
  # Опустить флаг
  #rm /postgres/scripts/tester/stress_tester/TESTER_IN_PROGRESS
  /postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
  #################################################

  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : STRESS_REPORT STARTED '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : STRESS_REPORT STARTED ' >> $LOG_FILE  
  cd /postgres/scripts/tester/reports/
  /postgres/scripts/tester/reports/stress_report.sh
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : STRESS_REPORT FINISH '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : STRESS_REPORT FINISH ' >> $LOG_FILE  
  exit 0 
fi
#ЕСЛИ ТЕСТ МОЖЕТ БЫТЬ ЗАВЕРШЕН
#################################################

# НАЧАТЬ СЛЕДУЮЩИЙ ПРОХОД 
#Выполнить вакуум анализ для тестовой БД
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : TRUNCATE pgbench_history / VACUUM ANALYZE FULL : STARTED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : TRUNCATE pgbench_history / VACUUM ANALYZE FULL : STARTED' >> $LOG_FILE

#################################################################################
# СЦЕНАРИЙ pgbench
if [ "$scenario" == "1" ] || [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ] || [ "$scenario" == "5" ] || [ "$scenario" == "6" ] ||
   [ "$scenario" == "11" ] || [ "$scenario" == "12" ] || [ "$scenario" == "13" ] || [ "$scenario" == "14" ] || [ "$scenario" == "15" ] || [ "$scenario" == "16" ]
then 
#################################################
# Поднять флаг TRUNCATE_PGBENCH_HISTORY_VACUUM_ANALYZE_FULL
touch /postgres/scripts/tester/stress_tester/TRUNCATE_PGBENCH_HISTORY_VACUUM_ANALYZE_FULL
#################################################

  psql -d test_pgbench_custom -c 'TRUNCATE TABLE pgbench_history' >>$LOG_FILE 2>$PROGRESS_FILE
  exit_code $? $LOG_FILE $PROGRESS_FILE
############################################################################# 
# DISABLED 
#  
#  psql -d test_pgbench_custom -c 'VACUUM ANALYZE' >>$LOG_FILE 2>$PROGRESS_FILE
#  exit_code $? $LOG_FILE $PROGRESS_FILE
#  psql -d test_pgbench_custom -c 'VACUUM FULL' >>$LOG_FILE 2>$PROGRESS_FILE
#  exit_code $? $LOG_FILE $PROGRESS_FILE
############################################################################# 

#################################################
# опустить флаг TRUNCATE_PGBENCH_HISTORY_VACUUM_ ANALYZE_FULL
rm /postgres/scripts/tester/stress_tester/TRUNCATE_PGBENCH_HISTORY_VACUUM_ANALYZE_FULL
#################################################

fi
# СЦЕНАРИЙ pgbench
#################################################################################

#################################################################################
# СЦЕНАРИЙ в пользовательской БД
if [ "$scenario" == "101" ] || [ "$scenario" == "102" ]
then 
  test_user_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path test_user_db 2>$ERR_FILE`
  exit_code $? $LOG_FILE $ERR_FILE
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_user_db = '$test_user_db
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : test_user_db = '$test_user_db >> $LOG_FILE	
  
  psql -d $test_user_db -c 'VACUUM ANALYZE' >>$LOG_FILE 2>$PROGRESS_FILE
  exit_code $? $LOG_FILE $PROGRESS_FILE
fi 
# СЦЕНАРИЙ в пользовательской БД
#################################################################################
# СЦЕНАРИЙ
#################################################################################

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : TRUNCATE pgbench_history / VACUUM ANALYZE FULL : FINISHED'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : pg_stat_tester : OK : TRUNCATE pgbench_history / VACUUM ANALYZE FULL : FINISHED' >> $LOG_FILE


#################################################
# Опустить флаг
rm /postgres/scripts/tester/stress_tester/TESTER_IN_PROGRESS
#################################################
exit 0
