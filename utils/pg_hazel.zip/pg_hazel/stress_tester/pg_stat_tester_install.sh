﻿#!/bin/sh
# pg_stat_tester_install.sh
# version 59.0


#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}


script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/pg_stat_tester_install.log'
ERR_FILE=$current_path'/pg_stat_tester_install.err'

timestamp_label=$(date "+%Y%m%d")'T'$(date "+%H%M%S")

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED '> $LOG_FILE

#####################################
cd /postgres/scripts/tester/stress_tester
#####################################

echo 'OK : START INSTALLATION '
echo 'OK : START INSTALLATION ' >> $LOG_FILE

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_stats CREATION '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pgpro_stats CREATION ' >> $LOG_FILE
psql -d $performance_monitoring_db -v ON_ERROR_STOP=on --echo-errors -c 'CREATE EXTENSION IF NOT EXISTS pgpro_stats' >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : is_test_could_be_finished'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : is_test_could_be_finished' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stress_tester/is_test_could_be_finished.sql >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_collect_data'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : start_collect_data' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stress_tester/start_collect_data.sql >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stop_collect_data'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stop_collect_data' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stress_tester/stop_collect_data.sql >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : TABLES AND FUNCTIONS'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : TABLES AND FUNCTIONS' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stress_tester/tables_functions.sql >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : UPDATE VERSION'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : UPDATE VERSION' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user  -v ON_ERROR_STOP=on --echo-errors -f /postgres/scripts/tester/stress_tester/pg_stats_tester_version.sql >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : LOG AUTOVACUUM DURATION '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : LOG AUTOVACUUM DURATION log' >> $LOG_FILE
psql -v ON_ERROR_STOP=on --echo-errors -c 'ALTER SYSTEM SET log_autovacuum_min_duration = 0;' >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
psql -v ON_ERROR_STOP=on --echo-errors -c 'select pg_reload_conf()' >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


exit 0 