#!/bin/sh
# pg_stat_tester_stop.sh
# version 53.0

#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

LOG_FILE=$current_path'/tester_stop.log'
ERR_FILE=$current_path'/tester_stop.err'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: STOPING TEST STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: STOPING TEST STARTED ' >> $LOG_FILE

rm /postgres/scripts/tester/stress_tester/TESTER_STARTED
rm /postgres/scripts/tester/stress_tester/TESTER_IN_PROGRESS
rm /postgres/scripts/tester/stress_tester/TESTER_LOG_IN_PROGRESS
rm /postgres/scripts/tester/stress_tester/PGBENCH_WORKING

psql -d $performance_monitoring_db -U $performance_monitoring_user -c 'select stop_test()' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: stop_test '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: stop_test ' >> $LOG_FILE


psql -c 'ALTER SYSTEM SET log_connections=on' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: ALTER SYSTEM SET log_connections=on '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: ALTER SYSTEM SET log_connections=on ' >> $LOG_FILE

psql -c 'ALTER SYSTEM SET log_disconnections=on' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: ALTER SYSTEM SET log_disconnections=on '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: ALTER SYSTEM SET log_disconnections=on ' >> $LOG_FILE

psql -c 'select pg_reload_conf()' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: select pg_reload_conf() '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: select pg_reload_conf() ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: STATS NOW IS COLLECTING '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: STATS NOW IS COLLECTING ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: TEST STOPPED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : pg_stat_tester_stop: TEST STOPPED ' >> $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL RESUMED' >> $LOG_FILE
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_resume()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


exit 0 

