#!/bin/sh
# pg_stats_tester_version.sh 
performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'
psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'SELECT * FROM jsonb_each (pg_stats_tester_version()) ORDER BY 2 DESC ' 