﻿--pg_stats_tester_version.sql
------------------------------------------------------------------------------------
--Версия 
CREATE OR REPLACE FUNCTION pg_stats_tester_version() RETURNS JSONB AS $$
BEGIN
RETURN 
jsonb_build_object
(
'pg_stat_tester.sh' , '16.0' ,
'stress_start.sh' , '15.0' ,
'pg_stat_tester_stop.sh' , '15.0' ,
'tables_functions.sql' , '07.0' ,
'start_collect_data.sql' , '05.1' ,
'stop_collect_data.sql' , '05.1' ,
'pg_stat_tester_install.sh' , '05.1' ,
'custom_test.1.sql' , '05.0' ,
'custom_test.2.sql' , '05.0' ,
'custom_test.3.sql' , '05.0' ,
'custom_test.4.sql' , '05.0' ,
'custom_test.sql' , '05.0' ,
'finish_test.sh' , '05.0' ,
'is_test_could_be_finished.sql' , '05.0' ,
'pg_stat_tester.create_db.sh' , '05.0' ,
'pg_stat_tester.init_pgbench.sh' , '05.0' ,
'stress.sh' , '05.0' ,
'stress_start_custom.sh' , '05.0' ,
'user_test.sql' , '05.0' ,
'user_test.101.sql' , '05.0' ,
'user_test.102.sql' , '05.0' 
);
END
$$ LANGUAGE plpgsql IMMUTABLE;
