-- start_collect_data.sql
-- version 5.1
--Начать собирать данные для статистики для текущей фазы теста
CREATE OR REPLACE FUNCTION start_collect_data() RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
  current_pass_counter bigint ;   
  curr_id bigint ;
  
  current_test_mode text ;
  
  descent_reference_list_of_values_rec RECORD ;
  test_statistics_rec	RECORD ; 
  test_statistics_pass_rec	RECORD ; 
  prev_test_statistics_pass_rec	RECORD ; 
  
  
  next_value integer  ;
  current_param_order_id bigint ; 
  start_collect_data_result bigint ;
  next_descent_param_result text ;
  param_order_count bigint ; 
  
  has_the_first_hour_passed integer ;
  
  test_status integer ; 
  current_descent_mode text ;
  current_descent_direction integer ;
  current_value integer ; 
  
  test_queryid bigint ;
  
BEGIN
	
	SELECT has_the_first_hour_passed()
	INTO has_the_first_hour_passed ; 
	  
    SELECT get_current_test_id()
	INTO current_test_id;

	SELECT pass_counter
	INTO current_pass_counter
	FROM test_statistics
	WHERE test_id =  current_test_id;
	
	current_pass_counter = current_pass_counter + 1 ;
	PERFORM increment_pass_counter();


	INSERT INTO test_statistics_pass 
	( 
	  test_id , 
	  start_timestamp , 
	  pass_counter   --Номер прохода 
	)
	VALUES 
	( 
	  current_test_id ,  							--test_id bigint , 
	  date_trunc('minute'  , CURRENT_TIMESTAMP) , --start_timestamp , 
	  current_pass_counter  						--pass_counter  , --Номер прохода 
	);

 PERFORM set_test_status( 0 ) ; 	
 return 0  ; 		

END
$$ LANGUAGE plpgsql;




