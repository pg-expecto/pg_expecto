-- stop_collect_data.sql
-- version 5.1
--Завершить сбор данных для статистики для текущей фазы теста
CREATE OR REPLACE FUNCTION stop_collect_data() RETURNS integer AS $$
DECLARE 
  min_timestamp timestamptz ; 
  max_timestamp timestamptz ; 
  
  curr_id bigint;  
  current_test_id bigint ;  
  current_mode text ; 
  
  has_the_first_hour_passed integer ;
  current_test_mode text ;
  
  test_statistics_rec record ; 
  current_load integer ; 
BEGIN
	
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT get_current_test_pass_id()
	INTO curr_id ;
	
	UPDATE test_statistics_pass SET finish_timestamp = date_trunc('minute'  , CURRENT_TIMESTAMP) WHERE id = curr_id ;
	UPDATE test_statistics SET test_finished = date_trunc('minute'  , CURRENT_TIMESTAMP) WHERE test_id = current_test_id ;
	
    SELECT get_test_mode()
	INTO current_test_mode ; 
	
	----------------------------------------------------------------------------------
	--ОБНОВИТЬ ПОКАЗАТЕЛИ ТЕКУЩЕГО ПРОХОДА - ЗАГРУЗКА	
	SELECT get_load()
	INTO  current_load ; 
RAISE NOTICE 'current_load=%',current_load;		

	UPDATE 	test_statistics_pass 
	SET 	load_connections = current_load
   	WHERE id = curr_id ;
	--ОБНОВИТЬ ПОКАЗАТЕЛИ ТЕКУЩЕГО ПРОХОДА - ЗАГРУЗКА
	----------------------------------------------------------------------------------				
	
    

  return 0 ; 
END
$$ LANGUAGE plpgsql;

