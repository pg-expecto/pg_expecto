#!/bin/sh
# stress.sh
# Стандартный режим запуска 
# version 53.0

#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
	/postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/stress.log'
ERR_FILE=$current_path'/stress.err'

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : STARTED' > $LOG_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : INFO : PG_HAZEL PAUSED' >> $LOG_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -Aqtc 'select stats_pause()' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
 
 
/postgres/scripts/tester/stress_tester/stress_start.sh 4 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress : OK : FINISHED' >> $LOG_FILE


exit 0 

