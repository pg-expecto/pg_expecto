#!/bin/sh
# stress_start.sh режим
# 0 - LOW
# 1 - HIGH 
# 2 - HIGHLOAD
# 3 - CUSTOM 
# 4 - STANDARD
# stress_start.sh  3 connections increment
# ./stress_start.sh 0 1 
# version 50.0

#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
	/postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

performance_monitoring_db='performance_monitoring_db'
performance_monitoring_user='performance_monitoring_user'

LOG_FILE=$current_path'/stress_start.log'
ERR_FILE=$current_path'/stress_start.err'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED' > $LOG_FILE
 

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : CREATION OF TEST DB IS STARTING '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : CREATION OF TEST DB IS STARTING  '>> $LOG_FILE
/postgres/scripts/tester/stress_tester/pg_stat_tester.create_db.sh 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : CREATION OF TEST DB HAS BEEN FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : CREATION OF TEST DB HAS BEEN FINISHED  '>> $LOG_FILE


##############################################################
# НОВЫЙ ТЕСТ STRESS
test_mode='STRESS'

######################################################################
# Сценарий 
scenario=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path scenario 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : СЦЕНАРИЙ = '$scenario
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : СЦЕНАРИЙ = '$scenario >> $LOG_FILE	

#################################################################################
# СЦЕНАРИЙ pgbench
if [ "$scenario" == "1" ] || [ "$scenario" == "2" ] || [ "$scenario" == "3" ] || [ "$scenario" == "4" ] || [ "$scenario" == "5" ] || [ "$scenario" == "6" ]
then 
	test_user_db="test_pgbench_custom"
fi
# СЦЕНАРИЙ pgbench
#################################################################################

#################################################################################
# СЦЕНАРИЙ в пользовательской БД
if [ "$scenario" == "101" ] || [ "$scenario" == "102" ]
then 
  test_user_db=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path test_user_db 2>$ERR_FILE`
  exit_code $? $LOG_FILE $ERR_FILE
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : test_user_db = '$test_user_db
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : test_user_db = '$test_user_db >> $LOG_FILE	
  
  if [ "$test_user_db" == "" ]
  then 
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : ERROR : test_user_db IS EMPTY '
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : ERROR : test_user_db IS EMPTY ' >> $LOG_FILE	
    exit 10
  fi
  
  psql -d $test_user_db -c 'SELECT 1 '   
  if [ $? -ne 0 ]
  then 
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : ERROR : test_user_db = '$test_user_db' NOT EXISTS '
    echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : ERROR : test_user_db = '$test_user_db' NOT EXISTS ' >> $LOG_FILE	
    exit 20  
  fi  
fi
# СЦЕНАРИЙ в пользовательской БД
#################################################################################
# Сценарий 
######################################################################

######################################################################
# СНИМОК PGPRO_PWR
psql -d "dbname=pgpropwr application_name=take_sample" -c "SELECT * FROM profile.take_sample('local', true)" >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE	
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PROFILE.TAKE_SAMPLE'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : PROFILE.TAKE_SAMPLE' >> $LOG_FILE
# СНИМОК PGPRO_PWR
######################################################################

######################################################################
# СБРОС СТАТИСТИКИ 
psql -c "select pgpro_stats_statements_reset()" >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : pgpro_stats_statements_reset  '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK :  pgpro_stats_statements_reset  ' >> $LOG_FILE

psql -c "select pg_stat_reset()" >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : pg_stat_reset '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : pg_stat_reset  ' >> $LOG_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -c "select new_test_statistics('STRESS' , '$test_user_db')" >> $LOG_FILE 2>>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : NEW STRESS '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : NEW STRESS ' >> $LOG_FILE
# СБРОС СТАТИСТИКИ 
##############################################################

##############################################################
# РЕЖИМ НАГРУЗКИ
load_mode=$1
# Режим = LOW
if [ "$load_mode" == "0" ];
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN LOW MODE '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN LOW MODE ' >> $LOG_FILE
fi

# Режим = HIGH 
if [ "$load_mode" == "1" ];
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN HIGH MODE '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN HIGH MODE ' >> $LOG_FILE
fi

# Режим = HIGHLOAD 
if [ "$load_mode" == "2" ];
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN HIGHLOAD MODE '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN HIGHLOAD MODE ' >> $LOG_FILE
fi

# Режим = CUSTOM
if [ "$load_mode" == "3" ];
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN CUSTOM MODE '
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN CUSTOM MODE ' >> $LOG_FILE
fi

#####################################################################
# Режим = STANDARD
if [ "$load_mode" == "4" ];
then
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN STANDARD MODE'
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : STARTED IN STANDARD MODE' >> $LOG_FILE
fi

psql -d $performance_monitoring_db -U $performance_monitoring_user -c "select set_load_mode( "$load_mode" )" >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  

base_load_connections=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path start_load 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : base_load_connections =  '$base_load_connections
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : base_load_connections =  '$base_load_connections >> $LOG_FILE
  
psql -d $performance_monitoring_db -U $performance_monitoring_user -c "select set_custom_base_load_connections( "$base_load_connections" )" >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
########################################################################




# Режим = CUSTOM
if [ "$load_mode" == "3" ];
then
  base_load_connections=$2
  if [ "$base_load_connections" == "" ];
  then 
    echo 'ERROR : BASE_LOAD_CONNECTIONS must be set !'
    exit 20;
  fi

  psql -d $performance_monitoring_db -U $performance_monitoring_user -c "select set_custom_base_load_connections( "$base_load_connections" )" >> $LOG_FILE 2>$ERR_FILE
  exit_code $? $LOG_FILE $ERR_FILE  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : base_load_connections =  '$base_load_connections
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : base_load_connections =  '$base_load_connections >> $LOG_FILE
  
  base_load_increment=$3
  if [ "$base_load_connections" == "" ];
  then 
    echo 'ERROR : INCREMENT must be set !'
    exit 30;
  fi
  
  psql -d $performance_monitoring_db -U $performance_monitoring_user -c "select set_custom_base_load_increment( "$base_load_increment" )" >> $LOG_FILE 2>$ERR_FILE
  exit_code $? $LOG_FILE $ERR_FILE  
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : base_load_increment =  '$base_load_increment
  echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : base_load_increment =  '$base_load_increment >> $LOG_FILE
  
fi
##############################################################


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : INIT PGBENCH DATABASE  IS STARTING '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : INIT PGBENCH DATABASE  IS STARTING  '>> $LOG_FILE
/postgres/scripts/tester/stress_tester/pg_stat_tester.init_pgbench.sh
exit_code $? $LOG_FILE $ERR_FILE
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : INIT PGBENCH DATABASE  HAS BEEN FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : INIT PGBENCH DATABASE  HAS BEEN FINISHED  '>> $LOG_FILE

TESTER_LOG_FILE=$current_path'/pg_stat_tester.log'
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : STARTED ' > $TESTER_LOG_FILE

###################################################################################
# МАКСМИМАЛЬНОЕ КОЛИЧЕСТВО СЕССИЙ
finish_load=`/postgres/scripts/tester/stress_tester/get_conf_param.sh $current_path finish_load 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE

psql -d $performance_monitoring_db -U $performance_monitoring_user -c 'select set_max_load('$finish_load');' 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE


echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : finish_load = '$finish_load
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start : OK : finish_load = '$finish_load >> $LOG_FILE
###################################################################################

###################################################################################
# МАКСМИМАЛЬНОЕ КОЛИЧЕСТВО СЕССИЙ




touch /postgres/scripts/tester/stress_tester/TESTER_STARTED


rm $current_path'/*.err'

psql -c 'ALTER SYSTEM SET log_connections=off' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stress_start: ALTER SYSTEM SET log_connections=off '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stress_start: ALTER SYSTEM SET log_connections=off ' >> $LOG_FILE

psql -c 'ALTER SYSTEM SET log_disconnections=off' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stress_start: ALTER SYSTEM SET log_disconnections=off '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stress_start: ALTER SYSTEM SET log_disconnections=off ' >> $LOG_FILE

psql -c 'select pg_reload_conf()' >> $LOG_FILE 2>$ERR_FILE
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stress_start: select pg_reload_conf() '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : OK : stress_start: select pg_reload_conf() ' >> $LOG_FILE


exit 0 

