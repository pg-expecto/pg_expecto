#!/bin/sh
# stress_start_custom.sh длительность connections increment
# 3 - CUSTOM
# version 5.0

#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
	/postgres/scripts/tester/stress_tester/pg_stat_tester_stop.sh
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/stress_start_custom.log'
ERR_FILE=$current_path'/stress_start_custom.err'

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start_custom : OK : STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start_custom : OK : STARTED' > $LOG_FILE

##############################################################
# ЗАГРУЗКА
base_load_connections=$1
if [ "$base_load_connections" == "" ];
then 
  echo 'ERROR : BASE_LOAD_CONNECTIONS must be set !'
  exit 20;
fi

##############################################################
# ИНКРЕМЕНТ
base_load_increment=$2
if [ "$base_load_increment" == "" ];
then 
  echo 'ERROR : INCREMENT must be set !'
  exit 30;
fi


/postgres/scripts/tester/stress_tester/stress_start.sh  3 $base_load_connections $base_load_increment
exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start_custom : OK : FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : stress_start_custom : OK : FINISHED' > $LOG_FILE

exit 0 

