﻿-- tables_functions.sql
-- version 67.0
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ТАБЛИЦЫ
-----------------------------------------------------------------------------------
--Новый сбор статистических данных 
DROP TABLE IF EXISTS test_statistics CASCADE;
CREATE UNLOGGED TABLE test_statistics
(
  test_id SERIAL , 
  current_mode text , -- 'BENCHMARK STRESS DESCENT
  load_mode integer , --0 = low ; 1 = high ; 2 = highload ; 3 - custom  ; 4 - standard
  test_duration integer, --длительность бенчмарка в часах , если NULL то остановка по результатам стресс теста
  base_load_connections DOUBLE PRECISION , -- Базовое количество соединений pgbench
  connections_inc integer   ,		--Приращение к количеству соединений для стресс теста
  test_started timestamp with time zone , 
  test_finished timestamp with time zone ,
  pass_counter integer ,   -- Счетчик проходов теста
  test_status integer  DEFAULT 0 , --  1=тест завершен 2,3 - тест продолжается
  best_mean_exec_time numeric ,  --Лучшее время отклика
  best_mean_exec_time_load integer ,  --Нагрузка для лучшего времени отклика
  best_operational_speed  numeric , --Лучшая операционная скорость
  best_operational_speed_load  integer  , --Нагрузка для лучшей операционная скорость
  best_cpi  numeric , --Лучшая производительность   
  best_load numeric , --Лучшая загрузка
  test_queryid bigint ,		 --queryid тестового запроса
  test_db text ,  --тестовая БД
  performance_zone text , 
  max_load integer , 
  current_scenario integer ,
  scenario_1_queryid bigint , 
  scenario_2_queryid bigint , 
  scenario_3_queryid bigint , 
  scenario_4_queryid bigint   
);

--Статистические данные тестового прохода
DROP TABLE IF EXISTS test_statistics_pass CASCADE;
CREATE UNLOGGED TABLE test_statistics_pass
(
  id SERIAL , 
  test_id integer , 
  start_timestamp timestamp with time zone , 
  finish_timestamp timestamp with time zone , 
  load_connections DOUBLE PRECISION , -- количество соединений pgbench
  current_mean_time numeric ,
  --current_cpi numeric ,
  current_operational_speed numeric ,
  pass_counter integer  , --Номер прохода   
  operational_speed_pct DOUBLE PRECISION , --Относительное изменение операционной скорости
  pgpro_pwr_snapshot text --снимок pgpro_pwr
);

--------------------------------------------------------------------------------------------------------------------------
-- Индексы и ограничения 
ALTER TABLE test_statistics ADD CONSTRAINT test_statistics_pk PRIMARY KEY (test_id);
ALTER TABLE test_statistics_pass ADD CONSTRAINT test_statistics_pass_pk PRIMARY KEY (id);


ALTER TABLE test_statistics_pass ADD CONSTRAINT test_statistics_pass_fk FOREIGN KEY (test_id) REFERENCES test_statistics ( test_id );


CREATE INDEX test_statistics_pass_start_timestamp_idx ON test_statistics_pass ( start_timestamp );
CREATE INDEX test_statistics_pass_finish_timestampidx ON test_statistics_pass ( finish_timestamp );
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--ХРАНИМЫЕ ФУНКЦИИ
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- new_test_statistics( new_mode text ) RETURNS integer 									Начать тест new_mode = BENCHMARK / STRESS / DESCENT
-- get_test_queryid() RETURNS bigint											            queryid тестового запроса
-- get_test_queryid_for_scenario( int current_scenario) RETURNS bigint						queryid тестового запроса для сценария
-- set_scenario_queryid_for_mix()																	Установить quaryid для сценария MIX	
-- start_test()																				Зафиксировать время начала теста 
-- stop_test()																				Зафиксировать время окончания теста 
-- get_finish_timestamp()																	Получить время окончания теста 
-- get_current_test_id() RETURNS integer													id текущего теста
-- get_current_test_pass_id() RETURNS integer 												Получить id тестового прохода
-- get_test_mode() RETURNS text 															Получить режим работы теста  = BENCHMARK / STRESS / DESCENT
-- set_test_duration( new_duration bigint ) RETURNS integer								Установить длительность нагрузки 
-- set_load_mode( new_mode bigint  ) RETURNS integer										Установить нагрузку new_mode = 0 (low) / 1 (high) / 2 (highload) / 3 (custom) / 4 (standard)
-- get_load_mode() RETURNS integer															Получить текущий режим нагрузки  0 (low) / 1 (high) / 2 (highload) / 3 (custom) / 4 (standard)
-- set_custom_base_load_connections( new_base_load_connections bigint  ) RETURNS integer	Установить количество подключения для pgbench в режиме custom
-- set_custom_base_load_increments( new_increment bigint  ) RETURNS integer				Установить инкремент подключений для pgbench в режиме custom
-- set_load() RETURNS integer 														    	Установить  количество подключений для pgbench
-- get_load() RETURNS integer 														    	Текущее количество подключений для pgbench
-- get_load_by_scenario( int ) RETURNS integer 														    	Текущее количество подключений для pgbench для заданного сценария
-- set_max_load( new_max_load integer ) RETURNS integer 								    Установить максимальное  количество подключений для pgbench
-- set_descent_pct( descent_pct integer ) RETURNS integer										Значимое изменение скорости в процентах
-- get_descent_pct() RETURNS DOUBLE PRECISION 												Получить значимое изменение скорости в процентах
-- get_base_load() RETURNS integer 														Базовое количество подключений для инициализации pgbench
-- set_scenario( new_scenario integer  ) RETURNS integer								    Установить сценарий 1-легкий, 2-стандартный, 3-утяжеленый, 4-тяжелый, 5-нагрузочный
-- get_scenario() RETURNS integer															Получить текущий сценарий 1-легкий, 2-стандартный, 3-утяжеленый, 4-тяжелый, 5-нагрузочный
-- start_collect_data() RETURNS integer										Начать сбор статистических данных текущего прохода
-- stop_collect_data() RETURNS integer											Завершить сбор статистических данных текущего прохода
-- stats_report() RETURNS text[]												Текущие показатели производительности  
-- stats_for_pass() RETURNS text												Расчитать статистически данные текущего прохода
-- current_pass() RETURNS integer												Текущий проход
-- clear_cpi_history() RETURNS integer 										Очистить  показатели производительности  
-- ???? first_pass_time() RETURNS text	 										    Начало и окончание первого прохода
-- ??? last_pass_time() RETURNS text	 										    Начало и окончание последнего прохода
-- is_test_could_be_finished() RETURNS integer									ЕСЛИ ТЕСТ МОЖЕТ БЫТЬ ОСТАНОВЛЕН 
-- set_test_status( new_status integer ) RETURNS integer						Установить статус возможности окончания теста 	
-- get_test_status() RETURNS integer											Получить статус возможности окончания теста 	
-- increment_pass_counter() 													УВЕЛИЧИТЬ СЧЕТЧИК ИТЕРАЦИЙ
-- has_the_first_hour_passed() RETURNS integer 								ЕСЛИ закончился первый час работы

-- start_performance_monitoring() Добавить тестовую БД и SQL в мониторинг произвоительности
-- finish_performance_monitoring() Удалить тестовую БД и SQL в мониторинг произвоительности

-- add_pgpro_pwr_sample( new_pgpro_pwr_sample text ) Добавить снимок pgpro_pwr
-- get_scenario_queryid( current_scenario int) bigint --получить queryid
-- get_test_id_by_timestamp() RETURNS integer													id теста



-------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------
--Начать новый тест
CREATE OR REPLACE FUNCTION new_test_statistics( new_mode text , new_test_db text  ) RETURNS integer AS $$
BEGIN
	
	---------------------------------------
	-- СБРОСИТЬ СТАТИСТИКУ 
	TRUNCATE TABLE test_statistics CASCADE ;
	-- СБРОСИТЬ СТАТИСТИКУ 
	---------------------------------------

    IF new_test_db IS NOT NULL 
	THEN
		INSERT INTO test_statistics ( current_mode , test_started , pass_counter , test_db ) VALUES ( new_mode , CURRENT_TIMESTAMP  , 0  , new_test_db ) ;		
	ELSE
		RAISE EXCEPTION ' TECT_DB MUST BE SET !' ;
		return 100;
	END IF ;
	
  return 0 ; 
END
$$ LANGUAGE plpgsql;

--Получить id текущего теста
CREATE OR REPLACE FUNCTION get_current_test_id() RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
BEGIN
    SELECT MAX(test_id)
	INTO current_test_id
	FROM test_statistics ; 

/*	
	IF current_test_id IS NULL 
	THEN 
		RAISE EXCEPTION ' НЕТ НАЧАТЫХ ТЕСТОВ !' ;
	END IF;
*/	
	return current_test_id ; 

END
$$ LANGUAGE plpgsql;													


--Получить id тестового прохода
CREATE OR REPLACE FUNCTION get_current_test_pass_id() RETURNS integer AS $$
DECLARE    
  curr_id bigint ;    
  current_test_id bigint;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	  
	SELECT MAX(id) 
	INTO curr_id
	FROM test_statistics_pass WHERE current_test_id = test_id;
	
	IF curr_id IS NULL 
	THEN 
		RAISE EXCEPTION ' НЕТ НАЧАТЫХ ПРОХОДОВ ДЛЯ ТЕКУЩЕГО ТЕСТА !' ;
	END IF;
	
	return curr_id ;
END
$$ LANGUAGE plpgsql;													

--Получить режим работы теста
CREATE OR REPLACE FUNCTION get_test_mode() RETURNS text AS $$
DECLARE 
  current_test_id bigint; 
  current_test_mode text;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

	SELECT current_mode
	INTO current_test_mode 
	FROM test_statistics
	WHERE test_id = current_test_id;
	
	return current_test_mode ; 
END
$$ LANGUAGE plpgsql;

--Текущий проход
CREATE OR REPLACE FUNCTION  current_pass() RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
  current_pass_counter bigint ; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT pass_counter
	INTO current_pass_counter
	FROM test_statistics
	WHERE test_id =  current_test_id;
	
  return current_pass_counter ; 
END
$$ LANGUAGE plpgsql;

/************************************************************************************************************************/
--Начать собирать данные для статистики для текущей фазы теста
-- Перенесено в start_collect_data.sql
-- start_collect_data() RETURNS integer
/************************************************************************************************************************/

/************************************************************************************************************************/
--Завершить сбор данных для статистики для текущей фазы теста
-- перенесено в stop_collect_data.sql
--stop_collect_data() RETURNS integer
/************************************************************************************************************************/

/************************************************************************************************************************/
-- ПЕРЕНЕСЕНО В pass_statistics_report.sql
--Статистические показатели производительности теста
--CREATE OR REPLACE FUNCTION stats_for_pass() RETURNS text AS $$
-- ПЕРЕНЕСЕНО В pass_statistics_report.sql
/************************************************************************************************************************/



-- Установить длительность нагрузки 
CREATE OR REPLACE FUNCTION set_test_duration( new_duration bigint ) RETURNS integer AS $$
DECLARE
  result_code bigint ;
  current_test_id bigint ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

  
  UPDATE test_statistics SET test_duration = new_duration WHERE test_id = current_test_id ; 
  
  return 0 ; 
END
$$ LANGUAGE plpgsql;


-- установить нагрузку  - low / high / highload /custom
CREATE OR REPLACE FUNCTION set_load_mode( new_mode bigint  ) RETURNS integer AS $$
DECLARE
  curr_test_mode text ; 
  stress_test_statistics_rec record ;
 current_test_id bigint ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT get_test_mode() 
	INTO curr_test_mode ; 
	
    IF curr_test_mode = 'STRESS' OR curr_test_mode = 'BENCHMARK'
	THEN
		-----------------------------------------------------------------------------------------------
		-- connections_inc = относительное приращение в % на каждой итерации
		-----------------------------------------------------------------------------------------------
		CASE 
			WHEN new_mode = 0 THEN UPDATE  test_statistics SET base_load_connections = 2 , load_mode = 0  , connections_inc = 1   WHERE test_id = current_test_id;
			WHEN new_mode = 1 THEN UPDATE  test_statistics SET base_load_connections = 50 , load_mode = 1  , connections_inc = 5 WHERE test_id = current_test_id;
			WHEN new_mode = 2 THEN UPDATE  test_statistics SET base_load_connections = 100 , load_mode = 2  , connections_inc = 10 WHERE test_id = current_test_id;
			WHEN new_mode = 3 THEN UPDATE  test_statistics SET load_mode = 3   WHERE test_id = current_test_id;
			--WHEN new_mode = 4 THEN UPDATE  test_statistics SET base_load_connections = 2 , load_mode = 4  , connections_inc = 10 WHERE test_id = current_test_id;
			--3.0
			--WHEN new_mode = 4 THEN UPDATE  test_statistics SET base_load_connections = 5 , load_mode = 4  , connections_inc = 20 WHERE test_id = current_test_id;			
			--3.0
			--50.0
			WHEN new_mode = 4 THEN UPDATE  test_statistics SET load_mode = 4  , connections_inc = 20 WHERE test_id = current_test_id;
			--50.0
			ELSE RAISE EXCEPTION ' НЕКОРРЕКТНЫЙ РЕЖИМ ТЕСТА = % ', new_mode  ; -- Ошибка режима
		END CASE ; 
	END IF ;
	
	IF curr_test_mode = 'DESCENT'
	THEN 
		UPDATE  test_statistics SET base_load_connections = 5 , load_mode = 4   WHERE test_id = current_test_id;		
	END IF ;
  
  return 0 ; 
END
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION get_load_mode() RETURNS integer AS $$
DECLARE
  current_test_id bigint ;
  current_mode bigint ; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT load_mode
	INTO current_mode
	FROM test_statistics
	WHERE test_id = current_test_id ; 
	
	return current_mode; 
END
$$ LANGUAGE plpgsql;

-- get_load_mode( new_mode bigint  ) RETURNS integer										Получить текущий режим нагрузки  0 (low) / 1 (high) / 2 (highload) / 3 (custom)

--Установить количество подключения для pgbench в режиме custom
CREATE OR REPLACE FUNCTION set_custom_base_load_connections( new_base_load_connections bigint  ) RETURNS integer AS $$
DECLARE
 current_test_id bigint ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

  
  UPDATE  test_statistics SET base_load_connections = new_base_load_connections   WHERE test_id = current_test_id;
  
  return 0 ; 
END
$$ LANGUAGE plpgsql;

--Установить инкремент подключений для pgbench в режиме custom
CREATE OR REPLACE FUNCTION set_custom_base_load_increment( new_increment bigint  ) RETURNS integer AS $$
DECLARE
 current_test_id bigint ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

  
  UPDATE  test_statistics SET connections_inc = new_increment   WHERE test_id = current_test_id;
  
  return 0 ; 
END
$$ LANGUAGE plpgsql;

--Базовое количество подключений для инициализации pgbench
CREATE OR REPLACE FUNCTION get_base_load() RETURNS integer
AS $$
DECLARE
 current_test_id bigint ;
 current_base_load_connections bigint ; 
 test_statistics_rec record ;
BEGIN
  SELECT get_current_test_id()
  INTO current_test_id;
  
  SELECT *
  INTO test_statistics_rec
  FROM test_statistics 
  WHERE test_id = current_test_id;
  
  ------------------------------------
  -- ЕСЛИ РЕЖИМ РАБОТЫ НЕ STANDARD
  IF test_statistics_rec.load_mode != 4
  THEN 
	return 	test_statistics_rec.base_load_connections ;
  ELSE
  ------------------------------------
  -- STANDARD
	return  20 ; 
  END IF ;
  
END
$$ LANGUAGE plpgsql;
  
--Установить текущую нагрузку connections
CREATE OR REPLACE FUNCTION set_load() RETURNS integer AS $$
DECLARE
 current_test_id integer ;
 curr_id integer ; 
 test_statistics_rec record ; 
 test_statistics_pass_rec record ; 
 prev_test_statistics_pass_rec record ; 
 current_load_connections DOUBLE PRECISION ;
 result_load_connections integer  ;
 has_the_first_hour_passed integer ; 
 current_test_pass_id integer ; 
BEGIN
  SELECT get_current_test_id()
  INTO current_test_id;

  SELECT *
  INTO test_statistics_rec
  FROM test_statistics 
  WHERE test_id = current_test_id;
  
  SELECT get_current_test_pass_id()
  INTO current_test_pass_id ; 
  
  SELECT * 
  INTO test_statistics_pass_rec
  FROM test_statistics_pass
  WHERE id = current_test_pass_id ; 
  

  IF test_statistics_rec.current_mode = 'BENCHMARK' 
  THEN 
    return test_statistics_rec.base_load_connections ;
  END IF ;
  
  
  IF test_statistics_rec.current_mode = 'DESCENT' 
  THEN 	
    return test_statistics_rec.base_load_connections ;
  END IF ;

  ---------------------------------------------------------------------------------------------------
  -- STRESS 
  ---------------------------------------------------------------------
	-- РОСТ НАГРУЗКИ НАЧИНАЕТСЯ СО ВТОРОГО ЧАСА 
	SELECT has_the_first_hour_passed()
	INTO has_the_first_hour_passed ; 
		
	IF has_the_first_hour_passed = 0 
	THEN 
		UPDATE test_statistics_pass
		SET load_connections = test_statistics_rec.base_load_connections
		WHERE test_id = current_test_id AND pass_counter = test_statistics_rec.pass_counter; 
	
		return test_statistics_rec.base_load_connections ;
	END IF ;
	-- РОСТ НАГРУЗКИ НАЧИНАЕТСЯ СО ВТОРОГО ЧАСА 
	---------------------------------------------------------------------
    
	
	current_load_connections  = power( 1.6::numeric , (test_statistics_rec.pass_counter::numeric - test_statistics_rec.base_load_connections::numeric )/2.0 )*1.6 + test_statistics_rec.base_load_connections::numeric ; 
	SELECT CEIL( current_load_connections )
	INTO result_load_connections ;  
	
	UPDATE 
		test_statistics_pass 
	SET 
		load_connections = current_load_connections
	WHERE  
		test_id = current_test_id AND 
		pass_counter = test_statistics_rec.pass_counter ;


	return result_load_connections  ;
/*	
	----------------------------------
    -- ПРЕДЫДУЩИЙ ПРОХОД
    SELECT * 
    INTO   prev_test_statistics_pass_rec
    FROM   test_statistics_pass 
    WHERE  test_id = current_test_id AND 
		 pass_counter = test_statistics_rec.pass_counter - 1 ;
    -- ПРЕДЫДУЩИЙ ПРОХОД
    ----------------------------------
    
	current_load_connections  =  prev_test_statistics_pass_rec.load_connections + (prev_test_statistics_pass_rec.load_connections * (test_statistics_rec.connections_inc / 100.0) ) ;

	UPDATE 
		test_statistics_pass 
	SET 
		load_connections = current_load_connections
	WHERE  
		test_id = current_test_id AND 
		pass_counter = test_statistics_rec.pass_counter ;

	SELECT CEIL( current_load_connections )
	INTO result_load_connections ;  
	
	return result_load_connections  ;
  -- STRESS
  ---------------------------------------------------------------------------------------------------
*/  
END
$$ LANGUAGE plpgsql;

-- get_load() RETURNS integer 														    	Текущее количество подключений для pgbench
CREATE OR REPLACE FUNCTION get_load() RETURNS integer AS $$
DECLARE
 current_test_id integer ;
 curr_id integer ; 
 test_statistics_rec record ; 
 test_statistics_pass_rec record ; 
 prev_test_statistics_pass_rec record ; 
 current_load_connections DOUBLE PRECISION ;
 result_load_connections integer  ;
 has_the_first_hour_passed integer ; 
 current_test_pass_id integer ; 
BEGIN
  SELECT get_current_test_id()
  INTO current_test_id;

  SELECT *
  INTO test_statistics_rec
  FROM test_statistics 
  WHERE test_id = current_test_id;
  
  SELECT get_current_test_pass_id()
  INTO current_test_pass_id ; 
  
  SELECT * 
  INTO test_statistics_pass_rec
  FROM test_statistics_pass
  WHERE id = current_test_pass_id ; 
  

  return test_statistics_pass_rec.load_connections ; 
END
$$ LANGUAGE plpgsql;

--Установить статус возможности окончания теста 	
CREATE OR REPLACE FUNCTION set_test_status( new_status integer  ) RETURNS integer AS $$
DECLARE
  current_test_id integer ;
  test_statistics_rec record ; 
BEGIN
  SELECT get_current_test_id()
  INTO current_test_id;

  UPDATE test_statistics 
  SET test_status = new_status
  WHERE test_id = current_test_id;
  
  return 0 ; 
END
$$ LANGUAGE plpgsql;

--Получить статус возможности окончания теста 	
CREATE OR REPLACE FUNCTION get_test_status() RETURNS integer AS $$
DECLARE
  current_test_id integer ;
  current_test_status integer  ; 
BEGIN
  SELECT get_current_test_id()
  INTO current_test_id;

  SELECT test_status
  INTO current_test_status
  FROM test_statistics   
  WHERE test_id = current_test_id;
  
  return current_test_status ; 
END
$$ LANGUAGE plpgsql;

/*******************************************************************************************/
-- ПЕРЕНЕСЕНО В IS_TEST_COULD_BE_FINISHED.SQL
-- Если тест может быть остановлен 
--CREATE OR REPLACE FUNCTION is_test_could_be_finished() RETURNS integer AS $$
-- ПЕРЕНЕСЕНО В IS_TEST_COULD_BE_FINISHED.SQL
/*******************************************************************************************/

/*******************************************************************************************/
-- ПЕРЕНЕСЕНО В CURRENT_STATISTICS_REPORT.SQL
-- Текущие показатели производительности  
--CREATE OR REPLACE FUNCTION stats_report() RETURNS text AS $$
-- ПЕРЕНЕСЕНО В CURRENT_STATISTICS_REPORT.SQL
/*******************************************************************************************/



-- Очистить  показатели производительности  
CREATE OR REPLACE FUNCTION clear_cpi_history() RETURNS integer AS $$
DECLARE
 min_timestamp timestamptz ; 
 max_timestamp timestamptz ;
BEGIN
  SELECT date_trunc( 'minute' , CURRENT_TIMESTAMP ) - interval '1 hour'
  INTO min_timestamp ; 
	
  SELECT date_trunc( 'minute' , CURRENT_TIMESTAMP ) 
  INTO max_timestamp ; 

  DELETE FROM stats_cpi WHERE curr_timestamp BETWEEN min_timestamp AND max_timestamp ; 
  
  return 0 ; 
END
$$ LANGUAGE plpgsql;

--Начало и окончание первого прохода
CREATE OR REPLACE FUNCTION first_pass_time() RETURNS text AS $$
DECLARE
 result_text text;
 curr_id bigint;  
 current_test_id bigint ;  
 test_statistics_pass_rec record ; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT MIN(id) 
	INTO curr_id 
	FROM test_statistics_pass
	WHERE test_id = current_test_id ; 
	
	
	SELECT start_timestamp , finish_timestamp 
	INTO test_statistics_pass_rec
	FROM test_statistics_pass
	WHERE id = curr_id ; 
	
    result_text = to_char( test_statistics_pass_rec.start_timestamp , 'YYYY-MM-DD HH24:MI') 
	              || ' | ' ||to_char( test_statistics_pass_rec.finish_timestamp , 'YYYY-MM-DD HH24:MI') 
				  || ' | ' ;
				  
  return result_text ; 
END
$$ LANGUAGE plpgsql;	 										    

--Начало и окончание последнего прохода
CREATE OR REPLACE FUNCTION last_pass_time() RETURNS text AS $$
DECLARE
 result_text text;
 curr_id bigint;  
 current_test_id bigint ;  
 test_statistics_pass_rec record ; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT MAX(id) 
	INTO curr_id 
	FROM test_statistics_pass
	WHERE test_id = current_test_id ; 
	
	
	SELECT start_timestamp , finish_timestamp 
	INTO test_statistics_pass_rec
	FROM test_statistics_pass
	WHERE id = curr_id ; 
	
    result_text = to_char( test_statistics_pass_rec.start_timestamp , 'YYYY-MM-DD HH24:MI') 
	              || ' | ' ||to_char( test_statistics_pass_rec.finish_timestamp , 'YYYY-MM-DD HH24:MI') 
				  || ' | ' ;
				  
  return result_text ; 	 										    
END
$$ LANGUAGE plpgsql;	 										    




--УВЕЛИЧИТЬ СЧЕТЧИК ИТЕРАЦИЙ
CREATE OR REPLACE FUNCTION increment_pass_counter() RETURNS integer AS $$				
DECLARE 
 current_test_id bigint; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	UPDATE test_statistics SET pass_counter = pass_counter + 1 WHERE test_id = current_test_id; 
	
  return 0 ; 
END
$$ LANGUAGE plpgsql;					

--ЕСЛИ идет первый час работы
CREATE OR REPLACE FUNCTION has_the_first_hour_passed() RETURNS integer  AS $$				
DECLARE 
  min_pass_start_time timestamptz ; 
  current_test_id bigint; 
  working_pass integer ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

 	SELECT MIN( start_timestamp ) 
	INTO min_pass_start_time
	FROM test_statistics_pass
	WHERE test_id = current_test_id ;
	
	---------------------------------
	-- ТЕКУЩИЙ ПРОХОД 
	SELECT current_pass()
	INTO working_pass ;
	-- ТЕКУЩИЙ ПРОХОД 
	---------------------------------

/*	
	-- TEST !!!!!!!!!!!!!!	
	IF working_pass > 2 
	THEN   
		return 1 ; 
	ELSE 
		return 0 ; 
	END IF;	
	-- TEST !!!!!!!!!!!!!!
*/	
	
	-- РАСЧЕТ ДОЛГИХ ЗНАЧЕНИЕ ПОСЛЕ ЧАСА 
	IF ( CURRENT_TIMESTAMP - min_pass_start_time ) >= interval '60 minute' 
	THEN   
		return 1 ; 
	ELSE 
		return 0 ; 
	END IF;


END
$$ LANGUAGE plpgsql;					

--Установить максимальное  количество подключений для pgbench
CREATE OR REPLACE FUNCTION set_max_load( new_max_load integer ) RETURNS integer AS $$				
DECLARE 
  current_test_id bigint; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

	UPDATE test_statistics
	SET max_load = new_max_load
    WHERE test_id = current_test_id ;	
	
	return 0 ; 
END
$$ LANGUAGE plpgsql;	

--Установить значимое изменение скорости в процентах														
CREATE OR REPLACE FUNCTION set_descent_pct( new_pct integer ) RETURNS integer AS $$				
DECLARE 
  current_test_id bigint; 
  new_descent_pct DOUBLE PRECISION;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

	UPDATE test_statistics
	SET descent_pct = new_pct
    WHERE test_id = current_test_id ;	
	
	return 0 ; 
END
$$ LANGUAGE plpgsql;	

--Получить значимое изменение скорости в процентах														
CREATE OR REPLACE FUNCTION get_descent_pct() RETURNS integer AS $$				
DECLARE 
  current_test_id bigint; 
  new_descent_pct integer;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;

	SELECT descent_pct
	INTO new_descent_pct
	FROM test_statistics
    WHERE test_id = current_test_id ;	
	
	return new_descent_pct ; 
END
$$ LANGUAGE plpgsql;	


--queryid тестового запроса
CREATE OR REPLACE FUNCTION get_test_queryid() RETURNS bigint AS $$
DECLARE 
 curr_queryid bigint ; 
 current_test_id bigint; 
 current_scenario integer;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT get_scenario()
	INTO current_scenario;

    IF current_test_id IS NULL 
	THEN 
		return 0 ;
	END IF ;
	
	SELECT test_queryid
	INTO curr_queryid
	FROM test_statistics
	WHERE test_id = current_test_id ; 
	
	IF curr_queryid IS NULL 
	THEN 
		IF  current_scenario = 1 OR 
			current_scenario = 2 OR 
			current_scenario = 3 OR 
			current_scenario = 4 OR 
		THEN 
			SELECT queryid 
			INTO curr_queryid
			FROM pgpro_stats_statements 
			WHERE query like 'select custom_test%';	
		END IF ;
		
		IF  current_scenario = 100
		THEN 
			SELECT queryid 
			INTO curr_queryid
			FROM pgpro_stats_statements 
			WHERE query like 'select customized_test%';	
		END IF ;
		
		
		UPDATE test_statistics
		SET test_queryid = curr_queryid
		WHERE test_id = current_test_id ; 

		
	END IF ;

	return curr_queryid ;
END
$$ LANGUAGE plpgsql ;

--Зафиксировать время начала теста 
CREATE OR REPLACE FUNCTION start_test() RETURNS integer AS $$
DECLARE 
 current_test_id bigint; 
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	UPDATE test_statistics
	SET test_started = CURRENT_TIMESTAMP
	WHERE test_id = current_test_id ; 
	
	return 0 ;
END
$$ LANGUAGE plpgsql ;

--Зафиксировать время окончания теста 
CREATE OR REPLACE FUNCTION stop_test() RETURNS integer AS $$
DECLARE 
 current_test_id bigint; 
 test_statistics_rec record ; 
 current_dbid_userid_rec  record  ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	UPDATE test_statistics
	SET test_finished = CURRENT_TIMESTAMP
	WHERE test_id = current_test_id ; 
	
	SELECT * 
	INTO test_statistics_rec
	FROM test_statistics
	WHERE test_id = current_test_id ; 
/*	
	--------------------------------------------------------------------
	--УДАЛИТЬ ТЕСТОВУЮ БД ИЗ МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--  PERFORM remove_db_for_performance_monitoring( test_statistics_rec.test_db );
	--УДАЛИТЬ ТЕСТОВУЮ БД ИЗ МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--------------------------------------------------------------------	
	
	--------------------------------------------------------------------
	--УДАЛИТЬ ТЕСТОВЫЙ SQL ИЗ МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	FOR current_dbid_userid_rec IN 
	SELECT dbid , userid 
	FROM pgpro_stats_statements
	WHERE queryid = test_statistics_rec.test_queryid 
	LOOP 
	  PERFORM remove_statement_for_performance_monitoring( current_dbid_userid_rec.dbid , current_dbid_userid_rec.userid , test_statistics_rec.test_queryid );
	END LOOP;	
	--УДАЛИТЬ ТЕСТОВЫЙ SQL ИЗ МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--------------------------------------------------------------------
*/
	return 0 ;
END
$$ LANGUAGE plpgsql ;

-- Получить время начала теста 
CREATE OR REPLACE FUNCTION get_start_timestamp() RETURNS text AS $$
DECLARE 
 current_test_id bigint; 
 current_start_timestamp text ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT to_char( date_trunc('minute' , test_started ) , 'YYYY-MM-DD HH24:MI' )
	INTO current_start_timestamp
	FROM test_statistics
	WHERE test_id = current_test_id ; 
	
	return  current_start_timestamp;
END
$$ LANGUAGE plpgsql ;


-- Получить время окончания теста 
CREATE OR REPLACE FUNCTION get_finish_timestamp() RETURNS text AS $$
DECLARE 
 current_test_id bigint; 
 current_finish_timestamp text ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT to_char( date_trunc('minute' , test_finished ) , 'YYYY-MM-DD HH24:MI' )
	INTO current_finish_timestamp
	FROM test_statistics
	WHERE test_id = current_test_id ; 
	
	return  current_finish_timestamp;
END
$$ LANGUAGE plpgsql ;


--Добавить тестовую БД и SQL в мониторинг произвоительности
CREATE OR REPLACE FUNCTION start_performance_monitoring() RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
  test_statistics_rec	RECORD ; 
  current_dbid_userid_rec  record  ;
  current_test_queryid bigint ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT get_test_queryid()
	INTO current_test_queryid ;
	
	SELECT * 
	INTO test_statistics_rec
	FROM test_statistics
	WHERE test_id = current_test_id ; 

RAISE NOTICE 'test_statistics_rec.test_db = % ' , test_statistics_rec.test_db ; 	
RAISE NOTICE 'test_statistics_rec.test_queryid = % ' , test_statistics_rec.test_queryid ; 	
	
	--------------------------------------------------------------------
	--ДОБАВИТЬ ТЕСТОВУЮ БД  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	  PERFORM add_db_for_performance_monitoring( test_statistics_rec.test_db );
	--ДОБАВИТЬ ТЕСТОВУЮ БД  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--------------------------------------------------------------------	
	
	--------------------------------------------------------------------
	--ДОБАВИТЬ ТЕСТОВЫЙ SQL  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	FOR current_dbid_userid_rec IN 
	SELECT dbid , userid 
	FROM pgpro_stats_statements
	WHERE queryid = test_statistics_rec.test_queryid 
	LOOP 
	  PERFORM add_statement_for_performance_monitoring( current_dbid_userid_rec.dbid , current_dbid_userid_rec.userid , test_statistics_rec.test_queryid );
	END LOOP;
	--ДОБАВИТЬ ТЕСТОВЫЙ SQL  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--------------------------------------------------------------------
RETURN 0 ; 
END
$$ LANGUAGE plpgsql;


--Удалить тестовую БД и SQL в мониторинг произвоительности
CREATE OR REPLACE FUNCTION finish_performance_monitoring() RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
  test_statistics_rec	RECORD ; 
  
  current_dbid_userid_rec  record  ;
  
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT * 
	INTO test_statistics_rec
	FROM test_statistics
	WHERE test_id = current_test_id ; 

RAISE NOTICE 'test_statistics_rec.test_db = % ' , test_statistics_rec.test_db ; 	
RAISE NOTICE 'test_statistics_rec.test_queryid = % ' , test_statistics_rec.test_queryid ; 	
	
	--------------------------------------------------------------------
	--УДАЛИТЬ ТЕСТОВУЮ БД  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	  PERFORM remove_db_for_performance_monitoring( test_statistics_rec.test_db );
	--УДАЛИТЬ ТЕСТОВУЮ БД  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--------------------------------------------------------------------	
	
	--------------------------------------------------------------------
	--УДАЛИТЬ ТЕСТОВЫЙ SQL  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	FOR current_dbid_userid_rec IN 
	SELECT dbid , userid 
	FROM pgpro_stats_statements
	WHERE queryid = test_statistics_rec.test_queryid 
	LOOP 
	  PERFORM remove_statement_for_performance_monitoring( current_dbid_userid_rec.dbid , current_dbid_userid_rec.userid , test_statistics_rec.test_queryid );
	END LOOP;
	--УДАЛИТЬ ТЕСТОВЫЙ SQL  МОНИТОРИНГ ПРОИЗВОДИТЕЛЬНОСТИ 
	--------------------------------------------------------------------
RETURN 0 ; 
END
$$ LANGUAGE plpgsql;

--Добавить снимок pgpro_pwr

CREATE OR REPLACE FUNCTION add_pgpro_pwr_sample( new_pgpro_pwr_sample text ) RETURNS integer AS $$
DECLARE 
  current_test_pass_id bigint;  
BEGIN
    SELECT get_current_test_pass_id()
	INTO current_test_pass_id;

	UPDATE test_statistics_pass
	SET pgpro_pwr_snapshot = new_pgpro_pwr_sample
	WHERE id = current_test_pass_id ;

RETURN 0 ; 
END
$$ LANGUAGE plpgsql; 


-- Текущее количество подключений для pgbench для заданного сценария
CREATE OR REPLACE FUNCTION get_load_by_scenario( current_scenario integer ) RETURNS integer AS $$
DECLARE 
  total_load integer ;
  result_load integer ;
  current_load_connections DOUBLE PRECISION ;
BEGIN
-------------------------------------------
-- Текущий сценарий 
-- сценарий 1 - select only    : 50%
-- сценарий 2 - select + update: 30%
-- сценарий 3 - insert only    : 15%
-- сценарий 4 - CPU load       : 5%
-------------------------------------------

 SELECT get_load()
 INTO total_load ; 
 
 CASE 
	WHEN current_scenario = 1 THEN current_load_connections = total_load::DOUBLE PRECISION * 0.5 ;
	WHEN current_scenario = 2 THEN current_load_connections = total_load::DOUBLE PRECISION * 0.3 ;
	WHEN current_scenario = 3 THEN current_load_connections = total_load::DOUBLE PRECISION * 0.15 ;
	WHEN current_scenario = 4 THEN current_load_connections = total_load::DOUBLE PRECISION * 0.05 ;
 END CASE ;
 
 SELECT CEIL( current_load_connections )
 INTO result_load ;
  
RETURN result_load; 
END
$$ LANGUAGE plpgsql; 


-- get_test_queryid_for_scenario( int current_scenario) RETURNS bigint						queryid тестового запроса для сценария
CREATE OR REPLACE FUNCTION get_test_queryid_for_scenario( current_scenario integer ) RETURNS bigint AS $$
DECLARE 
  current_queryid bigint;
BEGIN
	CASE 
	WHEN current_scenario = 1 THEN 
		SELECT 
			queryid
		INTO 
			current_queryid
		FROM  
			pgpro_stats_statements 
		WHERE 
			query like 'select mix_custom_test1%';
	WHEN current_scenario = 2 THEN 
		SELECT 
			queryid
		INTO 
			current_queryid
		FROM 
			pgpro_stats_statements 
		WHERE 
			query like 'select mix_custom_test2%';
	WHEN current_scenario = 3 THEN 
		SELECT 
			queryid
		INTO 
			current_queryid
		FROM 
			pgpro_stats_statements 
		WHERE 
			query like 'select mix_custom_test3%';
	WHEN current_scenario = 4 THEN 
		SELECT 
			queryid
		INTO 
			current_queryid
		FROM 
			pgpro_stats_statements 
		WHERE 
			query like 'select mix_custom_test4%';
	
 END CASE ;
 
 IF current_queryid IS NULL 
 THEN 
	current_queryid = 0 ;
 END IF;
  
RETURN current_queryid; 
END
$$ LANGUAGE plpgsql; 



-- set_scenario( new_scenario integer  ) RETURNS integer
CREATE OR REPLACE FUNCTION set_scenario( new_scenario integer  )  RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	UPDATE test_statistics
	SET current_scenario= new_scenario ; 
	
RETURN 0 ;
END
$$ LANGUAGE plpgsql; 

-- get_scenario() RETURNS integer
CREATE OR REPLACE FUNCTION get_scenario()  RETURNS integer AS $$
DECLARE 
  current_test_id bigint;  
  curr_scenario integer ;
BEGIN
    SELECT get_current_test_id()
	INTO current_test_id;
	
	SELECT current_scenario
	INTO curr_scenario
	FROM test_statistics
	WHERE test_id = current_test_id ; 
	
RETURN curr_scenario ;
END
$$ LANGUAGE plpgsql; 

--Установить quaryid для сценария MIX
CREATE OR REPLACE FUNCTION set_scenario_queryid_for_mix() RETURNS integer  AS $$
DECLARE 
 queryid_count integer ;
 timepoint timestamptz ; 

 result_str text ;
 
 benchmark_queries_rec record ;
 stat_timer_calc_statistics_res integer ;
 
 current_scenario integer ;
 
 curr_scenario_queryid bigint ; 
 scenario_sql text ;
 current_test_id integer;
BEGIN
	SELECT get_scenario()
	INTO current_scenario;
	
	SELECT get_current_test_id()
	INTO current_test_id ;
	
	-------------------------------------------------------------------
	-- MIX 
	IF current_scenario = 5
	THEN 
		SELECT scenario_1_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
			
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_1_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mix_custom_test1%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_1_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_1_QUERYID
			-------------------------------------------------------
		END IF;
			
		SELECT scenario_2_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_2_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mix_custom_test2%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_2_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_2_QUERYID
			-------------------------------------------------------
		END IF;

		SELECT scenario_3_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			--SCENARIO_3_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mix_custom_test3%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_3_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_3_QUERYID
			-------------------------------------------------------
		END IF ;
			
		SELECT scenario_4_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_4_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mix_custom_test4%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_4_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_4_QUERYID
			-------------------------------------------------------
		END IF;
	END IF ;
	-- MIX 
	-------------------------------------------------------------------

	-------------------------------------------------------------------
	-- MIX WITHOUT MEDIAN TIME 
	IF current_scenario = 6
	THEN 
		SELECT get_current_test_id()
		INTO current_test_id ;
			
			
		SELECT scenario_1_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_1_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test1%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_1_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_1_QUERYID
			-------------------------------------------------------
		END IF;
		
		SELECT scenario_2_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_2_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test2%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_2_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_2_QUERYID
			-------------------------------------------------------
		END IF;

		SELECT scenario_3_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			--SCENARIO_3_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test3%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_3_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_3_QUERYID
			-------------------------------------------------------
		END IF ;
		
		SELECT scenario_4_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_4_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test4%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_4_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_4_QUERYID
			-------------------------------------------------------
		END IF;
		
	END IF ;
	-- MIX WITHOUT MEDIAN TIME 
	-------------------------------------------------------------------
	
	-------------------------------------------------------------------
	-- MIX WITHOUT MEDIAN TIME  WITHOUT CPU LOAD
	IF current_scenario = 7
	THEN 
		SELECT get_current_test_id()
		INTO current_test_id ;
			
			
		SELECT scenario_1_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_1_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test1%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_1_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_1_QUERYID
			-------------------------------------------------------
		END IF;
		
		SELECT scenario_2_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			-------------------------------------------------------
			--SCENARIO_2_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test2%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_2_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_2_QUERYID
			-------------------------------------------------------
		END IF;

		SELECT scenario_3_queryid
		INTO curr_scenario_queryid
		FROM test_statistics ;
		
		IF curr_scenario_queryid IS NULL 
		THEN 
			--SCENARIO_3_QUERYID
			SELECT 
				queryid
			INTO 
				curr_scenario_queryid
			FROM 
				pgpro_stats_statements
			WHERE 
				query like 'select mixwmt_custom_test3%' ;
					
			UPDATE 	
				test_statistics
			SET
				scenario_3_queryid = curr_scenario_queryid
			WHERE 
				test_id = current_test_id;
			--SCENARIO_3_QUERYID
			-------------------------------------------------------
		END IF ;			
	END IF ;
	-- MIX WITHOUT MEDIAN TIME  WITHOUT CPU LOAD
	-------------------------------------------------------------------

 RETURN 0 ; 

END
$$ LANGUAGE plpgsql ;


--54.0----------------------------------------------------------------------------------------------------------------
-- RESERVED FOR FUTURE
-- get_test_id_by_timestamp() RETURNS integer 
CREATE OR REPLACE FUNCTION get_test_id_by_timestamp( start_timestamp_text text , finish_timestamp_text text  )  RETURNS bigint AS $$
DECLARE 
  current_test_id bigint;  
  current_start_timestamp timestamp with time zone ;
  current_finish_timestamp timestamp with time zone ;
  
BEGIN
	SELECT 
		to_timestamp( start_timestamp_text, 'YYYY-MM-DD HH24:MI')
	INTO 
		current_start_timestamp ;
	
	SELECT 
		to_timestamp( finish_timestamp_text, 'YYYY-MM-DD HH24:MI')
	INTO 
		current_finish_timestamp;
  
	SELECT 
		test_id 
	INTO 
		current_test_id
	FROM 
		test_statistics_pass
	WHERE 
		start_timestamp BETWEEN current_start_timestamp AND current_finish_timestamp ; 
		
	IF current_test_id IS NULL 
	THEN 
		current_test_id = 0 ; 
	END IF ;
	
RETURN current_test_id ;
END
$$ LANGUAGE plpgsql; 

-- get_scenario_queryid( current_scenario int) bigint --получить queryid
CREATE OR REPLACE FUNCTION get_scenario_queryid( current_test_id integer , current_scenario integer )  RETURNS bigint AS $$
DECLARE   
  curr_scenario_queryid  bigint ;
BEGIN
    
	CASE
		WHEN current_scenario = 1 THEN 
			SELECT 
				scenario_1_queryid
			INTO 
				curr_scenario_queryid
			FROM 
				test_statistics
			WHERE 
				test_id = current_test_id ;
				
		WHEN current_scenario = 2 THEN 
			SELECT 
				scenario_2_queryid
			INTO 
				curr_scenario_queryid
			FROM 
				test_statistics
			WHERE 
				test_id = current_test_id ;

		WHEN current_scenario = 3 THEN 
			SELECT 
				scenario_3_queryid
			INTO 
				curr_scenario_queryid
			FROM 
				test_statistics
			WHERE 
				test_id = current_test_id ;
				
		WHEN current_scenario = 4 THEN 
			SELECT 
				scenario_4_queryid
			INTO 
				curr_scenario_queryid
			FROM 
				test_statistics
			WHERE 
				test_id = current_test_id ;
				
	END CASE ;
	
RETURN curr_scenario_queryid ;
END
$$ LANGUAGE plpgsql; 
-- RESERVED FOR FUTURE
--54.0----------------------------------------------------------------------------------------------------------------

--
CREATE OR REPLACE FUNCTION is_timestamp_exists( test_timestamp text )  RETURNS integer AS $$
DECLARE   
  res  integer  ;
  test_curr_timestamp timestamp with time zone ;
BEGIN

	test_curr_timestamp = to_timestamp( test_timestamp , 'YYYY-MM-DD HH24:MI' );
	
	SELECT count(*) 
	INTO res
	FROM pgh_stat_cluster_analysis
	WHERE curr_timestamp = test_curr_timestamp;
	
RETURN res ;
END
$$ LANGUAGE plpgsql; 

