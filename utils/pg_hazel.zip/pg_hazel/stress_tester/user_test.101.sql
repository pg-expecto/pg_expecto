﻿-- user_test.101.sql
-- 1trec-s-pg01n1
-- load-organizationstructure-service
-- version 5.0
CREATE OR REPLACE FUNCTION user_test101()  RETURNS integer AS $$
DECLARE
 test_rec record ;
 max_id  bigint ;
 current_id bigint ;
BEGIN

SELECT max(id) 
INTO max_id 
FROM "position" ;

SELECT ( random() * max_id ) 
INTO current_id ;

RAISE NOTICE 'max_id = % ', max_id ;
RAISE NOTICE 'current_id = % ', current_id ;

SELECT
  ectp."id",
  ectp."empCodeId",
  ectp."positionId",
  ectp."employeeGroupId",
  ectp."employmentPercentage",
  ectp."isMainHolder",
  ectp."positionEmployeeStatusId" AS "statusId",
  ectp."beginDate",
  ectp."endDate",
  ec."code",
  ec."email",
  ec."personId",
  date_part('year', age(person."birthDate")) as age,
  "person"."gender",
  "person"."firstName",
  "person"."middleName",
  "person"."lastName",
  "person"."phone" as "phone",
  "person"."photoFileUuid",
  "person"."thumbUuid",
  "position"."code" AS "positionCode",
  "position"."title" AS "positionTitle",
  "position"."balanceUnitId",
  "position"."employeeCategoryId" AS "employeeCategoryId",
  bu."title" AS "balanceUnitTitle",
  bu."code" AS "balanceUnitCode",
  "managerView"."managerId" AS "managerId",
  "managerView"."managerEmpCodeId" AS "managerEmpCodeId",
  divOU.id AS "orgUnitDivisionId",
  divOU.code AS "orgUnitDivisionCode",
  divOU.title AS "orgUnitDivisionTitle",
  compOU.id AS "orgUnitCompanyId",
  compOU.code "orgUnitCompanyCode",
  compOU.title "orgUnitCompanyTitle",
  ou.id AS "orgUnitId",
  ou.code AS "orgUnitCode",
  ou.title AS "orgUnitTitle"
INTO 
 test_rec
FROM
  "empCodeToPosition" AS ectp
  INNER JOIN "empCode" AS ec ON ec."id" = ectp."empCodeId"
  AND ec."isDeleted" = false
  INNER JOIN "person" ON "person"."id" = ec."personId"
  INNER JOIN "position" ON "position"."id" = ectp."positionId"
  AND "position"."isDeleted" = false
  LEFT JOIN "balanceUnit" AS bu ON bu."id" = "position"."balanceUnitId"
  INNER JOIN "structureLink" AS sl_ou ON sl_ou."structureLinkTypeId" = 2
  AND sl_ou."childNodeId" = "position"."id"
  INNER JOIN "ossObjectAttrValue" AS ooav ON ooav."objectType" = 'orgUnit'
  AND ooav."attr" = 'fullTree'
  AND ooav."objectId" = sl_ou."parentNodeId"
  LEFT JOIN "orgUnit" as divOU ON (ooav."value" -> 0 -> 'id') :: bigint = divOU."id"
  AND divOU."orgUnitTypeId" = 1
  AND divOU."isDeleted" = false
  LEFT JOIN "orgUnit" as compOU ON compOU."id" IN (
    (ooav."value" -> 1 -> 'id') :: bigint,
    (ooav."value" -> 0 -> 'id') :: bigint
  )
  AND compOU."orgUnitTypeId" = 2
  AND compOU."isDeleted" = false
  LEFT JOIN "orgUnit" ou ON ou."id" = sl_ou."parentNodeId"
  AND ou."isDeleted" = false
  LEFT JOIN public."employeeManagerView" as "managerView" ON ectp."id" = "managerView"."ectpId"
WHERE
  ectp."isDeleted" = false
  AND ectp."beginDate" < now()
  ---------------------------------------------------------
  -- сильно упрощенная конструкция без использования ORM 
  AND ectp."positionId" IN ( current_id ) -- Подстановка, ссылается на значение "empCodeToPosition"."positionId"
  -- сильно упрощенная конструкция без использования ORM 
  ---------------------------------------------------------
ORDER BY
  ectp."id" ASC ;

 return 0 ; 
END
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION user_test101() TO pgpropwr ; 

