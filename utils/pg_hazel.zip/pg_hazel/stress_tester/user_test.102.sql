﻿-- user_test.102.sql
-- 1trec-s-pg01n1
-- load-organizationstructure-service
-- version 5.0
CREATE OR REPLACE FUNCTION user_test102() RETURNS integer AS $$
DECLARE
 test_rec record ; 
 max_id  bigint ;
 current_id bigint ;
BEGIN

SELECT max(id) 
INTO max_id 
FROM "empCodeToPosition";

SELECT ( random() * max_id ) 
INTO current_id ;

RAISE NOTICE 'max_id = % ', max_id ;
RAISE NOTICE 'current_id = % ', current_id ;
  

  WITH RECURSIVE rcs(orgUnitId, "orgUnitTypeId") AS (
    SELECT
      eCARTOU."orgUnitId",
      o."orgUnitTypeId"
    FROM
      "empCodeAccessRoleToOrgUnit" eCARTOU
      JOIN "empCodeToRole" eCTR ON eCARTOU."empCodeToRoleId" = eCTR.id
      AND eCTR."endDateTime" >= NOW()
      JOIN "empCodeToPosition" eCTP ON eCTP."empCodeId" = eCTR."empCodeId"
      AND eCTP."isDeleted" = false
      JOIN "orgUnit" o ON o.id = eCARTOU."orgUnitId"
      AND o."isDeleted" = false
    WHERE
      eCTR."roleId" = 3
      AND eCTP.id = current_id -- Подстановка, ссылается на значение "empCodeToPosition"."id"
      AND eCARTOU."endDateTime" >= NOW()
    UNION
    ALL
    SELECT
      o.id,
      o."orgUnitTypeId"
    FROM
      rcs
      JOIN "structureLink" sl ON sl."childNodeId" = rcs.orgUnitId
      JOIN "structureLinkType" sLT ON sl."structureLinkTypeId" = sLT.id
      JOIN "orgUnit" o ON o.id = sl."parentNodeId"
      AND o."isDeleted" = false
    WHERE
      rcs."orgUnitTypeId" <> 1
      AND sLT.name = 'divisionalOrgUnitToOrgUnit'
  )
SELECT
  rcs.orgunitid AS id,
  oU.title AS title,
  oU.code AS "orgUnitCode"
INTO test_rec 
FROM
  rcs
  INNER JOIN "orgUnit" AS oU ON oU.id = rcs.orgunitid
  AND oU."isDeleted" = false
WHERE
  rcs."orgUnitTypeId" = 1
ORDER BY
  rcs.orgunitid;

 return 0 ; 
END
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION user_test102() TO pgpropwr ; 

