-- user_test.sql
-- version 5.0
CREATE OR REPLACE FUNCTION custom_test(  current_scenario integer ) RETURNS integer AS $$
DECLARE
 current_result integer ; 
BEGIN
-----------------------------------------------------------------
 -- СЦЕНАРИЙ 101
 IF current_scenario = 101
 THEN 
	SELECT user_test101() 
	INTO current_result ; 
 END IF ;
 -- СЦЕНАРИЙ 101
 ------------------------------------------------------------------

-----------------------------------------------------------------
 -- СЦЕНАРИЙ 102
 IF current_scenario = 102
 THEN 
	SELECT user_test102() 
	INTO current_result ; 
 END IF ;
 -- СЦЕНАРИЙ 101
 ------------------------------------------------------------------

 return 0 ; 
END
$$ LANGUAGE plpgsql;
GRANT EXECUTE ON FUNCTION custom_test(  current_scenario integer )  TO pgpropwr ; 

