#!/bin/sh
# vacuum_analyze.sh
# version 56.0
 
#Обработать код возврата 
function exit_code {
ecode=$1
if [[ $ecode != 0 ]];
then
	ecode=$1
	LOG_FILE=$2
	ERR_FILE=$3
	
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE
	echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : ERROR : Details in '$ERR_FILE >> $LOG_FILE
	
    exit $ecode
fi
}

script=$(readlink -f $0)
current_path=`dirname $script`

LOG_FILE=$current_path'/vacuum_analyze.log'
ERR_FILE=$current_path'/vacuum_analyze.err'


max_parallel_maintenance_workers=`psql  -Aqtc 'show max_parallel_maintenance_workers' 2>$ERR_FILE`
exit_code $? $LOG_FILE $ERR_FILE  
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : vacuum_analyze : OK : max_parallel_maintenance_workers =  '$max_parallel_maintenance_workers
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : vacuum_analyze : OK : max_parallel_maintenance_workers =  '$max_parallel_maintenance_workers >> $LOG_FILE

		
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : vacuum_analyze : OK : VACUUM ANALYZE STARTED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : vacuum_analyze : OK : VACUUM ANALYZE STARTED ' >> $LOG_FILE

psql -d test_pgbench_custom -c 'VACUUM ( PARALLEL '$max_parallel_maintenance_workers' ) ' & psql -d test_pgbench_custom -c 'ANALYZE'  >> $LOG_FILE 2>$ERR_FILE
wait

exit_code $? $LOG_FILE $ERR_FILE

echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : vacuum_analyze : OK : VACUUM ANALYZE FINISHED '
echo 'TIMESTAMP : '$(date "+%d-%m-%Y %H:%M:%S") ' : vacuum_analyze : OK : VACUUM ANALYZE FINISHED ' >> $LOG_FILE
		
exit 0
